//
//  CampRouterTests.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/24/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import XCTest
import Alamofire
import RxSwift


@testable import Campfiire

extension CampTests {
    
    func testFollow() {
        
        assyncAssert(){ exp in
            
            guard let camp = Camp(JSON: ["id" : 3]) else {
                XCTFail("Can't create user.")
                return
            }
            
            let followRout = CampRouter.follow(camp: camp)
            let unfollowRout = CampRouter.unfollow(camp: camp)
            
            assertCurentUserPresent(email: "email10@email.com", password: "password")
                .flatMap { _ in
                    return Alamofire.request(unfollowRout)
                        .rx_campfiireResponse(CampfiireResponse<Camp>.self)
                }
                .catchErrorJustReturn(Camp.fakeEntity())
                .flatMap { [unowned self] _ -> Observable<Camp> in
                    
                    self.request = Alamofire.request(followRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Camp>.self)
                    
                }.subscribe(onNext: { response in
                    
                    XCTAssertGreaterThan(response.id, 0, "id are expected to be filled")
                    XCTAssertNotEqual(response.title.lengthOfBytes(using: .utf8), 0, "title are expected to be filled")
                    XCTAssertNotNil(response.category, "category are expected to be filled")
                    XCTAssertTrue(response.isFollowedByCurrentUser, "We expect thet camp will like")
                    XCTAssertGreaterThan(response.followersCount, 0, "Since we followed it, there should be at least 1 follower")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    XCTFail(" Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }
    
    func testUnfollow() {
        
        assyncAssert(){ exp in
            
            guard let camp = Camp(JSON: ["id" : 3]) else {
                XCTFail("Can't create user.")
                return
            }
            
            let followRout = CampRouter.follow(camp: camp)
            let unfollowRout = CampRouter.unfollow(camp: camp)
            
            assertCurentUserPresent(email: "email10@email.com", password: "password")
                .flatMap { _ in
                    return Alamofire.request(followRout)
                        .rx_campfiireResponse(CampfiireResponse<Camp>.self)
                }
                .catchErrorJustReturn(Camp.fakeEntity())
                .flatMap{ user -> Observable<Camp> in
                    
                    self.request = Alamofire.request(unfollowRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Camp>.self)
                }.subscribe(onNext: { response in
                    
                    XCTAssertGreaterThan(response.id, 0, "id are expected to be filled")
                    XCTAssertNotEqual(response.title.lengthOfBytes(using: .utf8), 0, "title are expected to be filled")
                    XCTAssertNotNil(response.category, "category are expected to be filled")
                    XCTAssertFalse(response.isFollowedByCurrentUser, "We expect thet camp will not like")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    XCTFail("Request: \(self.request) returned error . Details - \(error)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }
    
    func testSearchCamps() {
        
        assyncAssert(){ exp in
            
            let batch = Batch(offset: 0, limit: 3)
            let searchRout = CampRouter.list(query: "Camper_Camper",
                                                    followedOnly: false,
                                                    batch: batch)
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[Camp]> in
                    
                    self.request = Alamofire.request(searchRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<Camp>.self)
                    
                }.subscribe(onNext: { (response) in
                    
                    XCTAssertLessThanOrEqual(response.count, 3, "We don't expect more than 3 camps")
                    
                    for item in response {
                        
                        XCTAssertGreaterThan(item.id, 0, "id are expected to be filled")
                        
                        XCTAssertNotEqual(item.title.lengthOfBytes(using: .utf8), 0, "title are expected to be filled")
                        
                        XCTAssertNotNil(item.category, "category are expected to be filled")
                        XCTAssertGreaterThan(item.lastActivityDate.timeIntervalSince1970, 0, "Last activity date must be filled")
                        
                        break
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Request: \(self.request) returned error . Details - \(error)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
        }
        
    }
    
}
