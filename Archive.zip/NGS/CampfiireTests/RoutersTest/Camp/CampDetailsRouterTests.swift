//
//  CampRouterTests.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/23/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import XCTest
import Alamofire
import RxSwift


@testable import Campfiire

class CampTests: XCTestCase {
    
    var camp = Camp.fakeEntity()
    var userLogIn : User?
    var request: DataRequest! = nil
    
    override func setUp() {
       super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testСreate() {
        
        assyncAssert(){ exp in
            
            var camp = Camp.fakeEntity()
            
            camp.populateDetails()
            let campRout = CampRouter.create (camp: camp)
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<Camp> in
                    
                    self.userLogIn = user
                    self.request = Alamofire.request(campRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Camp>.self)
                    
                }.subscribe(onNext: { (response) in
                    
                    XCTAssertGreaterThan(response.id, 0, "id are expected to be filled")
                    
                    XCTAssertNotEqual(response.title.lengthOfBytes(using: .utf8), 0, "title are expected to be filled")
                    XCTAssertNotNil(response.category, "category are expected to be filled")

                    guard let topic = response.topic else {
                        XCTFail("Topic are expected to be filled")
                        return;
                    }
                    
                    XCTAssertNotEqual(topic.text.lengthOfBytes(using: .utf8), 0, "Topic text is expected to be filled")
                    XCTAssertNotNil(topic.author, "We expect author to be present")
                    
                    XCTAssertEqual(self.userLogIn, topic.author, "User must be the same")
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
    
                }).addDisposableTo(rx_disposeBag)
        }
        
    }
    
    func testUpdate() {
        
        assyncAssert(){ exp in
            
            var camp = Camp.fakeEntity()
            camp.populateDetails()
            camp.id = 3
            camp.topic!.author = User.currentUser()
            
            let campRout = CampRouter.update(camp: camp)
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<Camp> in
                    
                    self.userLogIn = user
                    self.request = Alamofire.request(campRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Camp>.self)
                    
                }.subscribe(onNext: { (response) in
                    
                    XCTAssertEqual(response.id, camp.id, "id are expected to be same")
                    XCTAssertEqual(response.title, camp.title, "title are expected to be same")
                    XCTAssertEqual(response.category, camp.category, "category are expected to be same")
                    
                    guard let topic = response.topic,
                          let initialTopic = camp.topic else {
                        XCTFail("Topic are expected to be filled")
                        return;
                    }
                    
                    XCTAssertEqual(topic.text, initialTopic.text, "Topic texts are expected to match")
                    
                    XCTAssertEqual(self.userLogIn, topic.author, "User must be the same")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
        }
        
    }
    
    func testDelete() {
        
        assyncAssert(){ exp in
            
            var camp = Camp.fakeEntity()
            camp.populateDetails()
            let campRout = CampRouter.create (camp: camp)
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<Camp> in
                    
                    return Alamofire.request(campRout)
                        .rx_campfiireResponse(CampfiireResponse<Camp>.self)
                    
                }
                .flatMap { c -> Observable<[Camp]> in
                    
                    camp = c
                    
                    return Alamofire.request(CampRouter.list(query: nil,
                                                             followedOnly: false,
                                                             batch: Batch(offset: 0, limit: 1)))
                            .rx_campfiireResponse(CampfiireArrayResponse<Camp>.self)
                }
                .flatMap { list -> Observable<Void> in
                    
                    guard let first = list.first else {
                        return Observable.error( CampfiireError.generic(description: "Camp list does not start from newly created list") )
                    }
                    
                    XCTAssertEqual(first.id, camp.id, "First item must be the newly created camp")
                    
                    self.request = Alamofire.request(CampRouter.delete(camp: camp))
                    return self.request
                        .rx_campfiireResponse(CampfiireEmptyResponse.self)
                    
                }
                .flatMap { _ in
                    return Alamofire.request(CampRouter.details(camp: camp))
                        .rx_campfiireResponse(CampfiireResponse<Camp>.self)
                }
                .subscribe(onNext: { (response) in
                    
                    defer {
                        exp.fulfill()
                    }
                    
                    XCTFail("Camp with \(response.id) still exist. It should have been deleted")
                    
                }, onError: { error in
                    
                    guard let e = error as? CampfiireError else {
                        XCTFail("There was unhandled error - \(error)")
                        return
                    }
                    
                    switch e {
                        
                    case .businessError(let code, _):
                        XCTAssertEqual(code, CampfiireErrorStatusCode.objectWithIdNotFound.rawValue)
                    default:
                        XCTFail("This error have different type then CampfiireError.businessError - \(e)")
                    }
                    
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
        }
        
    }
    
    func testList(){
        
        assyncAssert() { exp in
            
            let campRout = CampRouter.list(query: nil,
                                           followedOnly: false,
                                           batch: Batch(offset: 0,limit: 5))
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[Camp]> in
                    
                    self.userLogIn = user
                    self.request = Alamofire.request(campRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<Camp>.self)
            
                }.subscribe(onNext: { (response) in
                    
                    XCTAssertLessThanOrEqual(response.count, 5, "We don't expect more than 5 camps")
                    
                    for item in response {
                        
                        XCTAssertGreaterThan(item.id, 0, "id are expected to be filled")
                        XCTAssertNotEqual(item.title.lengthOfBytes(using: .utf8), 0, "title are expected to be filled")
                        XCTAssertNotNil(item.category, "Category are expected to be filled. \(item)")
                        XCTAssertGreaterThan(item.lastActivityDate.timeIntervalSince1970, 0, "We expect last activity date to be filled")
                        
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Request: \(self.request) returned error . Details - \(error)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }
    
    func testDetails() {
        
        assyncAssert(){ exp in
            
            camp.id = 3
            let campRout = CampRouter.details(camp: camp)
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<Camp> in
                    
                    self.userLogIn = user
                    self.request = Alamofire.request(campRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Camp>.self)
                    
                }.subscribe(onNext: { (response) in
                    
                    XCTAssertGreaterThan(response.id, 0, "id are expected to be filled")
                    
                    XCTAssertNotEqual(response.title.lengthOfBytes(using: .utf8), 0, "title are expected to be filled")
                    
                    XCTAssertNotNil(response.category, "category are expected to be filled")
                    
                    guard let topic = response.topic else {
                        XCTFail("Topic are expected to be filled")
                        return;
                    }
                    
                    XCTAssertNotEqual(topic.text.lengthOfBytes(using: .utf8), 0, "Topic text is expected to be filled")
                    XCTAssertNotNil(topic.author, "We expect author to be present")
                    XCTAssertEqual(self.userLogIn, topic.author, "User must be the same")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
        }
        
    }
    
    func testDeteilsDeleted() {
        
        assyncAssert(){exp in
            
            let camp = Camp(JSON: ["id" : 999999])!
            
            assertCurentUserPresent()
                .flatMap { user -> Observable<HotSpot> in
                    
                    self.request = Alamofire.request(CampRouter.details(camp: camp))
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<HotSpot>.self)
                    
                }.subscribe(onNext: { _ in
                    
                    XCTFail("We should have received error. Camp does not exist")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    defer {
                        exp.fulfill()
                    }
                    
                    guard let e = error as? CampfiireError,
                        case .businessError(let code, _) = e,
                        code == CampfiireErrorStatusCode.objectWithIdNotFound.rawValue else {
                            
                            XCTFail("We expected error with custom business error code 400")
                            return
                            
                    }
                    
                    
                }).addDisposableTo(rx_disposeBag)
        }
        
    }

    
    func testFollowersList() {
        
        assyncAssert() { exp in
            
            camp.id = 1
            let campRout = CampRouter.selectFollowers(camp: camp)
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[User]> in
                    
                    self.userLogIn = user
                    self.request = Alamofire.request(campRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<User>.self)
                    
                }.subscribe(onNext: { (response) in
                    
                    for item in response {
                        
                        XCTAssertGreaterThan(item.id, 0, "id are expected to be filled")
                        
                        XCTAssertNotEqual(item.name.lengthOfBytes(using: .utf8), 0, "title are expected to be filled")
                        XCTAssertNotEqual(item.pictureURL.lengthOfBytes(using: .utf8), 0, "pictureURL are expected to be filled")
                        
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }
    
}

extension XCTestCase {
    
    public typealias GenericTest = (XCTestExpectation) -> Swift.Void
    
    public func assyncAssert ( generalizedTest : GenericTest) {
        
        let exp = expectation(description: "assyncAssert")
        
        generalizedTest(exp)
        
        waitForExpectations(timeout: 5) { error in
            XCTAssertNil(error, "Request timed out - \(error)")
        }
        
    }
    
    public func assertCurentUserPresent (email : String = "email17@email.com", password : String = "password") -> Observable<User> {
        
        guard let user = User.currentUser(),
              let _ = AccessToken.token,
              user.email == email else {

            return AuthorizationManager
                .loginWith(data: .credentials(email: email, password: password))
                .catchError{ error in
                    fatalError("\(error.localizedDescription)")
                }
                .map { $0.user! }

        }

        return Observable.just(user)
        
    }
        
}
