//
//  ReportingTests.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 2016-12-13.
//  Copyright © 2016 campfiire. All rights reserved.
//


import Foundation
import XCTest
import Alamofire
import RxSwift

@testable import Campfiire

extension ReportingTests {
    
    func testReportCamp() {
       
        var campFirst : Camp?
        
        assyncAssert(){ exp in
            
            let getCampsRouter = CampRouter.list(query: nil, followedOnly: false, batch: Batch(offset: 0,limit: 5))
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[Campfiire.Camp]> in
                    
                    self.currentUser = user
                    self.request = Alamofire.request(getCampsRouter)
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<Camp>.self)
                }.flatMap{ (camps : [Camp]) -> Observable<Report> in
                    
                    guard let camp = camps.first else {
                        return Observable.error(CampfiireError.generic(description: "Can't verify camp without any camps exisitng"))
                    }
                    
                    let campRouter = CampRouter.reportCamp(camp: camp)
                    campFirst = camps.first!
                    return Alamofire.request(campRouter)
                        .rx_campfiireResponse(CampfiireResponse<Campfiire.Report>.self)

                    
                 }.subscribe(onNext: { report in
                    
                    XCTAssertEqual(report.targetId, campFirst?.id, "We expect equal target Id and camp Id")
                    XCTAssertEqual(report.reporterId, self.currentUser?.id, "We expect equal reporter Id and user Id")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
        }
        
        
        
    }
    
    func testReportMessage() {
        var campFirst : Camp?
        var comment : Comment?
        assyncAssert(){ exp in
           
            let getCampsRouter = CampRouter.top(batch: nil)
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[Campfiire.Camp]> in
                    
                    self.currentUser = user
                    self.request = Alamofire.request(getCampsRouter)
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<Camp>.self)
                }.flatMap{ (camps : [Camp]) -> Observable<[Comment]> in
                    
                    guard let c = camps.first else {
                        return Observable.error(CampfiireError.generic(description: "Can't verify test without any camps available"))
                    }
                    campFirst = c
                    
                    let rout = CampRouter.commentsList(camp: campFirst!,
                                                       batch: Batch(offset: 0,limit: 5))
                    return Alamofire.request(rout)
                        .rx_campfiireResponse(CampfiireArrayResponse<Comment>.self)
                    
                }.flatMap{ (comments) ->  Observable<Report> in
                    guard let c = comments.first else {
                        return Observable.error(CampfiireError.generic(description: "Can't verify test without any comments available"))
                    }
                    comment = c
                    
                    let campRouter = CampRouter.reportMessage(comment: comment!)
                    return Alamofire.request(campRouter)
                        .rx_campfiireResponse(CampfiireResponse<Campfiire.Report>.self)
                    
                }.subscribe(onNext: { report in
                    
                    XCTAssertEqual(report.targetId, comment!.id, "We expect equal target Id and camp message Id")
                    XCTAssertEqual(report.reporterId, self.currentUser?.id, "We expect equal reporter Id and user Id")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
           
        }
        
    }
    
    
}


