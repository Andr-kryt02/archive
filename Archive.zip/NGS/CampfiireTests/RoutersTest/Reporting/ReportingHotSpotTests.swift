//
//  ReportingHotSpotTests.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 2016-12-13.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import XCTest
import Alamofire
import RxSwift
import MapKit
import CoreLocation

@testable import Campfiire

class ReportingTests: XCTestCase {
    
    var currentUser : User? = nil
    var request: DataRequest! = nil
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    
    func testReportHotSpot() {
        var hotspot : HotSpot?
        assyncAssert(){ exp in
            
            let initialRegion = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 0,longitude: 0),
                                               span: MKCoordinateSpan(latitudeDelta: 90,longitudeDelta: 180))
            
            
            let getHotSpots = HotspotRouter.map(georegion: (initialRegion.circularApproximation), query: nil, followedOnly: false)
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[Campfiire.HotSpot]> in
                    
                    self.currentUser = user
                    self.request = Alamofire.request(getHotSpots)
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<HotSpot>.self)
                }.flatMap{ (hotspots) -> Observable<Campfiire.Report> in
                    
                    hotspot = hotspots.first!
                    let hotSpotRouter = HotspotRouter.reportHotSpot(hotspot: hotspot!)
                    return Alamofire.request(hotSpotRouter)
                                .rx_campfiireResponse(CampfiireResponse<Campfiire.Report>.self)
                
                }.subscribe(onNext: { report in
                    print("************************")
                    print(report.targetId)
                    XCTAssertEqual(report.targetId, hotspot?.id, "We expect equal target Id and hotspot Id")
                    XCTAssertEqual(report.reporterId, self.currentUser?.id, "We expect equal reporter Id and user Id")
                    
                   exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
        }
        
        
        
    }
    
    
    
    func testReportHotSpotComment() {
        
        assyncAssert(){ exp in
            
            let getHotSpots = HotspotRouter.top(batch: nil)
            
            assertCurentUserPresent()
                
                .flatMap{ user -> Observable<[Campfiire.HotSpot]> in
                    
                    self.currentUser = user
                    self.request = Alamofire.request(getHotSpots)
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<HotSpot>.self)
                }.flatMap{ (hotspots) -> Observable<CommentListRepsonse> in
                    
                    guard let hotspot = hotspots.first else {
                        return Observable.error(CampfiireError.generic(description: "Can't report on comments in hotspots that do not exist. Please make sure at least one hotspot with comments exists"))
                    }
                    
                    self.request = Alamofire.request(HotspotRouter.commentsList(hotspot: hotspot,
                                                                                batch: Batch(offset: 0, limit: 1)))
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<CommentListRepsonse>.self)
                }.flatMap{ resp -> Observable<Campfiire.Report> in
                    
                    guard let comment = resp.comments.first else {
                        return Observable.error(CampfiireError.generic(description: "Can't report on comments that do not exist. Please make sure at least one comment exists"))
                    }
                    
                    let hotSpotRouter = HotspotRouter.reportHotSpotComment(comment: comment)
                    self.request = Alamofire.request(hotSpotRouter)
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Campfiire.Report>.self)
                    
                    
                }.subscribe(onNext: { report in
                    
                    XCTAssertEqual(report.reporterId, self.currentUser?.id, "We expect equal reporter Id and user Id")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }

    
    func testReportHotSpotPhoto() {
        var hotspotWithId : HotSpot?
        
        assyncAssert(){ exp in
            
            let getHotSpots = HotspotRouter.top(batch: nil)
            
            assertCurentUserPresent()
                
                .flatMap{ user -> Observable<[Campfiire.HotSpot]> in
                    
                    self.currentUser = user
                    self.request = Alamofire.request(getHotSpots)
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<HotSpot>.self)
                    
                }.flatMap{(hotspots) -> Observable<Campfiire.HotSpot> in
                    
                    hotspotWithId = hotspots.first!
                    self.request = Alamofire.request(HotspotRouter.details(hotSpot: hotspotWithId!))
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<HotSpot>.self)
                }.flatMap{ (hotspotDetailed ) -> Observable<Campfiire.Report> in
                    
                    guard let photo = hotspotDetailed.photos.first else {
                        return Observable.error(CampfiireError.generic(description: "Can not report non existing photo. Please make sure hotspot has at least one"))
                    }
                    
                    let hotSpotRouter = HotspotRouter.reportHotSpotPhoto(photo: photo)
                    self.request = Alamofire.request(hotSpotRouter)
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Campfiire.Report>.self)
                    
                }.subscribe(onNext: { report in
                    
                    XCTAssertEqual(report.reporterId, self.currentUser?.id, "We expect equal reporter Id and user Id")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }


}

