//
//  HotspotRouterTets.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/21/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import XCTest
import Alamofire
import RxSwift

import MapKit
import CoreLocation

@testable import Campfiire

class HotSpotTets: XCTestCase {
    
    let hotSpot = HotSpot.fakeEntity()
    var photo : Photo? = nil
    
    var request: DataRequest! = nil
    
    func testMap() {
        
        assyncAssert(){ exp in
            
            let hotSpotMap = HotspotRouter.map(georegion: MKCoordinateRegion.worldRegion.circularApproximation,
                                               query: nil,
                                               followedOnly: false)
            
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[HotSpot]> in
                    
                    self.request = Alamofire.request(hotSpotMap)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<HotSpot>.self)
                    
                }.subscribe(onNext: { (response : [HotSpot]) in
                    
                    XCTAssertNotNil(response, "Response can't be empty")
                    XCTAssertGreaterThan(response.count, 0, "Cant' verify hotspots on empty set")
                    
                    for item in response {
                        
                        XCTAssertGreaterThan(item.id, 0, "Id is expected to be present")
                        XCTAssertNotEqual(item.name.lengthOfBytes(using: .utf8), 0, "name is expected to be filled")
                        
                        XCTAssertNotNil(item.author, "Basic Hotspot data is expected to contain hotspot author")
                        
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }
    
    func testCreate() {
        
        assyncAssert(){exp in
            
            var hotspot = HotSpot.fakeEntity()
            hotspot.description = HotSpot.fakeString()
            hotspot.adress = HotSpot.fakeString()
            hotspot.author = User.fakeEntity()
            hotspot.name = User.fakeString(components: 2)
            
            let rout = HotspotRouter.create(hotSpot: hotspot)
            
            assertCurentUserPresent()
                .flatMap { user -> Observable<HotSpot>  in
                    
                    self.request = Alamofire.request(rout)
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<HotSpot>.self)
            
                }.subscribe(onNext: { (result) in
                    
                    defer {
                        exp.fulfill()
                    }
                    
                    XCTAssertGreaterThan(result.id, 0, "Id is expected to be present")
                    XCTAssertEqual(result.name, hotspot.name, "name should match")
                    XCTAssertEqual(result.description, hotspot.description, "descriptions should match")
                    guard let ad = result.adress else {
                        XCTFail("Address should be present")
                        return
                    }
                    
                    XCTAssertEqual(ad, hotspot.adress!, "addresses should match")
                    
                    guard let a1 = result.adress,
                        let a2 = hotspot.adress, a1 == a2 else {
                            
                            XCTFail("We expect adres strings to be present and match each other")
                            
                            return
                    }
                    
                    XCTAssertEqualWithAccuracy(result.longitude, hotspot.longitude, accuracy: 0.0001,  "Longitudes should match")
                    XCTAssertEqualWithAccuracy(result.latitude, hotspot.latitude,  accuracy: 0.0001, "Latitudes should match")
                    
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
    }
    
    func testDetails() {
        
        assyncAssert(){exp in
            
            guard let hotSpotWithId = HotSpot(JSON: ["id" : 1]) else {
                XCTFail("Can't initialize HotSpot")
                return
            }
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<HotSpot> in
                    
                    self.request = Alamofire.request(HotspotRouter.details(hotSpot: hotSpotWithId))
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<HotSpot>.self)
                    
                }.subscribe(onNext: { hotSpot in
                    
                    XCTAssertEqual(hotSpotWithId.id, hotSpot.id)
                    
                    XCTAssertNotEqual(hotSpot.name.lengthOfBytes(using: .utf8), 0, "name is expected to be filled")
                    XCTAssertNotEqual(hotSpot.description.lengthOfBytes(using: .utf8), 0, "description is expected to be filled")
                    
                    for item in hotSpot.photos {

                        XCTAssertNotEqual(item.id, 0, "Id is expected to be present")
                        XCTAssertNotEqual(item.pictureURL.lengthOfBytes(using: .utf8), 0, "pictureURLs are expected to be filled")
                        
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Error has occurred. Details - \(error). \nResponse: \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
        }
    }
    
    func testDeteilsDeleted() {
        
        assyncAssert(){exp in
            
            guard let hotSpotWithId = HotSpot(JSON: ["id" : 123128]) else {
                XCTFail("Can't initialize HotSpot")
                return
            }
            
            assertCurentUserPresent()
                .flatMap { user -> Observable<HotSpot> in
                    
                    self.request = Alamofire.request(HotspotRouter.details(hotSpot: hotSpotWithId))
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<HotSpot>.self)
                    
                }.subscribe(onNext: { hotSpot in
                    
                    XCTFail("We should have received error. Hotspot does not exist")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    defer {
                        exp.fulfill()
                    }
                    
                    guard let e = error as? CampfiireError,
                        case .businessError(let code, _) = e,
                        code == CampfiireErrorStatusCode.objectWithIdNotFound.rawValue else {
                            
                            XCTFail("We expected error with custom business error code 400")
                            return
                            
                    }
                    
                    
                }).addDisposableTo(rx_disposeBag)
        }
        
    }

    
    func testUpdateAvatar() {
        
        assyncAssert(){ exp in
            
            let bundle = Bundle(for: type(of: self))
            let image =   UIImage(named: bundle.path(forResource: "images", ofType: "jpg")!)!
            let data = UIImageJPEGRepresentation(image, 1)!
            
            guard let hotSpotWithId = HotSpot(JSON: ["id" : 1]) else {
                XCTFail("Can't initialize HotSpot")
                return
            }
            
            let updateAvaRout = HotspotRouter.updateAvatar(hotSpot: hotSpotWithId)
            
            assertCurentUserPresent()
                .flatMap{ _ in
                    return Campfiire.rx_upload(rout: updateAvaRout, data: ["file" : data] )
                }
                .flatMap { $0.rx_campfiireResponse(CampfiireResponse<AvatarUpdateResponse>.self) }
                .subscribe(onNext: { (avaResp) in
                    
                    XCTAssertNotNil(avaResp.url)
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Error has occurred. Details - \(error). \nResponse: \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
        }
        
    }
    
    func testUpdate(){
        
        assyncAssert(){ exp in
            
            var hotspot = HotSpot.fakeEntity()
            hotspot.id = 1
            hotspot.name = HotSpot.fakeString(components: 2)
            hotspot.description = HotSpot.fakeString()
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<HotSpot> in
                    
                    self.request = Alamofire.request(HotspotRouter.update(hotSpot: hotspot))
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<HotSpot>.self)
                    
                }.subscribe(onNext: { resp in
                    
                    XCTAssertEqual(resp.description, hotspot.description, "The updated value of the description must match to value which updates")
                    XCTAssertEqual(resp.id, hotspot.id, "Ids must be the same")
                    
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Error has occurred. Details - \(error). \nResponse: \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
    }
    
    func testCreatePhoto() {
        
        assyncAssert(){ exp in
            
            let bundle = Bundle(for: type(of: self))
            let image =   UIImage(named: bundle.path(forResource: "images", ofType: "jpg")!)!
            let data = UIImageJPEGRepresentation(image, 1)!
            
            guard let hotSpotWithId = HotSpot(JSON: ["id" : 1]) else {
                XCTFail("Can't initialize HotSpot")
                return
            }
            
            let createPhotoRout = HotspotRouter.createPhoto(hotspot: hotSpotWithId)
            
            assertCurentUserPresent()
                .flatMap{ user ->  Observable<DataRequest> in
                    return Campfiire.rx_upload(rout: createPhotoRout, data: ["file" : data] )
                }
                .flatMap { $0.rx_campfiireResponse(CampfiireResponse<Photo>.self) }
                .subscribe(onNext: { (img) in
                    
                    XCTAssertNotEqual(img.id, 0, "Id is expected to be present")
                    XCTAssertNotEqual(img.pictureURL.lengthOfBytes(using: .utf8), 0, "pictureURLs are expected to be filled")
                    
                    XCTAssertNotEqual(img.datePosted.timeIntervalSince1970, 0, "Photo must have date")
                    
                    XCTAssertNotNil(img.author, "We expect Author to be present")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
        }
        
    }
    
}
