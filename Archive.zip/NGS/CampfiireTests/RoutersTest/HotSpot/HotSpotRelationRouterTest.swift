//
//  HotspotRouterTest.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/22/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import XCTest
import Alamofire
import RxSwift

import MapKit
import CoreLocation

@testable import Campfiire

extension HotSpotTets {
    
    func testFollow() {
        
        assyncAssert(){exp in
            
            guard let hotSpotWithId = HotSpot(JSON: ["id" : 1]) else {
                XCTFail("Can't initialize HotSpot")
                return
            }
            
            let likeRout = HotspotRouter.follow(hotSpot: hotSpotWithId)
            let unlikeRout = HotspotRouter.unfollow(hotSpot: hotSpotWithId)
            
            assertCurentUserPresent()
                .flatMap { _ in
                    return Alamofire.request(unlikeRout)
                        .rx_campfiireResponse(CampfiireResponse<HotSpot>.self)
                }
                .catchErrorJustReturn(HotSpot.fakeEntity())
                .flatMap{ user -> Observable<HotSpot> in
                    
                    self.request = Alamofire.request(likeRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<HotSpot>.self)
                    
                }.subscribe(onNext: { (result) in
                    
                    XCTAssertGreaterThan(result.id, 0, "Id is expected to be present")
                    XCTAssertNotEqual(result.name.lengthOfBytes(using: .utf8), 0, "name is expected to be filled")
                    XCTAssertNotEqual(result.description.lengthOfBytes(using: .utf8), 0, "description is expected to be filled")
                    XCTAssertTrue(result.isFolowedByCurrentUser, "User must follow current HotSpot")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Error has occurred. Details - \(error). \nResponse: \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
        }
    }
    
    func testUnfollow() {
        
        assyncAssert() { exp in
            
            guard let hotSpotWithId = HotSpot(JSON: ["id" : 1]) else {
                XCTFail("Can't initialize HotSpot")
                return
            }
            
            let likeRout = HotspotRouter.follow(hotSpot: hotSpotWithId)
            let unlikeRout = HotspotRouter.unfollow(hotSpot: hotSpotWithId)
            
            assertCurentUserPresent()
                .flatMap { _ in
                    return Alamofire.request(likeRout)
                        .rx_campfiireResponse(CampfiireResponse<HotSpot>.self)
                }
                .catchErrorJustReturn(HotSpot.fakeEntity())
                .flatMap{ _ -> Observable<HotSpot> in
                    
                    self.request = Alamofire.request(unlikeRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<HotSpot>.self)
                    
                }.subscribe(onNext: { (result) in
                    
                    XCTAssertGreaterThan(result.id, 0, "Id is expected to be present")
                    XCTAssertNotEqual(result.name.lengthOfBytes(using: .utf8), 0, "name is expected to be filled")
                    XCTAssertNotEqual(result.description.lengthOfBytes(using: .utf8), 0, "description is expected to be filled")
                    XCTAssertFalse(result.isFolowedByCurrentUser, "User must unfollow current HotSpot")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Error has occurred. Details - \(error). \nResponse: \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
    }
    
    func testLikePhoto() {
        
        assyncAssert(){ exp in
            
            var photo = Photo(JSON: [:])!
            photo.id = 4
            
            let likeRout = HotspotRouter.like(photo: photo)
            let unlikeRout = HotspotRouter.dislike(photo: photo)
            
            assertCurentUserPresent()
                .flatMap { _ in
                    return Alamofire.request(unlikeRout)
                        .rx_campfiireResponse(CampfiireResponse<Photo>.self)
                }
                .catchErrorJustReturn(Photo.fakeEntity())
                .flatMap { _ -> Observable<Photo> in
                    
                    self.request = Alamofire.request(likeRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Photo>.self)
                
                }.subscribe(onNext: { (result) in
                    
                    XCTAssertEqual(result.id, photo.id, "Id is expected to be present")
                    XCTAssertNotEqual(result.pictureURL.lengthOfBytes(using: .utf8), 0, "pictureURL is expected to be filled")
                    
                    XCTAssertTrue(result.isLikedByCurrentUser, "User must like this picture")
                    XCTAssertNotNil(result.author, "Photo must have user")
                    XCTAssertGreaterThan(result.datePosted, Date(timeIntervalSince1970: 0))
                    XCTAssertGreaterThan(result.likesCount, 0, "We should have at least one like for photo")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
    }
    
    func testDislikePhoto() {
        
        assyncAssert(){ exp in
            
            var photo = Photo(JSON: [:])!
            photo.id = 4
            
            let likeRout = HotspotRouter.like(photo: photo)
            let unlikeRout = HotspotRouter.dislike(photo: photo)
            
            assertCurentUserPresent()
                .flatMap { _ in
                    return Alamofire.request(likeRout)
                        .rx_campfiireResponse(CampfiireResponse<Photo>.self)
                }
                .catchErrorJustReturn(Photo.fakeEntity())
                .flatMap { [unowned self] _ -> Observable<Photo> in
                    
                    self.request = Alamofire.request(unlikeRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Photo>.self)
                    
                }.subscribe(onNext: { (result) in
                    
                    XCTAssertEqual(result.id, photo.id, "Id should match expected to be present")
                    XCTAssertNotEqual(result.pictureURL.lengthOfBytes(using: .utf8), 0, "pictureURL is expected to be filled")
                    
                    XCTAssertFalse(result.isLikedByCurrentUser, "User must like this picture")
                    XCTAssertNotNil(result.author, "Photo must have user")
                    XCTAssertGreaterThan(result.datePosted, Date(timeIntervalSince1970: 0))
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
    }
}
