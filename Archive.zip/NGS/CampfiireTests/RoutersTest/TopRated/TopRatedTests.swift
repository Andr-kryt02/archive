//
//  TopRatedTests.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/14/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import XCTest
import Alamofire
import RxSwift
import ObjectMapper

@testable import Campfiire

class TopRatedTests: XCTestCase {
    
    func testTopBudtenders() {
     
        genericTopTest(rout: BudtenderRouter.top(batch: nil)) { (items: [Budtender]) in
            
            for b in items {
                
                XCTAssertNotEqual(b.name, "", "Item is expected to have name")
                
            }
            
        }
        
    }
    
    func testTopDispensaries() {
        
        genericTopTest(rout: DispensaryRouter.top(batch: nil)) { (items: [Dispensary]) in
            
            for b in items {
                
                XCTAssertNotEqual(b.pictureURL, "", "Item is expected to have picture URL")
                XCTAssertNotEqual(b.name, "", "Item is expected to have name")
                
            }
            
        }
        
    }
    
    func testTopDoctors() {
        
        genericTopTest(rout: DoctorRouter.top(batch: nil)) { (items: [Doctor]) in
            
            for b in items {
                
                XCTAssertNotEqual(b.pictureURL, "", "Item is expected to have picture URL")
                XCTAssertNotEqual(b.name, "", "Item is expected to have name")
                
            }
            
        }
        
    }
    
    func testTopPainClinics() {
        
        genericTopTest(rout: PainClinicRouter.top(batch: nil)) { (items: [PainClinic]) in
            
            for b in items {
                
                XCTAssertNotEqual(b.pictureURL, "", "Item is expected to have picture URL")
                XCTAssertNotEqual(b.name, "", "Item is expected to have name")
                
            }
            
        }
        
    }
    
    func testTopProducers() {
        
        genericTopTest(rout: LicensedProducerRouter.top(batch: nil)) { (items: [LicensedProducer]) in
            
            for b in items {
                
                XCTAssertNotEqual(b.pictureURL, "", "Item is expected to have picture URL")
                XCTAssertNotEqual(b.name, "", "Item is expected to have name")
                
            }
            
        }
        
    }
    
    func testTopStores() {
        
        genericTopTest(rout: OnlineStoreRouter.top(batch: nil)) { (items: [OnlineStore]) in
            
            for b in items {
                
                XCTAssertNotEqual(b.pictureURL, "", "Item is expected to have picture URL")
                XCTAssertNotEqual(b.name, "", "Item is expected to have name")
                
            }
            
        }
        
    }
    
    func testTopCamps() {
        
        genericTopTest(rout: CampRouter.top(batch: nil)) { (items: [Camp]) in
            
            for b in items {
                
                XCTAssertNotEqual(b.title, "", "Item is expected to have title")
                
            }
            
        }
        
    }
    
    func testTopHotspots() {
        
        genericTopTest(rout: HotspotRouter.top(batch: nil)) { (items: [HotSpot]) in
            
            for b in items {
                
                XCTAssertNotEqual(b.name, "", "Item is expected to have name")
                XCTAssertGreaterThan(b.followersCount, 0, "Item is expected to have at least 1 follower")
                
            }
            
        }
        
    }
}

extension TopRatedTests {
    
    
    func genericTopTest<T: Mappable>(rout: URLRequestConvertible, verifier: @escaping ([T]) -> () ) {
        
        var request: DataRequest! = nil
        
        assyncAssert(){ exp in
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[T]> in
                    
                    request = Alamofire.request(rout)
                    
                    return request
                        .rx_campfiireResponse(CampfiireArrayResponse<T>.self)
                    
                }.subscribe(onNext: { items in
                    
                    XCTAssertLessThanOrEqual(items.count, 10, "Top rated is expected to have not more than 10 items")
                    XCTAssertGreaterThan(items.count, 0, "Top rated is expected to have at least one item")
                    
                    verifier(items)
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }
    
}
