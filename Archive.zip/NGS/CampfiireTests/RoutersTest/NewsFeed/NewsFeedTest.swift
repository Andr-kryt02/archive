//
//  NewsFeedTest.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/13/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import XCTest
import Alamofire
import RxSwift

@testable import Campfiire

class NewsFeedTest: XCTestCase {
    
    func testNewsFeed() {
        
        assyncAssert { (exp) in
        
            var request: DataRequest!
            
            let _ =
             assertCurentUserPresent()
                .flatMap { _ -> Observable<[NewsFeedProxyObject]> in
                    
                    let rout = NewsFeedRouter.feed(batch: NewsFeedViewModel.NewsProvider.State())
                    request = Alamofire.request(rout)
                    
                    return request
                        .rx_campfiireResponse(CampfiireArrayResponse<NewsFeedProxyObject>.self)
                }
                .subscribe(onNext: { (proxies) in
                    
                    defer { exp.fulfill() }
                    
                    guard proxies.count > 0 else { XCTFail("Can't verify method on empty data set"); return; }
                    
                    for proxy in proxies {
                        
                        var item: NewsFeedTypes!
                        do { item = try proxy.newsFeedItem() }
                        catch {
                            XCTFail(" \(proxy) can't be mapped into proper news feed ")
                            continue
                        }
                        
                        switch item! {
                            
                        case .event(let event):
                            XCTAssertGreaterThan(event.id, 0, "Event must have id")
                            XCTAssertNotEqual(event.name, "", "Event must have name")
                            XCTAssertNotEqual(event.location, "", "Event must have location")
                            XCTAssertNotEqual(event.date.timeIntervalSince1970, 0, "Event must have date")
                            XCTAssertNotEqual(event.photoURL, "", "Event must have photoURL")
                            
                        case .hotSpotPhoto(let hotspotPhoto):
                            
                            guard let hs = hotspotPhoto.hotspot else {
                                XCTFail("Hotspot must be filled for NewsFeed item")
                                return
                            }
                            XCTAssertGreaterThan(hs.id, 0, "Hotspot should have id")
                            XCTAssertNotEqual(hs.name, "", "Hotspot must have name")
                            
                            XCTAssertGreaterThan(hotspotPhoto.photo.id, 0, "Photo should have id")
                            XCTAssertNotEqual(hotspotPhoto.photo.pictureURL, "", "Photo must have picture URL")
                            XCTAssertNotEqual(hotspotPhoto.photo.datePosted.timeIntervalSince1970, 0, "Photo must have date")
                            XCTAssertNotNil(hotspotPhoto.photo.author?.pictureURL, "Photo must have author image")
                            XCTAssertNotNil(hotspotPhoto.photo.author?.name, "Photo must have authpr name")
                            
                        case .userPhoto(let userPhoto):
                            
                            let photo = userPhoto.photo
                            
                            XCTAssertGreaterThan(photo.id, 0, "Photo should have id")
                            XCTAssertNotEqual(photo.pictureURL, "", "Photo must have picture URL")
                            XCTAssertNotEqual(photo.datePosted.timeIntervalSince1970, 0, "Photo must have date")
                            XCTAssertNotNil(photo.author?.pictureURL, "Photo must have author image")
                            XCTAssertNotNil(photo.author?.name, "Photo must have authpr name")
                            
                        }
                        
                    }
                    
                    
                    
                }, onError: { (error) in
                    
                    XCTFail("Error - \(error). Request failed. Request - \(request)")
                    
                    exp.fulfill()
                })
        }
        
    }
    
    
    
}
