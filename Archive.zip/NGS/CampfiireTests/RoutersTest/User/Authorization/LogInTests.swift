//
//  UserLogInTests.swift
//  Campfiire
//
//  Created by Andrew Seregin on 10/31/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import XCTest
import Alamofire
import RxSwift


@testable import Campfiire

extension UserTests { //LogInTests
    
    func testSuccessResult() {
        
        assyncAssert(){ exp in
            
            let loginRout = UserAuthorizationRouter.logIn(email: "email17@email.com", password: "password")
            
            request = Alamofire.request(loginRout)
            
            request
                .rx_campfiireResponse(CampfiireResponse<UserLoginResponse>.self)
                .subscribe(onNext: {(response: UserLoginResponse) in
                    
                    XCTAssertNotNil(response.token)
                    XCTAssertNotNil(response.user?.email)
                    exp.fulfill()
                
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                
                }).addDisposableTo(rx_disposeBag)
        }

    }
    
    func testInvalidPassword() {

        assyncAssert(){ exp in
            
            let email = "jjjj@jjjj.com"
            let password = "kk"
            
            let loginRout = UserAuthorizationRouter.logIn(email: email, password: password)
            
            request = Alamofire.request(loginRout)
            
            request
                .rx_campfiireResponse(CampfiireResponse<UserLoginResponse>.self)
                .subscribe(onNext: {(response: UserLoginResponse) in
                    
                    XCTFail("User with invalid email - \(email) exists.")
                    exp.fulfill()
                
                }, onError: { error in
                    
                    guard let e = error as? CampfiireError else {
                        XCTFail("There was unhandled error - \(error)")
                        return
                    }
                    
                    switch e {
                    
                    case .businessError(let code, _):
                        XCTAssertEqual(code, CampfiireErrorStatusCode.invalidPasword.rawValue)
                    default:
                        XCTFail("This error have different type then CampfiireError.businessError - \(e)")
                    }
                    exp.fulfill()
                
                }).addDisposableTo(rx_disposeBag)
        }


    }
    
    func testRegister() {
        
        assyncAssert(){ exp in
            
            let fakeNumber = 19//User.fakeNumber(bound: 100000)
            
            let regData = RegistrationData(username: "andrew\(fakeNumber)",
                password: "password",
                email: "email\(fakeNumber)@email.com",
                birthdate: NSDate().subtractingYears(20),
                location: User.fakeString(),
                gender: Gender.female,
                favoriteProduct: User.fakeString(components: 1),
                tags: [ User.fakeValue(from: ["One", "Two", "Three"]) ],
                tempImageURL : nil)
            
            let registrRout = UserAuthorizationRouter.registration(user: regData)
            request = Alamofire.request(registrRout)
            
            request
                .rx_campfiireResponse(CampfiireResponse<UserLoginResponse>.self)
                .subscribe(onNext: { (response : UserLoginResponse) in
                    
                    guard let user = response.user else {
                        XCTFail("Respons hasn't user")
                        exp.fulfill()
                        return
                    }
                    
                    let birthdayDifference = fabs(user.birthdate.timeIntervalSinceNow - regData.birthdate!.timeIntervalSinceNow)
                    
                    XCTAssertEqual(user.name, regData.username, "The user who registered should have the same name as in registration")
                    XCTAssertEqual(user.email, regData.email, "The user who registered should have the same email as in registration")
                    XCTAssertLessThan(birthdayDifference, 12 * 60 * 60, "The user who registered should have the same birthday as in registration, up to 12 hours")
                    XCTAssertEqual(user.gender, regData.gender, "The user who registered should have the same gender as in registration")
                    XCTAssertEqual(user.location, regData.location, "The user who registered should have the same location as in registration")
                    XCTAssertEqual(user.tags, regData.tags, "The user who registered should have the same tag as in registration")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }

    
}
