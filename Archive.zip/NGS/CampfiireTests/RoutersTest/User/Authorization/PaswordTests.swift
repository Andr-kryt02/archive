import XCTest
import Alamofire
import RxSwift


@testable import Campfiire

extension UserTests { //PaswordTests
    
    func testChangPassword() {
        
        assyncAssert(){ exp in
            
            
            assertCurentUserPresent()
                .flatMap{ resp -> Observable<User>  in
                    
                    let passwordRout = UserAuthorizationRouter.changePassword (oldPassword : "password",
                                                                               newPassword : "password")
                    
                    self.request = Alamofire.request(passwordRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<User>.self)
                    
                }.subscribe(onNext: {(response: User) in
                    
                    XCTAssertGreaterThan(response.id, 0, "id are expected to be filled")
                    XCTAssertNotEqual(response.name.lengthOfBytes(using: .utf8), 0, "name are expected to be filled")
                    XCTAssertNotNil(response.email, "The user who entered through the mail can not have it")
                    
                    exp.fulfill()
                    
                }, onError: { error in

                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
        }
        
    }
    
    func testRecoverPassword() {
        
        assyncAssert(){exp in
            
            let passwordRecoverRout = UserAuthorizationRouter.paswordRecover(email: "email2@email.com")
            
            Alamofire.request(passwordRecoverRout)
                .rx_campfiireResponse(CampfiireEmptyResponse.self)
                
                .subscribe(onNext: {
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
        }
        
    }
}
