//
//  BlockRouterTest.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/4/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import XCTest
import Alamofire
import RxSwift


@testable import Campfiire

extension UserTests { //BlockUnblockTest
    
    func testBlockUser() {
        
        assyncAssert(){ exp in
            
            guard let userWithId = User(JSON: ["id" : 6]) else {
                XCTFail("Can't create user.")
                return
            }
            
            let blockUser = UserRelationRouter.blockUser(user: userWithId)
            
            assertCurentUserPresent()
                .flatMap { _ -> Observable<User> in
                    
                    self.request = Alamofire.request(blockUser)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<User>.self)
                    
                }
                .flatMap { (user) -> Observable<User> in
                    
                    XCTAssertEqual(user.id, userWithId.id, "Id must matching.")
                    XCTAssertNotNil(user.id, "Each user must have id.")
                    XCTAssertNotNil(user.name, "Each user must have name.")
                    XCTAssertTrue(user.isBlocked, "user should be blocked")
                    
                    return Alamofire.request(UserDetailsRouter.details(user: user))
                            .rx_campfiireResponse(CampfiireResponse<User>.self)
                }
                .subscribe(onNext: { (response) in
                    
                    XCTAssertEqual(response.id, userWithId.id, "Id must matching.")
                    XCTAssertNotNil(response.id, "Each user must have id.")
                    XCTAssertNotNil(response.name, "Each user must have name.")
                    XCTAssertTrue(response.isBlocked, "user should be blocked")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }

    
    func testUnblockUser() {
        
        assyncAssert(){ exp in
            
            guard let userWithId = User(JSON: ["id" : 6]) else {
                XCTFail("Can't create user.")
                return
            }
            
            let blockUser = UserRelationRouter.unblockUser(user: userWithId)
            
            assertCurentUserPresent()
                .flatMap { _ -> Observable<User> in
                    
                    self.request = Alamofire.request(blockUser)
                    
                    return Alamofire.request(blockUser)
                        .rx_campfiireResponse(CampfiireResponse<User>.self)
                    
                }.subscribe(onNext: { (response) in
                    
                    XCTAssertEqual(response.id, userWithId.id, "Id must matching.")
                    XCTAssertNotNil(response.id, "Each user must have id.")
                    XCTAssertNotNil(response.name, "Each user must have name.")
                    XCTAssertFalse(response.isBlocked, "User must be unblocked.")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
        
    }
    
}



