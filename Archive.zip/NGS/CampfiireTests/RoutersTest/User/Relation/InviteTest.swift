//
//  CreateOrAcceptInviteTest.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/8/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import XCTest
import Alamofire
import RxSwift


@testable import Campfiire

extension UserTests { //InviteTest
    
    func testCreateInvite() {
        
        assyncAssert(){ exp in
            
            guard let userWithId = User(JSON: ["id" : 6]) else {
                XCTFail("Can't create user.")
                return
            }
            
            let putFriend = UserRelationRouter.createInvite(user: userWithId)
            
            assertCurentUserPresent()
                .flatMap{ _ -> Observable<User> in
                    
                    self.request = Alamofire.request(putFriend)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<User>.self)
                    
                }.subscribe(onNext: { (response) in
                    
                    XCTAssertEqual(response.id, userWithId.id, "Id must matching.")
                    XCTAssertNotNil(response.id, "Each user must have id.")
                    XCTAssertNotNil(response.name, "Each user must have name.")
                    
                    let year : Date! = response.birthdate
                    XCTAssertLessThanOrEqual(year, NSDate().subtractingYears(18))
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
    }
    
    func testDeleteInvite() {
        
        assyncAssert(){ exp in
            
            guard let userWithId = User(JSON: ["id" : 6]) else {
                XCTFail("Can't create user.")
                return
            }
            
            let deleteFriend = UserRelationRouter.deleteInvite(user: userWithId)
            
            assertCurentUserPresent()
                .flatMap { _ -> Observable<User> in
                    
                    self.request = Alamofire.request(deleteFriend)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<User>.self)
                    
                }.subscribe(onNext: { (response) in
                    
                    XCTAssertEqual(response.id, userWithId.id, "Id must matching.")
                    XCTAssertNotNil(response.id, "Each user must have id.")
                    XCTAssertNotNil(response.name, "Each user must have name.")
                    
                    let year : Date! = response.birthdate
                    XCTAssertLessThanOrEqual(year, NSDate().subtractingYears(18))
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
    }

    func testGetInvites() {
        
        assyncAssert(){ exp in
            
            let inviteRout = UserRelationRouter.invitesList
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[FriendsInvitesResponse]> in
                    
                    self.request = Alamofire.request(inviteRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<FriendsInvitesResponse>.self)
                    
                }.subscribe(onNext: { (resp) in
                    
                    XCTAssertNotNil(resp)
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
    }
}
