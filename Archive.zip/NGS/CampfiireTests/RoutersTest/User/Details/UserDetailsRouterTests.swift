//
//  UpdateMainInfoTest.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/8/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import XCTest
import Alamofire
import RxSwift


@testable import Campfiire

class UserTests: XCTestCase {
    
    var request: DataRequest! = nil
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    
    func testUpdateMainInfo() {
        
        assyncAssert(){ exp in
            
            let fakeLocation = User.fakeString(components: 2)
            let fakeTags = [ User.fakeValue(from: ["One", "Two", "Three"]) ]
            let fakeGender: Gender = User.fakeBool() ? .male : .female
            
            let years = User.fakeNumber(bound: 30) + 18
            let fakeBirthday = NSDate().subtractingYears(years)!
            
            assertCurentUserPresent()
                .flatMap { user -> Observable<User> in
                    
                    var changes = user
                    
                    changes.location = fakeLocation
                    changes.tags = fakeTags
                    changes.gender = fakeGender
                    changes.birthdate = fakeBirthday
                    
                    self.request = Alamofire.request(UserDetailsRouter.update(user: changes))
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<User>.self)
                    
                }.subscribe(onNext: {(response: User) in
                    
                    XCTAssertNotEqual(response.id, 0, "Each user must have id.")
                    XCTAssertNotEqual(response.name, "", "Each user must have name.")
                    
                    XCTAssertEqual(response.location, fakeLocation, "Location must match the one we provided")
                    XCTAssertEqual(response.tags, fakeTags, "Tags must match the one we provided")
                    XCTAssertEqual(response.gender, fakeGender, "Location must match the one we provided")
                    
                    let birthdayDifference = fabs(fakeBirthday.timeIntervalSinceNow - response.birthdate.timeIntervalSinceNow)
                    XCTAssertLessThan(birthdayDifference, 12 * 60 * 60, "The user who updated should have the same birthday as in update, up to 12 hours")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
            
        }
    }
    
    func testUpdateAvatar() {
        
        assyncAssert(){ exp in
            
            let bundle = Bundle(for: type(of: self))
            let image =   UIImage(named: bundle.path(forResource: "images", ofType: "jpg")!)!
            let data = UIImageJPEGRepresentation(image, 1)!
            
            let updateAvaRout = UserDetailsRouter.updateAvatar
            
            assertCurentUserPresent()
                .flatMap { _ in
                    return Campfiire.rx_upload(rout: updateAvaRout, data: ["file" : data] )
                }
                .flatMap { $0.rx_campfiireResponse(CampfiireResponse<AvatarUpdateResponse>.self) }
                .subscribe(onNext: { (avaResp) in
                    
                    XCTAssertNotNil(avaResp.url)
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
    }

    
    func testGetMainInfo() {
        
        assyncAssert(){ exp in
            
            assertCurentUserPresent()
                .flatMap { user -> Observable<User> in
                    
                    self.request = Alamofire.request(UserDetailsRouter.details(user: user))
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<User>.self)
                    
                }.subscribe(onNext: {(response: User) in
                    
                    XCTAssertNotEqual(response.id, 0, "Each user must have id.")
                    XCTAssertNotEqual(response.name, "", "Each user must have name.")
                    
                    let year : Date! = response.birthdate
                    XCTAssertLessThanOrEqual(year, NSDate().subtractingYears(18))
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
    }
    
    func testGetUserAvatar() {
        
        let loginRout = UserAuthorizationRouter.logIn(email: "email2@email.com", password: "password")
        
        let exp = expectation(description: "testSuccessResult")
        
        Alamofire.request(loginRout)
            
            .rx_campfiireResponse(CampfiireResponse<UserLoginResponse>.self)
            .flatMap { (userLoginResp) -> Observable<UIImage?> in
                
                if userLoginResp.token == nil {
                    XCTFail()
                }
                
                AccessToken.token = userLoginResp.token!
                
                guard let p = userLoginResp.user?.pictureURL else {
                    fatalError("Can't test get avatar if user does not have avatar image")
                }
                
                ImageRetreiver.flushImageForKey(key: p)
                
                return ImageRetreiver.imageForURLWithoutProgress(url: p).asObservable()
                
            }
            .subscribe(onNext: { (maybeImage) in
                
                XCTAssertNotNil(maybeImage, "Image must not be nil")
                
                exp.fulfill()
                
            }, onError: { error in
                
                XCTFail("Response returned error. Details - \(error)")
                exp.fulfill()
                
            }).addDisposableTo(rx_disposeBag)
        
        waitForExpectations(timeout: 5) { error in
            
            XCTAssertNil(error, "Something went horribly wrong")
            
        }
        
    }
    
    func testFriendsSearch() {
        
        assyncAssert(){ exp in
            
            let filter = SearchUsersFilter(query: "",
                                           ageRange: nil,
                                           gender: nil,
                                           location: nil,
                                           tag: nil)
            
            let searchRout = SearchRouter.friends(searchFilter: filter)
            
            assertCurentUserPresent()
                .flatMap { _ -> Observable<[User]> in
                    
                    self.request = Alamofire.request(searchRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<User>.self)
                    
                }.subscribe(onNext: {(users: [User]) in
                    
                    defer {
                        exp.fulfill()
                    }
                    
                    for item in users {
                        
                        XCTAssertNotEqual(item.id, 0, "Empty users are of no use for us")
                        XCTAssertNotEqual(item.name, "", "Users must have name present")
                        
                        break
                    }
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }
    
    func testTagSearch() {
        
        assyncAssert(){ exp in
            
            let filter = SearchUsersFilter(query: nil,
                                           ageRange: nil,
                                           gender: nil,
                                           location: nil,
                                           tag: "One")
            
            let searchRout = SearchRouter.user(batch: Batch(offset: 0, limit: 5),
                                               searchFilter: filter)
            
            assertCurentUserPresent()
                
                .flatMap { (user) -> Observable<[User]> in
                    
                    self.request = Alamofire.request(searchRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<User>.self)
                    
                }.subscribe(onNext: { (users: [User]) in
                    
                    defer {
                        exp.fulfill()
                    }
                    
                    XCTAssertLessThanOrEqual(users.count, 5, "We do not expect more than 5 users in a batch")
                    
                    for item in users {
                        
                        XCTAssertNotEqual(item.id, 0, "Empty users are of no use for us")
                        XCTAssertNotEqual(item.name, "", "Users must have name present")
                        
                        break
                    }
                    
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
            
        }
    }
    
    func testSearchUser() {
        
        assyncAssert(){ exp in
            
            let filter = SearchUsersFilter(query: "",
                                           ageRange: nil,
                                           gender: nil,
                                           location: nil,
                                           tag: nil)
            
            let searchRout = SearchRouter.user(batch: Batch(offset: 0, limit: 5),
                                               searchFilter: filter)
            
            assertCurentUserPresent()
                .flatMap { user -> Observable<[User]> in
                    
                    self.request = Alamofire.request(searchRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<User>.self)
                    
                }.subscribe(onNext: { (users: [User]) in
                    
                    defer {
                        exp.fulfill()
                    }
                    
                    XCTAssertLessThanOrEqual(users.count, 5, "We don't expect more than 5 users")
                    
                    guard let first = users.first else {
                        XCTFail("We expect at least some results to be present")
                        return;
                    }
                    
                    XCTAssertNotEqual(first.id, 0, "Empty users are of no use for us")
                    XCTAssertNotEqual(first.name, "", "Users must have name present")
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
        
    }
    
    func testSettings() {
        
        assyncAssert { (exp) in
            
            var request: DataRequest!
            
            assertCurentUserPresent()
                .flatMap { _ -> Observable<Void> in
                    
                    let data = SettingsResponse(push: User.fakeBool(), showEvent: User.fakeBool(),
                                                attachment: User.fakeBool(),
                                                time24: User.fakeBool(),
                                                visibility: User.fakeValue(from: [.allUsers, .nobody, .friendsOnly]) )
                    let rout = SettingsRouter.send(settings: data)
                    
                    request = Alamofire.request(rout)
                    
                    return request.rx_campfiireResponse(CampfiireEmptyResponse.self)
                }
                .subscribe(onNext: { (_) in
                    
                    ///so far that all we need
                    
                    exp.fulfill()
                    
                }, onError: { (error) in
                    
                    XCTFail("Error \(error). Request details - \(request)")
                    exp.fulfill()
                    
                })
                .addDisposableTo(rx_disposeBag)
            
        }
        
    }
    
}
