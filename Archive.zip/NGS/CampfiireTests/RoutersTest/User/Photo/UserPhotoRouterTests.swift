//
//  UserPhotoRouterTests.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 2016-12-21.
//  Copyright © 2016 campfiire. All rights reserved.
//

import XCTest
import Foundation
import Alamofire
import RxSwift

@testable import Campfiire

extension UserTests { /// PhotoTests
    
    func testListOwnPhotos() {
        
        assyncAssert(){ exp in
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[Photo]> in
                    
                    let rout = UserPhotoRouter.list(friendsPhotos: false,
                                                    batch: Batch(offset: 0, limit: 3))
                    
                    self.request = Alamofire.request(rout)
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<Photo>.self)
                    
                }.subscribe(onNext: { (photos : [Photo]) in
                    
                    XCTAssertGreaterThan(photos.count, 0, "Can't verify empty list")
                    XCTAssertLessThan(photos.count, 4, "We don't expect more than 3 photos for requested batch")
                    
                    for photo in photos {
                        
                        XCTAssertGreaterThan(photo.id, 0, "Id is expected to be present")
                        XCTAssertNotEqual(photo.pictureURL, "", "photo must provide valid picture URL")
                        
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }
    
    func testListFriendsPhotos() {
        
        assyncAssert(){ exp in
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[Photo]> in
                    
                    let rout = UserPhotoRouter.list(friendsPhotos: true,
                                                    batch: Batch(offset: 0, limit: 3))
                    
                    self.request = Alamofire.request(rout)
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<Photo>.self)
                    
                }.subscribe(onNext: { (photos : [Photo]) in
                    
                    XCTAssertGreaterThan(photos.count, 0, "Can't verify empty list")
                    XCTAssertLessThan(photos.count, 4, "We don't expect more than 3 photos for requested batch")
                    
                    for p in photos {
                        
                        XCTAssertGreaterThan(p.id, 0, "Id is expected to be present")
                        XCTAssertNotEqual(p.pictureURL, "", "photo must provide valid picture URL")
                        guard let author = p.author else {
                            XCTFail("Photo Author is expected to be present")
                            continue
                        }
                        
                        XCTAssertNotEqual(author, User.currentUser()!, "Friend's list photos must not contain own photos")
                        
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }
    
    func testCreatePhoto() {
        
        let bundle = Bundle(for: type(of: self))
        let image =  UIImage(named: bundle.path(forResource: "images", ofType: "jpg")!)!
        
        assyncAssert(){ exp in
            assertCurentUserPresent()
                .flatMap{ (user : User) -> Observable<UserPhoto> in
                    
                    return NewsFeedManager.postUserPhoto(image: image)
                }
                .subscribe(onNext: { (userPhoto) in
                    
                    XCTAssertGreaterThan(userPhoto.photo.id, 0, "Id is expected to be present")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Error has occurred. Details - \(error).")
                    
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
        }
    }
    
    
    func testDeletePhoto() {
        
        assyncAssert(){ exp in
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<Photo> in
                    
                    let bundle = Bundle(for: type(of: self))
                    let image =  UIImage(named: bundle.path(forResource: "images", ofType: "jpg")!)!
                    
                    return NewsFeedManager.postUserPhoto(image: image)
                        .map { $0.photo }
                    
                }
                .flatMap{ photo -> Observable<Void> in
                    
                    let rout = UserPhotoRouter.delete( photo: photo )
                    self.request = Alamofire.request(rout)
                    return self.request
                        .rx_campfiireResponse(CampfiireEmptyResponse.self)
                    
                }.subscribe(onNext:  { _ in
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }
    
    
    func testLikePhoto() {
        
        var storedPhoto : Photo! = nil
        
        assyncAssert(){ exp in
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[Photo]> in
                    
                    let getAllRout = UserPhotoRouter.list( friendsPhotos: false,
                                                           batch: Batch(offset: 0,limit: 3) )
                    self.request = Alamofire.request(getAllRout)
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<Photo>.self)
                    
                }
                .flatMap { photos -> Observable<Photo> in
                    
                    guard let photo = photos.first else {
                        return Observable.error(
                            CampfiireError.generic(description: "Can't test like when no photos exist") )
                    }
                    storedPhoto = photo
                    
                    let rout = UserPhotoRouter.dislike(photo: photo)
                    
                    self.request = Alamofire.request(rout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Photo>.self)
                        .catchErrorJustReturn(storedPhoto)
                }
                .flatMap { photo -> Observable<Photo> in
                    
                    let rout = UserPhotoRouter.like( photo: photo )
                    
                    self.request = Alamofire.request(rout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Photo>.self)
                    
                }
                .subscribe(onNext: { (photo) in
                    
                    XCTAssertEqual(photo.id, storedPhoto.id, "Id is expected to be present")
                    XCTAssertTrue(photo.isLikedByCurrentUser, "User must like this photo")
                    XCTAssertGreaterThan(photo.likesCount, 0, "We need at least 1 like to be present as we've just liked it")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                })
                .addDisposableTo(rx_disposeBag)
            
            
        }
    }
    
    
    
    func testDislikePhoto() {
        
        var storedPhoto : Photo! = nil
        
        assyncAssert(){ exp in
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[Photo]> in
                    
                    let getAllRout = UserPhotoRouter.list( friendsPhotos: false,
                                                           batch: Batch(offset: 0,limit: 3) )
                    self.request = Alamofire.request(getAllRout)
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<Photo>.self)
                    
                }
                .flatMap { photos -> Observable<Photo> in
                    
                    guard let photo = photos.first else {
                        return Observable.error(
                            CampfiireError.generic(description: "Can't test like when no photos exist") )
                    }
                    storedPhoto = photo
                    
                    let rout = UserPhotoRouter.like(photo: photo)
                    
                    self.request = Alamofire.request(rout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Photo>.self)
                        .catchErrorJustReturn(storedPhoto)
                }
                .flatMap { photo -> Observable<Photo> in
                    
                    let rout = UserPhotoRouter.dislike( photo: photo )
                    
                    self.request = Alamofire.request(rout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Photo>.self)
                    
                }
                .subscribe(onNext: { (photo) in
                    
                    XCTAssertEqual(photo.id, storedPhoto.id, "Id is expected to be present")
                    XCTAssertFalse(photo.isLikedByCurrentUser, "User must dislike this photo")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                })
                .addDisposableTo(rx_disposeBag)
            
            
        }
        
    }
    
}
