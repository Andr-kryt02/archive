//
//  MMjRouterTests.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 2016-12-19.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

import XCTest
import Alamofire
import RxSwift

@testable import Campfiire

class SimpleListTests: XCTestCase {
 
    var userLogIn : User?
    var request: DataRequest! = nil
    
    func testMMJList(){
        
        assyncAssert() { exp in
            
            // uncomment to use real router for real requests
            let batch = Batch(offset: 0, limit: 5)
            let mmjRout = SimpleRouter.mmj(batch : batch)
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[MMJ]> in
                    
                    self.userLogIn = user
                    self.request = Alamofire.request(mmjRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<MMJ>.self)
                    
                }.subscribe(onNext: { (response) in
                    
                    XCTAssertGreaterThanOrEqual(response.count, 1, "We expect more than 1 mmj")
                    XCTAssertLessThanOrEqual(response.count, 5, "We expect not more than 5 mmj")
                    
                    for item in response {
                        
                        let url = URL(string: item.url)
                        XCTAssertNotNil(url, "url cannot be nil")
                        XCTAssertTrue(UIApplication.shared.canOpenURL(url!), "We expect valid url")
                       
                        XCTAssertNotEqual(item.title.lengthOfBytes(using: .utf8), 0, "title are expected to be filled")
                        XCTAssertNotEqual(item.image, "", "We expect image to be filled")
                        XCTAssertNotEqual(item.url, "", "We expect url to be filled")
                        
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Request: \(self.request) returned error . Details - \(error)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }
    
    func testVideoList(){
        
        assyncAssert() { exp in
            
            let videoRout = SimpleRouter.video
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[Video]> in
                    
                    self.userLogIn = user
                    
                    self.request = Alamofire.request(videoRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<Video>.self)
                    
                }.subscribe(onNext: { (response) in
                    
                    XCTAssertGreaterThanOrEqual(response.count, 1, "We expect more than 1 video")
                    //XCTAssertLessThanOrEqual(response.count, 6, "We don't expect more than 5 videos")
                    
                    for item in response {
                        
                        XCTAssertGreaterThan(item.id, 0, "id are expected to be filled")
                        XCTAssertNotEqual(item.title.lengthOfBytes(using: .utf8), 0, "title are expected to be filled")
                        XCTAssertNotEqual(item.url, "", "We expect url to be filled")
                        XCTAssertNotEqual(item.thumbNail, "", "We expect thumbNail url to be filled")
                        
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }

    func testInfoSourcesList(){
        
        assyncAssert() { exp in
            
            let sourceRout = SimpleRouter.infoSource
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[InfoSource]> in
                    
                    self.userLogIn = user
                    self.request = Alamofire.request(sourceRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<InfoSource>.self)

                    
                }.subscribe(onNext: { (response) in
                    
                    XCTAssertGreaterThan(response.count, 0, "We expect more than 1 InfoSource")
                    
                    for item in response {
                        
                        XCTAssertGreaterThan(item.id, 0, "id are expected to be filled")
                        XCTAssertNotEqual(item.title.lengthOfBytes(using: .utf8), 0, "title are expected to be filled")
                        XCTAssertNotEqual(item.url, "", "We expect url to be filled")
                        
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }

    
}
