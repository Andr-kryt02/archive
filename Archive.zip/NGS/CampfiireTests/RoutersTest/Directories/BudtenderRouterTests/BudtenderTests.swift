//
//  BudtenderTests.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 05.12.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import XCTest
import Alamofire
import RxSwift

@testable import Campfiire

class DirectoryTests: XCTestCase {
    
    var request: DataRequest! = nil
    
    func testGetBudtender() {
        
        assyncAssert(){ exp in
            
            assertCurentUserPresent()
                .flatMap { _ -> Observable<[Budtender]> in
            
                    let batch = Batch(offset: 0, limit: 10)
                    
                    let budtenderRouter = BudtenderRouter.list(query: "",
                                                               batch: batch)
                    
                    return Alamofire.request(budtenderRouter)
                        .rx_campfiireResponse(CampfiireArrayResponse<Campfiire.Budtender>.self)
                    
                }
                .flatMap{ buds -> Observable<Campfiire.Budtender> in
                    
                    guard let budtender = buds.first else {
                        return Observable.error(CampfiireError.generic(description: "Can't verify budtenders details on empty budtender list"))
                    }
                    
                    let budtenderRouter = BudtenderRouter.details(budtender: budtender)
                    
                    self.request = Alamofire.request(budtenderRouter)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Campfiire.Budtender>.self)
                    
                }.subscribe(onNext: { budtender in
                    
                    XCTAssertNotEqual(budtender.name, "", "Budtender must have name")
                    XCTAssertNotEqual(budtender.email, "", "Budtender must have address")
                    XCTAssertNotEqual(budtender.userId ,0, "Budtender must have user id")
                    XCTAssertNotEqual(budtender.phoneNumber ,"", "Budtender must have phone number")
                    
                    XCTAssertGreaterThan(budtender.birthday.timeIntervalSince1970, 0, "Budtender must have age")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
        
        
    }
    
    func testGetBudtenders() {
        
        assyncAssert(){ exp in
            let batch = Batch(offset: 0, limit: 10)
            
            let budtenderRouter = BudtenderRouter.list(query: "",
                                                 batch: batch)
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[Campfiire.Budtender]> in
                    
                    self.request = Alamofire.request(budtenderRouter)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<Campfiire.Budtender>.self)
                    
                }.subscribe(onNext: { budtenders in
                    
                    XCTAssertLessThan(budtenders.count, 10, "We expect not more than 10 budtenders")
                    XCTAssertGreaterThan(budtenders.count, 0, "We expect at least one budtender for nil query")
                    
                    for bud in budtenders {
                        
                        XCTAssertNotEqual(bud.id ,0, "Budtender must have user id")
                        XCTAssertNotEqual(bud.name, "", "Budtender must have name")
                        XCTAssertNotNil(bud.isOnline, "Budtenders must have isOnline flag")
                        
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
        }
        
    }
    
    
    func testLikeBudtender() {
        
        assyncAssert(){ exp in
            
            var bud = Budtender.fakeEntity()
            bud.id = 1
            
            let likeRout = BudtenderRouter.like(budtender: bud)
            let dislikeRout = BudtenderRouter.dislike(budtender: bud)
            
            assertCurentUserPresent()
                .flatMap { _ in
                    return Alamofire.request(dislikeRout)
                        .rx_campfiireResponse(CampfiireResponse<Budtender>.self)
                }
                .catchErrorJustReturn(Budtender.fakeEntity())
                .flatMap { _ -> Observable<Budtender> in
                    
                    self.request = Alamofire.request(likeRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Budtender>.self)
                    
                }.subscribe(onNext: { (result) in
                    
                    XCTAssertEqual(result.id, bud.id, "Id is expected to be present")
                    //XCTAssertNotEqual(result.avatar.lengthOfBytes(using: .utf8), 0, "pictureURL is expected to be filled")
                    
                    XCTAssertTrue(result.isLikedByCurrentUser, "User must like this budtender")
                    XCTAssertGreaterThan(result.likes, 0, "We need at least 1 like to be present as we've just liked it")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
    }
    
    func testDislikeBudtender() {
        
        assyncAssert(){ exp in
            
            var bud = Budtender.fakeEntity()
            bud.id = 1
            
            let unlikeRout = BudtenderRouter.dislike(budtender: bud)
            let likeRout = BudtenderRouter.like(budtender: bud)
            
            assertCurentUserPresent()
                
                .flatMap { _ in
                    return Alamofire.request(likeRout)
                        .rx_campfiireResponse(CampfiireResponse<Budtender>.self)
                }
                .catchErrorJustReturn(Budtender.fakeEntity())
                .flatMap { [unowned self] _ -> Observable<Budtender> in
                    
                    self.request = Alamofire.request(unlikeRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Budtender>.self)
                    
                }.subscribe(onNext: { (result) in
                    
                    XCTAssertEqual(result.id, bud.id, "Id should match expected to be present")
                    //XCTAssertNotEqual(result.avatar.lengthOfBytes(using: .utf8), 0, "avatar is expected to be filled")
                    
                    XCTAssertFalse(result.isLikedByCurrentUser, "User must dislike this budtender")
                    
                    
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
    }
    
    
    func testApplyBudtender() {
        
        ////As of now the test has no real API available so it always fails
        
        assyncAssert(){ exp in
            
            let fakeNumber = User.fakeNumber(bound: 100000)
            
            let regData = RegistrationData(username: "andrew\(fakeNumber)",
                password: "password",
                email: "email\(fakeNumber)@email.com",
                birthdate: NSDate().subtractingYears(20),
                location: User.fakeString(),
                gender: Gender.female,
                favoriteProduct: User.fakeString(components: 1),
                tags: [ User.fakeValue(from: ["One", "Two", "Three"]) ],
                tempImageURL : nil)
            
            let budtenderRouter = BudtenderRouter.apply(phone: "\(User.fakeNumber(bound: 1000000))",
                                                        reason: User.fakeString(components: 9))
            AuthorizationManager.loginWith(data:
                AuthenticationData.register(registrationData: regData))
                .flatMap{ _ -> Observable<Void> in
                    
                    self.request = Alamofire.request(budtenderRouter)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireEmptyResponse.self)
                    
                }.subscribe(onNext: { _ in
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }
    
}


