//
//  PainClinicTests.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 06.12.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import XCTest
import Alamofire
import RxSwift
import MapKit

@testable import Campfiire

extension DirectoryTests {
    
    func testGetPainClinic() {
        
        assyncAssert(){ exp in
            
            var clinicExpected = Campfiire.PainClinic.fakeEntity()
            clinicExpected.id = 1
            
            let clinicRouter = PainClinicRouter.details(clinic: clinicExpected)
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<Campfiire.PainClinic> in
                    
                    self.request = Alamofire.request(clinicRouter)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Campfiire.PainClinic>.self)
                    
                }.subscribe(onNext: { clinic in
                    
                    XCTAssertEqual(clinic.id, clinicExpected.id, "clinic must have the same id")
                    XCTAssertNotEqual(clinic.name, "", "clinic must have name")
                    XCTAssertNotEqual(clinic.phoneNumber, "", "clinic must have phoneNumber")
                    XCTAssertNotEqual(clinic.email, "", "clinic must have email")
                    XCTAssertNotEqual(clinic.pictureURL, "", "clinic must have photoURL")
                    
                    XCTAssertGreaterThan(clinic.openingTime.timeIntervalSince1970, 0, "clinic must have opening time")
                    XCTAssertGreaterThan(clinic.closingTime.timeIntervalSince1970, 0, "clinic must have closing time")
                    
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
        
        
    }
    
    func testGetClinics() {
        
        assyncAssert(){ exp in
            let batch = Batch(offset: 2, limit: 10)
            
            let clinicRouter = PainClinicRouter.list(query: "",
                                                       batch: batch)
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[Campfiire.PainClinic]> in
                    
                    self.request = Alamofire.request(clinicRouter)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<Campfiire.PainClinic>.self)
                    
                }.subscribe(onNext: { clinics in
                    
                    XCTAssertLessThan(clinics.count, 10, "We expect not more than 10 clinics")
                    XCTAssertGreaterThan(clinics.count, 0, "We expect at least one clinic for nil query")
                    
                    for clinic in clinics {
                        
                        // XCTAssertNotEqual(doctor.id, 0, "Doctor must have the same id")
                        XCTAssertNotEqual(clinic.name, "", "clinic must have name")
                        XCTAssertNotEqual(clinic.address, "", "clinic must have address")
                        XCTAssertNotEqual(clinic.pictureURL, "", "clinic must have photoURL")
                        // XCTAssertNotNil(doctor.location , "Doctor must have location")
                     
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
             
        }
        
    }
    
    
    func testLikeClinic() {
        
        assyncAssert(){ exp in
            
            var bud = PainClinic.fakeEntity()
            bud.id = 1
            
            let likeRout = PainClinicRouter.like(clinic: bud)
            let unlikeRout = PainClinicRouter.dislike(clinic: bud)
            
            assertCurentUserPresent()
                
                .flatMap { _ in
                    return Alamofire.request(unlikeRout)
                        .rx_campfiireResponse(CampfiireResponse<PainClinic>.self)
                }
                .catchErrorJustReturn(PainClinic.fakeEntity())
                
                .flatMap { _ -> Observable<PainClinic> in
                    
                    self.request = Alamofire.request(likeRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<PainClinic>.self)
                    
                }.subscribe(onNext: { (result) in
                    
                    XCTAssertEqual(result.id, bud.id, "Id is expected to be present")
                    //XCTAssertNotEqual(result.avatar.lengthOfBytes(using: .utf8), 0, "pictureURL is expected to be filled")
                    
                    XCTAssertTrue(result.isLikedByCurrentUser, "User must like this clinic")
                    XCTAssertGreaterThan(result.likes, 0, "We need at least 1 like to be present as we've just liked it")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
    }
    
    func testDislikePainClinic() {
        
        assyncAssert(){ exp in
            
            var bud = PainClinic.fakeEntity()
            bud.id = 1
            
            let unlikeRout = PainClinicRouter.dislike(clinic: bud)
            let likeRout = PainClinicRouter.like(clinic: bud)

            assertCurentUserPresent()
                
                .flatMap { _ in
                    return Alamofire.request(likeRout)
                        .rx_campfiireResponse(CampfiireResponse<PainClinic>.self)
                }
                .catchErrorJustReturn(PainClinic.fakeEntity())

                
                .flatMap { [unowned self] _ -> Observable<PainClinic> in
                    
                    self.request = Alamofire.request(unlikeRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<PainClinic>.self)
                    
                }.subscribe(onNext: { (result) in
                    
                    XCTAssertEqual(result.id, bud.id, "Id should match expected to be present")
                                      
                    XCTAssertFalse(result.isLikedByCurrentUser, "User must unlike this clinic")
                    
                    
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Details - \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
    }
    
    
    
    func testPainClinicMap() {
        
        assyncAssert(){ exp in
            
            let center = CLLocationCoordinate2D(latitude: 30.794248582522617, longitude: 50.11742323766584)
            let location = CLCircularRegion(center: center, radius: 5000, identifier: "location")
            
            let router = PainClinicRouter.map(georegion: location, query: nil)
            
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[PainClinic]> in
                    
                    self.request = Alamofire.request(router)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<PainClinic>.self)
                    
                }.subscribe(onNext: { (response : [PainClinic]) in
                    
                    XCTAssertNotNil(response, "Response can't be empty")
                    
                    for item in response {
                        
                        XCTAssertGreaterThan(item.id, 0, "Id is expected to be present")
                        XCTAssertNotEqual(item.name.lengthOfBytes(using: .utf8), 0, "name is expected to be filled")
                        XCTAssertNotEqual(item.latitude, 0, "latitude is expected to be filled")
                        XCTAssertNotEqual(item.longitude, 0, "longitude is expected to be filled")
                        
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }

}


