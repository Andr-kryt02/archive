////
////  DoctorTests.swift
////  Campfiire
////
////  Created by Anna Gorobchenko on 05.12.16.
////  Copyright © 2016 campfiire. All rights reserved.
////
//
import Foundation
import XCTest
import Alamofire
import RxSwift
import MapKit


@testable import Campfiire

extension DirectoryTests {
    
    func testGetDoctor() {
        
        assyncAssert(){ exp in
            
            var doctorExpected = Doctor(JSON: [:])!
            doctorExpected.id = 1
            
            let doctorRouter = DoctorRouter.details(doctor: doctorExpected)
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<Campfiire.Doctor> in
                    
                    self.request = Alamofire.request(doctorRouter)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Campfiire.Doctor>.self)
                    
                }.subscribe(onNext: { doctor in
                    
                    XCTAssertEqual(doctor.id, doctorExpected.id, "Doctor must have the same id")
                    XCTAssertNotEqual(doctor.name, "", "Doctor must have name")
                    XCTAssertNotEqual(doctor.email, "", "Doctor must have address")
                    XCTAssertGreaterThan(doctor.worksSince.timeIntervalSince1970, 0, "Doctor must have experience")
                    XCTAssertNotEqual(doctor.pictureURL, "", "Doctor must have photoURL")
                    XCTAssertNotEqual(doctor.phoneNumber, "", "Doctor must have phone")
  
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
        
        
    }
    
    func testGetDoctors() {
        
        assyncAssert(){ exp in
            let batch = Batch(offset: 0, limit: 3)

            let doctorRouter = DoctorRouter.list(query: nil,
                                               batch: batch)
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[Campfiire.Doctor]> in
                    
                    self.request = Alamofire.request(doctorRouter)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<Campfiire.Doctor>.self)
                    
                }.subscribe(onNext: { doctors in
                    
                    XCTAssertLessThanOrEqual(doctors.count, batch.limit, "We expect not more than 4 doctors")
                    XCTAssertGreaterThan(doctors.count, 0, "We expect at least one doctor for nil query")
                    
                    for doctor in doctors {
                        
                        XCTAssertNotEqual(doctor.name, "", "Doctor must have name")
                        XCTAssertNotEqual(doctor.specialization, "", "Doctor must have specialization")
                        XCTAssertNotEqual(doctor.pictureURL, "", "Doctor must have photoURL")
        
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
        }
        
    }
    
    
    func testLikeDoctor() {
        
        assyncAssert(){ exp in
            
            var doctor = Doctor(JSON: [:])!
            doctor.id = 1
            
            let likeRout = DoctorRouter.like(doctor: doctor)
            let unlikeRout = DoctorRouter.dislike(doctor: doctor)

            assertCurentUserPresent()
                
                .flatMap { _ in
                    return Alamofire.request(unlikeRout)
                        .rx_campfiireResponse(CampfiireResponse<Doctor>.self)
                }
                .catchErrorJustReturn(Doctor.fakeEntity())
                
                .flatMap { _ -> Observable<Doctor> in
                    
                    self.request = Alamofire.request(likeRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Doctor>.self)
                    
                }.subscribe(onNext: { (result) in
                    
                    XCTAssertEqual(result.id, doctor.id, "Id is expected to be present")
                    XCTAssertNotEqual(result.pictureURL.lengthOfBytes(using: .utf8), 0, "pictureURL is expected to be filled")
                    
                    XCTAssertTrue(result.isLikedByCurrentUser, "User must like this doctor")
                    XCTAssertGreaterThan(result.likes, 0, "We should have at least one like for this doctor")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
    }
    
    func testDislikeDoctor() {
        
        assyncAssert(){ exp in
            
            var doctor = Doctor(JSON: [:])!
            doctor.id = 1
            
            let unlikeRout = DoctorRouter.dislike(doctor: doctor)
            let likeRout = DoctorRouter.like(doctor: doctor)

            assertCurentUserPresent()
                
                .flatMap { _ in
                    return Alamofire.request(likeRout)
                        .rx_campfiireResponse(CampfiireResponse<Doctor>.self)
                }
                .catchErrorJustReturn(Doctor.fakeEntity())
                
                
                .flatMap { [unowned self] _ -> Observable<Doctor> in
                    
                    self.request = Alamofire.request(unlikeRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Doctor>.self)
                    
                }.subscribe(onNext: { (result) in
                    
                    XCTAssertEqual(result.id, doctor.id, "Id should match expected to be present")
                    XCTAssertNotEqual(result.pictureURL.lengthOfBytes(using: .utf8), 0, "avatar is expected to be filled")
                    
                    XCTAssertFalse(result.isLikedByCurrentUser, "User must dislike this doctor")
                    
                  
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
    }
    
    func testDoctorMap() {
        
        assyncAssert(){ exp in
            
            let center = CLLocationCoordinate2D(latitude: 30.794248582522617,
                                                longitude: 50.11742323766584)
            let location = CLCircularRegion(center: center, radius: 5000, identifier: "location")
            
            let router = DoctorRouter.map(georegion: location, query: nil)
            
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[Doctor]> in
                    
                    self.request = Alamofire.request(router)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<Doctor>.self)
                    
                }.subscribe(onNext: { (response : [Doctor]) in
                    
                    XCTAssertNotNil(response, "Response can't be empty")
                    
                    for item in response {
                        
                        XCTAssertGreaterThan(item.id, 0, "Id is expected to be present")
                        XCTAssertNotEqual(item.pictureURL.lengthOfBytes(using: .utf8), 0, "name is expected to be filled")
                        XCTAssertNotEqual(item.latitude, 0, "latitude is expected to be filled")
                        XCTAssertNotEqual(item.longitude, 0, "longitude is expected to be filled")
                        
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
         
        }
        
    }

    
    
}


