//
//  ProducerTests.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 06.12.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import XCTest
import Alamofire
import RxSwift
import CoreLocation
import MapKit

@testable import Campfiire

extension DirectoryTests {
   
    func testGetProducer() {
        
        assyncAssert(){ exp in
            
            var producerExpected = Campfiire.LicensedProducer.fakeEntity()
            producerExpected.id = 1
            
            let producerRouter = LicensedProducerRouter.details(producer: producerExpected)
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<Campfiire.LicensedProducer> in
                    
                    self.request = Alamofire.request(producerRouter)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Campfiire.LicensedProducer>.self)
                    
                }.subscribe(onNext: { producer in
                    
                    XCTAssertEqual(producer.id, producerExpected.id, "producer must have the same id")
                    XCTAssertNotEqual(producer.name, "", "producer must have name")
                    XCTAssertNotEqual(producer.phoneNumber, "", "producer must have phoneNumber")
                    XCTAssertNotEqual(producer.email, "", "producer must have email")
                    XCTAssertNotEqual(producer.pictureURL, "", "producer must have photoURL")
                    XCTAssertGreaterThanOrEqual(producer.likes, 0, "producer must have rating")
                    XCTAssertNotEqual(producer.website, "", "producer must have website")
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
        
        
    }
    
    func testGetProducers() {
        
        assyncAssert(){ exp in
            let batch = Batch(offset: 2, limit: 10)
            
            let producerRouter = LicensedProducerRouter.list(query: nil,
                                                             batch: batch)
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[Campfiire.LicensedProducer]> in
                    
                    self.request = Alamofire.request(producerRouter)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<Campfiire.LicensedProducer>.self)
                    
                }.subscribe(onNext: { producers in
                    
                    XCTAssertLessThanOrEqual(producers.count, 10, "We expect not more than 10 producers")
                    XCTAssertGreaterThan(producers.count, 0, "We expect at least one producer for nil query")
                    
                    for producer in producers {
                        
                        // XCTAssertNotEqual(doctor.id, 0, "Doctor must have the same id")
                        XCTAssertNotEqual(producer.name, "", "producer must have name")
                        XCTAssertNotEqual(producer.address, "", "producer must have address")
                        XCTAssertNotEqual(producer.pictureURL, "", "producer must have photoURL")
                        // XCTAssertNotNil(doctor.location , "Doctor must have location")
                        
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }
    
    
    func testLikeProducer() {
        
        assyncAssert(){ exp in
            
            var producer = LicensedProducer.fakeEntity()
            producer.id = 1
            
            let likeRout = LicensedProducerRouter.like(producer: producer)
            let unlikeRout = LicensedProducerRouter.dislike(producer: producer)
            
            assertCurentUserPresent()
                
                .flatMap { _ in
                    return Alamofire.request(unlikeRout)
                        .rx_campfiireResponse(CampfiireResponse<LicensedProducer>.self)
                }
                .catchErrorJustReturn(LicensedProducer.fakeEntity())

                
                .flatMap { _ -> Observable<LicensedProducer> in
                    
                    self.request = Alamofire.request(likeRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<LicensedProducer>.self)
                    
                }.subscribe(onNext: { (result) in
                    
                    XCTAssertEqual(result.id, producer.id, "Id is expected to be present")
                    //XCTAssertNotEqual(result.avatar.lengthOfBytes(using: .utf8), 0, "pictureURL is expected to be filled")
                    
                    XCTAssertTrue(result.isLikedByCurrentUser, "User must like this producer")
                    XCTAssertGreaterThan(result.likes, 0, "We need at least 1 like to be present as we've just liked it")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
    }
    
    func testDislikeProducer() {
        
        assyncAssert(){ exp in
            
            var producer = LicensedProducer.fakeEntity()
            producer.id = 1
            
            let unlikeRout = LicensedProducerRouter.dislike(producer: producer)
            let likeRout = LicensedProducerRouter.like(producer: producer)

            assertCurentUserPresent()
                
                .flatMap { _ in
                    return Alamofire.request(likeRout)
                        .rx_campfiireResponse(CampfiireResponse<LicensedProducer>.self)
                }
                .catchErrorJustReturn(LicensedProducer.fakeEntity())

                
                .flatMap { [unowned self] _ -> Observable<LicensedProducer> in
                    
                    self.request = Alamofire.request(unlikeRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<LicensedProducer>.self)
                    
                }.subscribe(onNext: { (result) in
                    
                    XCTAssertEqual(result.id, producer.id, "Id should match expected to be present")
                    //XCTAssertNotEqual(result.avatar.lengthOfBytes(using: .utf8), 0, "avatar is expected to be filled")
                    
                    XCTAssertFalse(result.isLikedByCurrentUser, "User must like this producer")
                    
                    
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
    }
    
    
    func testProducerMap() {
        
        assyncAssert(){ exp in
            
            let center = CLLocationCoordinate2D(latitude: 30.794248582522617, longitude: 50.11742323766584)
            let location = CLCircularRegion(center: center, radius: 5000, identifier: "location")
            
            let router = LicensedProducerRouter.map(georegion: location, query: nil)
            
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[LicensedProducer]> in
                    
                    self.request = Alamofire.request(router)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<LicensedProducer>.self)
                    
                }.subscribe(onNext: { (response : [LicensedProducer]) in
                    
                    XCTAssertNotNil(response, "Response can't be empty")
                    
                    for item in response {
                        
                        XCTAssertGreaterThan(item.id, 0, "Id is expected to be present")
                        XCTAssertNotEqual(item.name.lengthOfBytes(using: .utf8), 0, "name is expected to be filled")
                        XCTAssertNotEqual(item.latitude, 0, "latitude is expected to be filled")
                        XCTAssertNotEqual(item.longitude, 0, "longitude is expected to be filled")
                        
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }

    
    
    
}


