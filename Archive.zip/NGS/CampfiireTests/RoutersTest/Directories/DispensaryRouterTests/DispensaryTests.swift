//
//  DispensaryTests.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 06.12.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import XCTest
import Alamofire
import RxSwift
import MapKit

@testable import Campfiire

extension DirectoryTests {
    
    func testGetDispensary() {
        
        assyncAssert(){ exp in
            
            var dispensaryExpected = Campfiire.Dispensary.fakeEntity()
            dispensaryExpected.id = 1
            
            let dispensaryRouter = DispensaryRouter.details(dispensary: dispensaryExpected)
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<Campfiire.Dispensary> in
                    
                    self.request = Alamofire.request(dispensaryRouter)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Campfiire.Dispensary>.self)
                    
                }.subscribe(onNext: { dispensary in
                    
                    XCTAssertEqual(dispensary.id, dispensaryExpected.id, "dispensary must have the same id")
                    XCTAssertNotEqual(dispensary.name, "", "dispensary must have name")
                    XCTAssertNotEqual(dispensary.phoneNumber, "", "dispensary must have phoneNumber")
                    XCTAssertNotEqual(dispensary.email, "", "dispensary must have email")
                    XCTAssertNotEqual(dispensary.pictureURL, "", "dispensary must have photoURL")
                    
                    XCTAssertGreaterThan(dispensary.openingTime.timeIntervalSince1970, 0, "dispensary must have opening time")
                    XCTAssertGreaterThan(dispensary.closingTime.timeIntervalSince1970, 0, "dispensary must have closing time")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
        
        
    }
    
    func testGetDispensaries() {
        
        assyncAssert(){ exp in
            let batch = Batch(offset: 0, limit: 10)
            
            let dispensaryRouter = DispensaryRouter.list(query: nil,
                                                        batch: batch)
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[Campfiire.Dispensary]> in
                    
                    self.request = Alamofire.request(dispensaryRouter)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<Campfiire.Dispensary>.self)
                    
                }.subscribe(onNext: { dispensaries in
                    //                    defer {
                    //                        exp.fulfill()
                    //                    }
                    //
                    
                    XCTAssertLessThan(dispensaries.count, 10, "We expect not more than 10 dispensaries")
                    XCTAssertGreaterThan(dispensaries.count, 0, "We expect at least one dispensary for nil query")
                    
                    for dispensary in dispensaries {
                        
                        // XCTAssertNotEqual(doctor.id, 0, "Doctor must have the same id")
                        XCTAssertNotEqual(dispensary.name, "", "dispensary must have name")
                        XCTAssertNotEqual(dispensary.address, "", "dispensary must have address")
                        XCTAssertNotEqual(dispensary.pictureURL, "", "dispensary must have logo")
                        // XCTAssertNotNil(doctor.location , "Doctor must have location")
                        
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }
    
    
    func testLikeDispensary() {
        
        assyncAssert(){ exp in
            
            var dispensary = Dispensary.fakeEntity()
            dispensary.id = 1
            
            let likeRout = DispensaryRouter.like(dispensary: dispensary)
            let unlikeRout = DispensaryRouter.dislike(dispensary: dispensary)
            
            assertCurentUserPresent()
                .flatMap { _ -> Observable<Dispensary> in
                    
                    return Alamofire.request(unlikeRout)
                        .rx_campfiireResponse(CampfiireResponse<Dispensary>.self)
                }
                .catchErrorJustReturn(Dispensary.fakeEntity())
                
                .flatMap { _ -> Observable<Dispensary> in
                    
                    self.request = Alamofire.request(likeRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Dispensary>.self)
                    
                }.subscribe(onNext: { (result) in
                    
                    XCTAssertEqual(result.id, dispensary.id, "Id is expected to be present")
                    //XCTAssertNotEqual(result.avatar.lengthOfBytes(using: .utf8), 0, "pictureURL is expected to be filled")
                    
                    XCTAssertTrue(result.isLikedByCurrentUser, "User must like this dispensary")
                    XCTAssertGreaterThan(result.likes, 0, "We need at least 1 like to be present as we've just liked it")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
    }
    
    func testDislikeDispensary() {
        
        assyncAssert(){ exp in
            
            var dispensary = Dispensary.fakeEntity()
            dispensary.id = 1
            
            let unlikeRout = DispensaryRouter.dislike(dispensary: dispensary)
            let likeRout = DispensaryRouter.like(dispensary: dispensary)
            
            assertCurentUserPresent()
                
                .flatMap { _ in
                    return Alamofire.request(likeRout)
                        .rx_campfiireResponse(CampfiireResponse<Dispensary>.self)
                }
                .catchErrorJustReturn(Dispensary.fakeEntity())
                
                .flatMap { [unowned self] _ -> Observable<Dispensary> in
                    
                    self.request = Alamofire.request(unlikeRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Dispensary>.self)
                    
                }.subscribe(onNext: { (result) in
                    
                    XCTAssertEqual(result.id, dispensary.id, "Id should match expected to be present")
                    //XCTAssertNotEqual(result.avatar.lengthOfBytes(using: .utf8), 0, "avatar is expected to be filled")
                    
                    XCTAssertFalse(result.isLikedByCurrentUser, "User must dislike this dispensary")
                    
                    
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
    }
    
    
    func testDispensaryMap() {
        
        assyncAssert(){ exp in
            
            let router = DispensaryRouter.map(georegion: MKCoordinateRegion.worldRegion.circularApproximation,
                                              query: nil)
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[Dispensary]> in
                    
                    self.request = Alamofire.request(router)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<Dispensary>.self)
                    
                }.subscribe(onNext: { (response : [Dispensary]) in
                    
                    XCTAssertGreaterThan(response.count, 0, "We expect at least one dispensary for nil query")
                    
                    for item in response {
                        
                        XCTAssertGreaterThan(item.id, 0, "Id is expected to be present")
                        XCTAssertNotEqual(item.name.lengthOfBytes(using: .utf8), 0, "name is expected to be filled")
                        XCTAssertNotNil(item.latitude, "latitude is expected to be filled")
                        XCTAssertNotNil(item.longitude, "longitude is expected to be filled")
                        
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
        }
        
    }

}


