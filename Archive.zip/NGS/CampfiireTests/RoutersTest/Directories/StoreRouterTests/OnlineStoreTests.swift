//
//  OnlineStoreTests.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 06.12.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import XCTest
import Alamofire
import RxSwift

@testable import Campfiire

extension DirectoryTests {
    
    func testGetStore() {
        
        assyncAssert(){ exp in
            
            var storeExpected = Campfiire.OnlineStore.fakeEntity()
            storeExpected.id = 1
            
            let clinicRouter = OnlineStoreRouter.details(store: storeExpected)
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<Campfiire.OnlineStore> in
                    
                    self.request = Alamofire.request(clinicRouter)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Campfiire.OnlineStore>.self)
                    
                }.subscribe(onNext: { store in
                    
                    XCTAssertEqual(store.id, storeExpected.id, "Store must have the same id")
                    XCTAssertNotEqual(store.name, "", "Store must have name")
                    XCTAssertNotEqual(store.phoneNumber, "", "Store must have phoneNumber")
                    XCTAssertNotEqual(store.email, "", "Store must have email")
                    XCTAssertNotEqual(store.pictureURL, "", "Store must have photoURL")
                    XCTAssertNotEqual(store.website, "", "Store must have website")

                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
        
        
    }
    
    func testGetStores() {
        
        assyncAssert(){ exp in
            let batch = Batch(offset: 0, limit: 10)
            
            let storeRouter = OnlineStoreRouter.list(query: "",
                                                   batch: batch)
            
            let _ =
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[Campfiire.OnlineStore]> in
                    
                    self.request = Alamofire.request(storeRouter)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<Campfiire.OnlineStore>.self)
                    
                }.subscribe(onNext: { stores in
                    
                    XCTAssertLessThan(stores.count, 10, "We expect not more than 10 stores")
                    XCTAssertGreaterThan(stores.count, 0, "We expect at least one store for nil query")
                    
                    for store in stores {
                        
                        // XCTAssertNotEqual(doctor.id, 0, "Doctor must have the same id")
                        XCTAssertNotEqual(store.name, "", "store must have name")
                        XCTAssertNotEqual(store.website, "", "store must have address")
                        //XCTAssertNotEqual(clinic.logo, "", "clinic must have photoURL")
                        // XCTAssertNotNil(doctor.location , "Doctor must have location")
                        
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                })
            
        }
        
    }
    
    
    func testLikeStore() {
        
        assyncAssert(){ exp in
            
            var store = OnlineStore.fakeEntity()
            store.id = 1
            
            let likeRout = OnlineStoreRouter.like(store: store)
            let unlikeRout = OnlineStoreRouter.dislike(store: store)
            assertCurentUserPresent()
                
                .flatMap { _ in
                    return Alamofire.request(unlikeRout)
                        .rx_campfiireResponse(CampfiireResponse<OnlineStore>.self)
                }
                .catchErrorJustReturn(OnlineStore.fakeEntity())
                .flatMap { _ -> Observable<OnlineStore> in
                    
                    self.request = Alamofire.request(likeRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<OnlineStore>.self)
                    
                }.subscribe(onNext: { (result) in
                    
                    XCTAssertEqual(result.id, store.id, "Id is expected to be present")
                    //XCTAssertNotEqual(result.avatar.lengthOfBytes(using: .utf8), 0, "pictureURL is expected to be filled")
                    
                    XCTAssertTrue(result.isLikedByCurrentUser, "User must like this store")
                    XCTAssertGreaterThan(result.likes, 0, "We need at least 1 like to be present as we've just liked it")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
    }
    
    func testDislikeStore() {
        
        assyncAssert(){ exp in
            
            var store = OnlineStore.fakeEntity()
            store.id = 1
            
            let unlikeRout = OnlineStoreRouter.dislike(store: store)
            let likeRout = OnlineStoreRouter.like(store: store)

            assertCurentUserPresent()
                
                .flatMap { _ in
                    return Alamofire.request(likeRout)
                        .rx_campfiireResponse(CampfiireResponse<OnlineStore>.self)
                }
                .catchErrorJustReturn(OnlineStore.fakeEntity())
                
                .flatMap { [unowned self] _ -> Observable<OnlineStore> in
                    
                    self.request = Alamofire.request(unlikeRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<OnlineStore>.self)
                    
                }.subscribe(onNext: { (result) in
                    
                    XCTAssertEqual(result.id, store.id, "Id should match expected to be present")
                    //XCTAssertNotEqual(result.avatar.lengthOfBytes(using: .utf8), 0, "avatar is expected to be filled")
                    
                    XCTAssertFalse(result.isLikedByCurrentUser, "User must unlike this store")
                    
                    
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
    }
}
