//
//  EventRouterTest.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/4/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import XCTest
import Alamofire
import RxSwift


@testable import Campfiire

class EventTests: XCTestCase {
    
    var request: DataRequest! = nil

    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testGetEvent() {
        
        assyncAssert(){ exp in
            
            var eventWithId = Campfiire.Event.fakeEntity()
            eventWithId.id = 2
            
            let eventRout = EventRouter.details(event: eventWithId)
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<Campfiire.Event> in
                    
                    self.request = Alamofire.request(eventRout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Campfiire.Event>.self)
                    
                }.subscribe(onNext: { event in
                    
                    XCTAssertEqual(event.id, eventWithId.id, "Event must have the same id")
                    XCTAssertNotEqual(event.name, "", "Event must have name")
                    XCTAssertNotEqual(event.location, "", "Event must have location")
                    XCTAssertNotEqual(event.date.timeIntervalSince1970, 0, "Event must have date")
                    XCTAssertNotEqual(event.photoURL, "", "Event must have photoURL")
                    XCTAssertNotNil(event.description , "Event must have description")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        

        
    }
    
    func testGetEvents() {
        
        assyncAssert(){ exp in
           
            let eventRouter = EventRouter.list(date: nil,
                                               batch: Batch(offset: 0, limit: 10))
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[Campfiire.Event]> in
                    
                    self.request = Alamofire.request(eventRouter)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<Campfiire.Event>.self)
                    
                }.subscribe(onNext: { events in
                    
                    XCTAssertLessThan(events.count, 10, "We expect not more than 10 events")
                    XCTAssertGreaterThan(events.count, 0, "We expect at least one event for nil date")
                    
                    for event in events {
                        
                        XCTAssertNotEqual(event.id, 0, "Event must have the same id")
                        XCTAssertNotEqual(event.name, "", "Event must have name")
                        XCTAssertNotEqual(event.location, "", "Event must have location")
                        XCTAssertNotEqual(event.date.timeIntervalSince1970, 0, "Event must have date")
                        XCTAssertNotEqual(event.photoURL, "", "Event must have photoURL")
                        
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }

    }
    
    func testGetEventsByDate() {
        
        assyncAssert(){ exp in
            
            let df = DateFormatter()
            df.dateFormat = "YYYY.MM.dd"
            let date = df.date(from: "2016.12.23")
            
            let eventRouter = EventRouter.list(date: date,
                                               batch: Batch(offset: 0, limit: 10))
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[Campfiire.Event]> in
                    
                    self.request = Alamofire.request(eventRouter)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<Campfiire.Event>.self)
                    
                }.subscribe(onNext: { events in
                    
                    XCTAssertLessThan(events.count, 10, "We expect not more than 10 events")
                    XCTAssertGreaterThan(events.count, 0, "We expect at least one event for nil date")
                    
                    for event in events {
                        
                        XCTAssertNotEqual(event.id, 0, "Event must have the same id")
                        XCTAssertNotEqual(event.name, "", "Event must have name")
                        XCTAssertNotEqual(event.location, "", "Event must have location")
                        XCTAssertNotEqual(event.date.timeIntervalSince1970, 0, "Event must have date")
                        XCTAssertNotEqual(event.photoURL, "", "Event must have photoURL")
                        
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Response returned error. Details - \(error). Request - \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
            
            
        }
    }

    
    
}
