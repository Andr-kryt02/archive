//
//  MMjRouterTests.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 2016-12-19.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

import XCTest
import Alamofire
import RxSwift


@testable import Campfiire

class MMJRTests: XCTestCase {
    
 
    var userLogIn : User?
    var request: DataRequest! = nil
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    
    func testList(){
        
        assyncAssert() { exp in
            
            // uncomment to use real router for real requests
            
            //let mmjRout = SimpleRouter.mmj(query: nil,
            //                            batch: Batch(offset: 0,limit: 5))
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[MMJ]> in
                    
                    self.userLogIn = user
                   // self.request = Alamofire.request(campRout)
                    
                    //return self.request
                        //.rx_campfiireResponse(CampfiireArrayResponse<MMJ>.self)
                    
                    return MMJ.retrieveWebNews(query: nil, batch: Batch(offset: 0,limit: 5))
                    
                }.subscribe(onNext: { (response) in
                    
                    XCTAssertGreaterThanOrEqual(response.count, 1, "We expect more than 1 mmj")
                    XCTAssertLessThanOrEqual(response.count, 5, "We don't expect more than 5 mmj")
                    
                    for item in response {
                        
                        XCTAssertGreaterThan(item.id, 0, "id are expected to be filled")
                        XCTAssertNotEqual(item.title.lengthOfBytes(using: .utf8), 0, "title are expected to be filled")
                        XCTAssertNotNil(item.text, "Text are expected to be filled. \(item)")
                        XCTAssertNotEqual(item.pictureURL, "", "We expect pictureURL to be filled")
                        XCTAssertNotEqual(item.url, "", "We expect url to be filled")
                        
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Request: \(self.request) returned error . Details - \(error)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }
    
}
