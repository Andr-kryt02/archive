//
//  CommentRouterTests.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/25/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import XCTest
import Alamofire
import RxSwift


@testable import Campfiire

extension CampTests { //CommentRouterTests
    
    func testCreateComment() {
        
        assyncAssert(){ exp in
            
            guard let camp = Camp(JSON: ["id" : 3]) else {
                XCTFail("Can't create user.")
                return
            }
            
            let commentString = Comment.fakeString()
            
            let commentRouter = CampRouter.postComment(camp: camp, text: commentString)
            
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<Comment> in
                    
                    self.request = Alamofire.request(commentRouter)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Comment>.self)
                    
                }.flatMap { (comment) -> Observable<Camp> in
                    
                    XCTAssertGreaterThan(comment.id, 0, "id are expected to be filled")
                    
                    XCTAssertEqual(comment.text, commentString, "Comment musts be the same.")
                    XCTAssertNotEqual(comment.text.lengthOfBytes(using: .utf8), 0, "title are expected to be filled")
                    
                    XCTAssertNotNil(comment.author, "We expect author to be present")
                    
                    return Alamofire.request(CampRouter.details(camp: camp))
                            .rx_campfiireResponse(CampfiireResponse<Camp>.self)
                }
                .subscribe(onNext: { camp in
                    
                    XCTAssertGreaterThan(camp.totalComments, 0, "Since we posted ")
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    XCTFail("Details - \(error). Request: \(self.request) returned error.")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }
    
    func testCommentList(){
        
        assyncAssert(){ exp in
            
            guard let camp = Camp(JSON: ["id" : 3]) else {
                XCTFail("Can't create user.")
                return
            }
            
            let batch = Batch(offset: 0, limit: 1)
            
            let commentRouter = CampRouter.commentsList(camp: camp, batch: batch)
            
            assertCurentUserPresent()
                .flatMap{ user -> Observable<[Comment]> in
                    
                    self.request = Alamofire.request(commentRouter)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireArrayResponse<Comment>.self)
                    
                }.subscribe(onNext: { response in
                    
                    XCTAssertLessThanOrEqual(response.count, batch.limit)
                    
                    for item in response {
                        
                        XCTAssertGreaterThan(item.id, 0, "id are expected to be filled")
                        XCTAssertNotEqual(item.text.lengthOfBytes(using: .utf8), 0, "title are expected to be filled")
                        XCTAssertNotNil(item.author, "We expect author to be present")
                        
                        break
                        
                    }
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    XCTFail("Request: \(self.request) returned error . Details - \(error)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
        
    }
}

extension HotSpotTets {
    
    func testCreateComment() {
        
        assyncAssert(){ exp in
            
            guard let hotSpotWithId = HotSpot(JSON: ["id" : 1]) else {
                XCTFail("Can't initialize HotSpot")
                return
            }
            
            var author : User! = nil
            let text = HotSpot.fakeString()
            
            let rout = HotspotRouter.postComment(hotspot: hotSpotWithId, text: text)
            
            assertCurentUserPresent()
                .flatMap{ resp -> Observable<Comment> in
                    
                    author = resp
                    
                    self.request = Alamofire.request(rout)
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<Comment>.self)
                    
                }.subscribe(onNext: { comment in
                    
                    XCTAssertGreaterThan(comment.id, 0, "Id is expected to be present")
                    XCTAssertNotEqual(comment.text.lengthOfBytes(using: .utf8), 0, "text is expected to be filled")
                    XCTAssertEqual(comment.text, text, "Text must be equals")
                    XCTAssertGreaterThan(comment.date, Date(timeIntervalSince1970: 0), "date is expected to be present")
                    
                    XCTAssertEqual(author, comment.author)
                    
                    exp.fulfill()
                    
                }, onError: { error in
                    
                    XCTFail("Error has occurred. Details - \(error). \nResponse: \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(rx_disposeBag)
            
        }
    }
    
    func testCommentList() {
        
        assyncAssert(){ [unowned self] exp in
            
            guard let hotSpotWithId = HotSpot(JSON: ["id" : 1]) else {
                XCTFail("Can't initialize HotSpot")
                return
            }
            
            let batch = Batch(offset: 0, limit: 5)
            
            
            self.assertCurentUserPresent()
                .flatMap{ user -> Observable<CommentListRepsonse> in
                    
                    self.request = Alamofire.request(HotspotRouter.commentsList(hotspot: hotSpotWithId, batch: batch))
                    
                    return self.request
                        .rx_campfiireResponse(CampfiireResponse<CommentListRepsonse>.self)
                    
                }.subscribe(onNext: { response in
                    
                    defer {
                        exp.fulfill()
                    }
                    
                    guard let comments = response.comments else {
                        XCTFail("We expect comments to be present in response")
                        return
                    }
                    
                    XCTAssertLessThanOrEqual(comments.count, batch.limit, "We don't expect more than \(batch.limit) comment")
                    
                    for item in comments {
                        
                        XCTAssertGreaterThan(item.id, 0, "Id is expected to be present")
                        XCTAssertNotEqual(item.text.lengthOfBytes(using: .utf8), 0, "text is expected to be filled")
                        XCTAssertGreaterThan(item.date, Date(timeIntervalSince1970: 0), "date is expected to be present")
                        
                        guard let author = item.author else {
                            XCTFail("comment author is expected to be present")
                            return
                        }
                        
                        XCTAssertNotEqual(author.name.lengthOfBytes(using: .utf8), 0, "author's name is expected to be filled")
                        
                    }
                    
                }, onError: { error in
                    
                    XCTFail("Error has occurred. Details - \(error). \nRequest: \(self.request)")
                    exp.fulfill()
                    
                }).addDisposableTo(self.rx_disposeBag)
            
        }
    }
    
}
