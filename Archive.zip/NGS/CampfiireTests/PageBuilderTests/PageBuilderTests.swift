//
//  PageBuilderTests.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/1/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import XCTest

@testable import Campfiire

class PageBuilderTests: XCTestCase {
    
    
    override func setUp() {
        super.setUp()
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testPagesCount() {
        
        var camp = Camp.fakeEntity()

        camp.totalComments = 0
        var pb = CampPageBuilder(camp: camp)
        XCTAssertEqual(pb.pagesCount, 1, "No comments should result in 1 page")
        
        camp.totalComments = 1
        pb = CampPageBuilder(camp: camp)
        XCTAssertEqual(pb.pagesCount, 1, "One comments should result in 1 page")
        
        camp.totalComments = CampPageBuilder.postsPerPage
        pb = CampPageBuilder(camp: camp)
        XCTAssertEqual(pb.pagesCount, 1, "\(camp.totalComments) comments should result in 1 page")
        
        camp.totalComments = CampPageBuilder.postsPerPage + 1
        pb = CampPageBuilder(camp: camp)
        XCTAssertEqual(pb.pagesCount, 2, "\(camp.totalComments) comments should result in 2 pages")
        
        camp.totalComments = CampPageBuilder.postsPerPage * 2
        pb = CampPageBuilder(camp: camp)
        XCTAssertEqual(pb.pagesCount, 2, "\(camp.totalComments) comments should result in 2 pages")
        
        camp.totalComments = CampPageBuilder.postsPerPage * 23
        pb = CampPageBuilder(camp: camp)
        XCTAssertEqual(pb.pagesCount, 23, "\(camp.totalComments) comments should result in 23 pages")
        
        camp.totalComments = CampPageBuilder.postsPerPage * 23 + 1
        pb = CampPageBuilder(camp: camp)
        XCTAssertEqual(pb.pagesCount, 24, "\(camp.totalComments) comments should result in 24 pages")
        
    }
    
    func testPageBatching() {
        
        var camp = Camp.fakeEntity()
        
        camp.totalComments = 0
        var pb = CampPageBuilder(camp: camp)
        var b: Batch! = pb.networkBatch(for: 1)
        XCTAssertNil(b, "No batch can be generated for empty commetns")
        
        camp.totalComments = 2
        pb = CampPageBuilder(camp: camp)
        b = pb.networkBatch(for: 2)
        XCTAssertNil(b, "No batch can be generated for commetns amount 2 => pages 1 => requested page 2")
        b = pb.networkBatch(for: 1)
        XCTAssertEqual(b.limit, 2, "Limit should not be greater than piece of comments in the page")
        XCTAssertEqual(b.offset, 0, "Offset is 0 since we had initial page")
        
        camp.totalComments = CampPageBuilder.postsPerPage
        pb = CampPageBuilder(camp: camp)
        b = pb.networkBatch(for: 2)
        XCTAssertNil(b, "No batch can be generated for commetns amount \(camp.totalComments) => pages 1 => requested page 2")
        b = pb.networkBatch(for: 1)
        XCTAssertEqual(b.limit, CampPageBuilder.postsPerPage, "Limit should not be greater than piece of comments in the page")
        XCTAssertEqual(b.offset, 0, "Offset is 0 since we had initial page")
        
        camp.totalComments = 218
        pb = CampPageBuilder(camp: camp)
        b = pb.networkBatch(for: 1)
        XCTAssertEqual(b.limit, CampPageBuilder.postsPerPage, "Limit should not be greater than number of pages")
        XCTAssertEqual(b.offset, 0, "Offset is 0 since we had initial page")
        b = pb.networkBatch(for: 17)
        XCTAssertEqual(b.limit, CampPageBuilder.postsPerPage, "Limit should not be greater than number of pages")
        XCTAssertEqual(b.offset,CampPageBuilder.postsPerPage * 16, "Offset is \(CampPageBuilder.postsPerPage * 16) since we had page # 17")
        
    }
 
    func testCampPageBuilding() {
        
        var camp = Camp.fakeEntity()
        
        ////empty set
        camp.totalComments = 0
        var pb = CampPageBuilder(camp: camp)
        var page: CampPage! = pb.campPage(at: 1, comments: [])
        XCTAssertNotNil(page, "No comments page is a valid page")
        XCTAssertNil(page.nextPageNumber, "Single page does not have nextNumber")
        XCTAssertNil(page.previousPageNumber, "Single page does not have prevNumber")
        XCTAssertEqual(page.pageNumber, 1, "Single page has 1 as it's number")
        
        ///stacked set
        camp.totalComments = CampPageBuilder.postsPerPage * 23 + 1
        pb = CampPageBuilder(camp: camp)
        
        ///page 1
        page = pb.campPage(at: 1, comments: [])
        XCTAssertNotNil(page, "First page must be present")
        XCTAssertNotNil(page.nextPageNumber, "Single page must have nextNumber")
        XCTAssertEqual(page.nextPageNumber!, 2, "Page after number 1 is 2")
        XCTAssertNil(page.previousPageNumber, "First page does not have prevNumber")
        XCTAssertEqual(page.pageNumber, 1, "First page has 1 as it's number")
        
        
        ///page middle
        page = pb.campPage(at: 12, comments: [])
        XCTAssertNotNil(page, "12 page must be present")
        
        XCTAssertNotNil(page.nextPageNumber, "Middle pages must have nextNumber")
        XCTAssertEqual(page.nextPageNumber!, 13, "Page after number 12 is 13")
        
        XCTAssertNotNil(page.previousPageNumber, "Middle pages must have prevNumber")
        XCTAssertEqual(page.previousPageNumber!, 11, "Page before number 12 is 11")
        
        XCTAssertEqual(page.pageNumber, 12, "First page has 1 as it's number")
        
        ////page last
        page = pb.campPage(at: 24, comments: [])
        XCTAssertNotNil(page, "Last page must be present")
        
        XCTAssertNil(page.nextPageNumber, "Last page must not have nextNumber")
        
        XCTAssertNotNil(page.previousPageNumber, "Last pages must have prevNumber")
        XCTAssertEqual(page.previousPageNumber!, 23, "Page before number 24 is 23")
        
        XCTAssertEqual(page.pageNumber, 24, "Last page has 24 as it's number")
    }
    
}
