//
//  AppDelegate.swift
//  Campfiire
//
//  Created by Vlad Soroka on 9/28/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import UIKit

import XMPPFramework

////TODO: |Ann, low| immprove bundle size

///We can reduce assets catalog by storing only the biggest header file and scaling it dynamically for all other headers

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, XMPPStreamDelegate, XMPPMUCDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        DDLog.add(DDTTYLogger.sharedInstance(), with: DDLogLevel.all)
        
        AppConfiguration.setUpServices()
        
        UIConfiguration.setUp()
        
        MainViewModel.shared.router.initialRoutForWindow(window: window)
         
        ///should be called after initial rout is established.
        ///application might have been launched from notification
        NotificationManager.setup(launchOptions: launchOptions)
        
        return true
    }
    
    func application(_ application: UIApplication,
                     didReceiveRemoteNotification userInfo: [AnyHashable : Any]) {
        NotificationManager.handleRemoteNotification(notificationPayload: userInfo,
                                                     applicationState: application.applicationState)
    }
    
    func application(_ application: UIApplication,
                     didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        NotificationManager.handleDeviceToken(tokenData: deviceToken)
    }

    
    func sendMessage() {
        
        //let messageStr = "testMessage"
        
//        let body: DDXMLElement = DDXMLElement(name: "body", stringValue: messageStr)
//        
//        let message: DDXMLElement = DDXMLElement(name: "message")
//        message.addAttribute(withName: "type", stringValue: "chat")
//        message.addAttribute(withName: "to", stringValue: "148@campfiire")
//        
//        message.addChild(body)
//        
//        xmppStream.send(message)

//        <iq type='set' id='juliet1'>
//        <query xmlns='urn:xmpp:mam:1' queryid='f27' />
//        </iq>
        

        
        
//        <iq from='hag66@shakespeare.lit/pda'
//        id='h7ns81g'
//        to='shakespeare.lit'
//        type='get'>
//        <query xmlns='http://jabber.org/protocol/disco#items'/>
//        </iq>
        
        //let q: DDXMLElement = DDXMLElement(name: "list", xmlns: "urn:xmpp:archive")
        
         //try! DDXMLElement(xmlString: "<iq type='get' id='321'><pref xmlns='urn:xmpp:archive'></pref></iq>")
//            DDXMLElement(name: "query")
//        q.addAttribute(withName: "xmlns", stringValue: "urn:xmpp:mam:tmp")
//        //q.addAttribute(withName: "queryid", stringValue: "f27")
//        
        //let iq = XMPPIQ(type: "get", elementID: "123", child: q)
//        
        //xmppStream.send(iq)
        
        
        
        //muc.discoverRooms(forServiceNamed: "conference.campfiire")
        
        
    }
    
    func xmppMUC(_ sender: XMPPMUC!, didDiscoverRooms rooms: [Any]!, forServiceNamed serviceName: String!) {
        print(rooms)
        print(serviceName)
    }
    
    func xmppMUC(_ sender: XMPPMUC!, failedToDiscoverRoomsForServiceNamed serviceName: String!, withError error: Error!) {
        print(error)
    }
    
    
    func xmppStream(_ sender: XMPPStream!, didReceive iq: XMPPIQ!) -> Bool {
        
        print(iq)
        
        return true
    }
    
    func xmppStream(_ sender: XMPPStream!, didReceive message: XMPPMessage!) {
        
        // message received
//        let msg: String = message.body()
//        let from: String = message.from().user
//        
        print("Received message '\(message)'")
        
    }
    
    func xmppStream(_ sender: XMPPStream!, didReceive presence: XMPPPresence!) {
        
        // a buddy went offline/online
        let presenceType: String = presence.type() // online/offline
        let myUsername: String = sender.myJID.user
        let presenceFromUser: String = presence.from().user
        
        if presenceFromUser != myUsername {
            
            if (presenceType == "available") {
                
                ///online
                
            } else if presenceType == "unavailable" {
                
                ///offline
                
            }
            
        }
        
    }

    func application(_ app: UIApplication,
                     open url: URL,
                     options: [UIApplicationOpenURLOptionsKey: Any]) -> Bool {
        return Simplicity.application(app, open: url, options: options)
    }
    
    func application(_ application: UIApplication,
                     open url: URL,
                     sourceApplication: String?,
                     annotation: Any) -> Bool {
        return Simplicity.application(application, open: url, sourceApplication: sourceApplication, annotation: annotation)
    }

}

