//
//  CampPage.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/19/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift

struct CampPage {
    
    var previousPageNumber: Int?
    var pageNumber: Int = -1
    var nextPageNumber: Int?
    
    var comments: [Comment] = []

    
}

extension CampPage: Fakeble {
    
    static func fakeEntity() -> CampPage {
        return fakeEntity(forPage: fakeNumber(bound: 5), totalPages: 5)
    }
    
    static func fakeEntity(forPage number: Int, totalPages: Int) -> CampPage {
        
        var page = CampPage()
        
        page.comments = [Comment.fakeEntity(picturesPossible: true),
                         Comment.fakeEntity(picturesPossible: true),
                         Comment.fakeEntity(picturesPossible: true),
                         Comment.fakeEntity(picturesPossible: true),
                         Comment.fakeEntity(picturesPossible: true)]
        
        page.pageNumber = number
        
        if number > 1 { page.previousPageNumber = number - 1 }
        if number < totalPages { page.nextPageNumber = number + 1 }
        
        return page
    }
    
}
