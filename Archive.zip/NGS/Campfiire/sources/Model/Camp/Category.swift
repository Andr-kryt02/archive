//
//  Category.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/22/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

extension Camp {

    enum Category: Int, CustomStringConvertible {
        
        case other = 1
        case sports = 2
        case club = 3
        case food = 4
        case services = 5
        case entertainment = 6
        case art = 7
        case music = 8
        
        
        var description: String {
            switch self {
            case .other: return "Other"
            case .sports: return "Sports"
            case .club: return "Club"
            case .food: return "Food"
            case .services: return "Services"
            case .entertainment: return "Entertainment"
            case .art: return "Art"
            case .music: return "Music"
            }
        }
        
        static func allCategories() -> [Category] {
            return [.other,
                    .sports,
                    .club,
                    .food,
                    .services,
                    .entertainment,
                    .art,
                    .music]
        }
        
    }
   
}
