//
//  Camp.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/16/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import RxDataSources
import RxSwift
import ObjectMapper
import Alamofire

struct Camp : Mappable {
    
    var id: Int = 0
    
    var title: String = ""
    var category: Category?
    var lastActivityDate: Date = Date(timeIntervalSince1970: 0)
    
    ///details
    var topic: Comment?
    var totalComments: Int = 0 ///does not include topic
    
    var isFollowedByCurrentUser: Bool = false
    var followersCount: Int = 0
    
    init?(map: Map) {
        mapping(map: map)
    }
    
    mutating func mapping(map: Map) {
        
        id <- map["id"]
        
        title <- map["name"]
        category <- map["category"]
        lastActivityDate <- (map["last_message_time"], ISO8601ExtendedDateTransform())
        
        topic <- map["topic"]
        totalComments <- map["message_count"]
        
        isFollowedByCurrentUser  <- map["followed"]
        followersCount <- map["follower_count"]
        
    }
    
    
    
}

extension Camp: Fakeble {
    
    static func fakeEntity() -> Camp {
        
        var camp = Camp(JSON: [:])!
        
        camp.id = fakeNumber(bound: 10000)
        
        camp.title = fakeString(components: 2)
        camp.lastActivityDate = fakeDate()
        camp.category = fakeValue(from: Category.allCategories())
        camp.isFollowedByCurrentUser = fakeBool()
        camp.followersCount = fakeNumber(bound: 500)
        
        return camp
        
    }
    
    mutating func populateDetails() {
        
        self.topic = Comment.fakeEntity()
        self.topic?.text = Comment.fakeString(components: 4)
        self.totalComments = Camp.fakeNumber(bound: 50)
        
    }
    
}

extension Camp : Storable {
    
    var identifier: Int { return id }
    
    static var storage: [Int : Variable<Camp>] = [ : ]
    
}


extension Camp : IdentifiableType, Equatable {
    
    var identity : Int { return id }
    
}

func ==(l: Camp, r: Camp) -> Bool {
    return l.id == r.id
}

extension Camp : Followable {
    
    func calculatedModel(change: Bool) -> Camp {
        
        var copy = self
        copy.isFollowedByCurrentUser = change
        return copy
        
    }
    
    var followRout : URLRequestConvertible { return CampRouter.follow(camp: self) }
    var unfollowRout : URLRequestConvertible { return CampRouter.unfollow(camp: self) }
    
}

