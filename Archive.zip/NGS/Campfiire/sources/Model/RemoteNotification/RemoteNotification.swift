//
//  RemoteNotification.swift
//  Campfiire
//
//  Created by Vlad Soroka on 1/22/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import ObjectMapper

struct RemoteNotification: Mappable {
    
    var payload: Payload!
    var data: Data!
    
    init?(map: Map) {
        mapping(map: map)
    }
    
    mutating func mapping(map: Map) {
        payload <- map["aps"]
        data <- map["details"]
    }
    
    struct Payload: Mappable {
        
        var message: String = ""
        var badge: Int = 0
        
        var contentAvailable: Bool = false
        var category: String? = nil
        
        init?(map: Map) {
            mapping(map: map)
        }
        
        mutating func mapping(map: Map) {
            message <- map["alert"]
            badge <- map["badge"]
            
            contentAvailable <- map["content-available"]
            category <- map["category"]
        }
        
    }
    
    struct Data: Mappable {
        
        var type: Int = 0
        var item: Item? = nil
        
        init?(map: Map) {
            mapping(map: map)
            
            item = Item(type: type, map: map["data"])
            
            assert(item != nil, "Error parsing notification JSON \(map)")
        }
        
        mutating func mapping(map: Map) {
            type <- map["type"]
        }
        
    }
    
    enum Item {
        
        case newEvent
        case eventToday(event: Event)
        case newMessage(chatData : [String: Any])
        case newRequest
        
        init?(type: Int, map: Map) {
            
            switch type {
            case 1: self = .newEvent
            case 2: self = .eventToday( event: Mapper<Event>().map(JSONObject: map.currentValue)! )
            case 3: self = .newMessage(chatData: map.JSON )
            case 4: self = .newRequest
            default: return nil
            }
            
        }
        
    }
    
}



