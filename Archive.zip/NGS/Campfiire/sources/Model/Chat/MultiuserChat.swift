//
//  Chat.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/30/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import RxDataSources
import RxSwift
import RxCocoa

struct MultiuserChat {
    
    var id : Int = 0
    
    var name : String = ""
    var description : String = ""
    var pictureURL : String = ""
    
    var members : [User] = []
    
    var lastMessageDate: Date? = nil
    
    let author: User
    init(author: User) {
        self.author = author
    }
    
}

extension MultiuserChat: ChatListCellPresentable {
    
    var chatName: Driver<String> { return Driver.just( name ) }
    var chatImageURL: Driver<String> { return Driver.just( pictureURL ) }
    
    var dateString: Driver<String> { return Driver.just( lastMessageDate?.campfiireString ?? "New" ) }
    
    var underlineColor: Driver<UIColor?> {
        return Driver.just( nil )
    }
    
}

extension MultiuserChat : Fakeble {
    
    static func fakeEntity() -> MultiuserChat {
        
        var chat = MultiuserChat(author: User.fakeEntity())
        
        chat.id = fakeNumber(bound: 10000)
        chat.name = fakeString()
        
        let closure = { (i: Int) -> [User] in
            var a:[User] = []
            for _ in 0...i {
                a.append(User.fakeEntity())
            }
            return a
        }
        
        chat.members = closure(fakeNumber(bound: 19))
        
        guard let me = User.currentUser() else { fatalError() }
        
        chat.members.append(me)
        chat.lastMessageDate = MultiuserChat.fakeDate()
        
        let photos = [
            "http://resources.touropia.com/gfx/d/best-places-to-visit-in-turkey/istanbul.jpg",
            "http://www.hellomagazine.com/imagenes/travel/201208299115/iconic-photographs-travel/0-45-151/egypt--a.jpg",
            "https://s-media-cache-ak0.pinimg.com/originals/3d/b1/f9/3db1f9332557ff6435de2fda6bc74e5e.jpg",
            "http://static3.businessinsider.com/image/5537f6f56bb3f740728fddb1-1190-625/26-beautiful-places-you-should-visit-before-they-disappear.jpg",
            "http://www.planetware.com/photos-large/MEX/mexico-top-places-cancun-mayan-riviera.jpg"
        ]
        
        chat.pictureURL = MultiuserChat.fakeValue(from: photos)
        
        return chat
        
    }
    
}

extension MultiuserChat : Storable {
    
    var identifier: Int { return id }
    
    static var storage: [Int : Variable<MultiuserChat>] = [ : ]
    
}

extension MultiuserChat : IdentifiableType, Equatable {
 
    var identity : Int {
        return self.id
    }

    static func == (lhs: MultiuserChat, rhs: MultiuserChat) -> Bool {
        return lhs.id == rhs.id
    }

    
}

