//
//  OneToOneChat.swift
//  Campfiire
//
//  Created by Vlad Soroka on 1/26/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import Foundation
import RxCocoa
import RxDataSources
import XMPPFramework

struct OneToOneChat {
    
    let peer: User
    let lastMessageDate: Date
    
    init (peer: User, lastMessageDate: Date) {
        self.peer = peer
        self.lastMessageDate = lastMessageDate
    }
    
    init?(xml: DDXMLElement) {
        
        guard let n = xml.name, n == "chat" else { return nil }
            
        guard let timestamp = xml.elements(forName: "last-message-time").first?.stringValueAsInt64() else {
            return nil
        }
        lastMessageDate = Date(timeIntervalSince1970: TimeInterval ( timestamp / 1000 ))
        
        guard let peerXML = xml.elements(forName: "peer").first, let peer = User(xml: peerXML) else {
            return nil
        }
        
        self.peer = peer
        
    }
    
}

extension OneToOneChat: ChatListCellPresentable {
    
    var chatName: Driver<String> {
        return peer.observableEntity()!
            .asDriver()
            .map { $0.name + " " + $0.jid.bare() }
    }
    
    var chatImageURL: Driver<String> {
        return peer.observableEntity()!
            .asDriver()
            .map { $0.pictureURL }
    }
    
    var dateString: Driver<String> { return Driver.just( lastMessageDate.campfiireString ) }
    
    var underlineColor: Driver<UIColor?> {
        return Driver.just( peer.isUserOnline ? UIColor.userStatusOnline : UIColor.userStatusOffline )
    }
    
}

extension OneToOneChat : IdentifiableType, Equatable {
    
    var identity : Int {
        return peer.id
    }
    
    static func == (lhs: OneToOneChat, rhs: OneToOneChat) -> Bool {
        return lhs.peer == rhs.peer
    }
    
}

extension OneToOneChat : Fakeble {
    
    static func fakeEntity() -> OneToOneChat {
        return OneToOneChat(peer: User.fakeEntity(),
                            lastMessageDate: OneToOneChat.fakeDate())
    }
    
}
