//
//  ChatMessage.swift
//  Campfiire
//
//  Created by Vlad Soroka on 1/17/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import Foundation
import XMPPFramework
import RxDataSources

struct ChatMessage {
    
    let body: String
    let date: Date
    
    let sender: User
    
    var pictureURL: String?
    
    init(message: XMPPMessage) {
        
        guard message.type() == "chat", message.from() != nil else {
            fatalError("Cannot represent XMPPMessage as ChatMessage if it is not of type 'chat'")
        }
        
        body = message.body()
        sender = message.from()?.userCampfiire ?? User.fakeEntity()
        
        if let timestamp = message.elements(forName: "timestamp").first?.stringValueAsInt64() {
            date = Date(timeIntervalSince1970: TimeInterval(timestamp / 1000))
        }
        else {
            date = Date(timeIntervalSince1970: 0)
        }
        
        if let url = message.elements(forName: "attachment").first?.stringValue {
            pictureURL = url
        }
        
    }
    
    init(text: String, pictureURL: String? = nil) {
        body = text
        date = Date()
        
        sender = User.currentUser()!
        self.pictureURL = pictureURL
    }
    
    var hashValue: Int {
        return body.hash ^ date.hashValue ^ sender.jid.hash
    }
    
}

extension ChatMessage {

    var isOwnMessage: Bool {
        return sender == User.currentUser()!
    }
    
    var isImageMessage: Bool {
        return pictureURL != nil
    }
    
}

extension ChatMessage: Fakeble {
    
    static func fakeEntity(number: Int) -> ChatMessage {
        let xmppMessage: XMPPMessage = XMPPMessage(type: "chat", to: User.fakeEntity().jid)
        xmppMessage.addAttribute(withName: "from", stringValue: User.fakeEntity().jid.bare())
        xmppMessage.addBody( "#\(number) " + ChatMessage.fakeString(components: 28) )
        
        return ChatMessage(message: xmppMessage)
    }
    
    static func fakeEntity() -> ChatMessage {
        return fakeEntity(number: 0)
    }
    
}

extension ChatMessage: IdentifiableType, Equatable {
    
    var identity: Int { return hashValue }
    static func ==(lhs: ChatMessage, rhs: ChatMessage) -> Bool {
        return lhs.hashValue == rhs.hashValue
    }
}
