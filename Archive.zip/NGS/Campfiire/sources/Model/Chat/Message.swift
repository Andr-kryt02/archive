//
//  Message.swift
//  Campfiire
//
//  Created by Andrew Seregin on 12/2/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import RxDataSources

struct Message : Equatable {
    
    var id: Int = 0
    
    var date: Date = Date(timeIntervalSince1970: 0)
    var text: String = ""
    var author: User!
    
    var pictureURL: String?
    
    var isUnread : Bool = false
    
}

func ==(lhs: Message, rhs: Message) -> Bool {
    return lhs.date == rhs.date &&
        lhs.text == rhs.text
}

extension Message: IdentifiableType {
    
    var identity: Int { return id }
    
}
