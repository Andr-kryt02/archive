//
//  HotSpot.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/25/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import CoreLocation
import RxSwift
import RxDataSources
import ObjectMapper
import Alamofire
import MapKit

struct HotSpot : Mappable {
    
    var id: Int = 0
    
    var name: String = ""
    var tags: [Tag] = []
    
    var latitude: CLLocationDegrees = 0
    var longitude: CLLocationDegrees = 0
    
    var location: CLLocation {
        get {
            return CLLocation(latitude: latitude,
                              longitude: longitude)
        }
        set {
            latitude = newValue.coordinate.latitude
            longitude = newValue.coordinate.longitude
        }
        
    }
    
    var adress: String?
    
    ////detailed attributes
    var imageURL: String = ""
    
    var description: String = ""
    var followersCount: Int = 0
    
    var photos : [Photo] = []
    
    var author: User?
    
    var isFolowedByCurrentUser : Bool = false
    
    
    init?(map: Map) {
        mapping(map: map)
    }
    
    mutating func mapping(map: Map) {
    
        id <- map["id"]
        
        name <- map["title"]
        description <- map["description"]
        
        tags <- map["tags"]
        
        latitude <- map["latitude"]
        longitude <- map["longitude"]
        
        imageURL <- map["avatarHotspot"]
        
        author <- map["host"]
        
        adress <- map["location"]
        
        photos <- map["photos"]
        
        followersCount <- map["followersCount"]
        isFolowedByCurrentUser <- map["followed"]
        
    }
    
}

extension HotSpot: NewsItemViewModelProtocol {
    
    var backgroundImageURL: String { return imageURL }
    
    var newsTypeLabelText: String { return followersCount.countableString(withSingularNoun: "follower") }
    var newsTypeLabelColor: UIColor { return UIColor.photoPurpleBackground }
    
    var newsNameSectionTitle: String { return name }
    var newsNameSectionImageURL: String? { return nil }
    
    var bottomLeftString: String? { return nil }
    var bottomRightString: String? { return nil }
    var upperRightString: String? { return nil }
    
    var likeStatus: Bool? { return nil }
    
}

extension HotSpot : CampfiireMapAnnotation {
    var coordinate: CLLocationCoordinate2D { return location.coordinate }

    var annotationTitle: String? { return name }
    var annotationSubtitle: String? { return nil }

}

extension HotSpot: Followable {
    
    func calculatedModel(change: Bool) -> HotSpot {
        
        var copy = self
        copy.isFolowedByCurrentUser = change
        
        let followersDif = change ? 1 : -1
        copy.followersCount += followersDif
        
        return copy
        
    }
    
    var followRout: URLRequestConvertible { return HotspotRouter.follow(hotSpot: self) }
    var unfollowRout: URLRequestConvertible { return HotspotRouter.unfollow(hotSpot: self) }
    
}

extension HotSpot: Fakeble {
    
    static func fakeEntity(in rect: MKCoordinateRegion) -> HotSpot {
    
        var hs = HotSpot(JSON: [:])!
        
        hs.id = fakeNumber(bound: 1000)
        hs.name = fakeString()
        
        ///
        let closure = { (i: Int) -> [Tag] in
            var a:[Tag] = []
            for _ in 0...i {
                a.append(Tag.fakeEntity())
            }
            return a
        }
        hs.tags = closure(fakeNumber(bound: 5))
        
        hs.latitude = fakeDouble(min: rect.center.latitude - rect.span.latitudeDelta / 5,
                                 max: rect.center.latitude + rect.span.latitudeDelta / 5)
        
        hs.longitude = fakeDouble(min: rect.center.longitude - rect.span.longitudeDelta / 5,
                                  max: rect.center.longitude + rect.span.longitudeDelta / 5)
        
        
        
        return hs
        
    }
    
    mutating func fakePopulateDetails() {
        ///details
        
        self.photos = [ Photo.fakeEntity(),
                        Photo.fakeEntity(),
                        Photo.fakeEntity() ]
        
        
        self.description = HotSpot.fakeString() +
                            HotSpot.fakeString() + HotSpot.fakeString() + HotSpot.fakeString()
        self.followersCount = HotSpot.fakeNumber(bound: 20)
        self.adress = HotSpot.fakeString()
        
        let photos = [
            "http://resources.touropia.com/gfx/d/best-places-to-visit-in-turkey/istanbul.jpg",
            "http://www.hellomagazine.com/imagenes/travel/201208299115/iconic-photographs-travel/0-45-151/egypt--a.jpg",
            "https://s-media-cache-ak0.pinimg.com/originals/3d/b1/f9/3db1f9332557ff6435de2fda6bc74e5e.jpg",
            "http://static3.businessinsider.com/image/5537f6f56bb3f740728fddb1-1190-625/26-beautiful-places-you-should-visit-before-they-disappear.jpg",
            "http://www.planetware.com/photos-large/MEX/mexico-top-places-cancun-mayan-riviera.jpg"
        ]
        
        
        self.imageURL = HotSpot.fakeValue(from: photos)
        
        self.author = User.fakeEntity()// User.currentUser()!
        
    }
    
    static func fakeEntity() -> HotSpot {
        
        return fakeEntity(in: MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 0,longitude: 0),
                                                 span: MKCoordinateSpan(latitudeDelta: 90,longitudeDelta: 180)))
        
    }
    
}

extension HotSpot : Storable {
    
    var identifier: Int { return id }
    
    static var storage: [Int : Variable<HotSpot>] = [ : ]
    
}


extension HotSpot : IdentifiableType, Equatable {
    
    var identity : Int { return id }
    
}

func ==(l: HotSpot, r: HotSpot) -> Bool {
    return l.id == r.id
}
