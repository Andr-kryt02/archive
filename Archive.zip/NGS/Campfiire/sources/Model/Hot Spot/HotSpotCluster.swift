//
//  HotSpotCluster.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/25/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import MapKit

struct HotSpotCluster {
    
    var hotspotsCount: Int = 0
    
    var center: CLLocationCoordinate2D = CLLocationCoordinate2D(latitude: 0,
                                                                longitude: 0)
    
    var location: CLLocation { return CLLocation(latitude: center.latitude,
                                                 longitude: center.longitude) }
    
    var nextCoordinateRegion: MKCoordinateRegion =
        MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 0,longitude: 0),
                           span: MKCoordinateSpan(latitudeDelta: 90,longitudeDelta: 180))
    
}

extension HotSpotCluster : CampfiireMapAnnotation {
    
    var coordinate: CLLocationCoordinate2D { return center }
    
    var annotationTitle: String? { return nil }
    var annotationSubtitle: String? { return nil }
}


extension HotSpotCluster : Fakeble {
    
    static func fakeEntity() -> HotSpotCluster {
        
        let region = MKCoordinateRegion(center:
            CLLocationCoordinate2D(latitude: 0,
                                   longitude: 0),
                                    span: MKCoordinateSpan(latitudeDelta: 90,
                                                           longitudeDelta: 180))
        
        return fakeEntity(for: region)
        
    }
    
    static func fakeEntity(for region: MKCoordinateRegion) -> HotSpotCluster {
        
        var instance = HotSpotCluster()
        
        instance.hotspotsCount = fakeNumber(bound: 20)
        
        let lat = region.center.latitude
        let lon = region.center.longitude
        let dlat = region.span.latitudeDelta
        let dlon = region.span.longitudeDelta
        
        instance.center = CLLocationCoordinate2D(
            latitude: lat + fakeDouble(min: -dlat * 0.1, max: dlat * 0.1),
            longitude: lon + fakeDouble(min: -dlon * 0.1, max: dlon * 0.1))
        
        
        instance.nextCoordinateRegion = MKCoordinateRegion(center:
            CLLocationCoordinate2D(latitude: fakeDouble(min: instance.center.latitude - dlat * 0.1,
                                                        max: instance.center.latitude + dlat * 0.1),
                                   longitude: fakeDouble(min: instance.center.longitude - dlon * 0.1,
                                                         max: instance.center.longitude + dlon * 0.1)),
                                        span: MKCoordinateSpan(latitudeDelta: fakeDouble(min: 0, max: dlat),
                                                               longitudeDelta: fakeDouble(min: 0, max: dlon)))

        
        return instance
        
    }
    
}
