//
//  NewsFeedProxyObject.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/13/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import ObjectMapper

///this is the adapter object for NewsFeed entities - Event, HotspotPhoto, Photo
struct NewsFeedProxyObject : Mappable {
    
    var type: Int?
    
    var id: Int?
    var timestamp: Date?
    
    var photoURL: String?
    var title: String?
    var location: String?
    var userInfo: User?
    
    var hotspotId: Int?
    var likesCount: Int?
    var isLiked: Bool?
    
    init?(map: Map) {
        mapping(map: map)
    }
    
    mutating func mapping(map: Map) {
        
        type <- map["type"]
        
        id <- map ["id"]
        timestamp <- (map ["timestamp"], ISO8601ExtendedDateTransform())
        
        photoURL <- map ["url"]
        title <- map ["title"]
        location <- map["location"]
        
        userInfo <- map["author"]
        
        hotspotId <- map["hotspot_id"]
        likesCount <- map["like_count"]
        isLiked <- map["like"]
        
    }
    
    func newsFeedItem() throws -> NewsFeedTypes {
        
        guard let type = self.type,
            type > 0, type < 4 else { fatalError("Can't map proper NewsFeed object with type \(self.type)") }
        
        ////this is the only place we're mapping "fancy" response into proper objects
        if type == 1 {
            
            var event = Event(JSON: [:])!
            
            event.id = try castOrFail(id)
            event.name = try castOrFail(title)
            event.location = try castOrFail(location)
            event.photoURL = try castOrFail(photoURL)
            event.date = try castOrFail(timestamp)
            
            return .event(event: event )
            
        }
        else if type == 2 {
            
            var hotspot = HotSpot(JSON: [:])!
            var photo = Photo(JSON: [:])!
            
            hotspot.id = try castOrFail(hotspotId)
            hotspot.name = try castOrFail(title)
            
            photo.id = try castOrFail(id)
            
            photo.author = try castOrFail(userInfo)
            photo.pictureURL = try castOrFail(photoURL)
            photo.datePosted = try castOrFail(timestamp)
            
            photo.likesCount = try castOrFail(likesCount)
            photo.isLikedByCurrentUser = try castOrFail(isLiked)
            
            return .hotSpotPhoto(hotspotPhoto: HotspotPhoto(photo: photo, hotspot: hotspot))
            
        }
        else {
            
            var photo = Photo(JSON: [:])!
            
            photo.id = try castOrFail(id)
            photo.author = try castOrFail(userInfo)
            photo.pictureURL = try castOrFail(photoURL)
            photo.datePosted = try castOrFail(timestamp)
            
            photo.likesCount = try castOrFail(likesCount)
            photo.isLikedByCurrentUser = try castOrFail(isLiked)
            
            return .userPhoto( userPhoto: UserPhoto(photo: photo) )
        }
        
    }
    
    func castOrFail<T>(_ item: T?) throws -> T {
        guard let i = item else { throw CampfiireError.generic(description: "Failed unwrapping fancy dictionary") }
        
        return i
    }
    
}
