//
//  HotspotPhoto.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/13/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Alamofire
import RxSwift
import ObjectMapper

///HotspotPhoto is a (Likable & NewsItemViewModelProtocol) wrapper for Photo Entity
///If you intend using NewsItemViewModelProtocol make sure hotspot variable is initialized

///As of 20.12.2016 this entity exists seperatelly from Photo entity just because server action for like
///is different for Photos that belong to Hotspot and Photos that belong to User which is odd
///but this is how server works
struct HotspotPhoto {
    
    let photo: Photo
    var hotspot: HotSpot?
    
    init(photo: Photo, hotspot: HotSpot?) {
        self.photo = photo
        self.hotspot = hotspot
    }
    
}

extension HotspotPhoto : NewsItemViewModelProtocol {
    
    var backgroundImageURL: String { return photo.pictureURL }
    
    var newsTypeLabelText: String { return photo.likesCount.countableString(withSingularNoun: "like") }
    var newsTypeLabelColor: UIColor { return UIColor.photoPurpleBackground }
    
    var newsNameSectionTitle: String { return photo.author!.name }
    var newsNameSectionImageURL: String? { return photo.author!.pictureURL }
    
    var bottomLeftString: String? { return hotspot?.name }
    var bottomRightString: String? { return photo.datePosted.campfiireString }
    var upperRightString: String? { return nil }
    
    var likeStatus: Bool? { return photo.isLikedByCurrentUser }
    
}

extension HotspotPhoto : Likable {
    
    var isLiked: Bool { return photo.isLikedByCurrentUser }
    
    var likeRout : URLRequestConvertible { return HotspotRouter.like(photo: self.photo) }
    var dislikeRout : URLRequestConvertible { return HotspotRouter.dislike(photo: self.photo) }
    
    func calculatedModel(change: Bool) -> HotspotPhoto {
        
        let copy = self.photo.calculatedPhoto(likeStatus: change)
        
        return HotspotPhoto(photo: copy, hotspot: hotspot)
    }
    
    ///because Likable uses Self in it's declaration it's impossible to declare
    ///let a: Likable = stuff
    ///which means that for HotspotPhoto |serverUpdateFor| method will always call this implementation
    ///not the one in protocol extension
    func serverUpdateFor(change: Bool) -> Observable<HotspotPhoto> {
        
        let rout = change ? likeRout : dislikeRout
        
        ///server does not provide us with hotspot value, so we need to preserve it manually
        let hotspot = self.hotspot
        
        return Alamofire.request(rout)
                .rx_campfiireResponse(CampfiireResponse<Photo>.self)
                .map { photo in
                    
                    ///upon like action we want to notify app about item  internal state change
                    photo.saveEntity()
                    
                    return HotspotPhoto(photo: photo, hotspot: hotspot)
                }
        
    }
    
    func refreshed() -> HotspotPhoto {
        ////picking up the most recent available Value of given photo
        let photo = self.photo.refreshedEntity() ?? self.photo
        
        return HotspotPhoto(photo: photo, hotspot: self.hotspot)
    }
    
}
