//
//  Photo.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/16/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import ObjectMapper
import RxSwift
import Alamofire

struct Photo : Mappable {
    
    var id : Int = 0
    var pictureURL : String = ""
    
    var likesCount: Int = 0
    var isLikedByCurrentUser: Bool = false
    
    var datePosted: Date = Date(timeIntervalSince1970: 0)
    var author: User? = nil
    
    init?(map: Map) {
        mapping(map: map)
        
    }
    
    mutating func mapping(map: Map) {
        
        id <- map["id"]
        pictureURL <- map["url"]
        
        likesCount <- map ["like_count"]
        isLikedByCurrentUser <- map["like"]
        
        datePosted <- (map["time"], ISO8601ExtendedDateTransform())
        author <- map["author"]
        
    }
    
}

extension Photo : Fakeble, Equatable {
    
    static func fakeEntity() -> Photo {
        var p = Photo(JSON: [:])!
        
        p.id = fakeNumber(bound: 10000)
        
        let photos = [
            "http://resources.touropia.com/gfx/d/best-places-to-visit-in-turkey/istanbul.jpg",
            "http://www.hellomagazine.com/imagenes/travel/201208299115/iconic-photographs-travel/0-45-151/egypt--a.jpg",
            "https://s-media-cache-ak0.pinimg.com/originals/3d/b1/f9/3db1f9332557ff6435de2fda6bc74e5e.jpg",
            "http://static3.businessinsider.com/image/5537f6f56bb3f740728fddb1-1190-625/26-beautiful-places-you-should-visit-before-they-disappear.jpg",
            "http://www.planetware.com/photos-large/MEX/mexico-top-places-cancun-mayan-riviera.jpg"
        ]
        
        p.pictureURL = fakeValue(from: photos)
        p.author = User.fakeEntity()
        p.datePosted = fakeDate()
        p.likesCount = fakeNumber(bound: 1001)
        
        return p
    }
    
}

func ==(lhs: Photo, rhs: Photo) -> Bool {
    return lhs.id == rhs.id
}

extension Photo {
    
    func calculatedPhoto(likeStatus: Bool) -> Photo {
        var copy = self
        
        copy.isLikedByCurrentUser = likeStatus
        copy.likesCount += likeStatus ? 1 : -1
        
        return copy
    }
    
}


extension Photo : Storable {
    
    var identifier: String { return pictureURL }
    static var storage: [String : Variable<Photo>] = [:]
    
}
