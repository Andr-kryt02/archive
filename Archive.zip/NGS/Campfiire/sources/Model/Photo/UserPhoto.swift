//
//  UserPhoto.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/20/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Alamofire
import RxSwift
import ObjectMapper

///UserPhoto photo is a (Likable & NewsItemViewModelProtocol) wrapper for Photo Entity

///As of 20.12.2016 this entity exists seperatelly from Photo entity just because server action for like
///is different for Photos that belong to Hotspot and Photos that belong to User which is odd
///but this is how server works
struct UserPhoto {
    
    let photo: Photo
    
}

extension UserPhoto : NewsItemViewModelProtocol {
    
    var backgroundImageURL: String { return photo.pictureURL }
    
    var newsTypeLabelText: String { return photo.likesCount.countableString(withSingularNoun: "like") }
    var newsTypeLabelColor: UIColor { return UIColor.photoPurpleBackground }
    
    var newsNameSectionTitle: String { return photo.author!.name }
    var newsNameSectionImageURL: String? { return photo.author!.pictureURL }
    
    var bottomLeftString: String? { return nil }
    var bottomRightString: String? { return photo.datePosted.campfiireString }
    var upperRightString: String? { return nil }
    
}

extension UserPhoto : Likable {
    
    var isLiked: Bool { return photo.isLikedByCurrentUser }
    
    var likeRout : URLRequestConvertible { return UserPhotoRouter.like(photo: photo) }
    var dislikeRout : URLRequestConvertible { return UserPhotoRouter.dislike(photo: photo) }
    
    func calculatedModel(change: Bool) -> UserPhoto {
        
        let copy = self.photo.calculatedPhoto(likeStatus: change)
        
        return UserPhoto(photo: copy)
    }
    
    func serverUpdateFor(change: Bool) -> Observable<UserPhoto> {
        
        let rout = change ? likeRout : dislikeRout
        
        return Alamofire.request(rout)
            .rx_campfiireResponse(CampfiireResponse<Photo>.self)
            .map { photo in
                
                ///upon like action we want to notify app about item  internal state change
                photo.saveEntity()
                
                return UserPhoto(photo: photo)
            }
        
    }
    
    func refreshed() -> UserPhoto {
        ////picking up the most recent available Value of given photo
        let photo = self.photo.refreshedEntity() ?? self.photo
        
        return UserPhoto(photo: photo)
    }
    
}
