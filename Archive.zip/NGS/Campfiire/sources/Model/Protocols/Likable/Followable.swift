//
//  Followable.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/13/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Alamofire
import RxSwift
import ObjectMapper

protocol Followable : OptimisticCalculatable, Mappable {
    
    var followRout : URLRequestConvertible { get }
    var unfollowRout : URLRequestConvertible { get }
    
}

extension Followable {
    
    func serverFollow() -> Observable<Self> {
        return Alamofire.request(followRout)
            .rx_campfiireResponse(CampfiireResponse<Self>.self)
    }
    
    func serverUnfollow() -> Observable<Self> {
        return Alamofire.request(unfollowRout)
            .rx_campfiireResponse(CampfiireResponse<Self>.self)
    }
    
    func serverUpdateFor(change: Bool) -> Observable<Self> {
        return change ? serverFollow() : serverUnfollow()
    }
    
}
