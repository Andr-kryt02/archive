//
//  Likable.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/13/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Alamofire
import RxSwift
import ObjectMapper

protocol Likable : OptimisticCalculatable {

    var isLiked: Bool { get }
    
    var likeRout : URLRequestConvertible { get }
    var dislikeRout : URLRequestConvertible { get }
    
}

extension Likable where Self: Mappable {
    
    func serverLike() -> Observable<Self> {
        return Alamofire.request(likeRout)
            .rx_campfiireResponse(CampfiireResponse<Self>.self)
    }
    
    func serverDislike() -> Observable<Self> {
        return Alamofire.request(dislikeRout)
            .rx_campfiireResponse(CampfiireResponse<Self>.self)
    }
    
    func serverUpdateFor(change: Bool) -> Observable<Self> {
        return change ? serverLike() : serverDislike()
    }
    
}
