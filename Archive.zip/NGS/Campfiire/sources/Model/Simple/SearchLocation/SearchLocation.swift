//
//  SearchLocation.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/6/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import ObjectMapper
import RxCocoa
import RxSwift

struct SearchLocation {
    
    let county: String
    let city: String
    
}

extension SearchLocation : Fakeble {
    
    static func fakeEntity() -> SearchLocation {
        
        return SearchLocation(county: fakeString(),
                              city: fakeString())
    }
    
}
