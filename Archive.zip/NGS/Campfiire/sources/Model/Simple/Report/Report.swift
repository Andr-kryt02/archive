//
//  Report.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 2016-12-13.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import ObjectMapper

struct Report : Mappable {
    
    var id : Int = 0
    var timestamp : String = ""
    var reporterId: Int = 0
    var targetId : Int = 0
    
    
    init?(map: Map) {
        mapping(map: map)
    }
    
    mutating func mapping(map: Map) {
        
        id <- map["id"]
        
        timestamp <- map["timestamp"]
        reporterId <- map["reporter_id"]
        targetId <- map["target_id"]
        
    }
    
}

extension Report : Storable {
    
    var identifier: Int { return id }
    
    static var storage: [Int : Variable<Report>] = [ : ]
    
}


func ==(l: Report, r: Report) -> Bool {
    return l.id == r.id
}


