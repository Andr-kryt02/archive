//
//  InfoSource.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 2016-12-20.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import ObjectMapper
import RxDataSources
import Alamofire

struct InfoSource : Mappable {
    
    var id: Int = 0
    var title: String = ""
    var url: String = ""
  
    
    init(map: Map) {
        mapping(map: map)
    }
    
    init() {}
    
    mutating func mapping(map: Map) {
        
        id <- map["id"]
        title <- map["name"]
        url <- map["link"]
        
    }
    
    
}

extension InfoSource : Equatable, IdentifiableType {
    
    var identity: Int { return id }
    
    static func ==(lhs: InfoSource, rhs: InfoSource) -> Bool {
        return lhs.id == rhs.id
    }
    
}

extension InfoSource: Fakeble {
    
    static func fakeEntity() -> InfoSource {
        
        var instance = InfoSource()
        
        instance.id = fakeNumber(bound: 10000)
        instance.title = self.fakeString(components: 5)
        instance.url = randomSourceUrls()
        return instance
    }
    
    
    private static func randomSourceUrls() -> String {
        
        let avs = [
            "http://www.leafly.com",
            "http://www.hightimes.com",
            "http://www.weedmaps.com",
            "http://www.thecannabist.co",
            "http://www.lift.co"
        ]
        
        return fakeValue(from: avs)
        
    }
    
    
    
}






