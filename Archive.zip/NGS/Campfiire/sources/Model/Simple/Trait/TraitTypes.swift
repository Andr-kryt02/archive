//
//  TraitTypes.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/13/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

enum TraitType: Int {
    
    case email
    case healthProblem
    case location
    case favoriteProduct
    case website
    case specialization
    case experience
    case phoneNumber
    case town
    
    var image: UIImage {
        
        switch self {
        case .email:
            return R.image.email2()!
            
        case .favoriteProduct:
            return R.image.page1Copy10()!
            
        case .healthProblem:
            return R.image.shape()!
            
        case .location:
            return R.image.earth()!
            
        case .website:
            return R.image.siteicon()!
            
        case .specialization:
            return R.image.cross()!
            
        case .experience:
            return R.image.medicineKit2()!
        case .phoneNumber:
            return R.image.phone()!
        case .town:
            return R.image.icLocationCity18Px()!
        }
    }
    
    var placeholder: String {
        switch self {
        case .email:
            return "E-mail"
            
        case .favoriteProduct:
            return "Favorite Product"
            
        case .healthProblem:
            return "Health Problem"
            
        case .location:
            return "Location"
            
        case .website:
            return "Website"
            
        case .specialization:
            return "Specialization"
            
        case .experience:
            return "Experience"
            
        case .phoneNumber:
            return "Phone Number"
            
        case .town:
            return "Adress"
        }
    }
    
}
