//
//  SearchUsersFilter.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/25/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

struct SearchUsersFilter {
    
    var query: String?
    
    struct AgeRange {
        let from: Int
        let to: Int
    }; var ageRange: AgeRange?
        
    var gender: Gender?
    var location: String?
    
    var tag: Tag?
    
}
