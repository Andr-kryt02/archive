//
//  Store.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 14.11.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import ObjectMapper
import RxDataSources
import CoreLocation
import MapKit
import Alamofire

struct OnlineStore: Mappable {
    
    var id: Int = 0
    
    var pictureURL: String = ""
    var name: String = ""
    var phoneNumber: String = ""
    var website: String = ""
    var email: String = ""
    
    var likes: Int = 0
    var isLikedByCurrentUser: Bool = false
    
    init(map: Map) {
        mapping(map: map)
    }
    
    mutating func mapping(map: Map) {
        
        id <- map["id"]
        pictureURL <- map["avatar"]
        name <- map["name"]
        phoneNumber <- map["call_number"]
        email <- map["email"]
        website <- map["web_site"]
        
        likes <- map["rating"]
        isLikedByCurrentUser <- map["is_like"]
    }
    
    
}


////------
////RxDataSource
////------
extension OnlineStore : Equatable, IdentifiableType {
    
    var identity: Int { return id }
    
    static func ==(lhs: OnlineStore, rhs: OnlineStore) -> Bool {
        return lhs.id == rhs.id
    }
    
}

////------
////DirectoryCellPresentable
////------
extension OnlineStore: DirectoryCellPresentable {
    
    var directoryCellTitle: String { return name }
    var directoryCellSubtitle: String? { return website }
    var directoryCellAvatarURL: String { return pictureURL  }
    
}

////------
////DirectoryItemDetailsPresentable
////------
extension OnlineStore: DirectoryItemDetailsPresentable {
    
    var directoryDetailsTitle: String { return name }
    var directoryDetailsSubtitle: String? { return nil }
    var directoryDetailsPictureURL: String { return pictureURL }
    
    var likesCount: Int { return likes }
    var isLiked: Bool { return isLikedByCurrentUser }
    
    var leftDescription: String? { return nil }
    var rightDescription: String? { return nil }
    var bottomButtonTitle: String? { return nil }
    
    var traits: [TraitType] {
        return [
            .website,
            .phoneNumber,
            .email,
            ]
    }
    
    func content(of trait: TraitType) -> String? {
        switch trait {
        case .website: return website
        case .phoneNumber: return phoneNumber
        case .email: return email
        default: return nil
        }
    }
    
}

////------
////TopRatedCellDisplayable
////------

extension OnlineStore : TopRatedCellDisplayable {
    
    var topRatedTitle: String { return name }
    var topRatedSubtitle: String { return likes.countableString(withSingularNoun: "vote") }
    
    var topRatedPictureURL: String { return pictureURL }
    
}

////------
////DirectoryRoutProvidable
////------
extension OnlineStore : DirectoryRoutProvidable {
    
    static func mapRout(query: String?, region: MKCoordinateRegion) -> URLRequestConvertible {
        ///TODO: method should not be mandatory
        
        fatalError("Online Store can't be presented on map")
    }
    
    static func listRout(query: String?, batch: Batch) -> URLRequestConvertible {
        return OnlineStoreRouter.list(query: query, batch: batch)
    }
    
    static func topRatedRout(batch: Batch?) -> URLRequestConvertible {
        return OnlineStoreRouter.top(batch: batch)
    }
    
    var detailsRout: URLRequestConvertible { return OnlineStoreRouter.details(store: self) }
    var likeRout   : URLRequestConvertible { return OnlineStoreRouter.like(store: self) }
    var dislikeRout: URLRequestConvertible { return OnlineStoreRouter.dislike(store: self) }
    static var top10Rout: URLRequestConvertible { return OnlineStoreRouter.top(batch: nil) }
}

////------
////OptimisticCalculatable
////------
extension OnlineStore: OptimisticCalculatable {
    
    func calculatedModel(change: Bool) -> OnlineStore {
        var copy = self
        
        copy.isLikedByCurrentUser = change
        copy.likes += 1 * (change ? 1 : -1)
        
        return copy
    }
    
}


extension OnlineStore: Fakeble {
    
    static func fakeEntity() -> OnlineStore {
        
        var instance = OnlineStore(JSON: [:])!
        
        instance.name = self.fakeString()
        instance.email = self.fakeString()
        instance.phoneNumber = self.fakeString()
        instance.pictureURL = randomAvatarURL()
        instance.website = self.fakeString()
        instance.likes = self.fakeNumber(bound: 1000)
        
        return instance
    }
    
    private static func randomAvatarURL() -> String {
        
        let avs = [
            "https://randomuser.me/api/portraits/men/50.jpg",
            "https://randomuser.me/api/portraits/men/85.jpg",
            "https://randomuser.me/api/portraits/men/57.jpg",
            "https://randomuser.me/api/portraits/women/11.jpg",
            "https://randomuser.me/api/portraits/women/29.jpg",
            "https://randomuser.me/api/portraits/women/58.jpg",
            ]
        
        return fakeValue(from: avs)
        
    }
    
}
