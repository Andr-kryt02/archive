//
//  Budtender.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 14.11.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import ObjectMapper
import RxDataSources
import CoreLocation
import MapKit
import Alamofire

struct Dispensary : Mappable {
    
    var id: Int = 0
    
    var pictureURL: String = ""
    var name: String = ""
    var phoneNumber: String = ""
    var address: String = ""
    var email: String = ""
    
    var openingTime: Date = Date(timeIntervalSince1970: 0)
    var closingTime: Date = Date(timeIntervalSince1970: 0)
    
    var latitude: CLLocationDegrees!
    var longitude: CLLocationDegrees!
    
    var likes: Int = 0
    var isLikedByCurrentUser: Bool = false
    
    init(map: Map) {
        mapping(map: map)
    }

    
    mutating func mapping(map: Map) {
      
        id <- map["id"]
        pictureURL <- map["avatar"]
        name <- map["name"]
        phoneNumber <- map["call_number"]
        email <- map["email"]
        
        latitude <- map["latitude"]
        longitude <- map["longitude"]
        
        address <- map["location"]
        
        openingTime <- (map["start_time"], ISO8601ExtendedDateTransform())
        closingTime <- (map["finish_time"], ISO8601ExtendedDateTransform())
        
        likes <- map["rating"]
        isLikedByCurrentUser <- map["is_like"]

    }
    
    
}

////------
////RxDataSource
////------
extension Dispensary : Equatable, IdentifiableType {
    
    var identity: Int { return id }
    
    static func ==(lhs: Dispensary, rhs: Dispensary) -> Bool {
        return lhs.id == rhs.id
    }
    
}

////------
////TopRatedCellDisplayable
////------

extension Dispensary : TopRatedCellDisplayable {
    
    var topRatedTitle: String { return name }
    var topRatedSubtitle: String { return likes.countableString(withSingularNoun: "vote") }
    
    var topRatedPictureURL: String { return pictureURL }
    
}

////------
////DirectoryCellPresentable
////------
extension Dispensary: DirectoryCellPresentable {
    
    var directoryCellTitle: String { return name }
    var directoryCellSubtitle: String? { return address }
    var directoryCellAvatarURL: String { return pictureURL  }
    
}

////------
////DirectoryItemDetailsPresentable
////------
extension Dispensary: DirectoryItemDetailsPresentable {
    
    var directoryDetailsTitle: String { return name }
    var directoryDetailsSubtitle: String? { return nil }
    //{ return "\(openingTime.campfiireTime) - \(closingTime.campfiireTime)" }
    
    var directoryDetailsPictureURL: String { return pictureURL }
    
    var likesCount: Int { return likes }
    var isLiked: Bool { return isLikedByCurrentUser }
    
    var leftDescription: String? { return nil }
    var rightDescription: String? { return nil }
    
    var traits: [TraitType] {
        return [
            .town,
            .phoneNumber,
            .email,
            ]
    }
    
    func content(of trait: TraitType) -> String? {
        switch trait {
        case .town: return address
        case .phoneNumber: return phoneNumber
        case .email: return email
        default: return nil
        }
    }
    
}

////------
////DirectoryItemDetailsPresentable
////------
extension Dispensary: CampfiireMapAnnotation {
    var coordinate: CLLocationCoordinate2D {
        return CLLocationCoordinate2D(latitude: latitude,
                                      longitude: longitude)
    }
    
    var annotationTitle: String? { return name }
    var annotationSubtitle: String? { return address }
}

////------
////DirectoryRoutProvidable
////------
extension Dispensary : DirectoryRoutProvidable {
    
    static func mapRout(query: String?, region: MKCoordinateRegion) -> URLRequestConvertible {
        return DispensaryRouter.map(georegion: region.circularApproximation,
                                    query: query)
    }
    
    static func listRout(query: String?, batch: Batch) -> URLRequestConvertible {
        return DispensaryRouter.list(query: query, batch: batch)
    }
    
    static func topRatedRout(batch: Batch?) -> URLRequestConvertible {
        return DispensaryRouter.top(batch: batch)
    }
    
    var detailsRout: URLRequestConvertible { return DispensaryRouter.details(dispensary: self) }
    var likeRout   : URLRequestConvertible { return DispensaryRouter.like(dispensary: self) }
    var dislikeRout: URLRequestConvertible { return DispensaryRouter.dislike(dispensary: self) }
    static var top10Rout: URLRequestConvertible { return DispensaryRouter.top(batch: nil) }
}

////------
////OptimisticCalculatable
////------
extension Dispensary: OptimisticCalculatable {
    
    func calculatedModel(change: Bool) -> Dispensary {
        var copy = self
        
        copy.isLikedByCurrentUser = change
        copy.likes += 1 * (change ? 1 : -1)
        
        return copy
    }
    
}

extension Dispensary: Fakeble {
    
    static func fakeEntity() -> Dispensary {
        
        var instance = Dispensary(JSON: [:])!
        
        instance.name = self.fakeString()
        instance.email = self.fakeString()
        instance.phoneNumber = self.fakeString()
        instance.likes = self.fakeNumber(bound: 1000)
        instance.pictureURL = randomAvatarURL()
        instance.latitude = fakeDouble(min: 0, max: 10000)
        instance.longitude = fakeDouble(min: 0, max: 10000)
        instance.address = fakeString()
    
        instance.openingTime = fakeDate()
        instance.closingTime = fakeDate()
        
        return instance
    }
    
    private static func randomAvatarURL() -> String {
        
        let avs = [
            "https://randomuser.me/api/portraits/men/50.jpg",
            "https://randomuser.me/api/portraits/men/85.jpg",
            "https://randomuser.me/api/portraits/men/57.jpg",
            "https://randomuser.me/api/portraits/women/11.jpg",
            "https://randomuser.me/api/portraits/women/29.jpg",
            "https://randomuser.me/api/portraits/women/58.jpg",
            ]
        
        return fakeValue(from: avs)
        
    }
    
}
