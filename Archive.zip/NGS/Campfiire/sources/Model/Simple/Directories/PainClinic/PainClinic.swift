//
//  PainClinic.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 14.11.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import ObjectMapper
import RxDataSources
import CoreLocation
import MapKit
import Alamofire

struct PainClinic: Mappable {
    /*
     
     "id": long,
     "name": String,
     "specialization": String,
     "experience" : timestamp (String  - yyyy-MM-dd),
     "location" : String,
     "cell_number": String,
     "email" : String,
     "avatar" : String,
     "rating" : int,
     "health_insurance" : boolean,
     “is_like”: boolean
     
     */
    
    var id: Int = 0
    
    var pictureURL: String = ""
    var name: String = ""
    var specialization: String = ""
    
    var latitude: CLLocationDegrees = 0
    var longitude: CLLocationDegrees = 0
    
    var openingTime: Date = Date(timeIntervalSince1970: 0)
    var closingTime: Date = Date(timeIntervalSince1970: 0)
    
    var phoneNumber: String = ""
    
    var address: String = ""
    var email: String = ""
    var likes: Int = 0
    
    var insuranceNeeded: Bool = false
    var isLikedByCurrentUser: Bool = false
    
    init(map: Map) {
        
        mapping(map: map)
    }
    
    
    mutating func mapping(map: Map) {
        
        id <- map["id"]
        pictureURL <- map["avatar"]
        name <- map["name"]
        
        latitude <- map["latitude"]
        longitude <- map["longitude"]
        
        specialization <- map["specialization"]
        phoneNumber <- map["call_number"]
        address <- map["location"]
        email <- map["email"]
        
        insuranceNeeded <- map["health_insurance"]
        
        openingTime <- (map["start_time"], ISO8601ExtendedDateTransform())
        closingTime <- (map["finish_time"], ISO8601ExtendedDateTransform())
        
        likes <- map["rating"]
        isLikedByCurrentUser <- map["is_like"]
        
    }
    
    
}

////------
////RxDataSource
////------
extension PainClinic : Equatable, IdentifiableType {
    
    var identity: Int { return id }
    
    static func ==(lhs: PainClinic, rhs: PainClinic) -> Bool {
        return lhs.id == rhs.id
    }
    
}

////------
////DirectoryCellPresentable
////------
extension PainClinic: DirectoryCellPresentable {
    
    var directoryCellTitle: String { return name }
    var directoryCellSubtitle: String? { return specialization }
    var directoryCellAvatarURL: String { return self.pictureURL  }
    
}

////------
////DirectoryItemDetailsPresentable
////------
extension PainClinic: DirectoryItemDetailsPresentable {
    
    var directoryDetailsTitle: String { return name }
    var directoryDetailsSubtitle: String? { return nil }
    //{ "\(openingTime.campfiireTime) - \(closingTime.campfiireTime)" }
    
    var directoryDetailsPictureURL: String { return pictureURL }
    
    
    var likesCount: Int { return likes }
    var isLiked: Bool { return isLikedByCurrentUser }
    
    var leftDescription: String? { return nil }
    var rightDescription: String? { return nil }
    
    var traits: [TraitType] {
        return [
            .healthProblem,
            .town,
            .phoneNumber,
            .email,
        ]
    }
    
    func content(of trait: TraitType) -> String? {
        switch trait {
        case .healthProblem: return specialization
        case .town: return address
        case .phoneNumber: return phoneNumber
        case .email: return email
        default: return nil
        }
    }
    
}

////------
////CampfiireMapAnnotation
////------
extension PainClinic: CampfiireMapAnnotation {
    var coordinate: CLLocationCoordinate2D {
        return CLLocationCoordinate2D(latitude: latitude,
                                      longitude: longitude)
    }
    
    var annotationTitle: String? { return name }
    var annotationSubtitle: String? { return specialization }
}

////------
////TopRatedCellDisplayable
////------

extension PainClinic : TopRatedCellDisplayable {
    
    var topRatedTitle: String { return name }
    var topRatedSubtitle: String { return likes.countableString(withSingularNoun: "vote") }
    
    var topRatedPictureURL: String { return pictureURL }
    
}

////------
////DirectoryRoutProvidable
////------
extension PainClinic : DirectoryRoutProvidable {
    
    static func mapRout(query: String?, region: MKCoordinateRegion) -> URLRequestConvertible {
        return PainClinicRouter.map(georegion: region.circularApproximation,
                                query: query)
    }
    
    static func listRout(query: String?, batch: Batch) -> URLRequestConvertible {
        return PainClinicRouter.list(query: query, batch: batch)
    }
    
    static func topRatedRout(batch: Batch?) -> URLRequestConvertible {
        return PainClinicRouter.top(batch: batch)
    }
    
    var detailsRout: URLRequestConvertible { return PainClinicRouter.details(clinic: self) }
    var likeRout   : URLRequestConvertible { return PainClinicRouter.like(clinic: self) }
    var dislikeRout: URLRequestConvertible { return PainClinicRouter.dislike(clinic: self) }
    static var top10Rout: URLRequestConvertible { return PainClinicRouter.top(batch: nil) }
}

////------
////OptimisticCalculatable
////------
extension PainClinic: OptimisticCalculatable {
    
    func calculatedModel(change: Bool) -> PainClinic {
        var copy = self
        
        copy.isLikedByCurrentUser = change
        copy.likes += 1 * (change ? 1 : -1)
        
        return copy
    }
    
}

////------
////Fakeble
////------
extension PainClinic : Fakeble {
    
    static func fakeEntity() -> PainClinic {
        
        var instance = PainClinic(JSON: [:])!
        
        instance.id = PainClinic.fakeNumber(bound: 10000)
        
        instance.name = PainClinic.fakeString()
        instance.specialization = PainClinic.fakeString()
        
        instance.latitude = PainClinic.fakeDouble(min: -10 ,
                                              max: 10)
        
        instance.longitude = PainClinic.fakeDouble(min: -18,
                                               max: 18)
        
        instance.pictureURL = randomAvatarURL()
        instance.email = PainClinic.fakeString()
        instance.phoneNumber = PainClinic.fakeString()
        instance.insuranceNeeded = PainClinic.fakeBool()
        instance.address = fakeString()
        
        instance.likes = fakeNumber(bound: 432)
        instance.isLikedByCurrentUser = fakeBool()
        
        instance.openingTime = fakeDate()
        instance.closingTime = fakeDate()
        
        return instance
    }
    
    private static func randomAvatarURL() -> String {
        
        let avs = [
            "https://randomuser.me/api/portraits/men/50.jpg",
            "https://randomuser.me/api/portraits/men/85.jpg",
            "https://randomuser.me/api/portraits/men/57.jpg",
            "https://randomuser.me/api/portraits/women/11.jpg",
            "https://randomuser.me/api/portraits/women/29.jpg",
            "https://randomuser.me/api/portraits/women/58.jpg",
            ]
        
        return fakeValue(from: avs)
        
    }
    //
}
