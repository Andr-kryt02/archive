//
//  DirectoryProtocols.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/11/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import Alamofire
import RxDataSources
import MapKit
import ObjectMapper

///entity might present detail in DirectoryItem screen
protocol DirectoryItemDetailsPresentable: TraitPresentable {
    
    var directoryDetailsTitle: String { get }
    var directoryDetailsSubtitle: String? { get }
    var directoryDetailsPictureURL: String { get }
    
    var likesCount: Int { get }
    var isLiked: Bool { get }
    
    var leftDescription: String? { get }
    var rightDescription: String? { get }
    
    var traits: [TraitType] { get }
    
}

protocol Top10RoutProvidable {
    static var top10Rout: URLRequestConvertible { get }
}

///entity might provide router for network requests
protocol DirectoryRoutProvidable: Likable, Top10RoutProvidable {
    
    static func listRout(query: String?, batch: Batch) -> URLRequestConvertible
    static func mapRout(query: String?, region: MKCoordinateRegion) -> URLRequestConvertible
    
    var detailsRout : URLRequestConvertible { get }
    
}


////------
/////Handy Aliases
////------

///can be used to work with Directory Manager
typealias DirectoryManagableType = DirectoryRoutProvidable & Mappable & Fakeble

///can be loaded in Directories list
typealias DirectoryListLoadType = DirectoryManagableType & Equatable

///can be presented as one item in Directories list
typealias DirectoryListItemType = DirectoryListLoadType & ///loading data
                                  IdentifiableType & /// pagin data in rx tableview
                                  OptimisticCalculatable & /// smart likes
                                  DirectoryItemDetailsPresentable/// presenting details

////can be presented on map
typealias DirectoryMapItemType = DirectoryItemType &  /// Details Presentable
                                 CampfiireMapAnnotation ////UI presentation

///can present details
typealias DirectoryItemType = DirectoryManagableType &  ////network requests
                              DirectoryItemDetailsPresentable &  ////UI presentation
                              OptimisticCalculatable  //// like status prediction
