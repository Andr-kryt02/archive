//
//  LisencedProducer.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 14.11.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import ObjectMapper
import RxDataSources
import CoreLocation
import MapKit
import Alamofire

struct LicensedProducer: Mappable {
    
    var id: Int = 0
    
    var pictureURL: String = ""
    var name: String = ""
    
    var latitude: CLLocationDegrees = 0
    var longitude: CLLocationDegrees = 0
    
    var website: String = ""
    var phoneNumber: String = ""
    
    var address: String = ""
    var email: String = ""
    var likes: Int = 0
    
    var insuranceNeeded: Bool = false
    var isLikedByCurrentUser: Bool = false
    
    init(map: Map) {
        mapping(map: map)
    }
    
    
    mutating func mapping(map: Map) {

        id <- map["id"]
        pictureURL <- map["avatar"]
        name <- map["name"]
        phoneNumber <- map["call_number"]
        email <- map["email"]
        website <- map["website"]
        latitude <- map["latitude"]
        longitude <- map["longitude"]
        address <- map["location"]
        
        likes <- map["rating"]
        isLikedByCurrentUser <- map["is_like"]
        
    }
        
}

////------
////RxDataSource
////------
extension LicensedProducer : Equatable, IdentifiableType {
    
    var identity: Int { return id }
    
    static func ==(lhs: LicensedProducer, rhs: LicensedProducer) -> Bool {
        return lhs.id == rhs.id
    }
    
}

////------
////DirectoryCellPresentable
////------
extension LicensedProducer: DirectoryCellPresentable {
    
    var directoryCellTitle: String { return name }
    var directoryCellSubtitle: String? { return address }
    var directoryCellAvatarURL: String { return pictureURL  }
    
}

////------
////DirectoryItemDetailsPresentable
////------
extension LicensedProducer: DirectoryItemDetailsPresentable {
    
    var directoryDetailsTitle: String { return name }
    var directoryDetailsSubtitle: String? { return nil }
    var directoryDetailsPictureURL: String { return pictureURL }
    
    var likesCount: Int { return likes }
    var isLiked: Bool { return isLikedByCurrentUser }
    
    var leftDescription: String? { return nil }
    var rightDescription: String? { return nil }
    
    var traits: [TraitType] {
        return [
            .town,
            .phoneNumber,
            .email,
            .website
        ]
    }
    
    func content(of trait: TraitType) -> String? {
        switch trait {
        case .website: return website
        case .town: return address
        case .phoneNumber: return phoneNumber
        case .email: return email
        default: return nil
        }
    }
    
}

////------
////CampfiireMapAnnotation
////------
extension LicensedProducer: CampfiireMapAnnotation {
    var coordinate: CLLocationCoordinate2D {
        return CLLocationCoordinate2D(latitude: latitude,
                                      longitude: longitude)
    }
    
    var annotationTitle: String? { return name }
    var annotationSubtitle: String? { return nil }
}

////------
////TopRatedCellDisplayable
////------

extension LicensedProducer : TopRatedCellDisplayable {
    
    var topRatedTitle: String { return name }
    var topRatedSubtitle: String { return likes.countableString(withSingularNoun: "vote") }
    
    var topRatedPictureURL: String { return pictureURL }
    
}

////------
////DirectoryRoutProvidable
////------
extension LicensedProducer : DirectoryRoutProvidable {
    
    static func mapRout(query: String?, region: MKCoordinateRegion) -> URLRequestConvertible {
        return LicensedProducerRouter.map(georegion: region.circularApproximation,
                                          query: query)
    }
    
    static func listRout(query: String?, batch: Batch) -> URLRequestConvertible {
        return LicensedProducerRouter.list(query: query, batch: batch)
    }
    
    static func topRatedRout(batch: Batch?) -> URLRequestConvertible {
        return LicensedProducerRouter.top(batch: batch)
    }
    
    var detailsRout: URLRequestConvertible { return LicensedProducerRouter.details(producer: self) }
    var likeRout   : URLRequestConvertible { return LicensedProducerRouter.like(producer: self) }
    var dislikeRout: URLRequestConvertible { return LicensedProducerRouter.dislike(producer: self) }
    static var top10Rout: URLRequestConvertible { return LicensedProducerRouter.top(batch: nil) }
}

////------
////OptimisticCalculatable
////------
extension LicensedProducer: OptimisticCalculatable {
    
    func calculatedModel(change: Bool) -> LicensedProducer {
        var copy = self
        
        copy.isLikedByCurrentUser = change
        copy.likes += 1 * (change ? 1 : -1)
        
        return copy
    }
    
}

////------
////Fakeble
////------
extension LicensedProducer : Fakeble {
    
    static func fakeEntity() -> LicensedProducer {
        
        var instance = LicensedProducer(JSON: [:])!
        
        instance.id = LicensedProducer.fakeNumber(bound: 10000)
        
        instance.name = LicensedProducer.fakeString()
        
        instance.latitude = LicensedProducer.fakeDouble(min: -10 ,
                                              max: 10)
        
        instance.longitude = LicensedProducer.fakeDouble(min: -18,
                                               max: 18)
        
        instance.pictureURL = randomAvatarURL()
        instance.email = LicensedProducer.fakeString()
        instance.phoneNumber = LicensedProducer.fakeString()
        instance.website = fakeString()
        instance.insuranceNeeded = LicensedProducer.fakeBool()
        instance.address = fakeString()
        
        instance.likes = fakeNumber(bound: 432)
        instance.isLikedByCurrentUser = fakeBool()
        
        
        return instance
    }
    
    private static func randomAvatarURL() -> String {
        
        let avs = [
            "https://randomuser.me/api/portraits/men/50.jpg",
            "https://randomuser.me/api/portraits/men/85.jpg",
            "https://randomuser.me/api/portraits/men/57.jpg",
            "https://randomuser.me/api/portraits/women/11.jpg",
            "https://randomuser.me/api/portraits/women/29.jpg",
            "https://randomuser.me/api/portraits/women/58.jpg",
            ]
        
        return fakeValue(from: avs)
        
    }
    //
}
