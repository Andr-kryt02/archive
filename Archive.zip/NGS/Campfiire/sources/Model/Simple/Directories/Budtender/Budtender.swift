//
//  Budtender.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 14.11.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import ObjectMapper
import RxDataSources
import CoreLocation
import MapKit
import Alamofire

struct Budtender : Mappable {
    
    var id: Int = 0
    
    var pictureURL: String = ""
    var name: String = ""
    var gender: Gender? = nil
    
    var address: String = ""
    var phoneNumber: String = ""
    var email: String = ""
    
    var latitude: CLLocationDegrees = 0
    var longitude: CLLocationDegrees = 0
    
    var birthday: Date = Date(timeIntervalSince1970: 0)
    
    var likes: Int = 0
    var isLikedByCurrentUser: Bool = false
    
    var isOnline: Bool!
    
    var userId: Int = 0
    var user: User {
        return User(id: userId)
    }
    
    init(map: Map) {
        mapping(map: map)
    }
    
    mutating func mapping(map: Map) {
        
        id <- map["id"]
        pictureURL <- map["avatar"]
        name <- map["name"]
        gender <- map["gender"]
        address <- map["location"]
        phoneNumber <- map["cell_phone"]
        email <- map["email"]
        
        birthday <- (map["birthday"], ISO8601ExtendedDateTransform())
        
        latitude <- map["latitude"]
        longitude <- map["longitude"]
        
        likes <- map["rating"]
        isLikedByCurrentUser <- map["is_like"]
        
        userId <- map["user_id"]
        isOnline <- map["online"]
        
    }
    
    
}

////------
////RxDataSource
////------
extension Budtender : Equatable, IdentifiableType {
    
    var identity: Int { return id }
    
    static func ==(lhs: Budtender, rhs: Budtender) -> Bool {
        return lhs.id == rhs.id
    }
    
}

////------
////UserSearchResultCellPresentable
////------
extension Budtender: UserSearchResultCellPresentable {
    ////properties match name
    var isUserOnline: Bool {
        return self.isOnline ?? false
    }
}

////------
////DirectoryItemDetailsPresentable
////------
extension Budtender: DirectoryCellPresentable {
    
    var directoryCellTitle: String { return name }
    var directoryCellSubtitle: String? { return nil }
    var directoryCellAvatarURL: String { return self.pictureURL  }
    
}

extension Budtender: DirectoryItemDetailsPresentable {
    
    var directoryDetailsTitle: String { return name }
    var directoryDetailsSubtitle: String? { return nil }
    var directoryDetailsPictureURL: String { return pictureURL }
    
    var likesCount: Int { return likes }
    var isLiked: Bool { return isLikedByCurrentUser }
    
    var leftDescription: String? { return gender?.description ?? "Gender" }
    var rightDescription: String? { return "\((birthday as NSDate).yearsAgo()) y.o." }
    
    var traits: [TraitType] {
        return [
            .email,
            .location,
            .phoneNumber
            ]
    }
    
    func content(of trait: TraitType) -> String? {
        switch trait {
        case .location: return address
        case .phoneNumber: return phoneNumber
        case .email: return email
        default: return nil
        }
    }
    
}

////------
////TopRatedCellDisplayable
////------

extension Budtender : TopRatedCellDisplayable {
    
    var topRatedTitle: String { return name }
    var topRatedSubtitle: String { return likes.countableString(withSingularNoun: "vote") }
    
    var topRatedPictureURL: String { return pictureURL }
    
}

////------
////DirectoryRoutProvidable
////------
extension Budtender : DirectoryRoutProvidable {
    
    static func mapRout(query: String?, region: MKCoordinateRegion) -> URLRequestConvertible {
        return BudtenderRouter.map(georegion: region.circularApproximation,
                                query: query)
    }
    
    static func listRout(query: String?, batch: Batch) -> URLRequestConvertible {
        return BudtenderRouter.list(query: query, batch: batch)
    }
    
    static func topRatedRout(batch: Batch?) -> URLRequestConvertible {
        return BudtenderRouter.top(batch: batch)
    }
    
    var detailsRout: URLRequestConvertible { return BudtenderRouter.details(budtender: self) }
    var likeRout   : URLRequestConvertible { return BudtenderRouter.like(budtender: self) }
    var dislikeRout: URLRequestConvertible { return BudtenderRouter.dislike(budtender: self) }
    static var top10Rout: URLRequestConvertible { return BudtenderRouter.top(batch: nil) }
}

////------
////OptimisticCalculatable
////------
extension Budtender: OptimisticCalculatable {
    
    func calculatedModel(change: Bool) -> Budtender {
        var copy = self
        
        copy.isLikedByCurrentUser = change
        copy.likes += 1 * (change ? 1 : -1)
        
        return copy
    }
    
}


extension Budtender: Fakeble {
    
    static func fakeEntity() -> Budtender {
        
        var instance = Budtender(JSON: [:])!
        
        instance.userId = self.fakeNumber(bound: 1000)
        instance.name = self.fakeString()
        instance.pictureURL = randomAvatarURL()
        instance.birthday = fakeDate()
        instance.email = self.fakeString()
        instance.address = self.fakeString()
        instance.phoneNumber = self.fakeString()
        instance.likes = self.fakeNumber(bound: 1000)
        instance.isOnline = self.fakeBool()
        
        return instance
    }
    
    private static func randomAvatarURL() -> String {
        
        let avs = [
            "https://randomuser.me/api/portraits/men/50.jpg",
            "https://randomuser.me/api/portraits/men/85.jpg",
            "https://randomuser.me/api/portraits/men/57.jpg",
            "https://randomuser.me/api/portraits/women/11.jpg",
            "https://randomuser.me/api/portraits/women/29.jpg",
            "https://randomuser.me/api/portraits/women/58.jpg",
            ]
        
        return fakeValue(from: avs)
        
    }
    
}
