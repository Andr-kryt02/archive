//
//  Doctor.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 11.11.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import CoreLocation
import MapKit
import RxSwift
import ObjectMapper
import RxDataSources
import Alamofire

struct Doctor: Mappable {
       /*
 
     "id": long,
     "name": String,
     "specialization": String,
     "experience" : timestamp (String  - yyyy-MM-dd),
     "location" : String,        
     "cell_number": String,
     "email" : String,
     "avatar" : String,
     "rating" : int,
     "health_insurance" : boolean,
     “is_like”: boolean
     
     */
    
    var id: Int = 0
    
    var pictureURL: String = ""
    var name: String = ""
    var specialization: String = ""
    
    var latitude: CLLocationDegrees = 0
    var longitude: CLLocationDegrees = 0
    
    var worksSince: Date = Date(timeIntervalSince1970: 0)
    var phoneNumber: String = ""
    
    var address: String = ""
    var email: String = ""
    var likes: Int = 0

    var insuranceNeeded: Bool = false
    var isLikedByCurrentUser: Bool = false
    
    init(map: Map) {
        
        mapping(map: map)
    }
    
   
    mutating func mapping(map: Map) {

        id <- map["id"]
        pictureURL <- map["avatar"]
        name <- map["name"]
        
        latitude <- map["latitude"]
        longitude <- map["longitude"]
        specialization <- map["specialization"]
        worksSince <- (map["experience"], ISO8601ExtendedDateTransform())
        phoneNumber <- map["call_number"]
        address <- map["location"]
        email <- map["email"]
        likes <- map["rating"]
        insuranceNeeded <- map["health_insurance"]
        isLikedByCurrentUser <- map["is_like"]
        
    }
    
    
}

////------
////RxDataSource
////------
extension Doctor : Equatable, IdentifiableType {
    
    var identity: Int { return id }

    static func ==(lhs: Doctor, rhs: Doctor) -> Bool {
        return lhs.id == rhs.id
    }

}

////------
////DirectoryCellPresentable
////------
extension Doctor: DirectoryCellPresentable {

    var directoryCellTitle: String { return name }
    var directoryCellSubtitle: String? { return specialization }
    var directoryCellAvatarURL: String { return pictureURL  }
    
}

////------
////DirectoryItemDetailsPresentable
////------
extension Doctor: DirectoryItemDetailsPresentable {
    
    var directoryDetailsTitle: String { return name }
    var directoryDetailsSubtitle: String? { return "Insurance " + (insuranceNeeded ? "is" : "isn't") + " required" }
    var directoryDetailsPictureURL: String { return pictureURL }
    
    var likesCount: Int { return likes }
    var isLiked: Bool { return isLikedByCurrentUser }
    
    var leftDescription: String? { return nil }
    var rightDescription: String? { return nil }
    
    var traits: [TraitType] {
        return [.healthProblem,
                .experience,
                .town,
                .phoneNumber,
                .email
                ]
    }
    
    func content(of trait: TraitType) -> String? {
        switch trait {
        case .healthProblem: return specialization
        case .experience:
            return (worksSince as NSDate).yearsAgo()
                .countableString(withSingularNoun: "year") + " of expirience"
        
        case .town: return address
        case .phoneNumber: return phoneNumber
        case .email: return email
        default: return nil
        }
    }
    
}

////------
////CampfiireMapAnnotation
////------
extension Doctor: CampfiireMapAnnotation {
    var coordinate: CLLocationCoordinate2D {
        return CLLocationCoordinate2D(latitude: latitude,
                                      longitude: longitude)
    }

    var annotationTitle: String? { return name }
    var annotationSubtitle: String? { return specialization }
}

////------
////TopRatedCellDisplayable
////------

extension Doctor : TopRatedCellDisplayable {
    
    var topRatedTitle: String { return name }
    var topRatedSubtitle: String { return likes.countableString(withSingularNoun: "vote") }
    
    var topRatedPictureURL: String { return pictureURL }
    
}

////------
////DirectoryRoutProvidable
////------
extension Doctor : DirectoryRoutProvidable {
    
    static func mapRout(query: String?, region: MKCoordinateRegion) -> URLRequestConvertible {
        return DoctorRouter.map(georegion: region.circularApproximation,
                                query: query)
    }

    static func listRout(query: String?, batch: Batch) -> URLRequestConvertible {
        return DoctorRouter.list(query: query, batch: batch)
    }
    
    static func topRatedRout(batch: Batch?) -> URLRequestConvertible {
        return DoctorRouter.top(batch: batch)
    }
    
    var detailsRout: URLRequestConvertible { return DoctorRouter.details(doctor: self) }
    var likeRout   : URLRequestConvertible { return DoctorRouter.like(doctor: self) }
    var dislikeRout: URLRequestConvertible { return DoctorRouter.dislike(doctor: self) }
    static var top10Rout: URLRequestConvertible { return DoctorRouter.top(batch: nil) }
}

////------
////OptimisticCalculatable
////------
extension Doctor: OptimisticCalculatable {
    
    func calculatedModel(change: Bool) -> Doctor {
        var copy = self
        
        copy.isLikedByCurrentUser = change
        copy.likes += 1 * (change ? 1 : -1)
        
        return copy
    }
    
}

////------
////Fakeble
////------
extension Doctor : Fakeble {
    
    static func fakeEntity() -> Doctor {
        
        var instance = Doctor(JSON: [:])!
        
        instance.id = Doctor.fakeNumber(bound: 10000)
        
        instance.name = Doctor.fakeString()
        instance.specialization = Doctor.fakeString()
        
        instance.latitude = Doctor.fakeDouble(min: -10 ,
                                              max: 10)
        
        instance.longitude = Doctor.fakeDouble(min: -18,
                                               max: 18)
        
        instance.pictureURL = randomAvatarURL()
        instance.email = Doctor.fakeString()
        instance.phoneNumber = Doctor.fakeString()
        instance.worksSince = fakeDate()
        instance.insuranceNeeded = Doctor.fakeBool()
        instance.address = fakeString()
        
        instance.likes = fakeNumber(bound: 432)
        instance.isLikedByCurrentUser = fakeBool()
        
        
        return instance
    }
    
    private static func randomAvatarURL() -> String {
        
        let avs = [
            "https://randomuser.me/api/portraits/men/50.jpg",
            "https://randomuser.me/api/portraits/men/85.jpg",
            "https://randomuser.me/api/portraits/men/57.jpg",
            "https://randomuser.me/api/portraits/women/11.jpg",
            "https://randomuser.me/api/portraits/women/29.jpg",
            "https://randomuser.me/api/portraits/women/58.jpg",
            ]
        
        return fakeValue(from: avs)
        
    }
    //
}
