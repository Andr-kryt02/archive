//
//  Video.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 2016-12-19.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

import RxSwift
import ObjectMapper
import RxDataSources
import Alamofire

struct Video : Mappable {
    
    var id: Int = 0
  
    var title: String = ""
    var thumbNail : String = ""
    var url: String = ""

    
    init(map: Map) {
        mapping(map: map)
    }

    init() {}
    
    mutating func mapping(map: Map) {
        
        id <- map["id"]
        title <- map["name"]
        url <- map["link"]
        thumbNail <- map["path_image"]
    }
    
    
}

extension Video : Equatable, IdentifiableType {
    
    var identity: Int { return id }
    
    static func ==(lhs: Video, rhs: Video) -> Bool {
        return lhs.id == rhs.id
    }
    
}


extension Video : Storable {
    
    var identifier: Int { return id }
    
    static var storage: [Int : Variable<Video>] = [ : ]
    
}

extension Video: Fakeble {
    
    static func fakeEntity() -> Video {
        
        var instance = Video()
        instance.id = fakeNumber(bound: 10000)
        instance.title = self.fakeString(components: 5)
        instance.thumbNail = randomPictureURL()
        instance.url = randomVideoURL()

        
        return instance
    }
    
    private static func randomVideoURL() -> String {
        
        let avs = [
            "https://youtu.be/6Sw3E4MVdw0",
            "https://youtu.be/E0yqhLBnms0",
            "https://www.youtube.com/watch?v=ZOUyrtWeW4Q",
            "https://youtu.be/UHDfvfYCY0U",
            "https://youtu.be/aOTWo6_602Q"
            ]
        
        return fakeValue(from: avs)
        
    }
    
    
    private static func randomPictureURL() -> String {
        
        let avs = [
            "http://loremflickr.com/320/240/nature",
            "http://loremflickr.com/320/240/nature",
            "http://placeimg.com/200/100/nature",
            "http://placeimg.com/200/100/tech",
            "http://placeimg.com/200/100/arch",
            ]
        
        return fakeValue(from: avs)
        
    }

    
}




