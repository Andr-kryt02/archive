//
//  MMJ.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 12.12.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import ObjectMapper
import RxDataSources
import Alamofire

struct MMJ : Mappable {

    
    var image: String = ""
    var title: String = ""
    var url: String = ""
    var description : String = ""
    var date : String = ""
    
    
    
    init(map: Map) {
        mapping(map: map)
    }
    
    init() {}
    
    mutating func mapping(map: Map) {
        
        title <- map["title"]
        url <- map["link"]
        image <- map["image"]
        description <- map["description"]
        date <- map["date"]
        
    }

}

extension MMJ : Equatable, IdentifiableType {
    
    var identity: String { return title }
    
    static func ==(lhs: MMJ, rhs: MMJ) -> Bool {
        return lhs.title == rhs.title
    }
    
}


extension MMJ : Storable {
    
    var identifier: String { return title }
    
    static var storage: [String : Variable<MMJ>] = [ : ]
    
}

extension MMJ: Fakeble {
    
    static func fakeEntity() -> MMJ {
        
        var instance = MMJ()
    
        instance.title = self.fakeString(components: 5)
        instance.image = randomPictureURL()
        instance.url = randomSourceUrls()
        instance.description = self.fakeString(components: 25)
        
        return instance
    }
    
    
    private static func randomSourceUrls() -> String {
        
        let avs = [
            "http://www.leafly.com",
            "http://www.hightimes.com",
            "http://www.weedmaps.com",
            "http://www.thecannabist.co",
            "http://www.lift.co"
            ]
        
        return fakeValue(from: avs)
        
    }

    
    private static func randomPictureURL() -> String {
        
        let avs = [
            "http://placeimg.com/200/100/nature",
            "http://placeimg.com/200/100/tech",
            "http://placeimg.com/200/100/arch",
        ]
        
        return fakeValue(from: avs)
        
    }
    
}






