//
//  Tag.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/18/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import ObjectMapper

typealias Tag = String

extension Tag : Fakeble {
    
    static func fakeEntity() -> Tag {
        return self.fakeString()
    }
    
    init(name: String) {
        self = name
    }
    
}
