//
//  User.swift
//  Night Life
//
//  Created by Vlad Soroka on 2/5/16.
//  Copyright © 2016 com.NightLife. All rights reserved.
//

import Foundation

import RxSwift
import ObjectMapper
import RxDataSources
import XMPPFramework

struct User: UserProtocol, Mappable {
    
    var id : Int = 0
    var identifier: Int { return id }
    
    var pictureURL : String = ""
    var name : String = ""
    var birthdate: Date = Date()
    var gender: Gender? = nil
    
    var email : String?
    var favoriteProduct : String?
    var healthProblem : String?
    var location : String?
    
    var isBlocked: Bool = false
    var isOnline: Bool = false
    var isFriend: Bool? = nil
    
    var tags: [Tag] = []
    
    init?(map: Map) {
        mapping(map: map)
    }
    
    init(id: Int) {
        self.id = id
    }
    
    mutating func mapping(map: Map) {
        
        id <- map["id"]
        
        pictureURL <- map["avatar"]
        name <- map["username"]
        birthdate <- (map["birthday"], ISO8601ExtendedDateTransform())
        gender <- map["gender"]
        email <- map["email"]
        favoriteProduct <- map["favorite_product"]
        healthProblem <- map["health_problem"]
        location <- map["location"]
        
        isOnline <- map["is_online"]
        isBlocked <- map["is_block"]
        isFriend <- map["is_friend"]
        
        tags <- map["tags"]
        
    }

}

extension User : UserSearchResultCellPresentable {
    var isUserOnline: Bool { return isOnline }
}

extension User : Storable {
    static var storage: [Int : Variable<User>] = [ : ]

}

extension User: Hashable {
    
    var hashValue: Int {
        return id
    }
}

extension User : IdentifiableType, Equatable {
    
    typealias Identity = Int
    
    var identity: Int {
        return id
    }

    static func ==(lhs: User, rhs: User) -> Bool {
        return lhs.id == rhs.id
    }
}

extension User : TraitPresentable {
    
    func content(of trait: TraitType) -> String? {
        var content: String? = nil
        
        switch trait {
        case .email: content = self.email
        case .favoriteProduct: content = self.favoriteProduct
        case .healthProblem: content = self.healthProblem
        case .location: content = self.location
        default : content = nil
        }
        
        return content
    }
    
    func updatedTrait(trait: TraitType, value: String?) -> User {
    
        var input: String? = nil
        if let v = value, v.lengthOfBytes(using: .utf8) > 0 {
            input = value
        }
        
        var user = self
        
        switch trait {
        case .email: user.email = input
        case .favoriteProduct: user.favoriteProduct = input
        case .healthProblem: user.healthProblem = input
        case .location: user.location = input
        default: break
        }
        
        return user
    }
    
}


extension User: Fakeble {
    
    static func fakeEntity() -> User {
        var instance = User(JSON: ["id" : 0])!
        
        instance.email = self.fakeString()
        instance.name = self.fakeString()
        instance.favoriteProduct = self.fakeString()
        instance.location = self.fakeString()
        instance.birthdate = self.fakeDate()
        instance.gender = self.fakeBool() ? .male : .female
        instance.id = self.fakeNumber(bound: 1000)
        instance.healthProblem = self.fakeString()
        instance.pictureURL = randomAvatarURL()
        
        instance.isOnline = fakeBool()
        
        ///
        let closure = { (i: Int) -> [Tag] in
            var a:[Tag] = []
            for _ in 0...i {
                a.append(Tag.fakeEntity())
            }
            return a
        }
        
        instance.tags = closure(fakeNumber(bound: 5))
        
        return instance
    }
    
    private static func randomAvatarURL() -> String {
        
        let avs = [
            "https://randomuser.me/api/portraits/men/50.jpg",
            "https://randomuser.me/api/portraits/men/85.jpg",
            "https://randomuser.me/api/portraits/men/57.jpg",
            "https://randomuser.me/api/portraits/women/11.jpg",
            "https://randomuser.me/api/portraits/women/29.jpg",
            "https://randomuser.me/api/portraits/women/58.jpg",
        ]
        
        return avs[self.fakeNumber(bound: UInt32(avs.count))]
        
    }
    
}

extension User {
    
    init?(xml: DDXMLElement) {
        
        ///TODO: enforce peer tag name
        guard let n = xml.name, n == "peer"
            else { return nil }
        
        guard let jidStr = xml.stringValue, let jid = XMPPJID(string: jidStr) else {
            return nil
        }
        
        guard let onlineString = xml.attribute(forName: "is-online")?.stringValue,
            let bool = Bool(str: onlineString) else {
                return nil
        }
        
        if let u = refreshedEntity() {
            self = u
        }
        
        self.id = jid.userCampfiire.id
        self.isOnline = bool
        
    }
    
    var jid: XMPPJID {
        return XMPPJID(string: "\(id)@campfiire")
    }
    
}

extension XMPPJID {
    
    var userCampfiire: User {
        return User(id: Int(user)!)
    }
    
}

extension Bool {
    init? (str: String) {
        if str == "true" { self = true; return }
        if str == "false" { self = false; return }
        
        return nil;
    }
}
