//
//  Gender.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/7/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import ObjectMapper

enum Gender: Int, CustomStringConvertible {
    
    case male = 1
    case female = 2
    
    var description: String {
        switch self {
        case .male: return "Male"
        case .female: return "Female"
        }
    }
}
