//
//  RegistrationData.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/23/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Alamofire
import ObjectMapper

struct RegistrationData {
    
    let username: String
    let password: String
    let email: String
    
    let birthdate: Date?
    let location: String?
    let gender: Gender?
    let favoriteProduct: String?
    
    let tags: [Tag]
    
    let tempImageURL: String?
    
    func serialize() -> Parameters {
        
        let dict: [String: Any?] = ["username"          : username,
                                    "password"          : password,
                                    "email"             : email,
                                    "birthday"          : ISO8601ExtendedDateTransform().transformToJSON(birthdate),
                                    "location"          : location,
                                    "favorite_product"  : favoriteProduct,
                                    "gender"            : gender?.rawValue,
                                    "tags"              : tags.map { $0 },
                                    "is_social"         : false]
        
        return dict.nullKeyRemoval()
        
    }
    
}
