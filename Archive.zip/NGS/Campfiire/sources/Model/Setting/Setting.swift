//
//  Setting.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/25/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift

protocol UserDefaultsStorable {
    
    func store(for key: String)
    init?(key: String)

}

struct Setting<T: UserDefaultsStorable> {
    
    var value: T {
        return variableValue.value
    }
    
    var observable: Observable<T> {
        return variableValue.asObservable()
    }
    
    func update(with value: T) {
        self.variableValue.value = value
    }
    
    fileprivate let variableValue: Variable<T>
    
    init (key: String, initialValue: T) {
        
        variableValue = Variable( T(key: key) ?? initialValue )
        
        let _ =
        variableValue.asObservable()
            .subscribe(onNext: { (newValue) in
                
                newValue.store(for: key)
                UserDefaults.standard.synchronize()
                
            })
    }
    
}


extension Bool : UserDefaultsStorable {
    
    func store(for key: String) {
        UserDefaults.standard.set(self, forKey: key)
    }
    
    init?(key: String) {
        
        guard let _ = UserDefaults.standard.object(forKey: key) else { return nil }
        
        self = UserDefaults.standard.bool(forKey: key)
    }
    
    static func retreive(for key: String) {
        return
    }
    
}
