//
//  MVVM.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/15/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import UIKit

////generic ViewController that requires all controllers to have ViewModels

protocol ViewController {
    
    associatedtype VM: ViewModel
    
    ///until apple allows creating custom intializers for ViewControllers created from storyboards, we are using unwrapped optionals to shut up the compiler
    var viewModel: VM! { get }
    
}

protocol ViewModel {
    
    weak var handler: UIViewController? { get }
    
}
