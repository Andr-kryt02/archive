//
//  DismissSelf.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/3/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

protocol CanPopBack {
    
    func popBack(animated: Bool)
    func popBackToRoot(animated: Bool)
    
}

extension UIViewController : CanPopBack {
    
    func popBack(animated: Bool) {
        let _ = navigationController?.popViewController(animated: animated)
    }
    
    func popBackToRoot(animated: Bool) {
        let _ = navigationController?.popToRootViewController(animated: true)
    }
    
}
