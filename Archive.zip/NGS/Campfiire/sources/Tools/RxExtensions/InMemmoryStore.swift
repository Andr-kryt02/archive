//
//  InMemmoryStore.swift
//  Night Life
//
//  Created by Vlad Soroka on 4/6/16.
//  Copyright © 2016 com.NightLife. All rights reserved.
//

import Foundation
import RxSwift

/// TODO: |Vlad| work on Signal for storageCahnged event. Think of proper parametrs that could be sent along with event
///TODO: |Vlad| work on purgin all entities on low memmory conditions??
protocol Storable {
    
    associatedtype IdentifierType: Hashable
    
    var identifier: IdentifierType { get }

    static var storage: [IdentifierType : Variable<Self>] { get set }
    
    static func entityBy(identifier: IdentifierType) -> Self?
    static func observableEntityBy(identifier: IdentifierType) -> Variable<Self>?
    static func allEntities() -> [Variable<Self>]
    
    func refreshedEntity() -> Self?
    func observableEntity() -> Variable<Self>?
    func saveEntity()
    func removeFromStorage()
    
}

extension Storable {
    
    static func entityBy(identifier: IdentifierType) -> Self? {
        return self.storage[identifier]?.value
    }
    
    static func observableEntityBy(identifier: IdentifierType) -> Variable<Self>? {
        return self.storage[identifier]
    }
    
    static func allEntities() -> [Variable<Self>] {
        return Array(self.storage.values)
    }
    
    func observableEntity() -> Variable<Self>? {
        return Self.storage[identifier]
    }
    
    func saveEntity() {
        if let existingEntity = observableEntity() {
            existingEntity.value = self
        }
        else {
            let variable = Variable(self)
            Self.storage[identifier] = variable
        }
    }
    
    func removeFromStorage() {
        Self.storage.removeValue(forKey: identifier)
    }
    
    func refreshedEntity() -> Self? {
        return Self.storage[identifier]?.value
    }
    
}
