//
//  ReactivePhotoTake.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/19/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import RxSwift

extension FDTakeController {
    
    func rxex_photo() -> Observable<UIImage> {
        
        return Observable.create{ observer in
            
            self.didGetPhoto = { image, info in
                observer.onNext(image)
            }
            
            return Disposables.create()
        }
        
    }
    
}
