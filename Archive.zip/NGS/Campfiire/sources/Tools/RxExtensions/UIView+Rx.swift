//
//  UIView+RX.swift
//  Campfiire
//
//  Created by Vlad Soroka on 1/20/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

extension Reactive where Base: UIView {
    
    /// Bindable sink for `isUserInteractionEnabled` property.
    public var isUserInteractionEnabled: UIBindingObserver<Base, Bool> {
        return UIBindingObserver(UIElement: self.base) { view, hidden in
            view.isUserInteractionEnabled = hidden
        }
    }
    
}
