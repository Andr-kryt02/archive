//
//  GoogleAuthenticator.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/16/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import UIKit
import RxSwift
import SafariServices

extension GoogleAuthenticator : Authenticator {
 
    static let identifier = "google"
    
    func authenticateUser(onController controller: UIViewController) -> Observable<AuthenticationData> {
        
        let auth = Google()
        
        auth.scopes = ["https://www.googleapis.com/auth/plus.login",
                       "https://www.googleapis.com/auth/plus.me" ]
        
        
        Simplicity.safariLogin(Google(),
                               safariDelegate: self)
        { [unowned self] maybeToken, maybeError in
        
            guard maybeError == nil else {
                
                self.outcome.value = ( nil, CampfiireError.generic(description: maybeError!.localizedDescription))
                
                return;
            }
                                
            guard let token = maybeToken else {
                fatalError("Simplicity for google returned neither token nor error")
            }
            
            self.outcome.value = ( token, nil )
            
        }
        return outcome.asObservable()
                .notNil()
                .take(1)
                .flatMapLatest { (maybeToken, error) -> Observable<AuthenticationData> in
                    
                    guard error == nil else {
                        
                        return Observable.error(error!)
                        
                    }
                    
                    guard let token = maybeToken else {
                        fatalError("Can't handle no error, no user situation when logging in to Google")
                    }
                    
                    let data = RemoteAuthData(token: token,
                                              backendIdentifier: GoogleAuthenticator.identifier)
                    
                    return Observable.just(.external(data: data))
                }

    }

    
}

class GoogleAuthenticator : NSObject {
    
    fileprivate let outcome: Variable<( String? , CampfiireError? )?> = Variable(nil)
    
}

extension GoogleAuthenticator : SFSafariViewControllerDelegate {
    
    func safariViewControllerDidFinish(_ controller: SFSafariViewController) {
        outcome.value = (nil, CampfiireError.userCanceled)
    }
    
}
