//
//  Authenticator.swift
//  Night Life
//
//  Created by Vlad Soroka on 2/12/16.
//  Copyright © 2016 com.NightLife. All rights reserved.
//

import RxSwift

struct RemoteAuthData {
    
    let token: String
    let backendIdentifier: String
    
    var headerString: String {
        
        return "Bearer " + Data(backendIdentifier.utf8).base64EncodedString() + ";\(token)"
    }
}

/**
 *  @discussion - data that can be used for authentication in Campfiire
 */
enum AuthenticationData {
    
    case external(data: RemoteAuthData)
    
    case credentials(email: String, password: String)
    case register(registrationData: RegistrationData)
    
}

protocol Authenticator {
    
    func authenticateUser(onController controller: UIViewController) -> Observable<AuthenticationData>
    
}


struct CredentialsAuthenticator : Authenticator {
    let email: String
    let password: String
    
    func authenticateUser(onController controller: UIViewController) -> Observable<AuthenticationData> {
        return Observable.just(.credentials(email: email, password: password))
    }
}

struct RegistrationAuthenticator : Authenticator {
    
    let data: RegistrationData
    
    func authenticateUser(onController controller: UIViewController) -> Observable<AuthenticationData> {
        return Observable.just(.register(registrationData: data))
    }
    
}
