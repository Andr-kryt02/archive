//
//  FacebookAuthenticator.swift
//  Night Life
//
//  Created by Vlad Soroka on 2/12/16.
//  Copyright © 2016 com.NightLife. All rights reserved.
//

import Foundation
import RxSwift
import SafariServices

extension FacebookAuthenticator : Authenticator {

    static private let backendIdentifier = "facebook"
    
    func authenticateUser(onController controller: UIViewController) -> Observable<AuthenticationData> {
        
        let fb = Facebook()
        fb.scopes = ["public_profile", "email"]
        
        Simplicity.safariLogin(fb, safariDelegate: self) {
            [unowned self] maybeToken, maybeError in
            
            guard maybeError == nil else {
                
                self.outcome.value = ( nil, CampfiireError.generic(description: maybeError!.localizedDescription))
                
                return;
            }
            
            guard let token = maybeToken else {
                fatalError("Simplicity for google returned neither token nor error")
            }
            
            self.outcome.value = ( token, nil )
            
        }
        
        return outcome.asObservable()
            .notNil()
            .take(1)
            .flatMapLatest { (maybeToken, error) -> Observable<AuthenticationData> in
                
                guard error == nil else {
                    return Observable.error(error!)
                }
                
                guard let token = maybeToken else {
                    fatalError("Can't handle no error, no user situation when logging in to Facebook")
                }
                
                let data = RemoteAuthData(token: token,
                                          backendIdentifier: FacebookAuthenticator.backendIdentifier)
                
                return Observable.just(.external(data: data))
        }
        

    }
    
}

class FacebookAuthenticator : NSObject {
    
    fileprivate let outcome: Variable<( String? , CampfiireError? )?> = Variable(nil)
    
}

extension FacebookAuthenticator : SFSafariViewControllerDelegate {
    
    func safariViewControllerDidFinish(_ controller: SFSafariViewController) {
        outcome.value = (nil, CampfiireError.userCanceled)
    }
    
}
