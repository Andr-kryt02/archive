//
//  InstagramAuthenticator.swift
//  Night Life
//
//  Created by Vlad Soroka on 2/11/16.
//  Copyright © 2016 com.NightLife. All rights reserved.
//

import Foundation
import RxSwift

class InstagramAuthenticator : Authenticator {
    
    static private let backendIdentifier = "instagram"
    
    func authenticateUser(onController controller: UIViewController) -> Observable<AuthenticationData> {
        
        return Observable.create { observer in
            
            let loginController = InstagramLoginViewController(presenter: controller)
                { (maybeToken, maybeError) -> Void in
                
                    if let er = maybeError {
                        observer.onError(er)
                        return
                    }
                    
                    /// "We expect accessToken to be valid if error is nil"
                    let token = maybeToken!
                    
                    let data = RemoteAuthData(token: token,
                        backendIdentifier: InstagramAuthenticator.backendIdentifier)
                    
                    
                    observer.onNext(.external(data: data))
                    observer.onCompleted()
            }
            
            loginController.presentLogin()
            
            return Disposables.create { loginController.stopLoading() }
            
        }
        
    }
    
    
}
