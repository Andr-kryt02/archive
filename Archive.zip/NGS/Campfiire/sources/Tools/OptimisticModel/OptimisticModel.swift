//
//  OptimisticModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/4/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import RxSwift

protocol OptimisticCalculatable {
    
    func calculatedModel(change: Bool) -> Self
    func serverUpdateFor(change: Bool) -> Observable<Self>
    
}

class OptimisticModelManager<T: OptimisticCalculatable> {
    
    ///last confirmed status from server.
    ///this should always match the server's value
    ///is expected to be set once initially before usage
    var confirmedModel: T!
    
    var likeActionOutcome: Observable<T> {
        return likeActionVariable.asObservable()
            .notNil()
    }
    private let likeActionVariable: Variable<T?> = Variable(nil)
    private let latestChange: Variable< (Bool, T)? > = Variable(nil)
    
    init() {
        
        latestChange.asObservable()
            .notNil()
            .debounce(0.2, scheduler: MainScheduler.instance)
            .flatMap { [unowned self] (changeTuple: (Bool, T)) -> Observable<T> in
                
                return changeTuple.1.serverUpdateFor(change: changeTuple.0)
                        .do(onNext: { [unowned self] (value) in
                            self.confirmedModel = value
                        })
                        .retry(1)
                        .catchErrorJustReturn( self.confirmedModel )
                
            }
            .bindTo(likeActionVariable)
            .addDisposableTo(bag)
        
    }
    
    func queueChange(change: Bool, model: T) {
        
        likeActionVariable.value = model.calculatedModel(change: change)
        latestChange.value = (change, model)
        
    }
    
    private let bag = DisposeBag()
    
}
