//
//  ReactiveObjectMapping.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/11/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Alamofire
import ObjectMapper
import RxSwift

extension Alamofire.DataRequest {
    
    func rx_campfiireResponse<T: CampfiireResponeProtocol>(_ unused: T.Type) -> Observable<T.DataType> {
        
        return Observable.create { [weak self] (subscriber) -> Disposable in
            
            let request =
                self?.validate(statusCode: 200...299)
                    .responseObject { [weak self] (response: DataResponse< T >) in
                
                do {
                    guard let s = self else {
                        
                        ///happens when Observer get's disposed, but request.cancel() does not interrupt network request and still invokes completition handler
                        
                        subscriber.onCompleted()
                        return;
                    }
                    
                    let data = try s.processResponse(response: response)
                    
                    subscriber.onNext( data )
                    subscriber.onCompleted()
                }
                catch (let er) {
                    
                    guard let afError = er as? AFError,
                        case .responseValidationFailed(let reason) = afError,
                        case .unacceptableStatusCode(let code) = reason,
                        code == 401
                    else {
                        subscriber.onError(er)
                        return;
                    }
                    
                    subscriber.onError(CampfiireError.unauthorised)
                    
                }
            }
            
            return Disposables.create { request?.cancel() }
        }
    }
    
    
}

extension Alamofire.DataRequest {
    
    fileprivate func processResponse<S: CampfiireResponeProtocol>
        (response : DataResponse<S>) throws -> S.DataType {
        
        if let er = response.result.error {
            throw er
        }
        
        guard let mappedResponse = response.result.value else {
            fatalError("Result is not success and not error")
        }
        
        if let m = mappedResponse.errorMessage,
            let code = mappedResponse.code {
            
            throw CampfiireError.businessError(code: code, message: m)
        }
        
        guard let data = mappedResponse.data else {
            throw CampfiireError.generic(description: "Server returned malformed response ('data' key is invalid)")
        }
        
        return data
    }
    
}

///TODO: Verify, that images are not exreamly heavy, probably squeeze them

///currently works only for images
func rx_upload<T: AuthorizedRouter>
              ( rout: T, data: [String : Data]) -> Observable<Alamofire.DataRequest> {

    return Observable.create { (observer) -> Disposable in
     
        Alamofire
            .upload(multipartFormData: { (formData) in
            
            for (key, value) in data {
                formData.append(value, withName: key, fileName: "image.jpg", mimeType: "image/jpeg")
            }
            
        }, with: rout,
           encodingCompletion: { (res: SessionManager.MultipartFormDataEncodingResult) in
            
            switch res {
            case .failure(let er):
                observer.onError(er)
                
            case .success(let request, _, _):
                
                observer.onNext( request )
                observer.onCompleted()
                
            }
            
        })
        
        return Disposables.create {  }
        
    }
    

    
}
