//
//  Base.swift
//  Night Life
//
//  Created by Vlad Soroka on 2/16/16.
//  Copyright © 2016 com.NightLife. All rights reserved.
//

import Alamofire
import RxSwift

struct GatewayConfiguration {

#if DEBUG
    static let hostName = "http://178.165.92.42:8082/campfiire"
#elseif ADHOC
    static let hostName = "http://178.165.92.42:8081/campfiire/api/test"
#else
    static let hostName = "http://34.195.42.117:8082/campfiire"
#endif
    
}

protocol AuthorizedRouter : URLRequestConvertible {
    
    func authorizedRequest(method: Alamofire.HTTPMethod,
        path: String,
        params: Parameters,
        encoding: ParameterEncoding,
        headers: HTTPHeaders?) -> URLRequest
    
    func unauthorizedRequest(method: Alamofire.HTTPMethod,
        path: String,
        params: Parameters,
        encoding: ParameterEncoding,
        headers: HTTPHeaders?) -> URLRequest
    
}

extension AuthorizedRouter {
    
    func authorizedRequest(method: Alamofire.HTTPMethod,
        path: String,
        params: Parameters = [:],
        encoding: ParameterEncoding = URLEncoding.default,
        headers: HTTPHeaders? = nil) -> URLRequest {
        
        var request = self.unauthorizedRequest(method: method,
                                               path: path,
                                               params: params,
                                               encoding: encoding,
                                               headers: headers)

        guard let token = AccessToken.token else {
            fatalError("Can't make authorized request without stored token")
        }
        
        request.setValue(token, forHTTPHeaderField: "Authorization")
        
        return request
    }
    
    func unauthorizedRequest(method: Alamofire.HTTPMethod,
        path: String,
        params: Parameters = [:],
        encoding: ParameterEncoding = URLEncoding.default,
        headers: HTTPHeaders? = nil)
         -> URLRequest {
            
            let URL = NSURL(string: GatewayConfiguration.hostName)!
            var request = URLRequest(url: URL.appendingPathComponent(path)!)
            request.httpMethod = method.rawValue
            
            if let h = headers {
                for (key, value) in h {
                    request.setValue(value, forHTTPHeaderField: key)
                }
            }
            else {
                request.setValue("application/json", forHTTPHeaderField: "Accept")
            }
            
            
            do {
                return try encoding.encode(request, with: params)
            }
            catch (let error) {
                fatalError("Error encoding request \(request), details - \(error)")
            }
            
    }
    
}
