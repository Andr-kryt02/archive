//
//  SimpleRouter.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 2016-12-20.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import Alamofire

enum SimpleRouter : AuthorizedRouter {
    
    case mmj(batch: Batch)
    case video
    case infoSource
}

extension SimpleRouter {
    
    func asURLRequest() throws -> URLRequest {
        
        switch self {
            
        case .mmj(let batch):
            
            let params : [String: Any?] = ["count"  : batch.limit,
                                           "offset" : batch.offset]
            return self.authorizedRequest(method: .get,
                                          path: "/mmj",
                                          params : params.nullKeyRemoval())
            
        case .video:
          
            
            return self.authorizedRequest(method: .get,
                                          path: "commercial/video"
                                          )
            
        case .infoSource:
            
            return self.authorizedRequest(method: .get,
                                          path: "commercial/infosource")
            
   
        }
        
    }
    
}
