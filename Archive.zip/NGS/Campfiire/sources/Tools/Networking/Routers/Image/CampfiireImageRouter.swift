//
//  CampfiireImageRout.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/23/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

enum CampfiireImageRouter : AuthorizedRouter {
    
    case image(url: String)
    
}

extension CampfiireImageRouter {
    
    func asURLRequest() throws -> URLRequest {
        
        switch self {
        case .image(let url):
            var request = self.authorizedRequest(method: .get,
                                                 path: "", ///full image path will be provided later with url parametr
                                                 headers: [ : ]) ////we should not put any special headers into this request
            request.url = URL(string: url)
            
            return request
        }
        
    }
    
}
