//
//  NewsFeedRouter.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/13/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import ObjectMapper

enum NewsFeedRouter : AuthorizedRouter {
    
    case feed(batch: NewsFeedViewModel.NewsProvider.State)
    
}

extension NewsFeedRouter {
    
    func asURLRequest() throws -> URLRequest {
        switch self {
        case .feed(let batch):
            
            let page: Int = batch.timesLoaded
            let timestamp = ISO8601ExtendedDateTransform().transformToJSON(batch.lastTimestamp)
            
            let params: [String: Any?] = [ "page" : page,
                                           "timestamp" : timestamp]
            
            return self.authorizedRequest(method: .get,
                                          path: "/feed",
                                          params: params.nullKeyRemoval())
        
        }
    }
    
}
