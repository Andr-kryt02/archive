//
//  PhotoRouter.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/23/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

//import Foundation
//import Alamofire
//
//enum PhotoRouter : AuthorizedRouter {
//    
//    case postComment (comment : Comment)
//    
//    case selectForCamp (photo : Photo)
//    
//    case deleteForCamp (photo : Photo)
//    
//}
//
//extension PhotoRouter {
//    
//    func asURLRequest() throws -> URLRequest {
//        
//        switch self {
//            
//        case .postComment (let comment) :
//            
//            return self.authorizedRequest(method: .post,
//                                          path: "camp/photo/\(comment.id)")
//            
//        case .selectForCamp (let photo) :
//            
//            return self.authorizedRequest(method: .post,
//                                          path: "camp/photo/\(photo.id)")
//            
//        case .deleteForCamp (let photo) :
//            
//            return self.authorizedRequest(method: .delete,
//                                          path: "camp/photo/\(photo.id)")
//            
//        }
//    }
//}
