//
//  CampRouter.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/22/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Alamofire

enum CampRouter : AuthorizedRouter {

    ///CRUD
    case details (camp : Camp)
    case list(query: String?, followedOnly: Bool, batch: Batch)
    
    case create (camp : Camp)
    case update (camp : Camp)
    case delete (camp : Camp)
    
    ///Following
    case follow (camp : Camp)
    case unfollow (camp : Camp)
    
    ///Comments
    case postComment ( camp : Camp, text : String)
    case commentsList ( camp : Camp, batch : Batch)
    
    case selectFollowers (camp : Camp)
    
    
    ///Reports
    
    case reportCamp (camp : Camp)
    case reportMessage (comment : Comment)
    
    
    
    case top (batch : Batch?)
}

extension CampRouter {
    
    func asURLRequest() throws -> URLRequest {
        
        switch self {
            
        case .list(let query, let followedOnly, let batch):
            
            let params : [String: Any?] = ["q"         : query,
                                          "favorites" : followedOnly,
                                          "offset"    : batch.offset,
                                          "count"     : batch.limit]
            
            return self.authorizedRequest(method: .get,
                                          path: "/camp",
                                          params: params.nullKeyRemoval())
            
            
        case .details (let camp) :
            
            return self.authorizedRequest(method: .get,
                                          path: "/camp/\(camp.id)")
            
        case .delete (let camp) :
            
            return self.authorizedRequest(method: .delete,
                                          path: "/camp/\(camp.id)")
            
        case .create (let camp) :
            
            let params : [String : Any?] = camp.toJSON()
            
            return self.authorizedRequest(method: .post,
                                          path: "/camp",
                                          params: params.nullKeyRemoval(),
                                          encoding: JSONEncoding.default)
            
        case .update(let camp) :
            
            let params : [String : Any?] = camp.toJSON()
            
            return self.authorizedRequest(method: .put,
                                          path: "/camp",
                                          params: params.nullKeyRemoval(),
                                          encoding: JSONEncoding.default)
            
        case .selectFollowers(let camp) :
            
            return self.authorizedRequest(method: .get,
                                          path: "/camp/followers/\(camp.id)")
            
        case .follow (let camp) :
            
            return self.authorizedRequest(method: .post,
                                          path: "/camp/favorite/\(camp.id)")
            
        case .unfollow (let camp) :
            
            return self.authorizedRequest(method: .delete,
                                          path: "/camp/favorite/\(camp.id)")
            
            
        case .postComment (let camp, let text) :
            
            let params : [String : Any] = ["text" : text]
            
            return self.authorizedRequest(method: .post,
                                          path: "camp/\(camp.id)/message",
                                          params: params,
                                          encoding: JSONEncoding.default)
            
        case .commentsList (let camp, let batch) :
            
            return self.authorizedRequest(method: .get,
                                          path: "camp/message/all",
                                          params: ["camp_id" : camp.id,
                                                   "offset" : batch.offset,
                                                   "count" : batch.limit],
                                          encoding: URLEncoding.default)
        case .reportCamp(let camp) :
            
            return self.authorizedRequest(method: .post,
                                          path: "/report/camp/\(camp.id)")

        case .reportMessage(let comment) :
          
            return self.authorizedRequest(method: .post,
                                          path: "/report/camp_message/\(comment.id)")
        
        case .top (let batch):
            
            let b = batch ?? Batch(offset: 0, limit: 10)
            
            return self.authorizedRequest(method: .get,
                                          path: "/camp/top",
                                          params: ["count" : b.limit,
                                                   "offset" : b.offset])
        }
        
    
    }
    
}


