//
//  EntityRouter.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 05.12.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import Alamofire
import MapKit
import CoreLocation

enum DoctorRouter: AuthorizedRouter {
   
    case list(query: String?, batch : Batch)
    case map ( georegion : CLCircularRegion, query: String?)
    
    case details (doctor : Doctor)
    case like (doctor : Doctor)
    case dislike (doctor : Doctor)
    
    case top (batch : Batch?)
}

extension DoctorRouter {
    
    func asURLRequest() throws -> URLRequest {
        
        switch self {
          
        case .list(let query, let batch):
            
            let params : [String : Any?] = ["key" : query,
                                            "count" : batch.limit,
                                            "offset" : batch.offset]
            
            return self.authorizedRequest(method: .get,
                                          path: "/commercial/doctor",
                                          params: params.nullKeyRemoval(),
                                          encoding: URLEncoding.default)
            

            
            
            
        case .map( let georegion, let query):
            
            let params : [String : Any?] = ["latitude" : georegion.center.latitude,
                                            "longitude" : georegion.center.longitude,
                                            "radius" : georegion.radius / 1000,
                                            "key" : query
            ]
            
            return self.authorizedRequest(method: .get,
                                          path: "/commercial/doctor/map",
                                          params: params.nullKeyRemoval(),
                                          encoding: URLEncoding.default)
            
        case .details (let doctor) :
            
            return self.authorizedRequest(method: .get,
                                          path: "/commercial/doctor/\(doctor.id)")
            
        case .like (let doctor) :
            
            return self.authorizedRequest(method: .post,
                                          path: "/commercial/doctor/like/\(doctor.id)")
            
        case .dislike (let doctor) :
            
            return self.authorizedRequest(method: .delete,
                                          path: "/commercial/doctor/like/\(doctor.id)")
            
        case .top (let batch):
            
            let b = batch ?? Batch(offset: 0, limit: 10)
            
            return self.authorizedRequest(method: .get,
                                          path: "/commercial/doctor/top",
                                          params: ["count" : b.limit,
                                                   "offset" : b.offset])
        }
    }
    
}

