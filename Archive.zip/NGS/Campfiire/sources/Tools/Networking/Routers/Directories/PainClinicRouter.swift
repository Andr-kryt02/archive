//
//  PainClinicRouter.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 06.12.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import Alamofire
import MapKit
import CoreLocation

enum PainClinicRouter : AuthorizedRouter {
    
    case list(query: String?, batch : Batch)
    case map ( georegion : CLCircularRegion, query: String?)
    
    case details (clinic : PainClinic)
    
    case like (clinic : PainClinic)
    case dislike (clinic : PainClinic)
    
    case top (batch : Batch?)
    
}

extension PainClinicRouter {
    
    func asURLRequest() throws -> URLRequest {
        
        switch self {
            
        case .list(let query, let batch):
            
            let params : [String : Any?] = ["key" : query,
                                            "count" : batch.limit,
                                            "offset" : batch.offset]
            
            return self.authorizedRequest(method: .get,
                                          path: "/commercial/clinic",
                                          params: params.nullKeyRemoval(),
                                          encoding: URLEncoding.default)
            
            
            
            
            
        case .map( let georegion, let query):
            
            let params : [String : Any?] = ["latitude" : georegion.center.latitude,
                                            "longitude" : georegion.center.longitude,
                                            "radius" : georegion.radius / 1000,
                                            "key" : query
            ]
            
            return self.authorizedRequest(method: .get,
                                          path: "/commercial/clinic/map",
                                          params: params.nullKeyRemoval(),
                                          encoding: URLEncoding.default)
            
        case .details (let clinic) :
            
            return self.authorizedRequest(method: .get,
                                          path: "/commercial/clinic/\(clinic.identity)")
            
        case .like (let clinic) :
            
            return self.authorizedRequest(method: .post,
                                          path: "/commercial/clinic/like/\(clinic.identity)")
            
        case .dislike (let clinic) :
            
            return self.authorizedRequest(method: .delete,
                                          path: "/commercial/clinic/like/\(clinic.identity)")
            
        case .top (let batch):
            
            let b = batch ?? Batch(offset: 0, limit: 10)
            
            return self.authorizedRequest(method: .get,
                                          path: "/commercial/clinic/top",
                                          params: ["count" : b.limit,
                                                   "offset" : b.offset])
        }
    }
    
}
