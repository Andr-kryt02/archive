//
//  BudtenderRouter.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 06.12.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import Alamofire
import MapKit
import CoreLocation

enum BudtenderRouter : AuthorizedRouter {
    
    case list(query: String?, batch : Batch)
    case map ( georegion : CLCircularRegion, query: String?)
    
    case details (budtender : Budtender)
    
    case like (budtender : Budtender)
    case dislike (budtender : Budtender)
    
    case top (batch : Batch?)
 
    case apply(phone: String, reason: String)
    
}

extension BudtenderRouter {
    
    func asURLRequest() throws -> URLRequest {
        
        switch self {
            
        case .list(let query, let batch):
            
            let params : [String : Any?] = ["key" : query,
                                            "count" : batch.limit,
                                            "offset" : batch.offset]
            
            return self.authorizedRequest(method: .get,
                                          path: "/budtender",
                                          params: params.nullKeyRemoval(),
                                          encoding: URLEncoding.default)
            
            
            
            
            
        case .map( let georegion, let query):
            
            let params : [String : Any?] = ["latitude" : georegion.center.latitude,
                                            "longitude" : georegion.center.longitude,
                                            "radius" : georegion.radius / 1000,
                                            "key" : query
            ]
            
            return self.authorizedRequest(method: .get,
                                          path: "budtender/map",
                                          params: params.nullKeyRemoval(),
                                          encoding: URLEncoding.default)
            
        case .details (let budtender) :
            
            return self.authorizedRequest(method: .get,
                                          path: "budtender/\(budtender.id)")
            
        case .like (let budtender) :
            
            return self.authorizedRequest(method: .post,
                                          path: "/budtender/like/\(budtender.id)")
            
        case .dislike (let budtender) :
            
            return self.authorizedRequest(method: .delete,
                                          path: "/budtender/like/\(budtender.id)")
            
        case .top (let batch):
            
            let b = batch ?? Batch(offset: 0, limit: 10)
            
            return self.authorizedRequest(method: .get,
                                          path: "/budtender/top",
                                          params: ["count" : b.limit,
                                                   "offset" : b.offset])
         
        case .apply(let phone, let reason):
            
            return self.authorizedRequest(method: .post,
                                          path: "/budtender/form",
                                          params: [ "cell_phone" : phone,
                                                    "note" : reason ],
                                          encoding: JSONEncoding.default)
            
        }
    }
    
}
