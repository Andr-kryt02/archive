//
//  DispensaryRouter.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 06.12.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import Alamofire
import MapKit
import CoreLocation

enum DispensaryRouter : AuthorizedRouter {
    
    case list(query: String?, batch : Batch)
    case map ( georegion : CLCircularRegion, query: String?)
    
    case details (dispensary : Dispensary)
    
    case like (dispensary : Dispensary)
    case dislike (dispensary : Dispensary)
    
    case top (batch : Batch?)
    
}

extension DispensaryRouter {
    
    func asURLRequest() throws -> URLRequest {
        
        switch self {
            
        case .list(let query, let batch):
            
            let params : [String : Any?] = ["key" : query,
                                            "count" : batch.limit,
                                            "offset" : batch.offset]
            
            return self.authorizedRequest(method: .get,
                                          path: "/commercial/dispensary",
                                          params: params.nullKeyRemoval(),
                                          encoding: URLEncoding.default)
            
            
        case .map( let georegion, let query):
            
            let params : [String : Any?] = ["latitude" : georegion.center.latitude,
                                            "longitude" : georegion.center.longitude,
                                            "radius" : georegion.radius / 1000,
                                            "key" : query
            ]
            
            return self.authorizedRequest(method: .get,
                                          path: "/commercial/dispensary/map",
                                          params: params.nullKeyRemoval(),
                                          encoding: URLEncoding.default)
            
            
            
            
        case .details (let dispensary) :
            
            return self.authorizedRequest(method: .get,
                                          path: "/commercial/dispensary/\(dispensary.id)")
            
        case .like (let dispensary) :
            
            return self.authorizedRequest(method: .post,
                                          path: "/commercial/dispensary/like/\(dispensary.id)")
            
        case .dislike (let dispensary) :
            
            return self.authorizedRequest(method: .delete,
                                          path: "/commercial/dispensary/like/\(dispensary.id)")
            
        case .top (let batch):
            
            let b = batch ?? Batch(offset: 0, limit: 10)
            
            return self.authorizedRequest(method: .get,
                                          path: "/commercial/dispensary/top",
                                          params: ["count" : b.limit,
                                                   "offset" : b.offset])

        }
    }
    
}
