//
//  OnlineStoreRouter.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 06.12.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import Alamofire
import MapKit
import CoreLocation

enum OnlineStoreRouter : AuthorizedRouter {
    
    case list(query: String?, batch : Batch)
    case details (store : OnlineStore)
    
    case like (store : OnlineStore)
    case dislike (store : OnlineStore)
    
    case top (batch : Batch?)
}

extension OnlineStoreRouter {
    
    func asURLRequest() throws -> URLRequest {
        
        switch self {
            
        case .list(let query, let batch):
            
            let params : [String : Any?] = ["key" : query,
                                            "count" : batch.limit,
                                            "offset" : batch.offset]
            
            
            return self.authorizedRequest(method: .get,
                                          path: "/commercial/store",
                                          params: params.nullKeyRemoval(),
                                          encoding: URLEncoding.default)
            
            
        case .details (let store) :
            
            return self.authorizedRequest(method: .get,
                                          path: "/commercial/store/\(store.id)")
            
        case .like (let store) :
            
            return self.authorizedRequest(method: .post,
                                          path: "/commercial/store/like/\(store.id)")
            
        case .dislike (let store) :
            
            return self.authorizedRequest(method: .delete,
                                          path: "/commercial/store/like/\(store.id)")
            
        case .top (let batch):
            
            let b = batch ?? Batch(offset: 0, limit: 10)
            
            return self.authorizedRequest(method: .get,
                                          path: "/commercial/store/top",
                                          params: ["count" : b.limit,
                                                   "offset" : b.offset])
        }
    }
    
}
