//
//  ProducerRouter.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 06.12.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import Alamofire
import MapKit
import CoreLocation

enum LicensedProducerRouter : AuthorizedRouter {
    
    case list(query: String?, batch : Batch)
    case map ( georegion : CLCircularRegion, query: String?)
    
    case details (producer : LicensedProducer)
    
    case like (producer : LicensedProducer)
    case dislike (producer : LicensedProducer)
    
    case top (batch : Batch?)
    
}

extension LicensedProducerRouter {
    
    func asURLRequest() throws -> URLRequest {
        
        switch self {
            
        case .list(let query, let batch):
            
            let params : [String : Any?] = ["key" : query,
                                            "count" : batch.limit,
                                            "offset" : batch.offset]
            
            return self.authorizedRequest(method: .get,
                                          path: "/commercial/producer",
                                          params: params.nullKeyRemoval(),
                                          encoding: URLEncoding.default)
            
            
        case .map( let georegion, let query):
            
            let params : [String : Any?] = ["key" : query,
                                            "latitude" : georegion.center.latitude,
                                            "longitude" : georegion.center.longitude,
                                            "radius" : georegion.radius / 1000
            ]
            
            return self.authorizedRequest(method: .get,
                                          path: "/commercial/producer/map",
                                          params: params.nullKeyRemoval(),
                                          encoding: URLEncoding.default)
            
 
            
            
        case .details (let producer) :
            
            return self.authorizedRequest(method: .get,
                                          path: "/commercial/producer/\(producer.id)")
            
        case .like (let producer) :
            
            return self.authorizedRequest(method: .post,
                                          path: "/commercial/producer/like/\(producer.id)")
            
        case .dislike (let producer) :
            
            return self.authorizedRequest(method: .delete,
                                          path: "/commercial/producer/like/\(producer.id)")
            
        case .top (let batch):
            
            let b = batch ?? Batch(offset: 0, limit: 10)
            
            return self.authorizedRequest(method: .get,
                                          path: "/commercial/producer/top",
                                          params: ["count" : b.limit,
                                                   "offset" : b.offset])
        }
    }
    
}
