//
//  UserDetailsRouter.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/17/16.
//  Copyright © 2016 campfiire. All rights reserved.
//
import Foundation
import Alamofire

enum UserDetailsRouter : AuthorizedRouter {
    
    case details (user : User)
    
    case update (user : User)
    
    case updateAvatar
    
    case deleteAvatar
    
    case getAvatar(photo : Photo)
    
}

extension UserDetailsRouter {
    
    func asURLRequest() throws -> URLRequest {
        
        switch self {
            
        case .details (let user) :
            
            return self.authorizedRequest(method: .get,
                                          path: "/user/get_user_profile/\(user.id)")
            
            
        case .update (let user) :
            
            return self.authorizedRequest(method: .post,
                                          path: "/user/update",
                                          params: user.toJSON(),
                                          encoding: JSONEncoding.default)
            
        case .deleteAvatar :
            
            return self.authorizedRequest(method: .delete,
                                          path: "/user/update/avatar")
            
        case .updateAvatar:
            
            return self.authorizedRequest(method: .post,
                                          path: "/user/update/avatar")
            
            
        case .getAvatar(let photo) :
            
            return self.authorizedRequest(method: .get,
                                          path: "/user/get_avatar/\(photo.id)")
        }
    }
    
}
