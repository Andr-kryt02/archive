//
//  UserAuthorizationRouter.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/17/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import Alamofire

enum UserAuthorizationRouter : AuthorizedRouter {
    
    case registration (user : RegistrationData)
    case logIn (email: String, password: String)
    case social(data: RemoteAuthData)
    
    case chatRegistration
    case connectionData
    
    case paswordRecover (email : String)
    case changePassword (oldPassword : String, newPassword : String)
    
}

extension UserAuthorizationRouter {
    
    func asURLRequest() throws -> URLRequest {
        
        switch self {
            
        case .logIn(let email, let password):
            
            return self.unauthorizedRequest(method: .post,
                                               path: "/user/login",
                                               params: ["email" : email,
                                                        "password" : password],
                                               encoding: JSONEncoding.default)

            
        case .registration(let data):
            
            return self.unauthorizedRequest(method: .post,
                                             path: "/user/register",
                                             params : data.serialize(),
                                             encoding: JSONEncoding.default)
            
        case .social(let data):
            
            return self.unauthorizedRequest(method: .get,
                                            path: "/user/social",
                                            headers: ["Authorization" : data.headerString])
            
        case .chatRegistration:
            
            return self.authorizedRequest(method: .post,
                                          path: "/chat/user")
            
        case .connectionData :
            
            return self.authorizedRequest(method: .get, path: "/user/get_connection_data")
            
        case .paswordRecover (let email) :
            
            let req = self.unauthorizedRequest(method: .get,
                                               path: "/user/password_recover",
                                               params: ["email" : email])
            
            return req
            
        case .changePassword (let oldPassword, let newPassword) :
            
            return self.authorizedRequest(method: .post,
                                          path: "/user/update/change_password",
                                          params: ["confirm_password" : newPassword,
                                                   "new_password" : newPassword,
                                                   "old_password" : oldPassword],
                                          encoding: JSONEncoding.default)
        }
        
    }
    
}
