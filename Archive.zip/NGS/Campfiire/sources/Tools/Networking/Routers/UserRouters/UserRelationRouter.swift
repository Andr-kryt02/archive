//
//  UserRelationRouter.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/17/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import Alamofire

enum UserRelationRouter : AuthorizedRouter {
    
    case invitesList
    
    case createInvite (user : User)
    
    case deleteInvite (user : User)
    
    case blockUser (user : User)
    
    case unblockUser (user : User)
    
}

extension UserRelationRouter {
    
    func asURLRequest() throws -> URLRequest {
        
        switch self {
            
        case .invitesList :
            
            return self.authorizedRequest(method: .get,
                                          path: "/user/friends/invites")
            
        case .createInvite (let user):
            
            return self.authorizedRequest(method: .put,
                                          path: "/user/friends/\(user.id)")
            
            
        case .deleteInvite (let user):
            
            return self.authorizedRequest(method: .delete,
                                          path: "/user/friends/\(user.id)")
            
        case .blockUser(let user) :
            
            return self.authorizedRequest(method: .post,
                                          path: "/user/block/\(user.id)")
            
        case .unblockUser(let user) :
            
            return self.authorizedRequest(method: .post,
                                          path: "/user/unblock/\(user.id)")
        }
    }
}
