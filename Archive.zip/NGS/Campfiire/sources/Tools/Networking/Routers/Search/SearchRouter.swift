//
//  SearchRouter.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/3/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import Alamofire

enum SearchRouter : AuthorizedRouter {
    
    case user (batch : Batch, searchFilter : SearchUsersFilter)
    
    case friends (searchFilter : SearchUsersFilter)
    
}

extension SearchRouter {
    
    func asURLRequest() throws -> URLRequest {
        
        switch self {
            
        case .user(let batch, let searchFilter):
            
            var params : [String : Any?] = [:]
            var path = ""
            
            if let tag = searchFilter.tag {
                path = "/search/users/tag"
                params = ["q" : tag]
            }
            else {
            
                ////currently server treats empty string as a valid input, thus throws error "input must be from 1 to 50"
                ///have to manually nil out query if it's an empty input
                var filter = searchFilter
                if let q = filter.query,
                    q.lengthOfBytes(using: String.Encoding.utf8) == 0 {
                    filter.query = nil
                }
                
                path = "/search/users"
                params =  ["q": filter.query]
            }
            
            params["age_from"] = searchFilter.ageRange?.from
            params["age_to"] = searchFilter.ageRange?.to
            params["gender"] = searchFilter.gender?.rawValue
            params["location"] = searchFilter.location
            params["offset"] = batch.offset
            params["count"] = batch.limit
            
            return self.authorizedRequest(method: .get,
                                          path: path,
                                          params: params.nullKeyRemoval())
            
            
        case .friends(let searchFilter):
            
            return self.authorizedRequest(method: .get,
                                          path: "/user/friends",
                                          params: ["name" : searchFilter.query,
                                                   "tag" : searchFilter.tag].nullKeyRemoval())
        
        }
    }
}
