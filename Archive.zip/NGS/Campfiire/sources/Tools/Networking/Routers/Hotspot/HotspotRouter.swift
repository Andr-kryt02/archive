//
//  File.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/21/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import Alamofire
import MapKit
import CoreLocation

enum HotspotRouter : AuthorizedRouter {

    ///CRUD
    case map (georegion : CLCircularRegion, query: String?, followedOnly: Bool)
    case details (hotSpot : HotSpot)
    
    case create(hotSpot : HotSpot)
    case update (hotSpot : HotSpot)
    case updateAvatar (hotSpot : HotSpot)
    case delete (hotSpot : HotSpot)
    
    ///Following
    case follow (hotSpot : HotSpot)
    case unfollow (hotSpot : HotSpot)
    
    ///Photo interaction
    case createPhoto (hotspot : HotSpot)

    case like (photo : Photo)
    case dislike (photo : Photo)
 
    ////Comments
    case postComment ( hotspot : HotSpot, text : String)
    case commentsList ( hotspot : HotSpot, batch : Batch)

    ///Reports
    
    case reportHotSpot(hotspot : HotSpot)
    case reportHotSpotPhoto(photo : Photo)
    case reportHotSpotComment( comment : Comment)
    case top (batch : Batch?)
}

extension HotspotRouter {
    
    func asURLRequest() throws -> URLRequest {
        
        switch self {
            
        case .map(let georegion, let query, let followedOnly):
            
            let params : [String : Any?] = ["latitude" : georegion.center.latitude,
                                            "longitude" : georegion.center.longitude,
                                            "radius" : georegion.radius / 1000,
                                            "is_followed" : followedOnly,
                                            "query" : query
                                            ]
            
            return self.authorizedRequest(method: .post,
                                          path: "/hotspot/map",
                                          params: params.nullKeyRemoval(),
                                          encoding: JSONEncoding.default)
            
        case .details (let hotSpot) :
            
            return self.authorizedRequest(method: .get,
                                          path: "hotspot/\(hotSpot.id)")
            
        case .update (let hotSpot) :
            
            let params : [String : Any?] = hotSpot.toJSON()
            
            return self.authorizedRequest(method: .put,
                                          path: "hotspot/update",
                                          params: params.nullKeyRemoval(),
                                          encoding: JSONEncoding.default)
            
        case .updateAvatar(let hotSpot) :
            
            return self.authorizedRequest(method: .post,
                                          path: "hotspot/update_avatar/\(hotSpot.id)")
            
            
        case .create (let hotSpot) :
            
            let params : [String : Any?] = hotSpot.toJSON()
            
            return self.authorizedRequest(method: .post,
                                          path: "hotspot/add",
                                          params: params.nullKeyRemoval(),
                                          encoding : JSONEncoding.default)
            
        case .createPhoto (let hotSpot) :
            
            return self.authorizedRequest(method: .post,
                                          path: "hotspot/add_photo/\(hotSpot.id)")
        
        
        case .delete (let hotspot) :
        
            return self.authorizedRequest(method: .delete,
                                          path: "hotspot/\(hotspot.id)")
            
        case .follow(let hotSpot) :
            
            return self.authorizedRequest(method: .put,
                                          path: "hotspot/follower/\(hotSpot.id)")
            
        case .unfollow(let hotSpot) :
            
            return self.authorizedRequest(method: .delete,
                                          path: "hotspot/follower/\(hotSpot.id)")
            
        case .like (let photo) :
            
            return self.authorizedRequest(method: .put,
                                          path: "hotspot/photo/\(photo.id)")
            
        case .dislike (let photo) :
            
            return self.authorizedRequest(method: .delete,
                                          path: "hotspot/photo/\(photo.id)")
            
        case .postComment (let hotSpot, let text) :
            
            let params : [String : Any] = ["id" :  hotSpot.id,
                                           "text" : text]
            
            return self.authorizedRequest(method: .post,
                                          path: "hotspot/comment/add",
                                          params: params,
                                          encoding:  JSONEncoding.default)
            
        case .commentsList (let hotSpot, let batch) :
            
            return self.authorizedRequest(method: .get,
                                          path: "hotspot/comments",
                                          params: ["id" : hotSpot.id,
                                                   "count" : batch.limit,
                                                   "offset" : batch.offset],
                                          encoding: URLEncoding.default)
            
        case .reportHotSpot(let  hotspot) :
            //   /report/hotspot/{target_id}
            return self.authorizedRequest(method: .post,
                                          path: "/report/hotspot/\(hotspot.id)")
            
            
        case .reportHotSpotPhoto(let photo):
            
            //  /report/hotspot_photo/{target_id}
            return self.authorizedRequest(method: .post,
                                          path: "/report/hotspot_photo/\(photo.id)")

            
        case .reportHotSpotComment(let comment):
            
            //  /report/hotspot_comment/{target_id}
            return self.authorizedRequest(method: .post,
                                          path: "/report/hotspot_comment/\(comment.id)")
   
            
            
        case .top (let batch):
            
            let b = batch ?? Batch(offset: 0, limit: 10)
            
            return self.authorizedRequest(method: .get,
                                          path: "/hotspot/top",
                                          params: ["count" : b.limit,
                                                   "offset" : b.offset])
        }
    }
    
}
