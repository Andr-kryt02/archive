//
//  UserPhoto.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 2016-12-21.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import Alamofire

enum UserPhotoRouter : AuthorizedRouter {
    
    case create
    case delete (photo : Photo )
    
    case like ( photo : Photo )
    case dislike ( photo : Photo )
    
    case list(friendsPhotos: Bool, batch: Batch)
    
}

extension UserPhotoRouter {
    
    func asURLRequest() throws -> URLRequest {
        
        switch self {
            
        case .list(let friendsPhotos, let batch):
            
            var params : [String : Any] = ["offset" : batch.offset,
                                           "count"  : batch.limit]
            if !friendsPhotos {
                params["targetUserId"] = User.currentUser()!.id
            }

            return self.authorizedRequest(method: .get,
                                          path: "/user/photo",
                                          params: params)
        case .create:
            
            return self.authorizedRequest(method: .post,
                                          path: "/user/photo")
            
        case .delete(let photo) :
            
            return self.authorizedRequest(method: .delete,
                                          path:  "/user/photo/\(photo.id)")
       
        case .like(let photo) :
            
            return self.authorizedRequest(method: .post,
                                          path: "/user/photo/like/\(photo.id)")
        case .dislike(let photo) :
            
            return self.authorizedRequest(method: .delete,
                                          path: "/user/photo/like/\(photo.id)")
  
        }
    }
}

