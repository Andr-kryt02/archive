//
//  ChatRouter.swift
//  Campfiire
//
//  Created by Vlad Soroka on 1/30/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import Foundation
import Alamofire

enum ChatRouter : AuthorizedRouter {
    
    case uploadAttachment
    
}

extension ChatRouter {
    
    func asURLRequest() throws -> URLRequest {
        switch self {
        case .uploadAttachment:
            
            ///TODO: apply proper rout
            return authorizedRequest(method: .post, path: "/{chatId}/attachment")
            
            
        }
    }
    
    
    
}
