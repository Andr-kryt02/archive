//
//  EventRouter.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/4/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import Alamofire

enum EventRouter : AuthorizedRouter {
    
    case details (event : Event)
    
    case list (date : Date?, batch : Batch)
    case monthEvents(date : Date)
    
}

extension EventRouter {
    
    func asURLRequest() throws -> URLRequest {
        
        switch self {
            
        case .details (let event) :
            
            return self.authorizedRequest(method: .get,
                                            path: "/event/\(event.id)")
            
            
        case .list (let date, let batch):
            
            let params: [String: Any?] = ["date" : ISO8601ExtendedDateTransform().transformToJSON(date),
                                         "offset" : batch.offset,
                                         "count" : batch.limit]
            
            return self.authorizedRequest(method: .get,
                                            path: "/event",
                                            params: params.nullKeyRemoval() )
            
        case .monthEvents (let date):
            
            let params = ["date" : ISO8601ExtendedDateTransform().transformToJSON(date)!]
            
            return self.authorizedRequest(method: .get,
                                            path: "/event/calendar",
                                            params: params,
                                            encoding: URLEncoding.default)
        }
        
    }
}
