//
//  Settings.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/4/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import Alamofire

enum SettingsRouter : AuthorizedRouter {
    
    case get
    case send (settings : SettingsResponse)
    
    /**
     * Associate device token with currently logged in user
     */
    case linkDeviceToken(deviceToken: Data)
    
    /**
     * Unlink device token from currently logged in user
     */
    case unLinkDeviceToken
    
}

extension SettingsRouter {
    
    func asURLRequest() throws -> URLRequest {
        
        switch self {
            
        case .get :
            
            return self.authorizedRequest(method: .get, path: "/user/settings")
            
        case .send (let settings) :
            
            let parametrs : [String : Any?] = settings.toJSON()
            
            return self.authorizedRequest(method: .put, path: "/user/settings",
                                          params: parametrs.nullKeyRemoval(),
                                          encoding: JSONEncoding.default)
            
        case .linkDeviceToken(let deviceToken):
            
            ///TODO: insert proper methods
            return self.authorizedRequest(method: .post,
                                          path: "dev_token/",
                                          params: ["dev_token" : deviceToken.hexadecimalString],
                                          encoding: URLEncoding.default)
            
        case .unLinkDeviceToken:
            
            ///TODO: insert proper methods
            return self.authorizedRequest(method: .delete,
                                          path: "dev_token/",
                                          encoding: URLEncoding.default)
            
        }
        
        
    }
    
}
