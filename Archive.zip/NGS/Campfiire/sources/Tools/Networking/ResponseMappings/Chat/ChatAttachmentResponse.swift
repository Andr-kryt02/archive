//
//  AvatarUpdateResponse.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/7/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import ObjectMapper

struct ChatAttachmentResponse : Mappable {
    
    var url: String!
    
    init?(map: Map) {
        mapping(map: map)
    }
    
    mutating func mapping(map: Map) {
        
        url <- map["imageURL"]
        
    }
}
