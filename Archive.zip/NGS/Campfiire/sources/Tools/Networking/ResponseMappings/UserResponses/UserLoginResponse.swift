//
//  UserLoginResponse.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/27/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import ObjectMapper

struct UserLoginResponse : Mappable {
    
    var token: String?
    var user: User?
    var isNew: Bool = false
    
    init?(map: Map) {
        mapping(map: map)
        
    }
    
    mutating func mapping(map: Map) {
        
        token <- map["Authorization"]
        user <- map["user"]
        isNew <- map["isNew"]
        
    }
    
}
