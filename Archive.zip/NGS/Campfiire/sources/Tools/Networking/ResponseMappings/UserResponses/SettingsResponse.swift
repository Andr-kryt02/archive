//
//  SettingsResponse.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/4/16.
//  Copyright © 2016 campfiire. All rights reserved.
//


import ObjectMapper

struct SettingsResponse : Mappable {
    
    var pushNotification: Bool = false
    var showEvent: Bool = false
    var attachmentInCellular : Bool = false
    var visibility : ProfileVisibility = .allUsers
    var timeFormat24 : Bool = false
    
    init(push: Bool, showEvent: Bool, attachment: Bool, time24: Bool, visibility: ProfileVisibility) {
        self.pushNotification = push
        self.showEvent = showEvent
        self.attachmentInCellular = attachment
        self.visibility = visibility
        self.timeFormat24 = time24
    }
    
    init?(map: Map) {
        mapping(map: map)
    }
    
    mutating func mapping(map: Map) {
        
        pushNotification <- map["push_notification"]
        showEvent <- map["show_event"]
        attachmentInCellular <- map["attachment_in_cellular"]
        visibility <- map["visibility"]
        timeFormat24 <- map["time_format_24"]
        
    }
    
}

extension SettingsResponse : Equatable {
    
    static func==(lhs: SettingsResponse, rhs: SettingsResponse) -> Bool {
        return lhs.pushNotification == rhs.pushNotification &&
            lhs.showEvent == rhs.showEvent &&
            lhs.attachmentInCellular == rhs.attachmentInCellular &&
            lhs.visibility == rhs.visibility &&
            lhs.timeFormat24 == rhs.timeFormat24
    }
    
}
