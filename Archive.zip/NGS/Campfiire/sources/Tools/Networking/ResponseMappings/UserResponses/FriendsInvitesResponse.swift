//
//  FriendsInvitesResponse.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/8/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import ObjectMapper

struct FriendsInvitesResponse : Mappable {
    
    var inviteId: String?
    var senderUser: User?
    
    init?(map: Map) {
        mapping(map: map)
    }
    
    mutating func mapping(map: Map) {
        
        inviteId <- map["invite_id"]
        senderUser <- map["sender_user"]
        
    }
}
