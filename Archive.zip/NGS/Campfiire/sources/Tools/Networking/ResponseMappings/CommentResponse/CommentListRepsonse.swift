//
//  CommentListRepsonse.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/22/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import ObjectMapper

struct CommentListRepsonse : Mappable {
    
    var count: Int?
    var comments: [Comment]!
    
    init?(map: Map) {
        mapping(map: map)
    }
    
    mutating func mapping(map: Map) {
        
        count <- map ["count"]
        comments <- map ["comment"]
        
    }
    
}
