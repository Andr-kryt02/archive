//
//  BaseResponse.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/23/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import ObjectMapper

////each and every response from campfiire server must conform to the protocol
protocol CampfiireResponeProtocol : Mappable {
    
    associatedtype DataType
    
    var code: Int? { get }
    var errorMessage: String? { get }
    
    var data: DataType? { get }
    
}


struct CampfiireResponse<S: Mappable> : CampfiireResponeProtocol {

    typealias DataType = S
    
    var code: Int?
    var errorMessage: String?
    var data: S?
    
    init?(map: Map) {
        mapping(map: map)
    }
    
    mutating func mapping(map: Map) {
        
        data <- map["data"]
        code <- map["error.code"]
        errorMessage <- map["error.message"]
        
        
        
    }
    
}

struct CampfiireArrayResponse<S: Mappable> : CampfiireResponeProtocol {
    
    typealias DataType = [S]
    
    var code: Int?
    var errorMessage: String?
    var data: [S]?
    
    init?(map: Map) {
        mapping(map: map)
    }
    
    mutating func mapping(map: Map) {
        
        code <- map["error.code"]
        errorMessage <- map["error.message"]
        
        data <- map["data"]
        
    }
    
}

struct CampfiireEmptyResponse : CampfiireResponeProtocol {
    
    typealias DataType = Void
    
    var code: Int?
    var errorMessage: String?
    var data: Void?
    
    init?(map: Map) {
        mapping(map: map)
        data = ()
    }
    
    mutating func mapping(map: Map) {
        
        code <- map["error.code"]
        errorMessage <- map["error.message"]
        
    }
    
}
