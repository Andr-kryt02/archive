//
//  ErrorStatusCodes.swift
//  Campfiire
//
//  Created by Andrew Seregin on 10/31/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

enum CampfiireErrorStatusCode: Int {
    
    case objectWithIdNotFound = 400 /// when requesting resource with not existing id
    
    case invalidToken = 1000
    case invalidEmail = 1001
    case invalidPasword = 1002
    case emailDoesntExist = 1003
    case wrongPassword = 1004
 
    case alreadyFollowing = 1309 /// when trying to follow something, that is already followed
    case alreadyNotFollowing = 1310 /// when trying to stop follow something, that is not followed
    
    case userAlreadyRegisteredWithinChatService = 1502 // when trying to register user in chat service once more
    
}

extension CampfiireErrorStatusCode {
    
    public var description: String? {
        switch self {
            
        default: return nil
            
        }
    }
    
}
