//
//  CampfiireError.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/16/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import Alamofire

public enum CampfiireError: Error {
    
    case userCanceled
    
    case unauthorised
    case businessError(code: Int, message: String)
    
    case generic(description: String)
    case unknown
    
    public func shouldPresentError() -> Bool {
        switch self {
        case .userCanceled: return false
        default: return true
        }
    }
    
}

extension CampfiireError : CustomStringConvertible {
    
    public var description: String {
        
        switch self {
            
        case .userCanceled: return ""
        case .unknown: return "We're sorry. Unknown error occured"
        case .generic(let descr): return descr
     
        case .unauthorised: return "We no longer can access Campfiire with your local credentials. Please sign in once more"
        case .businessError(code: let code, message: let message):
            
            if let m = CampfiireErrorStatusCode(rawValue: code)?.description {
                return m
            }
            
            return message
            
        }
        
    }
    
}
