//
//  ISO8601ExtendedDateTransformer.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/22/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import ObjectMapper

open class ISO8601ExtendedDateTransform: DateFormatterTransform {
    
    public init() {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZZZZZ"
        
        super.init(dateFormatter: formatter)
    }
    
}
