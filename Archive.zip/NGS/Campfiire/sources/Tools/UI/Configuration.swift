//
//  Configuration.swift
//  Night Life
//
//  Created by Vlad Soroka on 2/22/16.
//  Copyright © 2016 com.NightLife. All rights reserved.
//

import UIKit
import CoreLocation
import Fabric
import Crashlytics

struct UIConfiguration {
    
    static func setUp() {
        
        UIApplication.shared.statusBarStyle = .lightContent
        
        UINavigationBar.appearance().titleTextAttributes = [
                NSFontAttributeName : UIFont.appRegularPrimaryFont(size: 24),
                NSForegroundColorAttributeName : UIColor.white
            ]
        
    }
    
}

enum AppConfiguration {}
extension AppConfiguration {
    
    /**
     * Place to set up everything you would normally do in AppDelegate
     */
    static func setUpServices() {
        
        Fabric.with([Crashlytics.self])

    }
    
    
}

extension CLLocationDistance {
    
    var metersToMiles: Double {
        return self / 1609.344
    }
    
}
