//
//  LocationManager.swift
//  Night Life
//
//  Created by Vlad Soroka on 2/22/16.
//  Copyright © 2016 com.NightLife. All rights reserved.
//

import CoreLocation
import RxSwift
import RxCocoa

class LocationManager {
    
    static var instance = LocationManager()
    
    private let manager = CLLocationManager()

    var lastRecordedLocationObservable: Observable<CLLocation> {
        
        self.startMonitoring()
        
        return self.manager.rx.didUpdateLocations
            .filter { $0.count > 0 }
            .map { $0.last! }
            .startWith(lastRecordedLocation)
            .notNil()
            
    }

    var lastRecordedLocation: CLLocation? {
        return manager.location
    }
    
    var authorizationStatus: Observable<CLAuthorizationStatus> {
        return manager.rx.didChangeAuthorizationStatus
    }
    
    private func startMonitoring() {
        
        let _ =
        authorizationStatus
            .subscribe( onNext: { [unowned m = manager] e in
                switch (e) {
                    
                case .denied: break;
                    
                case .notDetermined: fallthrough    ///here we should present introduction on why we need his location
                case .authorizedAlways: fallthrough
                case .authorizedWhenInUse: fallthrough
                case .restricted: fallthrough
                default:
                    m.startUpdatingLocation()
                    
                }

            })
        
        manager.requestWhenInUseAuthorization()
        
        manager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        manager.distanceFilter = 5///meters
    }
    
}

