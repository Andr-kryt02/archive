//
//  AuthValidators.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/23/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

import RxSwift


typealias ValidationResult = (isValid: Bool, failReason: String?)

struct RegistrationValidation {
    
    let emailValid : Variable< ValidationResult > = Variable((false, nil))
    let passwordValid : Variable< ValidationResult > = Variable((false, nil))
    let nameValid: Variable < ValidationResult > = Variable ( (false, nil) )
    let locationValid: Variable < ValidationResult > = Variable ( (true, nil) )
    let favoriteProductValid: Variable < ValidationResult > = Variable ( (true, nil) )
    
    init (email: Observable<String?> = Observable.just(nil),
          password: Observable<String?> = Observable.just(nil),
          confirmPassword: Observable<String?> = Observable.just(nil),
          name: Observable<String?> = Observable.just(nil),
          location: Observable<String?> = Observable.just(nil),
          favoriteProduct: Observable<String?>? = nil) {

        
        let _ =
        email.map { maybeEmail in
            
            guard let email = maybeEmail else { return false }
            
            let emailRegEx = "^(?=.{5,30}$)[\\w.%+-]+@[\\w-]+\\.[\\w]+$"
            
            return NSPredicate(format:"SELF MATCHES %@", emailRegEx).evaluate(with: email)
            }
            .map { $0 ? (true, nil) : (false, "Email does not satisfy rules") }
            .bindTo(emailValid)
        
        let _ =
        Observable
            .combineLatest(password, confirmPassword) { (one, two) -> ValidationResult in

                guard let pw = one,
                      let cpw = two else { return (false, "Password can not be empty") }
                
                guard pw == cpw else { return (false, "Password does not match confirmed password") }
                
                let regEx = "^[\\w-.]{8,18}$"
                guard NSPredicate(format:"SELF MATCHES %@", regEx).evaluate(with: one) else {
                    return (false, "Password must be at least 8 characters and not longer than 18 characters")
                }
                
                return (true, nil)
            }
            .bindTo(passwordValid)
        
        let _ =
        name.map { maybeName in
            
            guard let name = maybeName else { return (false, "Name is required field") }
            
            ///Name validation: min - 2, max - 20 characters. Can contain: «A...Z», «a...z», «space», « - », « . »
            
            let regEx = "^[a-zA-Z-. ]{2,20}$"
            guard NSPredicate(format:"SELF MATCHES %@", regEx).evaluate(with: name) else {
                return (false, "Name must containe only letters, be at least 2 characters and not longer than 20 characters")
            }
            
            return (true, nil)
            }
            .bindTo(nameValid)
        
        let _ =
        location.map { maybeLocation in
            
            guard let loc = maybeLocation,
                loc.lengthOfBytes(using: String.Encoding.utf8) > 0
                else { return (true, nil) }
            
            let regEx = "^[a-zA-Z-.,// ]{5,40}$"
            guard NSPredicate(format:"SELF MATCHES %@", regEx).evaluate(with: loc) else {
                return (false, "Location must contain only letters or numbers, must be at least 5 characters and not longer than 40 characters")
            }
            
            return (true, nil)
            }
            .bindTo(locationValid)
     
        if let favoriteObservable = favoriteProduct {
            
            let _ =
            favoriteObservable.map { maybeProduct in
                
                guard let product = maybeProduct,
                      product.lengthOfBytes(using: .utf8) > 0 else { return (true, nil) }
                
                let regEx = "^[a-zA-Z-. ]{2,20}$"
                guard NSPredicate(format:"SELF MATCHES %@", regEx).evaluate(with: product) else {
                    return (false, "Favorite Product must containe only letters, be at least 2 characters and not longer than 20 characters")
                }
                
                return (true, nil)
                
            }
            .bindTo(favoriteProductValid)
            
        }
        
        
    }
    
    func validateTags(tags: [Tag]?) -> ValidationResult {
        
        guard let tags = tags,
            tags.count > 0 else { return (false, "Please select at least one tag") }
        
        guard tags.count <= 10 else { return (false, "More that 10 tags is not allowed") }
        
        return (true, nil)
        
    }
    
    func validateBirthday(date: Date?) -> ValidationResult {
        
        guard let d = date else {
            return (false, "Please fill in your birthday")
        }
        
        guard d.timeIntervalSince1970 <= NSDate().subtractingYears(18).timeIntervalSince1970 else {
            return (false, "Sorry, you must be older than 18")
        }
        
        return (true, nil)
    }
    
}
