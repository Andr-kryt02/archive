//
//  ImageRetreiver+Campfiire.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/23/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxCocoa

extension ImageRetreiver {
    
    static func imageAuthorizedWithoutProgress(at url: String) -> Driver<UIImage?> {
        
        return imageAuthorized(at: url)
            .filter { $0.finished }
            .map { $0.image }
        
    }
    
    static func imageAuthorized(at url: String) -> Driver<ImageRetreiveResult> {
        
        let imageRout = CampfiireImageRouter.image(url: url)
        
        return self.imageForURLReques(request: imageRout)
            
    }
    
}
