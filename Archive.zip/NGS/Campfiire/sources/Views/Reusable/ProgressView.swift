//
//  ProgressView.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/11/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import UIKit

class ProgressView : UIImageView {
    
    convenience init() {
        
        self.init(image: R.image.spinner()!)
        
        let animationDuration: CFTimeInterval = 0.8;
        let linearCurve = CAMediaTimingFunction(name: kCAMediaTimingFunctionLinear)
        
        let animation = CABasicAnimation(keyPath: "transform.rotation")
        animation.fromValue = 0;
        animation.toValue = M_PI * 2
        animation.duration = animationDuration;
        animation.timingFunction = linearCurve;
        animation.isRemovedOnCompletion = false
        animation.repeatCount = FLT_MAX;
        animation.fillMode = kCAFillModeForwards;
        animation.autoreverses = false;
        self.layer.add(animation, forKey:"rotate")
        
        self.backgroundColor = UIColor.clear
        
    }
    
}
