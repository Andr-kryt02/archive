//
//  CampfiireNavigationBar.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/14/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import UIKit

class CampfiireNavigationBar: UINavigationBar {

    override func layoutSubviews() {
        super.layoutSubviews()
        
      //  self.frame = CGRect(origin: self.frame.origin, size: CGSize( width: self.frame.size.width, height: 100 ))
    }
    
}
