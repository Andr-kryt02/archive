//
//  CampfireButton.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 28.10.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

class CampfiireButton : UIButton {
    
    var underlineColor = UIColor.white
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
   
        self.backgroundColor = UIColor.clear
        self.layer.borderColor = UIColor.clear.cgColor
        
        //self.tit. = UIFont.appLightPrimaryFont(size: 14)
        self.setTitleColor(UIColor.white, for: .normal)
        self.tintColor = UIColor.white
//        
        
        if let title = self.currentTitle {
            //self.text = text
            //self.textColor = UIColor.gray
            let attributesNormal = NSAttributedString(string: title, attributes : [NSForegroundColorAttributeName: UIColor.gray])
            self.setAttributedTitle(attributesNormal, for: UIControlState.selected)
        }

        
        
//        if let text = self.text {
//            //self.text = text
//            //self.textColor = UIColor.gray
//            self.attributedText = NSAttributedString(string: text, attributes : [NSForegroundColorAttributeName: UIColor.gray])
//            //self.text = self.attributedText?.string
//        }
//
//        let attributesHighlightedState = NSAttributedString(string: (self.titleLabel?.text)!, attributes : [NSForegroundColorAttributeName: UIColor.white])
//        self.setAttributedTitle(attributesHighlightedState, for: UIControlState.selected)

    }
    
    
//    func setText (text : String) {
//     
//        self.attributedText = NSAttributedString(string: text, attributes : [NSForegroundColorAttributeName: UIColor.gray])
//                        
//    }
    
    
    
    
    override func draw(_ rect: CGRect) {
        
        let startingPoint   = CGPoint(x: rect.minX, y: rect.maxY)
        let endingPoint     = CGPoint(x: rect.maxX, y: rect.maxY)
        
        let path = UIBezierPath()
        
        path.move(to: startingPoint)
        path.addLine(to: endingPoint)
        path.lineWidth = 1.0
        
        underlineColor.setStroke()
        
        path.stroke()
        
    }
}
