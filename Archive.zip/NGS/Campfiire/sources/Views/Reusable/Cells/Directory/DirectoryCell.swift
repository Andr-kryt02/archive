//
//  DirectoryCell.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 11.11.16.
//  Copyright © 2016 campfiire. All rights reserved.
//
import Foundation
import RxSwift

protocol DirectoryCellPresentable {
    
    var directoryCellTitle: String { get }
    var directoryCellSubtitle: String? { get }
    var directoryCellAvatarURL: String { get }
    
}

class DirectoryCell: UITableViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!{
        didSet {
            descriptionLabel.font = UIFont.appLightItalicPrimaryFont(size: 12)
        }
    }
    
    @IBOutlet weak var photoContainer: UIView! {
        didSet {
            photoContainer.layer.shadowOffset = CGSize(width: 0,
                                                       height: 2)
            photoContainer.layer.shadowOpacity = 0.6;
            photoContainer.layer.shadowRadius = 1;
            photoContainer.layer.shadowColor = UIColor.black.cgColor
            photoContainer.layer.shadowPath = UIBezierPath(roundedRect: photoContainer.bounds,
                                                           cornerRadius: 18).cgPath
        }
    }
    @IBOutlet weak var photoImageView: UIImageView!
    
    var item: DirectoryCellPresentable? {
        didSet {
            
            guard let i = item else { return }
            
            ImageRetreiver.imageForURLWithoutProgress(url: i.directoryCellAvatarURL)
                .map { $0 ?? R.image.noimageIc() }
                .drive(photoImageView.rx.image(transitionType: kCATransitionFade))
                .addDisposableTo(disposeBag)

            nameLabel.text = i.directoryCellTitle
            descriptionLabel.text = i.directoryCellSubtitle
        }
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        disposeBag = DisposeBag()
    }
    
    private lazy var disposeBag = DisposeBag()
    
}
