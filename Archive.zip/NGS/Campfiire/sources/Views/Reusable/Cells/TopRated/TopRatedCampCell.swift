//
//  TopRatedCell.swift
//  Campfiire
//
//  Created by Andrew Seregin on 12/9/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift

class TopRatedCampCell: UITableViewCell {
    
    @IBOutlet weak var topTitleLabel: UILabel!
    @IBOutlet weak var subtitleLabel: UILabel!{
        didSet {
            subtitleLabel.font = UIFont.appLightItalicPrimaryFont(size: 12)
        }
    }
    
    @IBOutlet weak var ordinalNumberLabel: UILabel!
    
    @IBOutlet weak var rightImageView: UIImageView!
    
    var item: Camp! {
        
        didSet {
            guard let camp = item.observableEntity()?.asDriver() else {
                
                ////when going to camp details user might edit it
                ////or just follow/unfollow
                ///we need to be able to pick up those changes
                
                fatalError("Can't present camps that are not in the storage")
            }
            
            camp.map { $0.title }
                .drive(topTitleLabel.rx.text)
                .addDisposableTo(bag)
            
            camp.map { $0.followersCount.countableString(withSingularNoun: "follower") }
                .drive(subtitleLabel.rx.text)
                .addDisposableTo(bag)
            
            camp.map { $0.isFollowedByCurrentUser ? R.image.startFavorite()! : R.image.uNstartFavorite()! }
                .drive(rightImageView.rx.image(transitionType: kCATransitionFade))
                .addDisposableTo(bag)
        }
        
    }
    
    var ordinaryNumber: Int = 0 {
        didSet {
            ordinalNumberLabel.text = "\(ordinaryNumber)"
        }
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        bag = DisposeBag()
    }
    
    private var bag = DisposeBag()
    
}
