//
//  TopRatedCell.swift
//  Campfiire
//
//  Created by Andrew Seregin on 12/9/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift

protocol TopRatedCellDisplayable {
    
    var topRatedTitle: String { get }
    var topRatedSubtitle: String { get }
    
    var topRatedPictureURL: String { get }
}

class TopRatedCell: UITableViewCell {
    
    @IBOutlet weak var topTitleLabel: UILabel!
    @IBOutlet weak var subtitleLabel: UILabel! {
        didSet {
            subtitleLabel.font = UIFont.appLightItalicPrimaryFont(size: 12)
        }
    }
    
    @IBOutlet weak var ordinalNumberLabel: UILabel!
    
    
    @IBOutlet weak var shadowContainer: UIView! {
        didSet {
            shadowContainer.layer.shadowOffset = CGSize(width: 0,
                                                        height: 2)
            shadowContainer.layer.shadowOpacity = 0.8;
            shadowContainer.layer.shadowRadius = 2;
            shadowContainer.layer.shadowColor = UIColor.black.cgColor
            shadowContainer.layer.shadowPath = UIBezierPath(roundedRect: shadowContainer.bounds,
                                                            cornerRadius: 18).cgPath
        }
    }
    @IBOutlet weak var rightImageView: UIImageView!
    
    var item: TopRatedCellDisplayable! {
        
        didSet {
            topTitleLabel.text = item.topRatedTitle
            subtitleLabel.text = item.topRatedSubtitle
            
            ImageRetreiver.imageForURLWithoutProgress(url: item.topRatedPictureURL)
                .map { $0 ?? R.image.noimageIc() }
                .drive(rightImageView.rx.image(transitionType: kCATransitionFade))
                .addDisposableTo(bag)
        }
        
    }
    
    var ordinaryNumber: Int = 0 {
        didSet {
            ordinalNumberLabel.text = "\(ordinaryNumber)"
        }
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        bag = DisposeBag()
    }
    
    private var bag = DisposeBag()
    
}
