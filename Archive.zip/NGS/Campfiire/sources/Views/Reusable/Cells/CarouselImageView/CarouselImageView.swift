//
//  CarouselImageView.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/2/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa

protocol CarouselImageViewDelegate: class {
    
    func carouselImageDidReport(item: CarouselImageView)
    
}

class CarouselImageView: UIView {
    
    @IBOutlet var reportButton: UIButton!
    @IBOutlet var likeButon: UIButton!
    @IBOutlet var imageView: UIImageView!
    
    var bag = DisposeBag()
    
    var viewModel: CarouselImageViewModel! {
        
        didSet {
            guard let vm = viewModel else { return }
        
            vm.photoDriver
                .map { $0.pictureURL }
                .distinctUntilChanged()
                ////TODO: |Any| implement progress view for loading the image
                .flatMapLatest { [unowned self] image -> Driver<UIImage?> in
                    
                    self.indicateProgress = true
                    
                    return ImageRetreiver.imageForURLWithoutProgress(url: image)
                }
                .do(onNext: { [unowned self] (_) in
                    self.indicateProgress = false
                })
                .drive(imageView.rx.image(transitionType: kCATransitionFade))
                .addDisposableTo(rx_disposeBag)

            vm.photoDriver
                .map { $0.isLikedByCurrentUser ? R.image.hearted()! : R.image.likeButton()! }
                .drive(onNext: { [unowned self] (image) in
                    self.likeButon.setImage(image, for: .normal)
                })
                .addDisposableTo(rx_disposeBag)
            
        }
        
    }
    
    weak var delegate: CarouselImageViewDelegate?
    
    @IBAction func likeButtonTapped(_ sender: Any) {
        viewModel.likePhotoTapped()
    }

    @IBAction func reportButtonTapped(_ sender: Any) {
        delegate?.carouselImageDidReport(item: self)
    }
    
    func prepareForCarouselReuse() {
        bag = DisposeBag()
        self.imageView.image = nil
    }
    
}
