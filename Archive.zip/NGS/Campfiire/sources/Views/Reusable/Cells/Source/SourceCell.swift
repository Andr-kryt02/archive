//
//  SourceCell.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 2016-12-20.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift

class SourceCell : UITableViewCell {
    
    
    
    @IBOutlet weak var titleLabel: UILabel!
  
    
    func configureVithMMJ(item: InfoSource) {
        
        titleLabel.text = item.title
   }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        disposeBag = DisposeBag()
    }
    
    private lazy var disposeBag = DisposeBag()
    
}
