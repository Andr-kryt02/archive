//
//  ChatUsercell.swift
//  Campfiire
//
//  Created by Andrew Seregin on 1/4/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import Foundation
import RxSwift

protocol MemberCellDelegate: class {
    func changeMemberStatus(cell: ChatMemberCell)
}

class ChatMemberCell : UITableViewCell {
    
    @IBOutlet var avatarImageView: UIImageView!
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var indicatorView: UIView!
    @IBOutlet var actionButton: UIButton!
    
    weak var delegate: MemberCellDelegate?
    var viewModel : ChatUserViewModel!
    
    func cellConfigure(viewModel : ChatUserViewModel) {
        
        self.viewModel = viewModel
        
        nameLabel.text = self.viewModel.user.name
        indicatorView.backgroundColor = self.viewModel.user.isOnline ? UIColor.userStatusOnline : UIColor.userStatusOffline
        
        ImageRetreiver.imageAuthorizedWithoutProgress(at: self.viewModel.user.pictureURL)
            .map{ $0 ?? R.image.noimageIc() }
            .drive(avatarImageView.rx.image(transitionType: kCATransitionFade))
            .addDisposableTo(disposeBag)
        
        self.viewModel.isInChat.asDriver()
            .drive(onNext: {
                if $0 {
                    self.actionButton.setImage(R.image.done(), for: .normal)
                } else {
                    self.actionButton.setImage(R.image.plus(), for: .normal)
                }
            }).addDisposableTo(disposeBag)
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        disposeBag = DisposeBag()
    }
    
    @IBAction func changeStatusInChat(_ sender: Any) {
        delegate?.changeMemberStatus(cell: self)
    }
    
    private lazy var disposeBag = DisposeBag()
}
