//
//  ChatFriendCell.swift
//  Campfiire
//
//  Created by Admin on 09.01.17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import Foundation
