//
//  ChatsListCell.swift
//  Campfiire
//
//  Created by Andrew Seregin on 12/1/16.
//  Copyright © 2016 campfiire. All rights reserved.
//


import Foundation

import RxSwift
import RxCocoa
import RxDataSources

protocol ChatListCellPresentable {
    
    var chatName: Driver<String> { get }
    var chatImageURL: Driver<String> { get }
    
    var dateString: Driver<String> { get }
    
    var underlineColor: Driver<UIColor?> { get }
}

class ChatsListCell: UITableViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var avatarImageView: UIImageView!
    @IBOutlet weak var lastActiveLabel: UILabel!
    @IBOutlet weak var groupChatLabel: UILabel! {
        didSet {
            groupChatLabel.font = UIFont.appLightItalicPrimaryFont(size: 12)
        }
    }
    @IBOutlet weak var userStatusView: UIView!
    
    private lazy var disposeBag = DisposeBag()
    
    var cellPresentable: ChatListCellPresentable! {
        didSet {
            
            guard let item = cellPresentable else { return }
            
            item.chatName
                .drive(nameLabel.rx.text)
                .addDisposableTo(disposeBag)
            
            item.underlineColor.map { $0 != nil }
                .drive(self.groupChatLabel.rx.isHidden)
                .addDisposableTo(disposeBag)
            
            item.underlineColor.map { $0 == nil }
                .drive(self.userStatusView.rx.isHidden)
                .addDisposableTo(disposeBag)
            
            item.chatImageURL
                .flatMap { ImageRetreiver.imageAuthorizedWithoutProgress(at: $0) }
                .map { $0 ?? R.image.noimageIc() }
                .drive( avatarImageView.rx.image(transitionType: kCATransitionFade) )
                .addDisposableTo(disposeBag)
            
            item.underlineColor
                .drive( onNext: { [unowned self] color in
                    self.userStatusView.backgroundColor = color
                })
                .addDisposableTo(disposeBag)
            
            item.dateString
                .drive( lastActiveLabel.rx.text )
                .addDisposableTo(disposeBag)
        }
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        self.disposeBag = DisposeBag()
    }
    
}
