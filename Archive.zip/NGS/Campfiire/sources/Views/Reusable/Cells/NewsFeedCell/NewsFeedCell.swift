//
//  NewsFeedCell.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/29/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

import RxSwift
import RxCocoa

protocol NewsFeedCellViewModelProtocol: ViewModel {
    
    var item: Driver<NewsItemViewModelProtocol> { get }
    
    ///can be used for presenting like button
    ///or delete action
    ///tap action can be received via upperRightButtonTap method
    var upperRightButtonImageDriver: Driver<UIImage?> { get }
    func upperRightButtonTap()
    
    ///if you want to receive callbacks for bottom left section tap, return true
    var newsNameTappable: Bool { get }
    func newsNameTapped()
    
}

class NewsFeedCell: UITableViewCell {
    
    @IBOutlet var backgroundImageView: UIImageView!
    
    @IBOutlet var upperRightLabel: UILabel!
    @IBOutlet var bottomRightLabel: UILabel!
    @IBOutlet var bottomLeftLabel: UILabel!
    
    @IBOutlet var newsTypeLabel: UILabel!
    
    @IBOutlet weak var likeButton: UIButton!
    
    @IBOutlet var newsNameLabel: UILabel!
    @IBOutlet var newsNameImageView: UIImageView!
    @IBOutlet var newsNameImageViewWidthConstraint: NSLayoutConstraint!
    @IBOutlet weak var newsNameContiner: UIView!
    lazy var newsNameTapGestureRecognizer: UITapGestureRecognizer = {
        return UITapGestureRecognizer(target: self,
                                      action: #selector(NewsFeedCell.newsTypeTap))
    }()
    
    var viewModel: NewsFeedCellViewModelProtocol! {
        didSet {
            guard viewModel != nil else { return }
            
            let item = viewModel.item
            
            item.map { $0.bottomLeftString }
                .drive(bottomLeftLabel.rx.text)
                .addDisposableTo(bag)
            
            item.map { $0.bottomRightString }
                .drive(bottomRightLabel.rx.text)
                .addDisposableTo(bag)
            
            item.map { $0.upperRightString }
                .drive(upperRightLabel.rx.text)
                .addDisposableTo(bag)
            
            item.map { $0.upperRightString }
                .drive(upperRightLabel.rx.text)
                .addDisposableTo(bag)
            
            item.map { $0.backgroundImageURL }
                .flatMapLatest {
                    ImageRetreiver.imageForURLWithoutProgress(url: $0)
                }
                .map { $0 ?? R.image.imageOff() }
                .drive(backgroundImageView.rx.image(transitionType: kCATransitionFade))
                .addDisposableTo(bag)


            /////bottom right section
            item.map { $0.newsTypeLabelText }
                .drive(newsTypeLabel.rx.text)
                .addDisposableTo(bag)
            
            item.map { $0.newsTypeLabelColor }
                .drive(onNext: { [unowned self] (color) in
                    self.newsTypeLabel.backgroundColor = color
                })
                .addDisposableTo(bag)

            
            ////bottom left section
            item.map { $0.newsNameSectionTitle }
                .drive(newsNameLabel.rx.text)
                .addDisposableTo(bag)
            
            let smallImageURL = item.map { $0.newsNameSectionImageURL }
            
            smallImageURL.notNil()
                .flatMapLatest { ImageRetreiver.imageForURLWithoutProgress(url: $0) }
                .do(onNext: { [unowned self] _ in
                    self.newsNameImageViewWidthConstraint.constant = 20
                })
                .drive(newsNameImageView.rx.image(transitionType: kCATransitionFade))
                .addDisposableTo(bag)
                
            smallImageURL.filter { $0 == nil }
                .drive(onNext: { [unowned self] (url) in
                    
                        self.newsNameImageViewWidthConstraint.constant = 0
                        self.setNeedsLayout()
                })
                .addDisposableTo(bag)
            
            ///upperImage
            let imageDriver = viewModel.upperRightButtonImageDriver
            
            imageDriver.map { $0 == nil }
                .drive(likeButton.rx.isHidden)
                .addDisposableTo(bag)
            
            imageDriver
                .notNil()
                .drive(onNext: { [unowned self] (image) in
                    self.likeButton.wiggle(isInward: false)
                    self.likeButton.setImage(image, for: .normal)
                })
                .addDisposableTo(rx_disposeBag)
            
            ///full screen image
            
                ///as for now we'll display image fullscreen based on handler existence
                ///though it shoud better be configurable via ViewModel
            if let h = viewModel.handler {
                ///we're using custom disposeBag because not all NewsFeedCell are capable of presenting themselves in full screen. So we'll clear any FullScreen setup during reuse phase
                backgroundImageView.enableFullScreenMode(in: h, disposeBag: bag)
            }
            
            ////news name taps
            if viewModel.newsNameTappable {
                newsNameContiner.addGestureRecognizer(newsNameTapGestureRecognizer)
            }
            
        }
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        bag = DisposeBag()
        imageView?.image = nil
        newsNameContiner.removeGestureRecognizer(newsNameTapGestureRecognizer)
    }
    
    @IBAction func likeAction(_ sender: Any) {
        viewModel.upperRightButtonTap()
    }
    
    func newsTypeTap() {
        viewModel.newsNameTapped()
    }
    
    fileprivate var bag = DisposeBag()
    
}
