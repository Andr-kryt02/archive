//
//  TraitTableCell
//  Campfiire
//
//  Created by Vlad Soroka on 10/18/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import RxCocoa

class TraitTableCell : UITableViewCell {
    
    @IBOutlet weak var textField: CampfiireTextField! {
        didSet {
            textField.delegate = self
            textField.textColor = UIColor.black
        }
    }
    
    @IBOutlet weak var iconView: UIImageView!

    fileprivate var viewModel: TraitCellViewModel?

    func setViewModel(viewModel: TraitCellViewModel) {
        
        self.viewModel = viewModel
        
        textField.text = viewModel.title
        iconView.image = viewModel.image
        
        textField.isUserInteractionEnabled = viewModel.editable
        textField.placeholder = viewModel.placeholder
        
        if viewModel.traitType == .location {
            LocationAccessoryView.setUp(for: textField)
        }
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        textField.inputAccessoryView = nil
    }
    
}

extension TraitTableCell : UITextFieldDelegate {
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        textField.resignFirstResponder()
        
        viewModel?.updateTrait(string: textField.text!)
    }
    
}
