//
//  MMJCell.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 2016-12-13.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift

class MMJCell : UITableViewCell {
  
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var pictureImageView: UIImageView!
    @IBOutlet weak var artivleLabel: UILabel!
    
    func configureVithMMJ(item: MMJ) {
               
        titleLabel.text = item.title
        artivleLabel.text = item.description
        
        ImageRetreiver.imageForURLWithoutProgress(url: item.image)
            .map { $0 ?? R.image.noimageIc() }
            .drive(pictureImageView.rx.image(transitionType: kCATransitionFade))
            .addDisposableTo(disposeBag)
        
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        disposeBag = DisposeBag()
    }
    
    private lazy var disposeBag = DisposeBag()
    
}
