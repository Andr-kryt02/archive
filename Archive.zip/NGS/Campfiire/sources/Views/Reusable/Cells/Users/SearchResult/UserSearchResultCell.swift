//
//  UserSearchResultCell.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/25/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift

protocol UserSearchResultCellPresentable {

    var name: String { get }
    var isUserOnline: Bool { get }
    var pictureURL: String { get }
}

protocol SearchResultCellDelegate : class {
    func chatButtonTapped(cell: UserSearchResultCell)
}

class UserSearchResultCell: UITableViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var avatarImageView: UIImageView!
    @IBOutlet weak var chatButton: UIButton!
    
    @IBOutlet weak var userStatusView: UIView!
    
    weak var delegate : SearchResultCellDelegate?
    
    func configureWithUser(user: UserSearchResultCellPresentable,
                           showsChatIcon: Bool = true) {
        
        chatButton.isHidden = !showsChatIcon
        
        nameLabel.text = user.name
        
        userStatusView.backgroundColor = user.isUserOnline ? UIColor.userStatusOnline : UIColor.userStatusOffline

        ImageRetreiver.imageForURLWithoutProgress(url: user.pictureURL)
            .map { $0 ?? R.image.noimageIc() }
            .drive(avatarImageView.rx.image(transitionType: kCATransitionFade))
            .addDisposableTo(disposeBag)
        
    }
    
    @IBAction func chatTapped(_ sender: Any) {
        delegate?.chatButtonTapped(cell: self)
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        disposeBag = DisposeBag()
    }
    
    private lazy var disposeBag = DisposeBag()
    
}
