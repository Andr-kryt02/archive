//
//  FriendRequestCell.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/31/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

protocol FriendRequestCellDelegate: class {
    
    func cellDidRejectRequest(cell: FriendRequestCell)
    func cellDidAcceptRequest(cell: FriendRequestCell)
    
}

class FriendRequestCell : UITableViewCell {
    
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var acceptButton: UIButton! {
        didSet {
            acceptButton.titleEdgeInsets.left = -15
            acceptButton.imageEdgeInsets.left = 19
        }
    }
    @IBOutlet var rejectButton: UIButton!
    
    weak var delegate: FriendRequestCellDelegate?
    
    func configureWithUser(user: User) {
        
        nameLabel.text = user.name
        
    }
    
 
    @IBAction func acceptAction(_ sender: Any) {
        delegate?.cellDidAcceptRequest(cell: self)
    }
    
    @IBAction func rejectAction(_ sender: Any) {
        
        delegate?.cellDidRejectRequest(cell: self)
        
    }
    
}
