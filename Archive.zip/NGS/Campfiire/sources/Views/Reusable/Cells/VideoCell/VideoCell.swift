//
//  VideoCell.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 2016-12-19.
//  Copyright © 2016 campfiire. All rights reserved.
//


import Foundation
import RxSwift
import AVFoundation

class VideoCell : UITableViewCell {
    
    @IBOutlet weak var pictureImageView: UIImageView!
    
    @IBOutlet weak var titleLabel: UILabel!
    func configureVithVideo(item: Video) {
        
        titleLabel.text = item.title

        ImageRetreiver.imageForURLWithoutProgress(url: item.thumbNail)
            .map { $0 }
            .drive(pictureImageView.rx.image(transitionType: kCATransitionFade))
            .addDisposableTo(disposeBag)
        
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        disposeBag = DisposeBag()
    }
    
    private lazy var disposeBag = DisposeBag()

}
