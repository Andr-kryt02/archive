//
//  CommentCell.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/2/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift

protocol CommentCellDelegate: class {
    
    func commentCellDidTapAvatar(cell: CommentCell)
    func commentCellDidReport(cell: CommentCell)
    
}

class CommentCell : UITableViewCell {
    
    @IBOutlet weak var reportButton: UIButton!
    @IBOutlet weak var topBar: UIView!
    @IBOutlet var authorImageView: UIImageView!
    @IBOutlet var authorNameLabel: UILabel! {
        didSet {
            authorNameLabel.text = ""
        }
    }
    @IBOutlet var datelabel: UILabel! {
        didSet {
            datelabel.text = ""
        }
    }
    @IBOutlet var commentTextLabel: UILabel! {
        didSet {
            commentTextLabel.text = ""
        }
    }
    
    @IBOutlet weak var artworkImageView: UIImageView!
    
    @IBOutlet weak var separatorHeight: NSLayoutConstraint!
    
    ////one of these two should always be disabled
    @IBOutlet var imageViewHeight: NSLayoutConstraint!
    @IBOutlet var imageViewAspectRatioConstraint: NSLayoutConstraint!
    
    ////one of these two should always be disabled
    @IBOutlet var noImageLabelConstraint: NSLayoutConstraint!
    @IBOutlet var presentImageLabelConstraint: NSLayoutConstraint!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        let gr = UITapGestureRecognizer(target: self, action: #selector(CommentCell.didTapAvatar))
        authorImageView.addGestureRecognizer(gr)
     
        self.backgroundColor = UIColor.clear
        self.contentView.backgroundColor = UIColor.clear
        
    }
    
    weak var commentDelegate: CommentCellDelegate?
    
    var viewModel: CommentViewModel? {
        
        didSet {
            
            authorNameLabel.text = viewModel?.comment.author?.name
            datelabel.text = viewModel?.comment.date.campfiireString
            commentTextLabel.text = viewModel?.comment.text
            
            if let url = viewModel?.comment.author?.pictureURL {
                ImageRetreiver.imageForURLWithoutProgress(url: url)
                    .map { $0 ?? R.image.noimageIc() }
                    .drive(authorImageView.rx.image(transitionType: kCATransitionFade) )
                    .addDisposableTo(bag)
            }
            
            if let artwork = viewModel?.comment.pictureURL {
                ImageRetreiver.imageForURLWithoutProgress(url: artwork)
                    .drive(artworkImageView.rx.image(transitionType: kCATransitionFade) )
                    .addDisposableTo(bag)
            }
            
            topBar.backgroundColor = viewModel?.topBarColor
         
            authorNameLabel.textColor = viewModel?.headerTextColor
            datelabel.textColor = viewModel?.headerTextColor
            
            let showsImage = viewModel?.showsImage ?? false
            reportButton.isHidden = !(viewModel?.showsReportButton ?? false)
            
            separatorHeight.constant = showsImage ? 1 : 0
            imageViewAspectRatioConstraint.isActive = showsImage
            imageViewHeight.isActive = !showsImage
            
            noImageLabelConstraint.isActive = !showsImage
            presentImageLabelConstraint.isActive = showsImage
            
            self.setNeedsLayout()
            
        }
        
    }
    
    var bag = DisposeBag()
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        bag = DisposeBag()
        
        authorImageView.image = nil
        artworkImageView.image = nil
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        authorImageView.layer.cornerRadius = authorImageView.frame.size.width / 2
    }
    
    func didTapAvatar() {
        commentDelegate?.commentCellDidTapAvatar(cell: self)
    }
    
    @IBAction func reportTapped(_ sender: Any) {
        commentDelegate?.commentCellDidReport(cell: self)
    }
}
