//
//  TagTableCell.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/18/16.
//  Copyright © 2016 campfiire. All rights reserved.
//


import RxCocoa

protocol TagCellDelegate : class {
    func closeClicked(cell: TagTableCell)
}

class TagTableCell : UITableViewCell {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        let gr = UITapGestureRecognizer(target: self,
                                        action: #selector(TagTableCell.tagTapped(_:)))
        self.addGestureRecognizer(gr)
        
    }
    
    @IBOutlet var rightOffsetConstraint: NSLayoutConstraint!
    @IBOutlet var leftOffsetConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var clearButton: UIButton!
    @IBOutlet weak var clearButtonWiethConstraint: NSLayoutConstraint!
    @IBOutlet weak var label: UILabel!
    
    var closeButtonHidden: Bool = false {
        didSet {
            
            clearButtonWiethConstraint.constant =
                closeButtonHidden ? 0 : 20
            self.setNeedsLayout()
        }
    }
    
    var sideOffset: CGFloat = 8 {
        didSet {
            rightOffsetConstraint.constant = sideOffset
            leftOffsetConstraint.constant = sideOffset
            
            self.layoutIfNeeded()
        }
    }
    
    fileprivate var viewModel: TagCellViewModel!
    fileprivate weak var delegate: TagCellDelegate?
    
    func setViewModel(viewModel: TagCellViewModel, delegate: TagCellDelegate) {
        
        self.viewModel = viewModel
        self.delegate = delegate
        
        label.textAlignment = viewModel.titleAlignment
        containerView.backgroundColor = viewModel.containerColor
        
        label.text = viewModel.title
        closeButtonHidden = viewModel.closeButtonHidden
        
    }
    
    
    @IBAction func clearButtonClicked(_ sender: AnyObject) {
        if let d = delegate {
            d.closeClicked(cell: self)
        }
    }
    
    func tagTapped(_ sender: Any) {
        viewModel.tagSelected()
    }
    
    
}
