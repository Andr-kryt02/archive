//
//  FAQTableViewCell.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/6/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import UIKit

class FAQTableViewCell: UITableViewCell {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var textView: UILabel!
    @IBOutlet weak var pictureImage: UIImageView!
    @IBOutlet var heightConstraint: NSLayoutConstraint!
    
    var expanded: Bool = false {
        didSet {
            
            heightConstraint.isActive = !expanded
            
            pictureImage.image = expanded ? R.image.foldlessIc()! : R.image.foldmoreIc()!
            
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }


}
