//
//  AccessoryView.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 07.11.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa


class LocationAccessoryView: UIInputView {
    
    @discardableResult
    static func setUp(for textField: UITextField) -> LocationAccessoryView {
        
        let inst = R.nib.locationAccessoryView.firstView(owner: nil)!
        
        inst.owner = textField
        textField.inputAccessoryView = inst
        
        textField.addTarget(inst,
                            action: #selector(LocationAccessoryView.queryChanged(_:)),
                            for: .editingChanged)
        textField.autocorrectionType = .no
        
        inst.autoresizingMask = .flexibleHeight
        
        
        return inst
    }
    
    @IBOutlet var container: UIView!
    
    @IBOutlet var leftButton: UIButton!
    @IBOutlet var rightButton: UIButton!
    @IBOutlet var seprator: UIView!
    
    @IBOutlet var widthConstraint: NSLayoutConstraint!
    
    var twoButtonsVisible: Bool = true {
        didSet {
            widthConstraint.constant = twoButtonsVisible ? container.frame.size.width / 2 : 0

            UIView.animate(withDuration: 0.3) {
                self.seprator.isHidden = !self.twoButtonsVisible
                
                self.layoutIfNeeded()
            }
            
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        viewModel.foundLocations.asDriver()
            .drive(onNext: { [weak self] (locations) in
                
                self?.twoButtonsVisible = locations.count > 1

                if locations.count == 0 {
                    self?.leftButton.setTitle("No mathces", for: .normal)
                }
                
                if locations.count > 1 {
                    let second = locations[1]
                    
                    self?.rightButton.setTitle(second.city + ", " + second.county, for: .normal)
                }
                
                if locations.count > 0 {
                    let first = locations[0]
                    
                    self?.leftButton.setTitle(first.city + ", " + first.county, for: .normal)
                }
                
            })
            .addDisposableTo(rx_disposeBag)
        
        viewModel.selectedLocation.asDriver()
            .notNil()
            .drive(onNext: { [weak self] (location) in
                self?.owner?.text = location.city
            })
            .addDisposableTo(rx_disposeBag)
    }
    
    weak var owner: UITextField? = nil {
        didSet {
            owner?.inputAccessoryView = self
        }
    }
    
    let viewModel = LocationAccessoryViewModel()
    
}

extension LocationAccessoryView  {
 
    @IBAction func leftButtonAction(_ sender: Any) {
        viewModel.locationClicked(at: 0)
    }
    
    @IBAction func rightButtonAction(_ sender: Any) {
        viewModel.locationClicked(at: 1)
    }
    
    func queryChanged(_ textField: UITextField) {
        viewModel.query.value = textField.text
    }
    
}
