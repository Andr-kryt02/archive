//
//  RateBarView.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 21.11.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa


class RateBarView : UIView {

    @IBOutlet weak var rateButton: UIButton!

    @IBOutlet weak var ratingLabel: UILabel!

    @IBOutlet weak var container: UIView!    
    
}
