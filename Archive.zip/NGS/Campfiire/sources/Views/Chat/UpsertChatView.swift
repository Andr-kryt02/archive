//
//  UpsertChatview.swift
//  Campfiire
//
//  Created by Andrew Seregin on 1/5/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import RxDataSources


class UpsertChatView : UIView
{
 
    @IBOutlet var usersTableView: UITableView! {
        didSet {
            usersTableView.delegate = nil
            usersTableView.dataSource = nil
            
            usersTableView.rowHeight = 44;
            usersTableView.register(R.nib.tagCell)
            usersTableView.keyboardAvoiding()
        }
    }
    
    @IBOutlet var titleTextView: MPTextView! {
        didSet {
            titleTextView.placeholderText = "Type title..."
        }
    }
    
    @IBOutlet var descriptionTextView: MPTextView! {
        didSet {
            descriptionTextView.placeholderText = "Type description..."
        }
    }
    
    @IBOutlet var avatarImageView: UIImageView!
    @IBOutlet var membersLabel: UILabel!
    @IBOutlet var confirmButton: UIButton!

    var viewModel: UpsertChatViewModel! {
        didSet {
            guard let vm = viewModel else { return }
//            
//            vm.canEnterInfo.asObservable()
//                .subscribe(onNext: {
//                    self.descriptionTextView.isEditable = $0
//                    self.titleTextView.isEditable = $0
//                })
//                .addDisposableTo(rx_disposeBag)
//            
//            vm.observableChat
//                .map { "\($0.members.count) members" }
//                .bindTo(membersLabel.rx.text)
//                .addDisposableTo(rx_disposeBag)
//            
//            confirmButton.setTitle(vm.commitButtonTitle, for: .normal)
//            confirmButton.backgroundColor = vm.commitButtonColor
//            
//            vm.observableChat
//                .map { $0.pictureURL }
//                .distinctUntilChanged()
//                .flatMap { ImageRetreiver.imageAuthorizedWithoutProgress(at: $0) }
//                .map { $0 ?? R.image.addPhotoButton() }
//                .bindTo(avatarImageView.rx.image(transitionType: kCATransitionFade))
//                .addDisposableTo(rx_disposeBag)
//            
//            membersLabel.isHidden = vm.membersHidden
//            
//            vm.observableChat
//                .map{ "\($0.members.count) followers" }
//                .bindTo(membersLabel.rx.text)
//                .addDisposableTo(rx_disposeBag)
//            
//            titleTextView.text = vm.titleText
//            descriptionTextView.text = vm.descriptionText
// 
//            dataSource.configureCell = { [unowned self] (dataSource, tableView, indexPath, item) in
//                
//                let cell: TagTableCell = tableView.dequeueReusableCell(withIdentifier: R.nib.tagCell.identifier,
//                                                                       for: indexPath) as! TagTableCell
//                
//                cell.sideOffset = 30
//                cell.backgroundColor = UIColor.backgroundBlack
//                cell.setViewModel(viewModel: item,
//                                  delegate: self)
//                
//                return cell
//                
//            }
//            
//            vm.users
//                .bindTo(usersTableView.rx.items(dataSource: dataSource))
//                .addDisposableTo(self.rx_disposeBag)

        }
    }
    
    @IBAction func commitButtonTapped(_ sender: Any) {
        //viewModel.commitButtonSelected()
    }
    
    fileprivate let dataSource: RxTableViewSectionedAnimatedDataSource<AnimatableSectionModel<String, TagCellViewModel>> = RxTableViewSectionedAnimatedDataSource()
}

extension UpsertChatView: TagCellDelegate, UITextViewDelegate {
    
    func closeClicked(cell: TagTableCell) {
        //viewModel.closeClicked(at: usersTableView.indexPath(for: cell)!)
    }
    
    func textViewDidChange(_ textView: UITextView) {
//        if textView == titleTextView {
//            viewModel.titleChanged(text: textView.text)
//        }
//        else if textView == descriptionTextView {
//            viewModel.descriptionChanged(text: textView.text)
//        }
        
    }
    
}
