//
//  ImageMessageCell.swift
//  Campfiire
//
//  Created by Vlad Soroka on 1/29/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import Foundation

import RxSwift

class ChatImageCell: UITableViewCell {
    
    static let imageViewHeight: CGFloat = 100
    
    @IBOutlet weak var chatImageView: UIImageView! {
        didSet {
            chatImageView.layer.cornerRadius = 5
            chatImageView.layer.borderWidth = 0.5
            chatImageView.layer.borderColor = UIColor.lightGray.cgColor
            chatImageView.image = nil
        }
    }
    
    @IBOutlet weak var imageWidthConstraint: NSLayoutConstraint!
    @IBOutlet var imageLeadingConstraint: NSLayoutConstraint!
    @IBOutlet var imageTrailingConstraint: NSLayoutConstraint!
    
    var chatMessage: ChatMessage! {
        didSet {
            
            guard let message = chatMessage,
                  let url = message.pictureURL else { return }
            
            imageLeadingConstraint.isActive = !message.isOwnMessage
            imageTrailingConstraint.isActive = message.isOwnMessage
            
            self.layoutIfNeeded()
            
            if let lastURL = lastURL, lastURL == url {
                return;
            }
            
            chatImageView.image = nil
            ImageRetreiver.imageAuthorizedWithoutProgress(at: url)
                .notNil()
                .do(onNext: { [unowned self] image in
                    ///16 is the marigins for top and to bottom of the image
                    self.imageWidthConstraint.constant = image.size.width * (ChatImageCell.imageViewHeight - 16) / image.size.height
                    self.layoutIfNeeded()
                    self.lastURL = url
                })
                .drive(chatImageView.rx.image(transitionType: kCATransitionFade))
                .addDisposableTo(bag)
            
        }
    }
    
    fileprivate var bag = DisposeBag()
    fileprivate var lastURL: String? = nil
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        bag = DisposeBag()
    }
    
}
