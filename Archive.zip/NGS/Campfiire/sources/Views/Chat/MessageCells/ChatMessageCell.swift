//
//  ChatMessageCell.swift
//  Campfiire
//
//  Created by Vlad Soroka on 1/29/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import Foundation

class ChatMessageCell : UITableViewCell {
    
    static let bubleWidth: CGFloat = 250
    static let font = UIFont.appRegularPrimaryFont(size: 12)
    
    @IBOutlet weak var textView: UITextView! {
        didSet {
            textView.textContainerInset = UIEdgeInsets.zero
            textView.font = ChatMessageCell.font
        }
    }
    @IBOutlet weak var dateLabel: UILabel! {
        didSet {
            dateLabel.font = UIFont.appLightItalicPrimaryFont(size: 10)
        }
    }
    @IBOutlet weak var bubleView: UIView! {
        didSet {
            bubleView.layer.cornerRadius = 5
        }
    }
    
    @IBOutlet weak var bubleWidthConstraint: NSLayoutConstraint! {
        didSet {
            bubleWidthConstraint.constant = ChatMessageCell.bubleWidth
        }
    }
    
    @IBOutlet var leadingConstraint: NSLayoutConstraint!
    @IBOutlet var trailingConstraint: NSLayoutConstraint!
    
    var chatMessage: ChatMessage! {
        didSet {
            
            guard let message = chatMessage else { return }
            
            textView.text = message.body
            dateLabel.text = message.date.campfiireString
            
            bubleView.backgroundColor = message.isOwnMessage ? UIColor.ownChatBubble : UIColor.othersChatBuble
            
            leadingConstraint.isActive = !message.isOwnMessage
            trailingConstraint.isActive = message.isOwnMessage
            
            self.layoutIfNeeded()
        }
    }
    
}
