
//
//  ChatCellCalculator.swift
//  Campfiire
//
//  Created by Vlad Soroka on 1/29/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import Foundation

class ChatCellCalculator {
    
    private var heightCache: [ Int : CGFloat ] = [:]//NSCache<NSNumber, NSNumber> = NSCache()
    
    func height(of message: ChatMessage, for width: CGFloat) -> CGFloat {
        if message.isImageMessage {
            return ChatImageCell.imageViewHeight
        }
        
        if let cachedHeight = heightCache[message.hashValue] {
            return cachedHeight
        }
        
        var totalHeight: CGFloat = 0
        
        totalHeight += 8 ///top margin

        totalHeight += 4 //bubble topMargin
        totalHeight += 4 //textView top margin
        var textHeight = ChatMessageCell.font
            .sizeOfString(string: message.body, constrainedToWidth: Double(width)).height
        if textHeight < 20 {
            textHeight = 20
        }
        totalHeight += textHeight ///message height
        textHeight += 8 ///textView text inset
        totalHeight += 14 ///date label height
        totalHeight += 3 ///date label to buble height
        
        totalHeight += 8 ///bottom margin
        
        heightCache[message.hashValue] = totalHeight
        
        return totalHeight
    }
    
}

extension UIFont {
    func sizeOfString (string: String, constrainedToWidth width: Double) -> CGSize {
        return (string as NSString).boundingRect(with: CGSize(width: width, height: DBL_MAX),
                                                         options: .usesLineFragmentOrigin,
                                                         attributes: [NSFontAttributeName: self],
                                                         context: nil).size
    }
}
