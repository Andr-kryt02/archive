//
//  UpsertHotspotView.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/3/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import RxDataSources

class UpsertHotspotView: UIView {
    
    @IBOutlet var tagsTableView: UITableView! {
        didSet{
            tagsTableView.delegate = nil
            tagsTableView.dataSource = nil
            
            tagsTableView.rowHeight = 44
            
            tagsTableView.register(R.nib.tagCell)
            
            tagsTableView.keyboardAvoiding()
            
        }
    }
    
    @IBOutlet var titleTextView: MPTextView! {
        didSet {
            titleTextView.placeholderText = "Type title..."
        }
    }
    @IBOutlet var descriptionTextView: MPTextView! {
        didSet {
            descriptionTextView.placeholderText = "Type Description..."
        }
    }
    
    @IBOutlet var avatarImageView: UIImageView!
    @IBOutlet var followersLabel: UILabel!
    @IBOutlet var addressLabel: UILabel!
    @IBOutlet var commitButton: UIButton!
    
    var viewModel: UpsertHotspotViewModel! {
        didSet {
            guard let vm = viewModel else { return }
            
            commitButton.setTitle(vm.commitButtonTitle, for: .normal)
            commitButton.backgroundColor = vm.commitButtonColor
            
            followersLabel.isHidden = vm.followersHidden
            vm.observableHotspot
                .map { "\($0.followersCount) followers" }
                .bindTo(followersLabel.rx.text)
                .addDisposableTo(rx_disposeBag)
            
            vm.observableHotspot
                .map { $0.imageURL }
                .distinctUntilChanged()
                .flatMap { ImageRetreiver.imageForURLWithoutProgress(url: $0) }
                .map { $0 ?? R.image.addPhoto() }
                .bindTo(avatarImageView.rx.image(transitionType: kCATransitionFade))
                .addDisposableTo(rx_disposeBag)
            
            titleTextView.text = vm.titleText
            descriptionTextView.text = vm.descriptionText
            
            dataSource.configureCell = { [unowned self] (dataSource, tableView, indexPath, item) in
                
                let cell: TagTableCell = tableView.dequeueReusableCell(withIdentifier: R.nib.tagCell.identifier,
                                                                       for: indexPath) as! TagTableCell
                
                cell.sideOffset = 30
                cell.backgroundColor = UIColor.backgroundBlack
                cell.setViewModel(viewModel: item,
                                  delegate: self)
                
                return cell
                
            }
            
            vm.tags
                .bindTo(tagsTableView.rx.items(dataSource: dataSource))
                .addDisposableTo(self.rx_disposeBag)

            vm.observableHotspot
                .map { $0.adress }
                .notNil()
                .bindTo(addressLabel.rx.text)
                .addDisposableTo(rx_disposeBag)
            
        }
    }
    
    fileprivate let dataSource: RxTableViewSectionedAnimatedDataSource<AnimatableSectionModel<String, TagCellViewModel>> = RxTableViewSectionedAnimatedDataSource()
    
}

extension UpsertHotspotView: TagCellDelegate, UITextViewDelegate {
    
    func closeClicked(cell: TagTableCell) {
        viewModel.closeClicked(at: tagsTableView.indexPath(for: cell)!)
    }
    
    @IBAction func commitButtonTapped(_ sender: Any) {
        viewModel.commitButtonSelected()
    }
    
    func textViewDidChange(_ textView: UITextView) {
        if textView == titleTextView {
            viewModel.titleChanged(text: textView.text)
        }
        else if textView == descriptionTextView {
            viewModel.descriptionChanged(text: textView.text)
        }
        
    }
    
}
