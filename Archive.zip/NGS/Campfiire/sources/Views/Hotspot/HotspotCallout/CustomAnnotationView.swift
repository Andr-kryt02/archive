//
//  CustomAnnotationView.swift
//  SwiftMapViewCustomCallout
//
//  Created by Robert Ryan on 8/7/16.
//  Copyright © 2015-2016 Robert Ryan. All rights reserved.
//

import UIKit
import MapKit

class AnnotationView: MKAnnotationView {
    
    weak var calloutView: AnnotationCallout?
    weak var delegate: AnnotationCalloutDelegate?
    var viewModel: MapAnnotationViewModel! {
        didSet {
            self.image = self.viewModel.pinImage
        }
    }
    
    override var annotation: MKAnnotation? {
        willSet {
            calloutView?.removeFromSuperview()
        }
    }
    
    override init(annotation: MKAnnotation?,
         reuseIdentifier: String?) {
         
        super.init(annotation: annotation, reuseIdentifier: reuseIdentifier)
        
        canShowCallout = false
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("can't decode CustomAnnotationView")
    }
    
    let animationDuration: TimeInterval = 0.25

    override func setSelected(_ selected: Bool, animated: Bool) {
        if selected {
            let calloutView = AnnotationCallout(annotation: annotation as! AnnotationWrapper,
                                                viewModel: viewModel)
            calloutView.add(to: self)
            calloutView.delegate = delegate
            self.calloutView = calloutView
            
            if animated {
                calloutView.alpha = 0
                UIView.animate(withDuration: animationDuration) {
                    calloutView.alpha = 1
                }
            }
        } else {
            if animated {
                UIView.animate(withDuration: animationDuration, animations: {
                    self.calloutView?.alpha = 0
                    }, completion: { finished in
                        self.calloutView?.removeFromSuperview()
                })
            } else {
                calloutView?.removeFromSuperview()
            }
        }
    }
    
    // Per the Location and Maps Programming Guide, if you want to detect taps on callout,
    // you have to expand the hitTest for the annotation itself.
    
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        var hitView = super.hitTest(point, with: event)
        
        if let calloutView = calloutView, hitView == nil {
            let pointInCalloutView = convert(point, to: calloutView)
            hitView = calloutView.hitTest(pointInCalloutView, with: event)
        }
        return hitView;
    }
    
}

