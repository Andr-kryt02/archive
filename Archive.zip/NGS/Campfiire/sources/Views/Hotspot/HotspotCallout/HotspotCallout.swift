//
//  HotspotCallout.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/15/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import MapKit

protocol AnnotationCalloutDelegate: class {
    func calloutViewTapped(for annotation: AnnotationWrapper)
    func calloutReportTapped(for annotation: AnnotationWrapper)
}

class AnnotationCallout: CalloutView {
    
    weak var delegate: AnnotationCalloutDelegate? = nil
    
    
    private var titleLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textColor = UIColor.white
        label.font = UIFont.appRegularPrimaryFont(size: 14)
        
        return label
    }()
    
    private var reportButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setImage(R.image.reportIcon(), for: .normal)
        
        return button
    }()
    
    private let annotation: AnnotationWrapper
    private let viewModel: MapAnnotationViewModel
    
    init(annotation: AnnotationWrapper, viewModel: MapAnnotationViewModel) {
        
        self.annotation = annotation
        self.viewModel = viewModel
        
        super.init()
        
        configure()
        
        updateContents(for: annotation)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("Should not call init(coder:)")
    }
    
    /// Update callout contents
    
    private func updateContents(for annotation: AnnotationWrapper) {
        titleLabel.text = annotation.title ?? "Unknown"
        
    }
    
    /// Add constraints for subviews of `contentView`
    
    private func configure() {
        
        translatesAutoresizingMaskIntoConstraints = false
        
        if viewModel.showsReportButton {
            contentView.addSubview(reportButton)
        }
        contentView.addSubview(titleLabel)
        
        let views: [String : Any] = ["titleLabel": titleLabel,
                                     "reportButton": reportButton]
        
        var vflStrings: [String] = []
        if viewModel.showsReportButton {
            vflStrings = [ "V:|-(5)-[titleLabel]-(5)-|" ,
                           "V:|-(5)-[reportButton]-(5)-|",
                           "H:|-(10)-[titleLabel]-(10)-[reportButton]-(10)-|"]
        }
        else {
            vflStrings = [ "V:|-(5)-[titleLabel]-(5)-|" ,
                           "H:|-(10)-[titleLabel]-(10)-|"]
        }
        
        
        for vfl in vflStrings {
            contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: vfl, options: [], metrics: nil, views: views))
        }

        
        // if you don't want to detect tap on this callout view, comment out the following three lines
        
        isUserInteractionEnabled = true
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        addGestureRecognizer(tap)
        
        reportButton.addTarget(self, action: #selector(AnnotationCallout.report), for: .touchUpInside)

    }
    
    func handleTap(_ gesture: UITapGestureRecognizer) {
        delegate?.calloutViewTapped(for: annotation)
    }
 
    func report() {
        delegate?.calloutReportTapped(for: annotation)
    }
    
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        
        if reportButton.frame.contains(point) {
            return reportButton
        }
        
        return super.hitTest(point, with: event)
    }
    
}
