//
//  HotspotDetailsView.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/2/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift

import RxDataSources

class HotspotDetailsView : UIView {
    
    @IBOutlet var hotspotDescriptionLabel: UILabel!
    
    ///TODO: |Ann| - add shadows
    @IBOutlet var photosCarousel: iCarousel! {
        didSet {
            
            photosCarousel.bounces = true
            photosCarousel.bounceDistance = 0.2
            
            photosCarousel.isPagingEnabled = true
            
        }
    }
    
    @IBOutlet var hotspotImageView: UIImageView!
    
    @IBOutlet var addressLabel: UILabel!
    @IBOutlet var followerslabel: UILabel!
    
    @IBOutlet weak var photoBackButton: UIButton!
    @IBOutlet weak var photoForwardButton: UIButton!
    
    @IBOutlet var commentsTableView: UITableView!
     {
        didSet {
            
            commentsTableView.delegate = nil
            commentsTableView.dataSource = nil
            
            commentsTableView.rowHeight = UITableViewAutomaticDimension
            commentsTableView.estimatedRowHeight = 121
            
            commentsTableView.register(R.nib.commentCell)
            
        }
    }
    
    var viewModel: HotspotDetailsViewModel! {
        didSet {
            guard let vm = viewModel else { return }
            
            vm.hotSpotDriver
                .map { $0.description }
                .drive (hotspotDescriptionLabel.rx.text)
                .addDisposableTo(rx_disposeBag)
            
            vm.hotSpotDriver
                .flatMap { ImageRetreiver.imageForURLWithoutProgress(url: $0.imageURL) }
                .map { $0 ?? R.image.logoLast()! }
                .drive ( hotspotImageView.rx.image(transitionType: kCATransitionFade) )
                .addDisposableTo(rx_disposeBag)
            
            vm.hotSpotDriver
                .map { $0.followersCount }
                .distinctUntilChanged()
                .map { $0.countableString(withSingularNoun: "follower") }
                .drive ( followerslabel.rx.text )
                .addDisposableTo(rx_disposeBag)
            
            vm.hotSpotDriver
                .map { $0.adress }
                .notNil()
                .drive ( addressLabel.rx.text )
                .addDisposableTo(rx_disposeBag)
            
            vm.hotSpotDriver
                .map { $0.photos }
                .distinctUntilChanged { $0 == $1 }
                .drive(onNext: { [unowned self] (_) in
                    self.photosCarousel.reloadData()
                })
                .addDisposableTo(rx_disposeBag)
            
            ///animated comments table
            viewModel.paginatedViewModel.pageTrigger.value =
                commentsTableView!.rxex_simpleBottomShownTrigger()
            
            animatedDataSource.configureCell = { [unowned self] (dataSource, tableView, indexPath, item) in
                
                let cell = tableView.dequeueReusableCell(withIdentifier: R.reuseIdentifier.commentCell,
                                                         for: indexPath)!
                
                cell.viewModel = self.viewModel.commentViewModel(for: item)
                cell.commentDelegate = self
                
                cell.layoutIfNeeded()
                
                return cell
                
            }

            viewModel.commentsDataSource
                .drive(commentsTableView.rx.items(dataSource: animatedDataSource))
                .addDisposableTo(rx_disposeBag)

            ////photo index trigger
            vm.photoIndexTrigger.asDriver()
                .drive(onNext: { [unowned self] (x) in
                    
                    guard self.photosCarousel != nil else { return }
                    
                    self.photosCarousel.scrollToItem(at: x, animated: true)
                })
                .addDisposableTo(rx_disposeBag)
            
        }
    }
    
    fileprivate let animatedDataSource: RxTableViewSectionedAnimatedDataSource<AnimatableSectionModel<String, Comment>> = RxTableViewSectionedAnimatedDataSource()
    
    
}

extension HotspotDetailsView : iCarouselDataSource, iCarouselDelegate {
    
    func numberOfItems(in carousel: iCarousel) -> Int {
        
        guard viewModel != nil else { return 0 }
        
        return viewModel.hotSpotVariable.value.photos.count
    }
    
    func carousel(_ carousel: iCarousel,
                  viewForItemAt index: Int,
                  reusing view: UIView?) -> UIView {
        
        var imageView: CarouselImageView!
        
        if let reused = view as? CarouselImageView {
            reused.prepareForCarouselReuse()
            imageView = reused
        }
        else {
            imageView = R.nib.carouselImage.firstView(owner: nil)!
        }
        
        let photo = viewModel.hotSpotVariable.value.photos[index]
        imageView.viewModel = CarouselImageViewModel(photo: photo)
        imageView.delegate = self
        imageView.frame = carousel.frame
        
        return imageView
    }
    
    func carousel(_ carousel: iCarousel,
                  valueFor option: iCarouselOption,
                  withDefault value: CGFloat) -> CGFloat {
        switch option {
        case .spacing:
            
            return value * 1.03
            
        default:
            return value
        }
    }
    
    func carouselCurrentItemIndexDidChange(_ carousel: iCarousel) {
        photoBackButton.isHidden = !(carousel.currentItemIndex > 0)
        photoForwardButton.isHidden = !(carousel.currentItemIndex < viewModel.hotSpotVariable.value.photos.count - 1)
    }
    
    @IBAction func photoBackAction(_ sender: Any) {
        
        self.photosCarousel.scroll(byNumberOfItems: -1, duration: 0.3)
        
    }
    
    @IBAction func photoForwardAction(_ sender: Any) {
        self.photosCarousel.scroll(byNumberOfItems: 1, duration: 0.3)
    }
    
}

extension HotspotDetailsView: CommentCellDelegate, CarouselImageViewDelegate {
    
    func commentCellDidReport(cell: CommentCell) {
        let ip = commentsTableView.indexPath(for: cell)!
        
        viewModel.reportCommentTapped(at: ip)
    }
    
    func commentCellDidTapAvatar(cell: CommentCell) {
        let ip = commentsTableView.indexPath(for: cell)!
        
        viewModel.commentAuthorTapped(at: ip)
    }
    
    func carouselImageDidReport(item: CarouselImageView) {
        let index = photosCarousel.index(ofItemView: item)
        
        viewModel.reportPhotoTapped(at: index)
    }
    
}
