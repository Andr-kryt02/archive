//
//  TagButton.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/22/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation


class TagButton : UIButton {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.setTitleColor(UIColor.white, for: .normal)
        self.titleLabel?.numberOfLines = 2
        self.titleLabel?.textAlignment = .center
    }
    
    var viewModel: TagButtonViewModel! {
        didSet {
            
            ///title change
            viewModel.title
                .bindTo(self.rx.title(for: .normal))
                .addDisposableTo(rx_disposeBag)
            
            ///color change
            viewModel.color
                .subscribe(onNext: { [unowned self] (color) in
                    self.backgroundColor = color
                })
                .addDisposableTo(rx_disposeBag)
            
            ///bouncing on selection
            
            viewModel.selected.asObservable()
                .distinctUntilChanged()
                .skip(1)
                .subscribe(onNext: { [unowned self] x in
                    
                    self.wiggle(isInward: x)
                    
                })
                .addDisposableTo(rx_disposeBag)
            
            ////action reporting
            self.rx.tap.subscribe(onNext: { [unowned self] in
                self.viewModel.clickReported()
            })
            .addDisposableTo(rx_disposeBag)
        }
    }
    
    override func layoutSublayers(of layer: CALayer) {
        super.layoutSublayers(of: layer)
        
        self.layer.cornerRadius = self.bounds.size.width / 2
    }
 
    override func layoutSubviews() {
        super.layoutSubviews()
        
        self.titleLabel?.font = UIFont.appLightPrimaryFont(size: self.frame.size.width / 5)
    }
    
}
