//
//  AuthView.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/16/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import UIKit
import RxSwift
import AVFoundation

class AuthView: UIView {
    

    @IBOutlet weak var signUpButton: UIButton!
    @IBOutlet weak var signInButton: UIButton!
    @IBOutlet weak var slider: UIView!
    
    @IBOutlet weak var scrollView: UIScrollView!
    ///login section
    
    @IBOutlet weak var emailLoginTextField: UITextField!
    @IBOutlet weak var passwordLoginSection: UITextField!
    
    ///sign up section
    
    @IBOutlet weak var genderTextField: UITextField!
    @IBOutlet weak var avatarImageView: UIImageView!
    
    @IBOutlet weak var emailTextField: CampfiireTextField!
    @IBOutlet weak var passwordTextField: CampfiireTextField! {
        didSet {
            passwordTextField.enableSecureSwitch()
        }
    }
    @IBOutlet weak var confirmPasswordTextField: CampfiireTextField! {
        didSet {
            confirmPasswordTextField.enableSecureSwitch()
        }
    }
    @IBOutlet weak var nameTextField: CampfiireTextField!
    @IBOutlet weak var locationTextField: UITextField!
    @IBOutlet weak var dateOfBirthTextField: CampfiireTextField!
    @IBOutlet weak var favoriteProductTextField: CampfiireTextField!
    
    @IBOutlet weak var nextStepButton: UIButton!
    
    ///tags section
    @IBOutlet var tagButons: [TagButton]!

    
    ///state objects
    
    fileprivate var percent: CGFloat = 0 {
        didSet {
            if percent < 0 { percent = 0; return }
            if percent > 1 { percent = 1; return }
            
            self.setNeedsLayout()
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.scrollView.keyboardAvoiding()
        LocationAccessoryView.setUp(for: locationTextField)
    }
    
    var viewModel: RegisterUserViewModel! {
        didSet {
            
            viewModel.tagButtonsViewModel.enumerated()
                .forEach { (index: Int, element: TagButtonViewModel) in
                    self.tagButons[index].viewModel = element
            }
            
            viewModel.currentPage.asDriver()
                .drive(onNext: { [unowned self] (page: Int) -> Void in
                    
                    self.scrollView
                        .setContentOffset(CGPoint(x: self.scrollView.frame.size.width * CGFloat(page),
                                                  y:0),
                                          animated: true)
                    
                })
                .addDisposableTo(rx_disposeBag)
         
            viewModel.tempAvatarImage.asObservable()
                .notNil()
                .flatMapLatest { ImageRetreiver.imageForURL(url: $0) }
                .map { $0.image }
                .notNil()
                .bindTo(avatarImageView.rx.image())
                .addDisposableTo(rx_disposeBag)
         
            viewModel.selectedGender.asObservable()
                .map { $0?.description }
                .bindTo(self.genderTextField.rx.text
                ).addDisposableTo(rx_disposeBag)
            
            viewModel.selectedBirthDate.asObservable()
                .map {  $0 != nil ? "\(($0! as NSDate).yearsAgo()) y.o." : nil }
                .bindTo(dateOfBirthTextField.rx.text)
                .addDisposableTo(rx_disposeBag)
            
            ///validation UI
            
            viewModel.nameUnderlineColor.asObservable()
                .subscribe(onNext: { [unowned self] (color) in
                    self.nameTextField.underlineColor = color
                })
                .addDisposableTo(rx_disposeBag)
            
            viewModel.emailUnderlineColor.asObservable()
                .subscribe(onNext: { [unowned self] (color) in
                    self.emailTextField.underlineColor = color
                })
                .addDisposableTo(rx_disposeBag)
            
            viewModel.passwordUnderlineColor.asObservable()
                .subscribe(onNext: { [unowned self] (color) in
                    self.passwordTextField.underlineColor = color
                    self.confirmPasswordTextField.underlineColor = color
                })
                .addDisposableTo(rx_disposeBag)
            
            viewModel.dateUnderlineColor.asObservable()
                .subscribe(onNext: { [unowned self] (color) in
                    self.dateOfBirthTextField.underlineColor = color
                })
                .addDisposableTo(rx_disposeBag)
            
        }
    }
    
    lazy var transformer: (CGFloat, CGFloat) -> CGFloat =
        { [unowned self] (x: CGFloat, y: CGFloat) -> CGFloat in
        
        return (1 - self.percent) * x + self.percent * y
        
    }
 
    lazy var playerLayer: AVPlayerLayer = {
       
        let layer = AVPlayerLayer()
        
        let player = AVPlayer(url: R.file.videoFileMp4()!)
        player.isMuted = true
        
        
        
        let endNotification = NotificationCenter.default
            .rx.notification(NSNotification.Name.AVPlayerItemDidPlayToEndTime)
            .asObservable()
        
        let activeNotification = NotificationCenter.default
            .rx.notification(NSNotification.Name.UIApplicationWillEnterForeground)
            .asObservable()
        
        Observable.of(endNotification,
                      activeNotification)
            .merge()
            .subscribe(onNext: { [weak p = player] _ in
                
                p?.pause()
                p?.seek(to: kCMTimeZero)
                p?.play()
                
                })
            .addDisposableTo(self.rx_disposeBag)
        
        layer.player = player
        layer.backgroundColor = UIColor.black.cgColor
        layer.videoGravity = AVLayerVideoGravityResizeAspectFill
        
        self.layer.insertSublayer(layer, at: 0)
        
        layer.player!.play();
        
        return layer
        
    }()
    
}

extension AuthView {
    
    override func layoutSublayers(of layer: CALayer) {
        super.layoutSublayers(of: layer)
        
        self.playerLayer.frame = CGRect(x: 0,
                                        y: 0,
                                        width: self.bounds.size.width,
                                        height: self.bounds.size.height - nextStepButton.frame.size.height)
        
        avatarImageView.layer.cornerRadius = avatarImageView.bounds.size.width / 2
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        let left: UIButton = signInButton
        let right: UIButton = signUpButton
        
        let frame = CGRect(x: transformer( left.frame.origin.x, right.frame.origin.x ),
                           y: transformer( left.frame.origin.y, right.frame.origin.y ) + 30,
                           width: transformer( left.frame.size.width, right.frame.size.width ),
                           height: 1)
        
        slider.frame = frame
        
        let red: CGFloat = transformer(84, 167) / 255
        let green: CGFloat = transformer(167, 169) / 255
        let blue: CGFloat = transformer(81, 89) / 255
        
        slider.backgroundColor = UIColor(red: red,
                                         green: green,
                                         blue: blue, alpha: 1)
     
    }

}

extension AuthView: UIScrollViewDelegate {
    
        
    @IBAction func signInTapped(_ sender: AnyObject) {
        viewModel.reportSignInClicked()
        
    }
    @IBAction func signUpTapped(_ sender: AnyObject) {
        viewModel.reportSignUpClicked()
    }
    
    @IBAction func nextRegistraionStepClicked(_ sender: AnyObject) {
        viewModel.reportNextStepClicked()
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let furthestValue = scrollView.frame.size.width
        let offset = scrollView.contentOffset.x
        
        percent = offset / furthestValue
    }
    
}

extension AuthView: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        
        return true
    }
 
    func textFieldShouldBeginEditing (_ textField: UITextField) -> Bool {
        
        guard textField != self.genderTextField else {
            let dataSource = ["Gender", Gender.male.description, Gender.female.description]
            let initialIndex: Int = 0
            
            ActionSheetMultipleStringPicker.show(withTitle: "Pick your gender", rows: [
                dataSource], initialSelection: [ initialIndex ], doneBlock: { [unowned self]
                    picker, values, indexes in
                    
                    let selectedIndex = values!.first! as! NSNumber
                    self.viewModel.selectedGender.value = Gender(rawValue: selectedIndex.intValue)
                    
                }, cancel: { _ in }, origin: self.genderTextField)
            
             return false
        }
        
        guard textField != self.dateOfBirthTextField else {
            
            ActionSheetDatePicker.show(withTitle: "Pick your birthdate",
                                       datePickerMode: UIDatePickerMode.date,
                                       selectedDate: viewModel.selectedBirthDate.value ?? NSDate().subtractingYears(20),
                                       minimumDate: NSDate().subtractingYears(999),
                                       maximumDate: NSDate().subtractingYears(18),
                                       doneBlock: { [unowned self] (_, date: Any?, _) -> Void in
                                        
                                        let d = date as! NSDate
                                        
                                        self.viewModel.selectedBirthDate.value = d as Date
                                        
                                },
                                       cancel: { _ in },
                                       origin: self)
            
            return false
        }
        
        
        
        return true
    }
    
    
    
    
}
