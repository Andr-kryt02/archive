//
//  UpsertCampView.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/3/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift

class UpsertCampView: UIView {
    
    @IBOutlet var descriptionTextView: MPTextView! {
        didSet {
            descriptionTextView.placeholderText = "Start the conversation..."
        }
    }
    
    @IBOutlet var categoryButton: UIButton!
    @IBOutlet var titleTextField: UITextField!
    @IBOutlet var commitButton: UIButton!
    
    var viewModel: UpsertCampViewModel! {
        didSet {
            guard let vm = viewModel else { return }
            
            commitButton.setTitle(vm.commitButtonTitle, for: .normal)
            commitButton.backgroundColor = vm.commitButtonColor
            
            descriptionTextView.text = vm.discardableCamp.value.topic?.text
            titleTextField.text = vm.discardableCamp.value.title
            
            viewModel.observableCamp
                .map { $0.category?.description ?? "Pick a category" }
                .bindTo(categoryButton.rx.title(for: .normal))
                .addDisposableTo(rx_disposeBag)
        }
    }
    
}

extension UpsertCampView: UITextViewDelegate {
    
    @IBAction func commitButtonTapped(_ sender: Any) {
        viewModel.commitButtonSelected()
    }
    
    func textViewDidChange(_ textView: UITextView) {
        if textView == descriptionTextView {
            viewModel.descriptionChanged(text: textView.text)
        }
    }
    
    @IBAction func titleChanged(_ sender: Any) {
        viewModel.titleChanged(text: titleTextField.text ?? "")
    }
    
    @IBAction func chooseCategory(_ sender: Any) {
        let dataSource = Camp.Category.allCategories()
        let initialIndex = dataSource.index(of: viewModel.discardableCamp.value.category ?? .club)!
        
        ActionSheetMultipleStringPicker
            .show(withTitle: "Pick the category",
                  rows: [ dataSource ],
                  initialSelection: [ initialIndex ],
                  doneBlock: { [unowned self] picker, values, indexes in
                    
                    let selectedIndex = values!.first! as! NSNumber
                    
                    let category = dataSource[selectedIndex.intValue]
                    self.viewModel.updateCategory(category: category)
                    
                }, cancel: { _ in }, origin: sender)
        
    }
}
