//
//  CampPageTableView.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/19/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Rswift
import RxDataSources

protocol CampPageTableDelegate: class {
    
    func toNextPageTriggered()
    func toPreviousPageTriggered()
    
    func userAvatarTapped (user: User)
    func reportCommentTapped (comment: Comment)
    
    func userTappedPost()
    
}

class CampPageTableView: UITableView {
    
    static func pageTableView() -> CampPageTableView {
        return R.nib.campPageTableView().instantiate(withOwner: nil, options: nil).first! as! CampPageTableView
    }
    
    weak var campDelegate: CampPageTableDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.autoresizingMask = [.flexibleHeight, .flexibleWidth]
        
        self.rowHeight = UITableViewAutomaticDimension
        self.estimatedRowHeight = 200
        
        self.register(R.nib.commentCell)
    }
    
    var viewModel: CampPageViewModel! = nil {
        
        didSet {
            
            self.dataSource = nil
            self.delegate = nil
            
            animatedDataSource.configureCell = { [unowned self] (dataSource, tableView, indexPath, item) in
                
                let cell = tableView.dequeueReusableCell(withIdentifier: R.reuseIdentifier.commentCell,
                                                         for: indexPath)!
                
                cell.viewModel = self.viewModel.commentViewModel(for: item)
                cell.commentDelegate = self
                
                return cell
                
            }
            
            ////TODO: |Vlad| there has to be better way of showing bottom of the table
            self.rx.willDisplayCell.subscribe(onNext: { [unowned self] (_) in
                
                if self.viewModel.shouldScrollToBottom {
                    self.scrollToRow(at: IndexPath(row: self.viewModel.commentsCount - 1,
                                                   section:0),
                                     at: .top,
                                     animated: false)
                }
                
            })
            .addDisposableTo(rx_disposeBag)
            
            viewModel.commentsDataSource
                .drive(self.rx.items(dataSource: animatedDataSource))
                .addDisposableTo(rx_disposeBag)
            
            ///bottom buttons binding
            viewModel.pageVariable.asDriver()
                .map { page -> String in
                    guard let p = page else { return "" }
                    return "\(p.pageNumber)"
                }
                .drive(currentPageNumberButton.rx.title(for: .normal))
                .addDisposableTo(rx_disposeBag)
            
            let nextPageNumberObservable = viewModel.pageVariable.asDriver()
                .map { page -> String? in
                    guard let next = page?.nextPageNumber else { return nil }
                    return "\(next)"
                }
            
            nextPageNumberObservable
                .drive(nextPageNumberButton.rx.title(for: .normal))
                .addDisposableTo(rx_disposeBag)
            
            nextPageNumberObservable
                .map { $0 == nil }
                .drive(toNextPageButton.rx.isHidden)
                .addDisposableTo(rx_disposeBag)
            
            let previousPageNumberObservable = viewModel.pageVariable.asDriver()
                .map { page -> String? in
                    guard let next = page?.previousPageNumber else { return nil }
                    return "\(next)"
            }
            
            previousPageNumberObservable
                .drive(previousPageNumberButton.rx.title(for: .normal))
                .addDisposableTo(rx_disposeBag)
            
            previousPageNumberObservable
                .map { $0 == nil }
                .drive(toPreviousPageButton.rx.isHidden)
                .addDisposableTo(rx_disposeBag)
            
        }
        
    }
    
    internal let animatedDataSource: RxTableViewSectionedAnimatedDataSource<AnimatableSectionModel<String, Comment>> = RxTableViewSectionedAnimatedDataSource()
 
    
    @IBOutlet weak var toNextPageButton: UIButton!
    @IBOutlet weak var toPreviousPageButton: UIButton!
    @IBOutlet weak var nextPageNumberButton: UIButton!
    @IBOutlet weak var previousPageNumberButton: UIButton!
    @IBOutlet weak var currentPageNumberButton: UIButton!
    
}

extension CampPageTableView : CommentCellDelegate {
    
    @IBAction func nextPageTapped(_ sender: Any) {
        campDelegate?.toNextPageTriggered()
    }
    
    @IBAction func previousPageTapped(_ sender: Any) {
        campDelegate?.toPreviousPageTriggered()
    }
    
    func commentCellDidTapAvatar(cell: CommentCell) {
        
        let ip = self.indexPath(for: cell)!
        let author = viewModel.commentAuthor(at: ip)
        campDelegate?.userAvatarTapped(user: author)
        
    }
    
    func commentCellDidReport(cell: CommentCell) {
        
        let ip = self.indexPath(for: cell)!
        let comment = viewModel.comment(at: ip)
        campDelegate?.reportCommentTapped(comment: comment)
        
    }
    
    @IBAction func postTapped(_ sender: Any) {
        campDelegate?.userTappedPost()
    }
    
}
