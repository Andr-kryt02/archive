//
//  CampTableCell.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/16/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import UIKit
import RxSwift

class CampTableCell: UITableViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var categoryLabel: UILabel! {
        didSet {
            categoryLabel.font = UIFont.appLightItalicPrimaryFont(size: 12)
        }
    }
    @IBOutlet weak var dateLabel: UILabel!{
        didSet {
            dateLabel.font = UIFont.appLightItalicPrimaryFont(size: 12)
        }
    }
    
    func set(camp: Camp) {
        
        guard let o = camp.observableEntity()?.asDriver() else {
            fatalError("Can't work with camps that are not in the storage")
        }
        
        o.map { $0.title }
            .drive(nameLabel.rx.text)
            .addDisposableTo(rx_disposeBag)
        
        o.map { $0.category?.description ?? "No category" }
            .drive(categoryLabel.rx.text)
            .addDisposableTo(rx_disposeBag)
        
        dateLabel.text = camp.lastActivityDate.campfiireString
        
    }
    
}
