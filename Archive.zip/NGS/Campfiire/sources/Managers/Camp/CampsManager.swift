//
//  CampsManager.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/17/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire

extension Camp {
    
    static func list(query: String?, followedOnly: Bool, batch: Batch) -> Observable<[Camp]> {
        
        let request = CampRouter.list(query: query,
                                      followedOnly: followedOnly,
                                      batch: batch)
        
        return Alamofire.request(request)
                    .rx_campfiireResponse(CampfiireArrayResponse<Camp>.self)
                    .map { items in
                        items.forEach { $0.saveEntity() }
                        return items
                    }
        
        ///uncomment to fake data
        
//        guard batch.offset < 30 else { return Observable.just([]) }
//        
//        var fakes: [Camp] = []
//        for _ in 0...batch.limit {
//            
//            let c = Camp.fakeEntity()
//            c.saveEntity()
//            
//            fakes.append( c )
//        }
//        
//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
//                observer.onNext(fakes)
//                observer.onCompleted()
//            }
//            
//            return Disposables.create()
//        })
        
    }
    
    static func topRated(batch: Batch? = nil) -> Observable<[Camp]>{
        
        let request = CampRouter.top(batch: batch)
    
        return Alamofire.request(request)
            .rx_campfiireResponse(CampfiireArrayResponse<Camp>.self)
            .map { items in
                items.forEach { $0.saveEntity() }
                return items
        }
        
        ///uncomment to fake data
        
//        guard batch.offset < 30 else { return Observable.just([]) }
//
//        var fakes: [Camp] = []
//        for _ in 0...batch.limit {
//
//            let c = Camp.fakeEntity()
//            c.saveEntity()
//
//            fakes.append( c )
//        }
//
//        return Observable.create({ (observer) -> Disposable in
//
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
//                observer.onNext(fakes)
//                observer.onCompleted()
//            }
//
//            return Disposables.create()
//        })
        
    }
    
    func upsert() -> Observable<Camp> {
        
        let shouldCreate = self.id == 0
        
        let rout: CampRouter = shouldCreate ? .create(camp: self) : .update(camp: self)
        
        return Alamofire.request(rout)
            .rx_campfiireResponse(CampfiireResponse<Camp>.self)
            .map { camp in
                camp.saveEntity()
                return camp
            }

        ////uncomment to fake data
        
//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
//                
//                camp.saveEntity()
//                
//                observer.onNext(camp)
//                observer.onCompleted()
//            }
//            
//            return Disposables.create()
//        })
        
    }
 
    func delete() -> Observable<Void> {
        
        return Alamofire.request(CampRouter.delete(camp: self))
            .rx_campfiireResponse(CampfiireEmptyResponse.self)
            .do(onCompleted: {
                self.removeFromStorage()
            })
        
        
        ////uncomment to fake data
        
//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
//                
//                camp.removeFromStorage()
//                
//                observer.onNext( () )
//                observer.onCompleted()
//            }
//            
//            return Disposables.create()
//        })
        
    }
    
    func details() -> Observable<Camp> {
        
        return Alamofire.request(CampRouter.details(camp: self))
            .rx_campfiireResponse(CampfiireResponse<Camp>.self)
            .map { camp in
                
                camp.saveEntity()
                
                return camp
            }
        
        ////uncomment to fake data
//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
//                
//                var c = self
//                
//                c.populateDetails()
//                
//                c.saveEntity()
//                
//                observer.onNext( c )
//                observer.onCompleted()
//            }
//            
//            return Disposables.create()
//        })
        
    }
    
    ////TODO: |ANY| very low. Potentially we can process multiple consequent page requests via 1 netwrok request
    ////like pages 1,2,3 can be requested as batch 0, 15 and splitted in 3 pages
    ////instead of three requests for 0,5; 5,5; 10,5;
    func page(_ number: Int) -> Observable<CampPage> {
        
        let pageBuilder = CampPageBuilder(camp: self)
        
        guard let batch = pageBuilder.networkBatch(for: number) else {
            return Observable.just(pageBuilder.campPage(at: number, comments: []))
        }
        
        let rout = CampRouter.commentsList(camp: self,
                                           batch: batch)
        
        return Alamofire.request(rout)
                .rx_campfiireResponse(CampfiireArrayResponse<Comment>.self)
                .map {
                    pageBuilder.campPage(at: number,
                                         comments: $0)
                }

        ////uncomment for fake data
//        
//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
//                
//                let comments =
//                [Comment.fakeEntity(picturesPossible: true),
//                 Comment.fakeEntity(picturesPossible: true),
//                 Comment.fakeEntity(picturesPossible: true),
//                 Comment.fakeEntity(picturesPossible: true),
//                 Comment.fakeEntity(picturesPossible: true)]
//                
//                let fakePage = pageBuilder.campPage(at: number,
//                                                    comments: comments)
//                
//                observer.onNext( fakePage )
//                observer.onCompleted()
//            }
//            
//            return Disposables.create()
//        })
        
    }
    
    func post(text: String, image: UIImage?) -> Observable<Comment> {

        if image != nil { print ("CampsManager is incapable of posting coments with pictures") }
        
        let rout = CampRouter.postComment(camp: self, text: text)
        
        return Alamofire.request(rout)
            .rx_campfiireResponse(CampfiireResponse<Comment>.self)
        

        ///uncomment for fake data 
        
//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
//                
//                var fakeComment = Comment.fakeEntity()
//                
//                fakeComment.text = text
//                fakeComment.pictureURL = nil
//                fakeComment.date = Date()
//                fakeComment.author = User.currentUser()!
//                
//                if let i = image {
//                    let key = Comment.fakeString()
//                    ImageRetreiver.registerImage(image: i, forKey: key)
//                    fakeComment.pictureURL = key
//                }
//                
//                
//                observer.onNext( fakeComment )
//                observer.onCompleted()
//            }
//            
//            return Disposables.create()
//        })
        
    }
    
    
    
    func reportCamp() -> Observable<Report> {
        
        return Alamofire.request(CampRouter.reportCamp(camp: self))
            .rx_campfiireResponse(CampfiireResponse<Report>.self)
        }
    
    
    
    static func reportCampMessage(comment : Comment) -> Observable<Report> {
        
        return Alamofire.request(CampRouter.reportMessage(comment: comment))
            .rx_campfiireResponse(CampfiireResponse<Report>.self)
    }

    
    
    
    
}

extension Camp : TopRatedListProvider {
    
    typealias DataType = Camp

    static var top10List: Observable<[Camp]> {
        
        return Alamofire.request( CampRouter.top(batch: nil) )
            .rx_campfiireResponse(CampfiireArrayResponse<Camp>.self)
            .map { camps in
                camps.forEach { $0.saveEntity() }
                return camps
        }

        
//        var fakes: [Camp] = []
//        for _ in 1...10 {
//            
//            let c = Camp.fakeEntity()
//            c.saveEntity()
//            
//            fakes.append( c )
//        }
//        
//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
//                observer.onNext(fakes)
//                observer.onCompleted()
//            }
//            
//            return Disposables.create()
//        })
        
    }
    
}
