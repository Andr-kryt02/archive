//
//  MMJManager.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 2016-12-19.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire

extension MMJ {
    
    static func retrieveWebNews(batch: Batch) -> Observable<[MMJ]> {
        
        //uncomment to real data
        
                let request = SimpleRouter.mmj(batch: batch)
        
                return Alamofire.request(request)
                    .rx_campfiireResponse(CampfiireArrayResponse<MMJ>.self)
                    .map { items in
                        items.forEach { $0.saveEntity() }
                        return items
                }
        
        ///uncomment to fake data
        
//        guard batch.offset < 30 else { return Observable.just([]) }
//        
//        var fakes: [MMJ] = []
//        for _ in 1...batch.limit {
//            let c = MMJ.fakeEntity()
//            c.saveEntity()
//            
//            fakes.append( c )
//        }
//        
//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
//                observer.onNext(fakes)
//                observer.onCompleted()
//            }
//            
//            return Disposables.create()
//        })
        
    }
    
    
    
}


extension InfoSource {



 static func retriewSources (query: String?, batch: Batch) -> Observable<[InfoSource]> {
    
     let request = SimpleRouter.infoSource
    
            return Alamofire.request(request)
                .rx_campfiireResponse(CampfiireArrayResponse<InfoSource>.self)
    
//    ///uncomment to fake data
//    
//    guard batch.offset < 30 else { return Observable.just([]) }
//    
//    var fakes: [InfoSource] = []
//    for _ in 1...batch.limit {
//        let c = InfoSource.fakeEntity()
//        c.saveEntity()
//        
//        fakes.append( c )
//    }
//    
//    return Observable.create({ (observer) -> Disposable in
//        
//        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
//            observer.onNext(fakes)
//            observer.onCompleted()
//        }
//        
//        return Disposables.create()
//    })
    
    }
    
    
    
}

extension Video {
    
    static func retrieveVideos() -> Observable<[Video]> {
        
        ///uncomment to real data
        
        let request = SimpleRouter.video
        
                return Alamofire.request(request)
                    .rx_campfiireResponse(CampfiireArrayResponse<Video>.self)
                    .map { items in
                        items.forEach { $0.saveEntity() }
                        return items
                }
        
        ///uncomment to fake data
        
//        guard batch.offset < 30 else { return Observable.just([]) }
//        
//        var fakes: [Video] = []
//        for _ in 1...batch.limit {
//            let c = Video.fakeEntity()
//            c.saveEntity()
//            
//            fakes.append( c )
//        }
//        
//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
//                observer.onNext(fakes)
//                observer.onCompleted()
//            }
//            
//            return Disposables.create()
//        })
//        
//    }
//    
    
    
}

}

