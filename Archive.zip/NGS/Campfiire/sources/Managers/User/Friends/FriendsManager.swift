//
//  FriendsManager.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/31/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import RxSwift
import Alamofire

import Alamofire

enum FriendsManager {}
extension FriendsManager {
    
    static func friendScreenList(query: String?) -> Observable<[FriendListTableItem]> {
        
        ////on query nil or "" should return full list
        
        ///friends
        let filter = SearchUsersFilter(query: query,
                                       ageRange: nil,
                                       gender: nil,
                                       location: nil,
                                       tag: nil)
        let friendsSignal = Alamofire
            .request( SearchRouter.friends(searchFilter: filter) )
            .rx_campfiireResponse(CampfiireArrayResponse<User>.self)
            .map { frineds -> [FriendListTableItem] in
                return frineds.map { .friend( user: $0 ) }
            }
        
        ////invites
        
        let invitesSignal = Alamofire.request(UserRelationRouter.invitesList)
            .rx_campfiireResponse(CampfiireArrayResponse<FriendsInvitesResponse>.self)
            .map { invites -> [FriendListTableItem] in
                return invites.flatMap { $0.senderUser }
                    .map { .request ( user: $0 ) }
            }
        
        ///compound
        return Observable.combineLatest(friendsSignal, invitesSignal) { $1 + $0 } ///invites first, friends - second
        
        ///uncomment to use fake friends, requests
        
//        
//        var friends: [FriendListTableItem] = []
//        for _ in 0...User.fakeNumber(bound: 6) {
//            friends.append( .friend( user: User.fakeEntity() ) )
//        }
//        
//        var request: [FriendListTableItem] = []
//        for _ in 0...User.fakeNumber(bound: 3) {
//            request.append( .request( user: User.fakeEntity() ) )
//        }
//        
//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
//                observer.onNext( request + friends )
//                observer.onCompleted()
//            }
//            
//            return Disposables.create()
//        })
        
    }
    
    static func removeFriend(user: User) -> Observable<User> {

        return Alamofire
            .request( UserRelationRouter.deleteInvite(user: user) )
            .rx_campfiireResponse(CampfiireResponse<User>.self)
            .map { user in
                
                user.saveEntity()
                
                return user
            }
        
    }
    
    static func createFriendRequest(to user: User) -> Observable<User> {
        
        return Alamofire
            .request( UserRelationRouter.createInvite(user: user) )
            .rx_campfiireResponse(CampfiireResponse<User>.self)
            .map { user in
                
                user.saveEntity()
                
                return user
            }
        
    }
    
    static func block(user: User) -> Observable<User> {
        
        return Alamofire.request(UserRelationRouter.blockUser(user: user))
            .rx_campfiireResponse(CampfiireResponse<User>.self)
            .map {
                $0.saveEntity()
                return $0
            }
        
    }
    
    static func unblock(user: User) -> Observable<User> {

        return Alamofire.request(UserRelationRouter.unblockUser(user: user))
            .rx_campfiireResponse(CampfiireResponse<User>.self)
            .map {
                $0.saveEntity()
                return $0
            }
 
    }
}
