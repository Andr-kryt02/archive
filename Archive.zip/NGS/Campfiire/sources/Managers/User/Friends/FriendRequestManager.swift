//
//  FriendRequestManager.swift
//  Campfiire
//
//  Created by Vlad Soroka on 1/9/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire

enum FriendRequestManager {}
extension FriendRequestManager {
    
    static let requestsCount = Variable(0)
    
    static func refreshRequestsCount() {
        
        let _ =
            FriendsManager.friendScreenList(query: nil)
                .map { items in
                    items.reduce(0) { (aggregator, item) -> Int in
                        var sum = aggregator
                        if case .request(_) = item { sum += 1 }
                        return sum
                    }
                }
                .bindTo(requestsCount)
        
    }
    
    static func rejectRequest(from user: User) -> Observable<Void> {
        
        let count = requestsCount.value
        requestsCount.value = count - 1

        return Alamofire
            .request( UserRelationRouter.deleteInvite(user: user) )
            .rx_campfiireResponse(CampfiireResponse<User>.self)
            .map { user in
                user.saveEntity()
                
                return ()
        }
        
    }
    
    static func acceptRequest(from user: User) -> Observable<Void> {
        
        let count = requestsCount.value
        requestsCount.value = count - 1
        
        return Alamofire
            .request( UserRelationRouter.createInvite(user: user) )
            .rx_campfiireResponse(CampfiireResponse<User>.self)
            .map { user in
                
                user.saveEntity()
                
                return ()
        }
        
    }
    
}
