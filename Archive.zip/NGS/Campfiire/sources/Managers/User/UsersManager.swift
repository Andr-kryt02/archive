//
//  UsersManager.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/19/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire

enum UsersManager {}

extension UsersManager {
    
    static func mostRecentUserData(user: User) -> Observable<User> {
        
        ////currently our backend provider does not let current user to obtain email when requesting self details
        ////so we will have to rely on fact, that current user uses only one device
        if let currentUser = User.currentUser(),
            currentUser == user {
            return Observable.just(currentUser)
        }
        
        
        let updateRout = UserDetailsRouter.details(user: user)
        
        ///we don't really need to update every single user espacially when it's already properly populated
        ////let's update user always for now unless he is current User.
        
        return Alamofire.request(updateRout)
                .rx_campfiireResponse(CampfiireResponse<User>.self)
                .do(onNext: { (user) in
                
                        user.saveEntity()

                })
    }
    
    /**
     *  @discussion: updates user on server and ensures new entity is properly saved locally
     *  @returns newly saved user
     */
    static func updateUser(withData data: User?, avatar: UIImage?) -> Observable<User> {

        var updateSignal: Observable<User?> = Observable.just(nil)
        var uploadAvatarSignal: Observable<AvatarUpdateResponse?> = Observable.just(nil)
        
        if let user = data {
            
            ////sanity check
            guard let currentUserId = User.currentUser()?.id ,
                  currentUserId == user.id else {
                    fatalError("Can't update user that is not currently logged in")
            }
            
            updateSignal = Alamofire
                .request( UserDetailsRouter.update(user: user) )
                .rx_campfiireResponse(CampfiireResponse<User>.self)
                .map { $0 as User? }
            
        }
        
        if let a = avatar {
            
            let data = UIImageJPEGRepresentation(a, 1)!
            
            uploadAvatarSignal = Campfiire
                .rx_upload(rout: UserDetailsRouter.updateAvatar, data: [ "file" : data ])
                .flatMap { $0.rx_campfiireResponse(CampfiireResponse<AvatarUpdateResponse>.self) }
                .map { $0 as AvatarUpdateResponse? }
            
        }
        
        return Observable
            .combineLatest(updateSignal, uploadAvatarSignal) { (maybeUser, maybeAvatar) in
         
                var user = maybeUser ?? User.currentUser()!
            
                if let ava = maybeAvatar?.url {
                    user.pictureURL = ava
                }
                
                user.becomeCurrent()
                
                return user
            }
        
        ////uncomment to fake comunication
        
//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
//
//                observer.onNext(data!)
//                observer.onCompleted()
//            }
//            
//            return Disposables.create()
//        })
        
        

    }

    /*!
     * @discussion Method returns details of passed users suitable for presenting them in some collection
     * Particulary user fills names and pictures of users. All of the users will be stored in User storage
     * @param users - array of Users that should have at least id set up properly
     * @seealso - User.init(id: Int)
     * @return Signal of filled users
     */
    static func listDetails(of users: [User]) -> Observable<[User]> {
        
        let usersToRefresh = users.filter { $0.refreshedEntity() == nil }
        
        guard usersToRefresh.count > 0 else { return Observable.just(users) }
        
        return Observable.just( usersToRefresh.map { u in
            var a = User.fakeEntity()
            a.id = u.id
            a.saveEntity()
            return a
        } )

        ///TODO: set up proper rout
        
//        let rout = UserDetailsRouter.details(user: User(id: 0))
//        
//        return Alamofire.request(rout)
//            .rx_campfiireResponse(CampfiireArrayResponse<User>.self)
//            .map { users in
//                
//                users.forEach { $0.saveEntity() }
//                
//                return users
//            }
        
    }
    
}
