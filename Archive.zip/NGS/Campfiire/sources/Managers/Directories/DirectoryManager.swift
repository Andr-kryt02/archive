//
//  EntityManager.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 30.11.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import MapKit
import Alamofire
import ObjectMapper

enum DirectoryManager <T: DirectoryManagableType> {}
extension DirectoryManager {
    
    static func entitiesFor (query : String?, batch: Batch) -> Observable<[T]> {

//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
//                
//                var res: [T] = []
//                if batch.limit < 40 {
//                    for _ in 0...batch.limit {
//                        res.append(T.fakeEntity())
//                    }
//                }
//                
//                observer.onNext(res)
//                observer.onCompleted()
//            }
//            
//            return Disposables.create()
//        })
//        
//        
        let rout = T.listRout(query: query, batch: batch)
        
        return Alamofire.request(rout)
            .rx_campfiireResponse(CampfiireArrayResponse<T>.self)
        
    }
    
    static func mapFor (region: MKCoordinateRegion,
                        query : String?) -> Observable<[T]> {
    
//            return Observable.create({ (observer) -> Disposable in
//                
//                DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
//                    
//                    var res: [T] = []
//                    for _ in 0...10 {
//                        res.append(T.fakeEntity())
//                    }
//                    
//                    observer.onNext(res)
//                    observer.onCompleted()
//                }
//                
//                return Disposables.create()
//            })
        
        ///treating empty strings as nils
        var q = query
        if let unwrapped = query,
            unwrapped.lengthOfBytes(using: .utf8) == 0 {
            q = nil
        }
        
        let rout = T.mapRout(query: q, region: region)
        
        return Alamofire.request(rout)
            .rx_campfiireResponse(CampfiireArrayResponse<T>.self)
        
    }
    
}

extension DirectoryManager {
    
    static func details (of item: T) -> Observable<T> {
    
//            return Observable.create({ (observer) -> Disposable in
//                
//                DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
//                    
//                    observer.onNext(T.fakeEntity())
//                    observer.onCompleted()
//                }
//                
//                return Disposables.create()
//            })
//            
        
        let rout = item.detailsRout
        
        return Alamofire.request(rout)
            .rx_campfiireResponse(CampfiireResponse<T>.self)
        
    }
    
    
    static func top (batch: Batch? = nil) -> Observable<[T]> {
        
        return Observable.create({ (observer) -> Disposable in
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                
                var res: [T] = []
                for _ in 0...10 {
                    res.append(T.fakeEntity())
                }
                
                observer.onNext(res)
                observer.onCompleted()
            }
            
            return Disposables.create()
        })
        
//        let rout = T.topRatedRout(batch: batch)
//
//        return Alamofire.request(rout)
//            .rx_campfiireResponse(CampfiireArrayResponse<T>.self)
        
    }
}
