//
//  SettingsManager.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/25/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire

enum ProfileVisibility: String {
    
    case nobody = "friends"
    case friendsOnly = "nobody"
    case allUsers = "all"
    
}

struct SettingsManager {
    
    let pushEnabled: Setting<Bool>
        = Setting(key: "com.campfiire.settings.push",
                  initialValue: true)
    
    let showEventsInFeed: Setting<Bool>
        = Setting(key: "com.campfiire.settings.eventsInFeed",
                  initialValue: true)
    
    let attachmentsInCellular: Setting<Bool>
        = Setting(key: "com.campfiire.settings.attachmentsInCellular",
                  initialValue: false)

    let timeFormat24: Setting<Bool>
        = Setting(key: "com.campfiire.settings.timeFormat24",
                  initialValue: true)

    let profileVisibility: Setting<ProfileVisibility>
        = Setting(key: "com.campfiire.settings.profileVisibility.v2",
                  initialValue: .allUsers)
    
    init() {

        Observable.combineLatest(
            pushEnabled.observable,
            showEventsInFeed.observable,
            attachmentsInCellular.observable,
            timeFormat24.observable,
            profileVisibility.observable) {
                SettingsResponse(push: $0, showEvent: $1, attachment: $2, time24: $3, visibility: $4 )
            }
            .skip(1)
            .debounce(0.3, scheduler: MainScheduler.instance)
            .distinctUntilChanged()
            .flatMapLatest { (input) -> Observable<Void> in
                
                let rout = SettingsRouter.send(settings: input)
                
                return Alamofire.request(rout)
                    .rx_campfiireResponse(CampfiireEmptyResponse.self)
            }
            .subscribe( onNext: { _ in
                ///as of now we don't really care what was the outcome of operation
                ///is it failed or not
            })
            .addDisposableTo(bag)
    }
    
    private let bag = DisposeBag()
    
}


extension ProfileVisibility : UserDefaultsStorable {
    
    func store(for key: String) {
        UserDefaults.standard.set(self.rawValue, forKey: key)
    }
    
    init?(key: String) {
        
        guard let value = UserDefaults.standard.object(forKey: key) as? String else { return nil }
        
        self.init (rawValue: value)
        
    }
}
