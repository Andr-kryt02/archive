//
//  AuthorizationManager.swift
//  GlobBar
//
//  Created by Vlad Soroka on 5/19/16.
//  Copyright © 2016 com.NightLife. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire

enum AuthorizationManager { }
extension AuthorizationManager {
    
    static func loginWith(data: AuthenticationData) -> Observable<UserLoginResponse> {
        
        var authSignal: Observable<UserLoginResponse>! = nil
        var postAuthenticationAction: ( (UserLoginResponse) -> Observable<UserLoginResponse> ) = { Observable.just($0) }
        
        switch data {
        case .credentials(let creds):
            
            authSignal = Alamofire.request(UserAuthorizationRouter.logIn(email: creds.email,
                                                                   password: creds.password))
                .rx_campfiireResponse(CampfiireResponse<UserLoginResponse>.self)
            
        case .external(let data):
            
            authSignal = Alamofire.request(UserAuthorizationRouter.social(data: data))
                .rx_campfiireResponse(CampfiireResponse<UserLoginResponse>.self)
            
        case .register(let registrationData):
            
            ///server decided that upon registration we should not receive the token
            ///so we need to have another roundtrip to server to get it
            
            authSignal = Alamofire.request(UserAuthorizationRouter.registration(user: registrationData))
                .rx_campfiireResponse(CampfiireResponse<UserLoginResponse>.self)
                .flatMap { _ -> Observable<UserLoginResponse> in
                    
                    let loginRout = UserAuthorizationRouter.logIn(email: registrationData.email,
                                                                  password: registrationData.password)
                    
                    return Alamofire.request(loginRout)
                        .rx_campfiireResponse(CampfiireResponse<UserLoginResponse>.self)
                }
            
            guard let path = registrationData.tempImageURL,
                  let avatar = ImageRetreiver.cachedImageForKey(key: path) else {
                    break;
            }
            
            postAuthenticationAction = { x in UsersManager.updateUser(withData: nil, avatar: avatar).map { _ in x } }
            
            
//        default:
//            authSignal = Observable.create({ (observer) -> Disposable in
//                
//                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
//                    
//                    var fakeResponse = UserLoginResponse(JSON: [:])!
//                    fakeResponse.token = "👻 I'm Not a Token 👻"
//                    fakeResponse.user = User.fakeEntity()
//                    
//                    observer.onNext(fakeResponse)
//                    observer.onCompleted()
//                }
//                
//                return Disposables.create()
//            })
        }
        
        return authSignal  //// 1. obtain authorization token
            .map{ response in
            
                ///2. store token and set new current user
                
                AccessToken.token = response.token!
                let user = response.user!
                
                user.becomeCurrent()
                
                return response
            }
            .flatMap { (response) -> Observable<UserLoginResponse> in
                
                ///3. registering with in chat service if neccessary
                
                return Alamofire.request(UserAuthorizationRouter.chatRegistration)
                            .rx_campfiireResponse(CampfiireEmptyResponse.self)
                            .catchError { (error) -> Observable<Void> in

                                ///user already registered message is sufficient for us
                                ///we need to make sure that user is up and running after authorization
                                
                                if let e = error as? CampfiireError,
                                   case .businessError(let code, _) = e,
                                   code == CampfiireErrorStatusCode.userAlreadyRegisteredWithinChatService.rawValue {
                                    
                                    return Observable.just()
                                }
                                
                                return Observable.error(error)
                            }
                            .map { _ in response }
            }
            ///4. perform any user defined actions after authentication is complete
            .flatMap(postAuthenticationAction)
    }
    
    static func passwordRecover(email : String) -> Observable<Void> {
        
        return Alamofire.request(UserAuthorizationRouter.paswordRecover(email: email))
            .rx_campfiireResponse(CampfiireEmptyResponse.self)
        
    }

//    static func currentUserDetails() -> Observable<[String : AnyObject]> {
//        
//        return Alamofire.Manager.sharedInstance
//            .rx_request(UserRouter.Info(userId: nil))
//            .flatMap { $0.rx_responseJSON() }
//            .map { responce -> [String : AnyObject] in
//                
//                guard let rootJSON = responce.1["user"] as? [String : AnyObject] else {
//                    fatalError("error recognizing server response structure")
//                }
//                
//                return rootJSON
//        }
//
//        
//    }
    
}
