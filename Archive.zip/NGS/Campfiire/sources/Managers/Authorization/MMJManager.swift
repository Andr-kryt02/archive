//
//  MMJManager.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 12.12.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

import RxSwift
import Alamofire
import ObjectMapper

enum MMJManager {}
extension MMJManager {
    
    static func retrieveWebNews (batch: Batch) -> Observable<[MMJ]> {
        
        return Observable.create({ (observer) -> Disposable in
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                
                var res: [MMJ] = []
                if batch.limit < 40 {
                    for _ in 0...batch.limit {
                        res.append(MMJ.fakeEntity())
                    }
                }
                
                observer.onNext(res)
                observer.onCompleted()
            }
            
            return Disposables.create()
        })

}
}
