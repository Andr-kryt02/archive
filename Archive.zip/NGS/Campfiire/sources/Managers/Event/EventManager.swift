//
//  EventManager.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/1/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire

enum EventManager {}

extension EventManager {
    
    public static func details (of event : Event) -> Observable<Event> {
        
        let request = EventRouter.details(event: event)
        
        return Alamofire
            .request(request)
            .rx_campfiireResponse(CampfiireResponse<Campfiire.Event>.self)
        
    }
    
    public static func monthHighlightDates() -> Observable<[Date]> {
        
        let request = EventRouter.monthEvents(date: Date() )
        
        return Alamofire
            .request(request)
            .rx_campfiireResponse(CampfiireArrayResponse<Event.EventTimeStamp>.self)
            .map { $0.map { $0.date } }
        
    }
}
