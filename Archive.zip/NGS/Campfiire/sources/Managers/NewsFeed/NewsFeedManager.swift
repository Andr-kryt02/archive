//
//  NewsFeedManager.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/13/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire

enum NewsFeedManager {}
extension NewsFeedManager {
    
    static func feed(for batch:NewsFeedViewModel.NewsProvider.State) -> Observable<[NewsFeedTypes]> {

//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
//                
//                var response:[NewsFeedTypes] = []
//                for _ in 0...5 {
//                    response.append(NewsFeedTypes.fakeEntity())
//                }
//                
//                observer.onNext( response )
//                observer.onCompleted()
//            }
//            
//            return Disposables.create()
//        })
       
        let rout = NewsFeedRouter.feed(batch: batch)
        return Alamofire
            .request(rout)
            .rx_campfiireResponse(CampfiireArrayResponse<NewsFeedProxyObject>.self)
            .map { proxies in
                return proxies.flatMap { try? $0.newsFeedItem() }
            }
        
    }
    
    static func userPhotos(friendsPhotos: Bool, for batch: Batch) -> Observable<[UserPhoto]> {
        
        let request = UserPhotoRouter.list(friendsPhotos: friendsPhotos, batch: batch)
        
        return Alamofire.request(request)
            .rx_campfiireResponse(CampfiireArrayResponse<Photo>.self)
            .map { photos in
                photos.map { UserPhoto(photo: $0) }
            }
        
        ///uncomment for fake photos
        
//        guard batch.offset < 10 else { return Observable.just([]) }
//        
//        var fakePhotos: [Photo] = []
//        for _ in 0...batch.limit / 2 {
//            
//            var fakePhoto = Photo.fakeEntity()
//            if !friendsPhotos {
//                fakePhoto.author = User.currentUser()!
//            }
//            
//            fakePhotos.append( fakePhoto )
//        }
//        
//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
//                observer.onNext( fakePhotos.map { UserPhoto(photo: $0) } )
//                observer.onCompleted()
//            }
//            
//            return Disposables.create()
//        })

        
    }
 
    static func postUserPhoto(image: UIImage) -> Observable<UserPhoto> {
        
        let request = UserPhotoRouter.create
        let data = UIImageJPEGRepresentation(image, 1)!

        return rx_upload(rout: request, data: [ "photo" :  data ])
            .flatMap { $0.rx_campfiireResponse(CampfiireResponse<Photo>.self) }
//        return Observable.create({ (observer) -> Disposable in
//            
//                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
//                
//                    observer.onNext( Photo.fakeEntity() )
//                    observer.onCompleted()
//                }
//            
//                return Disposables.create()
//            })
            .do(onNext: { (photo) in
                ImageRetreiver.registerImage(image: image, forKey: photo.pictureURL)
            })
            .map { UserPhoto(photo: $0) }
        
    }
    
    static func deleteUserPhoto(photo: UserPhoto) -> Observable<Void> {
        
        return Alamofire.request(UserPhotoRouter.delete(photo: photo.photo))
                .rx_campfiireResponse(CampfiireEmptyResponse.self)
        
//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
//                
//                observer.onNext(  )
//                observer.onCompleted()
//            }
//            
//            return Disposables.create()
//        })
            .do(onNext: { _ in
                ImageRetreiver.flushImageForKey(key: photo.photo.pictureURL)
            })
        
        
    }
    
}
