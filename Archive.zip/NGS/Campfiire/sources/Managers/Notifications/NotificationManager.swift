//
//  NotificationManager.swift
//  Night Life
//
//  Created by Vlad Soroka on 3/29/16.
//  Copyright © 2016 com.NightLife. All rights reserved.
//

import UIKit
import Alamofire
import ObjectMapper

enum NotificationError : Error {
    case NoAuthorizedUser
    case NoTokenStored
}

enum NotificationManager {}
extension NotificationManager {

    private static let deviceTokenKey = "com.campfiire.deviceTokenKey"
    
    static func setup(launchOptions: [UIApplicationLaunchOptionsKey: Any]?) {
        
        let notificationSettings = UIUserNotificationSettings(types: [.alert, .sound], categories: nil)
        UIApplication.shared.registerUserNotificationSettings(notificationSettings)
        
        if UserDefaults.standard.object(forKey: deviceTokenKey) == nil {
            UIApplication.shared.registerForRemoteNotifications()
        }
        
        if let remoteNotificationPayload = launchOptions?[UIApplicationLaunchOptionsKey.remoteNotification] as? [AnyHashable : Any]
        {
            self.handleRemoteNotification(notificationPayload: remoteNotificationPayload,
                                          applicationState: .inactive)
        }
        
    }
    
    static func handleDeviceToken(tokenData: Data) {
        
        UserDefaults.standard.set(tokenData, forKey: deviceTokenKey)
        UserDefaults.standard.synchronize()
        
        do { try saveDeviceToken() }
        catch { print("Can't save token now. Will try later") }
        
    }
    
    static func saveDeviceToken() throws {
        
        guard let _ = AccessToken.token else {
            throw NotificationError.NoAuthorizedUser
        }
        
        guard let token = UserDefaults.standard.object(forKey: deviceTokenKey) as? Data else {
            throw NotificationError.NoTokenStored
        }
        
        Alamofire.request(SettingsRouter.linkDeviceToken(deviceToken: token))
            .responseJSON { response in
                print(response.result.value as Any)
            }
        
    }
    
    static func flushDeviceToken() {
        
        Alamofire.request(SettingsRouter.unLinkDeviceToken)
            .responseJSON { response in
                print(response.result.value as Any)
        }
        
    }
    
}

extension NotificationManager {
    
    static func handleRemoteNotification(notificationPayload: [AnyHashable : Any],
                                         applicationState: UIApplicationState) {
        
        guard let notification = Mapper<RemoteNotification>()
            .map(JSON: notificationPayload as! [String : Any]),
            let item = notification.data.item else {
                
                assert(false, "Error retreiving notification type from \(notificationPayload)")
                return
        }
        
        ///if app was active when notification arrived we'll present popup with alert string
        let verificationMessage: String? = applicationState == .active ? notification.payload.message : nil
        
        MainViewModel.shared.router.routForNotification(notification: item,
                                                        verificationMessage: verificationMessage)
        
    }
    
}
