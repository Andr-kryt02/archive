//
//  SearchManager.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 01.11.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

import Alamofire
import RxSwift
import CoreLocation
import AddressBookUI

enum LocationSearchManager { }
extension LocationSearchManager {
    
    static func retreiveAppropriateLocation(location : String) -> Observable<[SearchLocation]> {

        return Observable.create { (observer) -> Disposable in
            
            let geocoder = CLGeocoder()

            geocoder.geocodeAddressString(location, completionHandler: { (maybePlacemarks, maybeError) in
                guard maybeError == nil else {
                    observer.onError(maybeError!)
                    return
                }
                
                var results: [SearchLocation] = []
                
                if let placemark = maybePlacemarks?.first {
                    results.append(SearchLocation(county: placemark.country ?? "",
                                                  city: placemark.locality ?? ""))
                }
                
                if let c = maybePlacemarks?.count, c > 1 {
                   let placemark = maybePlacemarks![1]
                    results.append(SearchLocation(county: placemark.country ?? "",
                                                  city: placemark.locality ?? ""))
                }
                
                observer.onNext(results)
                observer.onCompleted()
                
            })
            
            return Disposables.create { geocoder.cancelGeocode() }
        }
        
    }

    static func retreiveAdressFor(location: CLLocation) -> Observable<String> {
        return Observable.create { (observer) -> Disposable in
            
            let geocoder = CLGeocoder()
            
            geocoder.reverseGeocodeLocation(location) { (placemarks: [CLPlacemark]?, maybeError) in
                
                guard maybeError == nil else {
                    observer.onError(maybeError!)
                    return
                }
                
                if let placemark = placemarks?.first {
                    
                    var addressString = ABCreateStringWithAddressDictionary(placemark.addressDictionary!, true)
                    addressString = addressString.replacingOccurrences(of: "\n", with: ", ")
                    observer.onNext(addressString)
                    
                }
                observer.onCompleted()
                
                
            }
            
            return Disposables.create { geocoder.cancelGeocode() }
        }
    }
    
}

