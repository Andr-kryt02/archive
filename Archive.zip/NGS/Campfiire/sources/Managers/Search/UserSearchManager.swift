//
//  UserSearchManager.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/21/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire

enum UserSearchManager {}
extension UserSearchManager {
    
    static func searchWith(filter: SearchUsersFilter, batch: Batch) -> Observable<[User]> {
        
        let searchRout = SearchRouter.user(batch: batch,
                                           searchFilter: filter)
        
        return Alamofire
            .request(searchRout)
            .rx_campfiireResponse(CampfiireArrayResponse<User>.self)
        
        /// I return fake users instead of real one
        
        //            guard batch.offset < 20 else { return Observable.just([]) }
        //
        //            var fakeUsers: [User] = []
        //            for _ in 0...batch.limit / 2 {
        //                fakeUsers.append(User.fakeEntity())
        //            }
        //
        //            return Observable.create({ (observer) -> Disposable in
        //
        //                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
        //                    observer.onNext(fakeUsers)
        //                    observer.onCompleted()
        //                }
        //                
        //                return Disposables.create()
        //            })
        
    }
    
}
