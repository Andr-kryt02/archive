//
//  ChatManager.swift
//  Campfiire
//
//  Created by Vlad Soroka on 1/10/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import Foundation

import XMPPFramework

import RxSwift
import RxCocoa


/////-----
/////One-to-One messaging
/////------
extension ChatManager {
    
    static func receiveRealTimeMessagesFrom(user: User, from date: Date) -> Observable<ChatMessage> {
        
        let messagesSignal = self.stream.messageReceived()
            .filter { message in
                
                guard message.isChatMessage() else { return false }
                guard let fromJID: XMPPJID = message.from(), fromJID.user == user.jid.user else { return false }
                
                return true
            }
            .map { ChatMessage(message: $0) }
            ///XMPP makes sure that all missed messages are delivered while user was offline
            ///Since we have IQ to request message archive we do not interested in missed messages
            .filter { $0.date.timeIntervalSince(date) > 0 }
        
        return stream.authorized.flatMap { messagesSignal }
        
    }
    
    static func sendMessage(chatMessage: ChatMessage,
                            to receiver: User) -> Observable<Void> {
        return sendMessage(chatMessage: chatMessage, to: receiver.jid)
    }
    
    static func sendMessage(chatMessage: ChatMessage, to jid: XMPPJID) -> Observable<Void> {
       
        let message: XMPPMessage = XMPPMessage(type: "chat", to: jid)
        message.addBody(chatMessage.body)
        if let attachment = chatMessage.pictureURL {
            message.addChild( DDXMLElement(name: "attachment", stringValue: attachment) )
        }
        
        return send( element: message )
    }
    
    fileprivate static func send(element: DDXMLElement) -> Observable<Void> {
        
        let messageRequest = Observable<Void>.create({ (observer) -> Disposable in
            
            var receipe: XMPPElementReceipt? = nil
            self.stream.xmpp.send(element, andGet: &receipe)
            
            if let status = receipe?.wait(ChatManager.Stream.timeout), status {
                observer.onCompleted()
            }
            else {
                observer.onError(CampfiireError.generic(description: "XMPP stream failed to send message \(element)"))
            }
            
            return Disposables.create()
        })
        
        return stream.authorized
            .flatMap { messageRequest }
        
    }
    
}

extension ChatManager {
    
    static func messagesWithUser(peer: User, batch: Batch) -> Observable<[ChatMessage]> {
        
//        if batch.offset > 130 {
//            return Observable.just([ ])
//        }
//        
//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
//                
//                var newAnnotations:[ChatMessage] = []
//                
//                for i in 0...batch.limit {
//                    
//                    let message = ChatMessage.fakeEntity(number: batch.offset + i )
//                    
//                    newAnnotations.append( message )
//                }
//                
//                observer.onNext(newAnnotations)
//                observer.onCompleted()
//            }
//            
//            return Disposables.create()
//        })

        
//        <iq id='...' action='private_history' recipient='newuser_1@campfiire' type='get'>
//        <query
//        xmlns='custom:iq:campfiire'>
//        <count>10</count>
//        <offset>1</offset>
//        </query>
//        </iq>
        
/////     response
        
//        <?xml version="1.0" encoding="UTF-8"?>
//        <iq xmlns="jabber:client" type="result" id="adsfadsf" to="19@campfiire/2tnir5pgls">
//          <set xmlns="custom:iq:campfiire">
//              <history>
//                  <message xmlns="">
//                      <id>585</id>
//                      <body>&#x1f3c0;</body>
//                      <from>19@campfiire</from>
//                      <to>17@campfiire</to>
//                      <time>1485606320334</time>
//                  </message>
        ////.......
//              </history>
//          </set>
//        </iq>
        
        
        let id = stream.xmpp.generateUUID()
        let iq: XMPPIQ = XMPPIQ(type: "get", elementID: id)
        iq.addAttribute(withName: "action", stringValue: "private_history")
        iq.addAttribute(withName: "recipient", stringValue: peer.jid.bare())
        
        let query: DDXMLElement = DDXMLElement(name: "query", xmlns: "custom:iq:campfiire")
        query.addChild(DDXMLElement(name: "count", numberValue: batch.limit as NSNumber))
        query.addChild(DDXMLElement(name: "offset", numberValue: batch.offset as NSNumber))
        
        iq.addChild(query)
        
        let _ = send(element: iq).subscribe(onNext: { })
        
        return stream.iqReceived()
            .filter { $0.elementID() == id }
            .take(1)
            .map { (a: XMPPIQ) in
            
            guard let messageNodes: [DDXMLElement] = a
                .childElement()? ///set
                .child(at: 0)? ///history
                .children as? [DDXMLElement] else  {
                    
                    fatalError("Error parsing history result")
                    
            }
            
            //return []
            return messageNodes.map { ChatMessage(message: XMPPMessage(from: $0) ) }
        }
        
    }
    
    static func chatList() -> Observable<[ChatsListTableItem]> {

        /*
         Searching for chat rooms
         */
        
//        let id: String = stream.xmpp.generateUUID()
//        
//        let iq: XMPPIQ = XMPPIQ(type: "get", elementID: id)
//        iq.addAttribute(withName: "xmlns", stringValue: "jabber:client")
//        iq.addAttribute(withName: "to", stringValue: "conference.campfiire")
//        iq.addAttribute(withName: "from", stringValue: "3@campfiire")
//        
//        
//        let list: DDXMLElement = DDXMLElement(name: "query")
//        list.addAttribute(withName: "xmlns", stringValue: "jabber:iq:search")
//        
//        let x: DDXMLElement = DDXMLElement(name: "x", xmlns: "jabber:x:data")
//        x.addAttribute(withName: "type", stringValue: "submit")
//        
//        let formType: DDXMLElement = DDXMLElement(name: "field")
//        
//        formType.addAttribute(withName: "var", stringValue: "FORM_TYPE")
//        formType.addAttribute(withName: "type", stringValue: "hidden")
//        
//        formType.addChild(DDXMLElement(name: "value", stringValue: "jabber:iq:search"))
//        
//        x.addChild(formType)
//        list.addChild(x)
//        iq.addChild(list)
//        
//        send(element: iq).subscribe(onNext: {
//            
//        })
//        
//        return stream.iqReceived()
//            .filter { $0.elementID() == id }
//            .map { data in
//                
//                ///TODO: map response to Array of ChatListItems
//                //print(data)
//                
//                return []
//        }
        
        
        let id: String = stream.xmpp.generateUUID()
        let iq: XMPPIQ = XMPPIQ(type: "get", elementID: id)
        iq.addAttribute(withName: "action", stringValue: "chatlist")
        
        let query: DDXMLElement = DDXMLElement(name: "query")
        query.addAttribute(withName: "xmlns", stringValue: "custom:iq:campfiire")
        query.addChild( DDXMLElement(name: "count", numberValue: 10 ) )
        query.addChild( DDXMLElement(name: "offset", numberValue: 0 ) )
        
        iq.addChild(query)
        
        let _ = send(element: iq).subscribe(onNext: { })
        
        return stream.iqReceived()
            .filter { $0.elementID() == id }
            .take(1)
            .flatMap { (data: XMPPIQ) -> Observable<XMPPIQ> in
                
                if data.isErrorIQ(), let er = data.childErrorElement() {
                    
                    return Observable.error( CampfiireError.generic(description: er.description ) )
                    
                }
                
                return Observable.just(data)
            }
            .map { data -> [DDXMLElement] in
                
                ///step 1. parse openfire response to receive all data about conversations
                
                guard let chatNodes: [DDXMLElement] = data
                    .childElement()? ///set
                    .child(at: 0)? ///chats
                    .children as? [DDXMLElement] else  {
                        fatalError("Error parsing history result")
                }
                
                return chatNodes
            }
            .flatMap { nodes -> Observable<[ChatsListTableItem]> in
                
                ///serializing chats the first time to get users we still need to retreive for Chats UI
                ///xmpp response does not contain usernames and profile picture urls
                let chats = nodes.flatMap { ChatsListTableItem( xml: $0) }
                
                let refreshUsers = chats.flatMap { i -> User? in
                    switch i {
                    case .group(_): return nil
                    case .personal(let chat): return chat.peer
                    }
                }
                
                ////step 2. retreiving details for all users that are needed in chat UI 
                return UsersManager.listDetails(of: refreshUsers )
                    .map { _ in
                        
                        ///step 3. creating chat list again with properly populated users
                        return nodes.flatMap { ChatsListTableItem( xml: $0) }
                        
                    }
                
            }


//        return Observable.just([ .group(chat: MultiuserChat.fakeEntity() ),
//                                 .group(chat: MultiuserChat.fakeEntity() ),
//                                 .group(chat: MultiuserChat.fakeEntity() ),
//                                 .personal( chat: OneToOneChat.fakeEntity() ),
//                                 .personal( chat: OneToOneChat.fakeEntity() ),
//                                 .personal( chat: OneToOneChat.fakeEntity() ) ])
        
    }
    
    static func disconnect() -> Observable<Void> {
        
        guard !stream.xmpp.isDisconnected() else {
            return Observable.just()
        }
        
        stream.xmpp.disconnectAfterSending()
            
        return stream.rx.methodInvoked(#selector(XMPPStreamDelegate.xmppStreamDidDisconnect(_:withError:)))
            .flatMap { args -> Observable<Void> in
//                
//                guard let er = args.last as? Error? else {
//                    fatalError("Disconnect method can't handle response properly")
//                }
//                
//                if er != nil {
//                    return Observable.error(er!)
//                }
                
                return Observable.just()
            }
        
    }
    
}

enum ChatManager {

    fileprivate class Stream: NSObject {
        
        lazy var xmpp: XMPPStream = {
            let stream = XMPPStream()!
            stream.hostName = "178.165.92.42"
            stream.hostPort = 5222
            stream.addDelegate(self, delegateQueue: DispatchQueue.main)
            return stream
        }()
        
        lazy var muc: XMPPMUC = {
            let muc: XMPPMUC = XMPPMUC(dispatchQueue: DispatchQueue.main)
            muc.addDelegate(self, delegateQueue: DispatchQueue.main)
            muc.activate(self.xmpp)
            return muc
        }()
        
        private let authStatus = Variable(false)
        //let authError: Variable<String?> = Variable(nil)
        
        var authorized: Observable<Void> {
            
            if !(xmpp.isAuthenticated() || xmpp.isAuthenticating()) {
                
                guard let user = User.currentUser() else {
                    fatalError("Can't connect with XMPP when current user does not exist")
                }
                
                ///kick off authentication procedure
                xmpp.myJID = user.jid
                try? xmpp.connect(withTimeout: Stream.timeout)
            }
            
            return authStatus.asObservable()
                .filter { $0 }
                .map { _ in () }
                .take(1)
            
        }
        
        fileprivate func xmppStreamDidConnect(_ sender: XMPPStream!) {
            try! xmpp.authenticate(withPassword: "password")
        }
        
        fileprivate func xmppStreamDidAuthenticate(_ sender: XMPPStream!) {
            let presence = XMPPPresence()
            xmpp.send(presence)
            
            authStatus.value = true
        }
        
        fileprivate func xmppStreamDidDisconnect(_ sender: XMPPStream!,
                                                 withError error: Error!) {
            authStatus.value = false
        }
        
    }; fileprivate static let stream = Stream()
    
}


extension ChatManager.Stream : XMPPStreamDelegate {
    
    fileprivate static let timeout: RxTimeInterval = 3
    
    ///////------------
    ////// XMPP IQ stanza
    //////------------
    
    func xmppStream(_ sender: XMPPStream!, didReceive iq: XMPPIQ!) -> Bool {
        xmppStream(didReceiveIQ: iq)
        return true
    }
    @objc private func xmppStream(didReceiveIQ iq: XMPPIQ) {}
    
    fileprivate func iqReceived() -> Observable<XMPPIQ> {
        
        let selector = #selector(ChatManager.Stream.xmppStream(didReceiveIQ:))
        
        return self.rx
            .methodInvoked(selector)
            .map { args in
                
                guard let iq = args.first as? XMPPIQ else {
                    fatalError("Can't cast argument to XMPPIQ element")
                }
                
                return iq
            }
            .timeout(ChatManager.Stream.timeout, scheduler: MainScheduler.instance)
        
    }
    
    ///////------------
    ////// XMPP Presence stanza
    //////------------
    
    fileprivate func xmppStream(_ sender: XMPPStream!, didReceive presence: XMPPPresence!) {
        xmppStream(didReceivePresence: presence)
    }
    @objc private func xmppStream(didReceivePresence presence: XMPPPresence) {}
    
    fileprivate func presenceReceived() -> Observable<XMPPPresence> {
        
        let selector = #selector(ChatManager.Stream.xmppStream(didReceivePresence:))
        
        return self.rx
            .methodInvoked(selector)
            .map { args in
                
                guard let presence = args.first as? XMPPPresence else {
                    fatalError("Can't cast argument to Presence element")
                }
                
                return presence
            }
            .timeout(ChatManager.Stream.timeout, scheduler: MainScheduler.instance)
        
    }
    
    ///////------------
    ////// XMPP Message stanza
    //////------------
    
    fileprivate func xmppStream(_ sender: XMPPStream!, didReceive message: XMPPMessage!) {
        xmppStream(didReceiveMessage: message)
    }
    @objc private func xmppStream(didReceiveMessage message: XMPPMessage) {}
    
    fileprivate func messageReceived() -> Observable<XMPPMessage> {
        
        let selector = #selector(ChatManager.Stream.xmppStream(didReceiveMessage:))
        
        return self.rx
            .methodInvoked(selector)
            .map { args in
                
                guard let message = args.first as? XMPPMessage else {
                    fatalError("Can't cast argument to XMPPMessage element")
                }
                
                return message
            }
        
    }

    ///////------------
    ////// Reactive stubs
    //////------------
    
    
    fileprivate func xmppStream(_ sender: XMPPStream!, didNotAuthenticate error: DDXMLElement!) {}
    
    fileprivate func xmppStreamConnectDidTimeout(_ sender: XMPPStream!) {}
    
    
}
