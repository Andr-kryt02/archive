//
//  ChatAttachmentManager.swift
//  Campfiire
//
//  Created by Vlad Soroka on 1/30/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire

enum ChatAttachmentManager {}

extension ChatAttachmentManager {
    
    static func uploadImage(image: UIImage) -> Observable<String> {
        
        let photos: [String] = [//nil,nil,nil,nil,nil,
            "http://resources.touropia.com/gfx/d/best-places-to-visit-in-turkey/istanbul.jpg",
            "http://www.hellomagazine.com/imagenes/travel/201208299115/iconic-photographs-travel/0-45-151/egypt--a.jpg",
            "https://s-media-cache-ak0.pinimg.com/originals/3d/b1/f9/3db1f9332557ff6435de2fda6bc74e5e.jpg",
            "http://static3.businessinsider.com/image/5537f6f56bb3f740728fddb1-1190-625/26-beautiful-places-you-should-visit-before-they-disappear.jpg",
            "http://www.planetware.com/photos-large/MEX/mexico-top-places-cancun-mayan-riviera.jpg"
        ]
        return Observable.just(ChatMessage.fakeValue(from: photos))
            .delay(0.6, scheduler: MainScheduler.instance)
        
//        let data = UIImageJPEGRepresentation(image, 1)!
//        
//        return rx_upload(rout: ChatRouter.uploadAttachment, data: ["file" : data])
//            .flatMap { $0.rx_campfiireResponse(CampfiireResponse<ChatAttachmentResponse>.self) }
//            .map { resp in
//                ImageRetreiver.registerImage(image: image, forKey: resp.url)
//                return resp.url
//            }
        
    }
    
}
