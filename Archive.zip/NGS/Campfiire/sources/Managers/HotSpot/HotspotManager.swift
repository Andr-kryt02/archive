//
//  HotspotManager.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/27/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import MapKit
import RxSwift
import Alamofire

enum HotspotManager {}
extension HotspotManager {
    
    static func retreiveHotspots(for area:MKCoordinateRegion,
                                 query: String?,
                                 followedOnly: Bool) -> Observable<[AnnotationWrapper]> {
        
        ///Make sure requests are canceled properly as this method potentially is called a lot of times
        ///Also move all data preparations to the background threads

        let region = area.circularApproximation
        
        let mapRout = HotspotRouter.map(georegion: region,
                                               query: query,
                                               followedOnly: followedOnly)
            
        return Alamofire.request(mapRout)
                .rx_campfiireResponse(CampfiireArrayResponse<HotSpot>.self)
                .map {
                    $0.map { hotspot in
                        hotspot.saveEntity()
                        return AnnotationWrapper( type: hotspot )
                    }
                }
        
//        
//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
//                
//                var newAnnotations:[HotspotAnnotationWrapper] = []
//                
//                for _ in 0...HotSpotCluster.fakeNumber(bound: 10) {
//                    
////                    let fakeCluster = HotSpotCluster.fakeEntity(for: area)
////                    let wrapper = HotspotAnnotationWrapper(type: .cluster( cluster: fakeCluster ))
//
//                    let fakeHotSpot = HotSpot.fakeEntity(in: area)
//                    fakeHotSpot.saveEntity()
//                    let wrapper = HotspotAnnotationWrapper(type: .hotspot( hotspot: fakeHotSpot ))
//
//                    newAnnotations.append( wrapper )
//                }
//                
//                observer.onNext(newAnnotations)
//                observer.onCompleted()
//            }
//            
//            return Disposables.create()
//        })
//        
    }
    
    static func topRated(batch: Batch? = nil) -> Observable<[HotSpot]>{
        
        let request = HotspotRouter.top(batch: batch)
        
        return Alamofire.request(request)
            .rx_campfiireResponse(CampfiireArrayResponse<HotSpot>.self)
            .map { items in
                items.forEach { $0.saveEntity() }
                return items
        }
    }
    

    static func refreshHotSpot(hotspot: HotSpot) -> Observable<HotSpot> {
        
        return Alamofire
            .request( HotspotRouter.details(hotSpot: hotspot) )
            .rx_campfiireResponse(CampfiireResponse<HotSpot>.self)
            .map { hs in
                hs.saveEntity()
                return hs
            }
        
//        
//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) {
//                
////                if HotSpot.fakeBool() {
////                    observer.onError(CampfiireError.objectDeleted)
////                    return;
////                }
//                
//                var hs = hotspot
//                hs.fakePopulateDetails()
//                hs.saveEntity()
//                
//                observer.onNext(hs)
//                observer.onCompleted()
//                
//            }
//            
//            return Disposables.create()
//        })
        
    }
    
    static func addNew(image: UIImage, for hotspot: HotSpot) -> Observable<HotSpot> {
        
        let createPhotoRout = HotspotRouter.createPhoto(hotspot: hotspot)
        let data = UIImageJPEGRepresentation(image, 1)!
        
        return Campfiire
            .rx_upload(rout: createPhotoRout, data: ["file" : data] )
            .flatMap { $0.rx_campfiireResponse(CampfiireResponse<Photo>.self) }
            .map { photo in
                
                guard let latestHS = hotspot.refreshedEntity() else { fatalError("Logic error for adding photo on hotspot that is till not in the storage") }
                
                var hs = latestHS
                hs.photos.insert(photo, at: 0)
                hs.saveEntity()
                
                return hs
            }
        
        
//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) {
//                
//                //                if HotSpot.fakeBool() {
//                //                    observer.onError(CampfiireError.objectDeleted)
//                //                    return;
//                //                }
//                
//                let fakeURL = Date().description + HotSpot.fakeString()
//                ImageRetreiver.registerImage(image: image,
//                                             forKey: fakeURL)
//                
//                var photo = Photo.fakeEntity()
//                photo.pictureURL = fakeURL
//                
//                var hs = HotSpot.entityBy(identifier: hotspot.id)!
//                hs.photos.insert(photo, at: 0)
//                hs.saveEntity()
//                
//                observer.onNext(hs)
//                observer.onCompleted()
//                
//            }
//            
//            return Disposables.create()
//        })
//        
    }
    
    static func delete(hotspot: HotSpot) -> Observable<Void> {
        
        let deleteRout = HotspotRouter.delete(hotSpot: hotspot)
        
        return Alamofire.request(deleteRout)
                .rx_campfiireResponse(CampfiireEmptyResponse.self)
                .do(onNext: {
                    hotspot.removeFromStorage()
                })

//        
//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) {
//                
//                hotspot.removeFromStorage()
//                
//                observer.onNext(  )
//                observer.onCompleted()
//                
//            }
//            
//            return Disposables.create()
//        })
        
    }
    
    static func upsert(hotspot: HotSpot) -> Observable<HotSpot> {
        
        guard hotspot.latitude != 0, hotspot.longitude != 0 else
        { fatalError("Can't upsert hotspot without location!") }
        
        let shouldCreate = hotspot.id == 0
        
        let upsertKey = "com.campfire.fakeURL.hotspot"
        let shouldUpdateAvatar = hotspot.imageURL.hasPrefix(upsertKey)
        
        var hs = hotspot
        hs.author = nil
        
        let rout: HotspotRouter = shouldCreate ? .create(hotSpot: hs) : .update(hotSpot: hotspot)
        
        return Alamofire.request(rout)
                .rx_campfiireResponse(CampfiireResponse<HotSpot>.self)
                .flatMap { hs -> Observable<HotSpot> in
                    
                    guard shouldUpdateAvatar,
                          let image = ImageRetreiver.cachedImageForKey(key: hs.imageURL),
                          let data = UIImageJPEGRepresentation(image, 1) else {
                        return Observable.just(hs)
                    }
                
                    let updateAvaRout = HotspotRouter.updateAvatar(hotSpot: hs)
                    
                    return Campfiire.rx_upload(rout: updateAvaRout, data: ["file" : data] )
                        .flatMap { $0.rx_campfiireResponse(CampfiireResponse<AvatarUpdateResponse>.self) }
                        .map { avatar in
                            
                            var hotspot = hs
                            hotspot.imageURL = avatar.url!
                            return hotspot
                            
                        }
                }
                .map { hs in
                    hs.saveEntity()
                    return hs
                }
        
//        
//        ////perform actual upsert with image uploading
//        
//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
//                
//                var hs = hotspot
//                
//                if (shouldCreate) {
//                    hs.id = HotSpot.fakeNumber(bound: 1000) + 1000
//                }
//                
//                hs.saveEntity()
//                
//                observer.onNext( hs )
//                observer.onCompleted()
//                
//            }
//            
//            return Disposables.create()
//        })
//        
    }
    
}

extension HotspotManager /*Comments*/ {
    
    static func retreiveComments(for hotspot: HotSpot, batch: Batch) -> Observable<[Comment]> {

        let rout = HotspotRouter.commentsList(hotspot: hotspot, batch: batch)
        
        return Alamofire.request(rout)
            .rx_campfiireResponse(CampfiireResponse<CommentListRepsonse>.self)
            .map { $0.comments }
        
        
        
//        guard batch.offset < 15 else { return Observable.just([]) }
//        
//        var fakeComments: [Comment] = []
//        for _ in 0...batch.limit / 3 {
//            fakeComments.append( Comment.fakeEntity() )
//        }
//        
//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) {
//                observer.onNext(fakeComments)
//                observer.onCompleted()
//            }
//            
//            return Disposables.create()
//        })
        
    }
    
    static func postCommentWithText(text: String, for hotspot: HotSpot) -> Observable<Comment> {
        
        let rout = HotspotRouter.postComment(hotspot: hotspot, text: text)
        
        return Alamofire.request(rout)
            .rx_campfiireResponse(CampfiireResponse<Comment>.self)
        
        
//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) {
//                
//                //                if HotSpot.fakeBool() {
//                //                    observer.onError(CampfiireError.objectDeleted)
//                //                    return;
//                //                }
//                
//                var comment = Comment(JSON: [ : ])!
//                comment.text = text
//                comment.date = Date()
//                comment.author = User.currentUser()!
//                
//                observer.onNext(comment)
//                observer.onCompleted()
//                
//            }
//            
//            return Disposables.create()
//        })
//        
    }
    
    
    static func reportHotSpot(hotspot: HotSpot) -> Observable<Report> {
        
        let rout = HotspotRouter.reportHotSpot(hotspot: hotspot)
        
        return Alamofire.request(rout)
            .rx_campfiireResponse(CampfiireResponse<Report>.self)
        
        
    }
    
    static func reportHotSpotComment(comment: Comment) -> Observable<Report> {
        
        let rout = HotspotRouter.reportHotSpotComment(comment: comment)
        
        return Alamofire.request(rout)
            .rx_campfiireResponse(CampfiireResponse<Report>.self)
        
        
    }
    
    
    static func reportHotSpotPhoto(photo: Photo) -> Observable<Report> {
        
        let rout = HotspotRouter.reportHotSpotPhoto(photo: photo)
        
        return Alamofire.request(rout)
            .rx_campfiireResponse(CampfiireResponse<Report>.self)
        
        
    }
    
    
    
}

extension HotSpot : TopRatedListProvider {
    
    typealias DataType = HotSpot
    
    static var top10List: Observable<[HotSpot]> {
        
//        var fakes: [HotSpot] = []
//        for _ in 0...10 {
//            
//            var c = HotSpot.fakeEntity()
//            c.fakePopulateDetails()
//            c.saveEntity()
//            
//            fakes.append( c )
//        }
//        
//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
//                observer.onNext(fakes)
//                observer.onCompleted()
//            }
//            
//            return Disposables.create()
//        })
        
        return Alamofire.request( HotspotRouter.top(batch: nil) )
            .rx_campfiireResponse(CampfiireArrayResponse<HotSpot>.self)
            .map { hotspots in
                hotspots.forEach { $0.saveEntity() }
                return hotspots
            }
    }
    
}
