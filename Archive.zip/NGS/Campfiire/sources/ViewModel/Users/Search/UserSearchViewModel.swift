//
//  UserSearchViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/22/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift

struct UserSearchViewModel: ViewModel {
    
    let appliedFilter: Variable<SearchUsersFilter?> = Variable(nil)
    
    var filterViewModel : FilterViewModel?
    
    weak var handler: UIViewController?
    
    init(handler: UIViewController) {
        self.handler = handler
        
    }
    
    func applyFilter(query: String) {
        
        var selectedFilter = filterViewModel?.selectedFilter.value ?? SearchUsersFilter()
        selectedFilter.query = query
        
        appliedFilter.value = selectedFilter
              
    }
    
}

