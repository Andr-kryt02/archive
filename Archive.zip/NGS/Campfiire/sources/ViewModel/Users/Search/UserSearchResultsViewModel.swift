//
//  UserSearchResultsViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/25/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

import Foundation
import RxSwift
import RxCocoa
import RxDataSources

struct UserSearchResultsViewModel: ViewModel {
    
    let filterViewModel: FilterViewModel
    
    weak var handler: UIViewController?
    init(handler: UIViewController, searchFilter: SearchUsersFilter) {
        self.handler = handler
        self.filterViewModel = FilterViewModel(initialFilter: searchFilter)
        providerViewModel.handler = handler
        
        filterViewModel
            .selectedFilter.asObservable()
            .notNil()
            .startWith(searchFilter)
            .map { UserSearchDataProvider(appliedFilter: $0) }
            .bindTo(providerViewModel.dataProvider)
            .addDisposableTo(bag)
        
        providerViewModel.loadingBatchDriver
            .drive( onNext: { [unowned h = handler] batch in
                
                var shouldAnimate = false
                if let b = batch, b.offset == 0 { ///animating only for the very first batch
                    shouldAnimate = true
                }
                
                h.changedAnimationStatusTo(status: shouldAnimate)
            })
            .addDisposableTo(bag)
        
    }
    
    var displayData: Driver<[AnimatableSectionModel<String, User>]> {
        return providerViewModel.displayDataDriver.map { (data) in
            return [AnimatableSectionModel(model: "",
                                           items: data)]
            }

    }
    var showsEmptyState: Driver<Bool> {
        return providerViewModel.displayDataDriver
            .map { $0.count == 0 }
            .skip(1) /// until we load at least one batch
    }
    
    
    let providerViewModel: FeedViewModel<UserSearchDataProvider> = FeedViewModel()
    
    fileprivate let bag: DisposeBag = DisposeBag()
    
}

extension UserSearchResultsViewModel  {
    
    func chatViewModelForItem(at ip: IndexPath, for handler: UIViewController) -> ChatMessagesProvider {
        let user = providerViewModel.currentData[ip.row]
        
        return OneToOneChatViewModel(handler: handler, peer: user)
    }
    
}

extension UserSearchResultsViewModel  {
    
    struct UserSearchDataProvider : DataProvider {
    
        let appliedFilter: SearchUsersFilter
        
        typealias DataType = User
        
        func loadBatch(batch: Batch) -> Observable<[User]> {

            return UserSearchManager.searchWith(filter: appliedFilter, batch: batch)

        }
        
    }
    
}
