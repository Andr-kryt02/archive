//
//  FilterViewModel.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 31.10.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa


struct FilterViewModel : ViewModel {
    
    ///range slider UI config
    let minimumRange : Float = 1
    let minimumValue : Float = 18
    let maximumValue : Float = 99
    let stepValue : Float = 1
    
    ////
    var genderIndex: Observable <Int> {
        return currentFilter.asObservable()
            .map { $0.gender?.rawValue ?? 0 }
    }
    var location: Observable <String> {
        return currentFilter.asObservable()
            .map { $0.location ?? "" }
    }
    var ageRange: Observable <(Float, Float)> {
        return currentFilter.asObservable()
            .map { filter in
                let from: Float = Float( filter.ageRange?.from ?? 22 )
                let to: Float = Float ( filter.ageRange?.to ?? 60 )
                
                return ( from, to )
        }
    }
    
    let currentFilter: Variable <SearchUsersFilter>
    
    ///triggers
    let selectedFilter: Variable<SearchUsersFilter?> = Variable(nil)
    
    
    init(handler: UIViewController? = nil,
         initialFilter: SearchUsersFilter? = nil) {
        
        self.handler = handler
        
        currentFilter = Variable(initialFilter ?? SearchUsersFilter(query: nil,
                                                               ageRange: SearchUsersFilter.AgeRange(from: 22,
                                                                                               to: 60),
                                                               gender: nil,
                                                               location: nil,
                                                               tag: nil))
        
        
    }

    weak var handler: UIViewController?
    fileprivate let bag = DisposeBag()
    
}

extension FilterViewModel {
    
    func setGender (selectedIndex : Int) {
        var filter = currentFilter.value
        filter.gender = Gender(rawValue : selectedIndex)
        currentFilter.value = filter
    }
    
    func setAgeRange (from : Float, to : Float) {
        var filter = currentFilter.value
        filter.ageRange = SearchUsersFilter.AgeRange(from: Int(from),
                                              to: Int(to))
        currentFilter.value = filter
    }
    
    func setLocation (location : String) {
        var filter = currentFilter.value
        filter.location = location
        currentFilter.value = filter
    }
    
    func approveFilters() {
    
        selectedFilter.value = currentFilter.value
        
    }
    
}
