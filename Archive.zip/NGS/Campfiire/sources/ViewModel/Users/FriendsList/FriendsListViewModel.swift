//
//  FriendsListViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/31/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

import RxSwift
import RxCocoa
import RxDataSources

struct FriendsListViewModel: ViewModel {
    
    weak var handler: UIViewController?
    init(handler: UIViewController) {
        
        self.handler = handler
        
        query.asObservable()
            .distinctUntilChanged()
            .debounce(0.4, scheduler: MainScheduler.asyncInstance)
            .flatMapLatest { [unowned i = indicator] q -> Observable<[FriendListTableItem]> in
                return FriendsManager.friendScreenList(query: q)
                    .trackView(viewIndicator: i)
            }
            .silentCatch(handler: handler)
            .bindTo(friendScreenList)
            .addDisposableTo(bag)
        
        indicator.asDriver()
            .drive(onNext: { [weak h = handler] (loading) in
                h?.changedAnimationStatusTo(status: loading)
            })
            .addDisposableTo(bag)
        
        ////on each hide
        
        searchBarHidden.asObservable()
            .filter { $0 }
            .map { _ in "" }
            .bindTo(query)
            .addDisposableTo(bag)
        
    }
    
    var datasource: Driver<[AnimatableSectionModel<String, FriendListTableItem>]> {
        return friendScreenList.asDriver()
            .map { (data) in
                return [AnimatableSectionModel(model: "",
                                               items: data)]
            }
    }
    var showsEmptyState: Driver<Bool> {
        return friendScreenList.asDriver()
            .map { $0.count == 0 }
            .skip(1) /// until we load at least one batch
    }
    
    let searchBarHidden: Variable<Bool> = Variable(true)

    fileprivate let friendScreenList: Variable<[FriendListTableItem]> = Variable([])
    fileprivate let query: Variable<String> = Variable("")
    fileprivate let indicator = ViewIndicator()
    let bag = DisposeBag()
    
}

extension FriendsListViewModel {
    
    func canEditItem(at: IndexPath) -> Bool {
        switch friendScreenList.value[at.row] {
        case .friend(_): return true
        case .request(_): return false
        }
    }
    
    func removeFriend(at: IndexPath) {
        
        let list = friendScreenList.value
        let friend = list[at.row].friend
        
        let message = DisplayMessage(title: "Please confirm",
                                     description: "Would you like to delete \(friend.name) from your friend list")
        handler?.presentConfirmQuestion(question: message)
            .filter { return $0 }
            .flatMapLatest { [unowned list = friendScreenList] _ -> Observable<Void> in
                
                var l = list.value
                l.remove(at: at.row)
                list.value = l
                
                return FriendsManager.removeFriend(user: friend).map { _ in () }
            }
            .subscribe(onCompleted: {
                ////nothing so far. Just silently succed or fail
            })
            .addDisposableTo(bag)
        
    }
 
    func acceptRequest(at: IndexPath) {
        
        var list = friendScreenList.value
        
        let user = list[at.row].request
        FriendRequestManager.acceptRequest(from: user)
            .subscribe(onCompleted: {
                ////nothing so far
            })
            .addDisposableTo(bag)
        
        list.remove(at: at.row)
        list.insert( .friend(user: user), at: at.row)
        
        friendScreenList.value = list
        
    }
    
    func rejectRequest(at: IndexPath) {
        
        var list = friendScreenList.value
        
        let user = list[at.row].request
        FriendRequestManager.rejectRequest(from: user)
            .subscribe(onCompleted: {
                ////nothing so far
            })
            .addDisposableTo(bag)
        
        list.remove(at: at.row)
        
        friendScreenList.value = list
        
    }
    
}

extension FriendsListViewModel {
    
    func searchQueryChanged(query: String) {
        self.query.value = query
    }
    
    func switchSearchBarStatus() {
        
        let isHidden = searchBarHidden.value
        
        searchBarHidden.value = !isHidden
    }
    
}
