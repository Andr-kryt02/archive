//
//  FriendListTableItem.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/31/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import RxDataSources

enum FriendListTableItem {
    
    case friend(user: User)
    case request(user: User)
    
    var friend: User {
        switch self {
        case .friend(let u): return u
        case .request(_): fatalError("Item is not friend but request")
        }
    }
    
    var request: User {
        switch self {
        case .friend(_): fatalError("Item is not request but firend")
        case .request(let u): return u
        }
    }
}

extension FriendListTableItem : IdentifiableType, Equatable {
    
    var identity: String {
        switch self {
        case .friend(let user):   return "\(user.id)"
        case .request(let user):  return "\(user.id)"
        }
    }
    
}

func ==(lhs: FriendListTableItem,
        rhs: FriendListTableItem) -> Bool {
    
    switch (lhs, rhs) {
        
    case (.friend(let lhs) , .friend(let rhs)):
        return lhs == rhs
        
    case (.request(let lhs) , .request(let rhs)):
        return lhs == rhs
        
    default:
        return false
    }

}
