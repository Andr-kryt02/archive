//
//  UserProfileViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/18/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import RxDataSources

typealias DataSourceType = [AnimatableSectionModel<String, TableItemViewModel>]

class UserProfileViewModel : ViewModel {

    let avatar: Variable<UIImage?> = Variable(nil)
    let name: Variable<String> = Variable("")
    let gender: Variable<String> = Variable("")
    let birthday: Variable<String> = Variable("")
    var birthDate: Date {
        return discardableUser.value!.birthdate
    }
    
    let editingMode: Variable<Bool> = Variable(false)
    
    let dataSource: Variable<[AnimatableSectionModel<String, TableItemViewModel>]> = Variable([])
    let rightButtons: Variable<NavigationButtons>
    let leftButtons: Variable<NavigationButtons>
    
    let presentSearchFilter: Variable<SearchUsersFilter?> = Variable(nil)
    
    internal weak var handler: UIViewController?
    init(handler: UIViewController,
         user: User) {
    
        self.handler = handler
        
        /////rigth buttons
        
        let isCurrentUser = User.currentUser() != nil ? user == User.currentUser()! : false
        self.rightButtons = Variable([])
        self.leftButtons = Variable([])
        
        /////user updating
        
        UsersManager.mostRecentUserData(user: user)
            .startWith(user)
            .trackView(viewIndicator: indicator)
            .retry(1)
            .silentCatch(handler: handler)
            .bindTo(discardableUser)
            .addDisposableTo(bag)
        
        discardAllChangesTrigger.asObservable()
            .filter { $0 }
            .map { _ in
                return user.refreshedEntity() ?? user
            }
            .bindTo(discardableUser)
            .addDisposableTo(bag)
        
        
        /////binding
        
        let editingObservable = editingMode.asObservable()
        let userObservable = discardableUser.asObservable().notNil()
        
        Observable
            .combineLatest(userObservable,
                           editingObservable)
            { [weak self,
                unowned h = handler,
                unowned r = discardableUser,
                unowned s = presentSearchFilter] (user, editingMode) -> DataSourceType in
                
                var simpleTags = user.tags.map { tag -> TagCellViewModel in
                    
                    var action: SearchTagAction? = nil
                    if !editingMode {
                        action = SearchTagAction(tag: tag,
                                                 searchFilterReference: s)
                    }
                    
                    return TagCellViewModel(title: tag,
                                            color: UIColor.userTagRegular,
                                            titleAlignment: .center,
                                            closeButtonHidden: !editingMode,
                                            action: action)
                    
                }
                
                if editingMode && isCurrentUser {
                    
                    if simpleTags.count < 10 {
                    
                        simpleTags.append( TagCellViewModel(title: "Add new tag...",
                                                            color: UIColor.userTagRegular,
                                                            titleAlignment: .center,
                                                            action: AddNewTagAction(handler: h,
                                                                                    userReference: r))
                        )
                        
                    }
                    
                    simpleTags.append ( TagCellViewModel(title: "Change password",
                                                         color: UIColor.destructiveRed,
                                                         titleAlignment: .center,
                                                         action: ChangePasswordAction(handler: h,
                                                                                      userReference: r)) )
                    
                }
                
                if !isCurrentUser {
                    simpleTags.append(  TagCellViewModel(title: user.isBlocked ? "Unblock User" : "Block User",
                                                         color: UIColor.destructiveRed,
                                                         titleAlignment: .center,
                                                         action: BlockTagAction(handler: h,
                                                                                userReference: r)) )
                }
                
                
                let traits = [TraitCellViewModel(traitType: .email,
                                                 editable: editingMode,
                                                 value: user,
                                                 hideOnEmptyContent: !editingMode,
                                                 delegate: self),
                              
                              TraitCellViewModel(traitType: .healthProblem,
                                                 editable: editingMode,
                                                 value: user,
                                                 hideOnEmptyContent: !editingMode,
                                                 delegate: self),
                              
                              TraitCellViewModel(traitType: .location,
                                                 editable: editingMode,
                                                 value: user,
                                                 hideOnEmptyContent: !editingMode,
                                                 delegate: self),
                              
                              TraitCellViewModel(traitType: .favoriteProduct,
                                                 editable: editingMode,
                                                 value: user,
                                                 hideOnEmptyContent: !editingMode,
                                                 delegate: self)
                    
                             ].flatMap { $0 }
                    
                
                return [
                    AnimatableSectionModel( model: "",
                                            items: traits.map { TableItemViewModel.trait(trait: $0) }),
                    AnimatableSectionModel( model: " ",
                                            items: simpleTags.map { TableItemViewModel.tag(tag: $0) })
                ]
            }
            .bindTo(dataSource)
            .addDisposableTo(bag)
        
        /////progress indicator
        
        indicator.asDriver()
            .skip(1)
            .drive(onNext: { [weak h = handler] (loading) in
                h?.changedAnimationStatusTo(status: loading)
            })
            .addDisposableTo(bag)
    
        ////avatarImage
        
        userObservable
            .flatMapLatest{ ImageRetreiver.imageForURLWithoutProgress(url: $0.pictureURL) }
            .map { $0 ?? R.image.noimageIc() }
            .bindTo(avatar)
            .addDisposableTo(bag)
        
        ///name
        
        userObservable
            .map { $0.name }
            .bindTo(name)
            .addDisposableTo(bag)
        
        ///gender
        
        userObservable
            .map { $0.gender?.description ?? "Gender" }
            .bindTo(gender)
            .addDisposableTo(bag)
        
        ///birthdate
        
        userObservable
            .map{ "\(($0.birthdate as NSDate).yearsAgo()) y.o." }
            .bindTo(birthday)
            .addDisposableTo(bag)
     
        ///rightBar buttons
        
        let friendshipChanged = userObservable
            .map { $0.isFriend ?? false }
            .distinctUntilChanged()
        
        Observable.combineLatest(editingObservable,
                                 friendshipChanged) { ($0, $1) }
            .map { (tuple) in
                
                let editingOn = tuple.0
                let isFriend = tuple.1
                
                if !isCurrentUser {
                    
                    return isFriend ?
                        [ .text, .removeFriend ] :
                        [ .text, .beFriend ]
                    
                }
                
                return editingOn ? [.apply] : [.edit, .logout]
            }
            .bindTo(rightButtons)
            .addDisposableTo(bag)
        
        ////left buttons
        editingObservable
            .map { (editingOn) in
                
                return editingOn ? [.discardChanges] : [.back]
            }
            .bindTo(leftButtons)
            .addDisposableTo(bag)
        
    }
    
    fileprivate let discardableUser: Variable<User?> = Variable(nil)
    fileprivate var bag = DisposeBag()
    fileprivate let indicator: ViewIndicator = ViewIndicator()
    fileprivate let discardAllChangesTrigger = Variable(false)
    
    fileprivate var fdTakeController: FDTakeController = {
        let d = FDTakeController()
        d.allowsVideo = false
        return d
    }()
    
    struct NavigationButtons: OptionSet {
        let rawValue: Int
        
        static let logout = NavigationButtons(rawValue: 1)
        static let edit = NavigationButtons(rawValue: 2)
        static let apply = NavigationButtons(rawValue: 4)
        static let beFriend = NavigationButtons(rawValue: 8)
        static let removeFriend = NavigationButtons(rawValue: 16)
        static let text = NavigationButtons(rawValue: 32)
        
        static let back = NavigationButtons(rawValue: 64)
        static let discardChanges = NavigationButtons(rawValue: 128)
        
    }
 
}

extension UserProfileViewModel {
    
    func saveClicked() {
        
        guard validateEditInput() else {
            return
        }
        
        weak var h = self.handler
        
        var data = discardableUser.value!
        var image: UIImage? = nil
        if data.pictureURL == "com.campfiire.temporayAvatar",
           let im = ImageRetreiver.cachedImageForKey(key: "com.campfiire.temporayAvatar") {
            
            image = im
            data.pictureURL = ""
            
        }
        
        UsersManager.updateUser(withData: data,
                                avatar: image)
            .trackView(viewIndicator: indicator)
            .silentCatch(handler: h)
            .subscribe(onNext: { (user) in
                self.editingMode.value = false
                
            })
            .addDisposableTo(bag)
        
    }
    
    func editButtonClicked() {
        editingMode.value = true
    }
    
    func removeClicked(at indexPath: IndexPath) {
        
        var user = discardableUser.value!
        
        guard indexPath.section == 1,
              indexPath.row < user.tags.count else { return }
        
        user.tags.remove(at: indexPath.row)
        discardableUser.value = user
        
    }
    
    func addFriendTapped() {
        
        FriendsManager.createFriendRequest(to: discardableUser.value!)
            .trackView(viewIndicator: indicator)
            .silentCatch(handler: handler)
            .subscribe(onNext: { [unowned d = discardableUser] user in
                d.value = user
            },
            onCompleted: { [weak h = handler] in
                h?.presentMessage(message: DisplayMessage(title: "Success",
                                                          description: "Your friend request is sent"))
            })
            .addDisposableTo(bag)
        
    }
    
    func removeFriendTapped() {
        
        FriendsManager.removeFriend(user: discardableUser.value!)
            .trackView(viewIndicator: indicator)
            .silentCatch(handler: handler)
            .subscribe( onNext: { [unowned d = discardableUser] user in
                d.value = user
            },
            onCompleted: { [weak h = handler] in
                h?.presentMessage(message: DisplayMessage(title: "Success",
                                                          description: "You're no longer friends"))
            })
            .addDisposableTo(bag)
        
    }
    
    func updateGenderTo(gender: Gender?) {
        
        var user = discardableUser.value!
        user.gender = gender
        discardableUser.value = user
        
    }
    
    func updateAgeTo(date: Date) {
        
        var user = discardableUser.value!
        user.birthdate = date
        discardableUser.value = user
        
    }
    
    func updateNameTo (newName: String) {
        
        var user = discardableUser.value!
        user.name = newName
        discardableUser.value = user

    }
    
    func dropChanges() {
        editingMode.value = false
        discardAllChangesTrigger.value = true
    }
    
    func logout() {
        handler?.presentConfirmQuestion(question: DisplayMessage(title: "Please confirm",
                                                                 description: "Are you sure you want to log out?"))
            .filter { $0 }
            .subscribe(onNext: { _ in
                MainViewModel.shared.logout()
            })
            .addDisposableTo(bag)
        
    }
    
    func chatViewModel(for handler: UIViewController) -> ChatMessagesProvider {
        return OneToOneChatViewModel(handler: handler,
                                     peer: discardableUser.value!)
    }
    
}

extension UserProfileViewModel {
    
    func updateAvatarClicked(cropFunction : @escaping (UIImage) -> ()) {
        guard editingMode.value else { return }
        
        fdTakeController.didGetPhoto = { (image, _) in
            
            cropFunction(image)
            
        }
        
        fdTakeController.didDelete = { [unowned d = discardableUser]  in
            let tempURL = d.value!.pictureURL
            ImageRetreiver.flushImageForKey(key: tempURL)
            
            var user = d.value!
            user.pictureURL = ""
            d.value = user
        }
        
        fdTakeController.present()
    }
    
    
    func uploadingCroppedImage (image : UIImage)
    {
        let tempURL = "com.campfiire.temporayAvatar"
        ImageRetreiver.registerImage(image: image,
                                     forKey: tempURL)
        
        var user = discardableUser.value!
        user.pictureURL = tempURL
        discardableUser.value = user
        
    }
    
}

extension UserProfileViewModel {
    
    func validateEditInput() -> Bool {
        
        let validator = RegistrationValidation(email: Observable.just(discardableUser.value?.email),
                                               password: Observable.just(nil),
                                               confirmPassword: Observable.just(nil),
                                               name: Observable.just(discardableUser.value?.name),
                                               location: Observable.just(discardableUser.value?.location),
                                               favoriteProduct: Observable.just(discardableUser.value?.favoriteProduct))

        let errors = [
            validator.emailValid.value.failReason,
            validator.nameValid.value.failReason,
            validator.locationValid.value.failReason,
            validator.validateTags(tags: discardableUser.value?.tags).failReason,
            validator.validateBirthday(date: discardableUser.value?.birthdate).failReason
            ].flatMap { $0 }
        
        guard errors.count == 0 else {
            
            self.handler?.presentMessage(message: DisplayMessage(title: "There's a problem with your profile.",
                                                                 description: errors.joined(separator: "\n ")))
            return false
        }
        
        return true
    }
    
}

extension UserProfileViewModel : TraitUpdateDelegate {
    
    func didUpdateItem(trait: TraitType, content: String?) {
        let user = discardableUser.value!.updatedTrait(trait: trait, value: content)
        discardableUser.value = user
    }
    
}
