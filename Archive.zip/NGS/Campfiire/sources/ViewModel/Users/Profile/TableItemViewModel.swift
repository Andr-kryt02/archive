//
//  TableItemViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/19/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import RxDataSources

enum TableItemViewModel {
    
    case tag(tag: TagCellViewModel)
    case trait(trait: TraitCellViewModel)
    
}

extension TableItemViewModel : IdentifiableType, Equatable {
    
    var identity: String {
        switch self {
        case .tag(let tag): return tag.identity
        case .trait(let trait): return "\(trait.identity)"
        
        }
    }
    
}

func ==(lhs: TableItemViewModel, rhs: TableItemViewModel) -> Bool {
    
    var lhsTag: TagCellViewModel?
    var rhsTag: TagCellViewModel?
    
    var lhsTrait: TraitCellViewModel?
    var rhsTrait: TraitCellViewModel?
    
      switch lhs {
    case .tag(let tag): lhsTag = tag
    case .trait(let trait): lhsTrait = trait
   
    
    }
    
    switch rhs {
    case .tag(let tag): rhsTag = tag
    case .trait(let trait): rhsTrait = trait
    
        
    }
    
    if let a = lhsTag, let b = rhsTag {
        return a == b
    }
    else if let a = lhsTrait, let b = rhsTrait {
        return a == b
    } 
    
    return false
}
