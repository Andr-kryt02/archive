//
//  VideosViewModel.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 2016-12-19.
//  Copyright © 2016 campfiire. All rights reserved.
//


import Foundation
import RxSwift
import RxCocoa
import RxDataSources

struct VideosViewModel : ViewModel {
    
    let title = "Campfiire series"
    private let bag = DisposeBag()
    
    weak var handler: UIViewController?
    
    init (handler: UIViewController) {
        self.handler = handler
        externalActions = ExternalActionsViewModel(handler: handler)
        
        providerViewModel.dataProvider.value = DataVideoProvider()
        
        
    }
    
    var displayData: Driver<[AnimatableSectionModel<String, Video>]> {
        return providerViewModel.displayDataDriver.map { (data) in
            return [AnimatableSectionModel(model: "",
                                           items: data)]
        }
    }
    
    let providerViewModel: FeedViewModel<DataVideoProvider> = FeedViewModel()
    let externalActions: ExternalActionsViewModel
    
    func openVideoPlayer(video : Video) {
        
        externalActions.video(video.url)

    }
    
}


extension VideosViewModel {
    
    struct DataVideoProvider: DataProvider {
        
        typealias DataType = Video
        
        func loadBatch(batch: Batch) -> Observable<[Video]> {
            
            if batch.offset != 0 { return Observable.just([]) }
            
            return Video.retrieveVideos()
            
        }
        
    }
    
}






