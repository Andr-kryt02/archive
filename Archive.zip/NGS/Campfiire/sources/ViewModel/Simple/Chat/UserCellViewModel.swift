//
//  UserCellViewModel.swift
//  Campfiire
//
//  Created by Andrew Seregin on 1/16/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import RxDataSources

struct UserCellViewModel
{
    let closeButtonHidden: Bool
    let containerColor: UIColor
    let titleAlignment: NSTextAlignment
    let action: TagSelectActionViewModel?
    let user : User?
    
    init(color : UIColor,
         titleAlignment : NSTextAlignment = NSTextAlignment.left,
         closeButtonHidden: Bool = true,
         action: TagSelectActionViewModel? = nil,
         user : User? = nil)
    {
        self.closeButtonHidden = closeButtonHidden
        self.containerColor = color
        self.titleAlignment = titleAlignment
        self.action = action
        self.user = user
    }
    
    func tagSelected()
    {
        action?.performSelectAction()
    }
}

extension UserCellViewModel : IdentifiableType, Equatable
{
    var identity : String
    {
        guard let u = self.user else
        {
            return "Add new user..."
        }
        
        return u.name
    }
}

func ==(lhs: UserCellViewModel, rhs: UserCellViewModel) -> Bool
{
    return lhs.identity == rhs.identity &&
        lhs.closeButtonHidden == rhs.closeButtonHidden
}

extension UserCellViewModel : CustomStringConvertible
{
    var description :String { return identity }
}

