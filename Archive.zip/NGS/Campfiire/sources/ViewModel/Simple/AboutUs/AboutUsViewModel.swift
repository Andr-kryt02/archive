//
//  AboutUsViewModel.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 02.11.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

struct AboutUsViewModel : ViewModel {

 internal weak var handler: UIViewController?
    

}
