//
//  CommentViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/19/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

struct CommentViewModel {
    
    let topBarColor: UIColor
    let headerTextColor: UIColor
    
    let comment: Comment
    
    var showsImage: Bool {
        return comment.pictureURL != nil
    }
    var showsReportButton: Bool {
        return comment.author != User.currentUser()!
    }
    
}
