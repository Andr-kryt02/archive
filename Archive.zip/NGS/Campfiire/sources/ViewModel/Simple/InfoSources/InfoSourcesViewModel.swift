//
//  InfoSourcesViewModel.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 2016-12-20.
//  Copyright © 2016 campfiire. All rights reserved.
//


import Foundation
import RxSwift
import RxCocoa
import RxDataSources

struct InfoSourcesViewModel : ViewModel {
    
    let title = "Info Sources"
    private let bag = DisposeBag()
    
    weak var handler: UIViewController?
    
    init (handler: UIViewController) {
        self.handler = handler
        
        externalActions = ExternalActionsViewModel(handler: handler)
        
        providerViewModel.dataProvider.value = InfoSourcesProvider()
        providerViewModel.handler = handler
        
        providerViewModel.displayDataDriver
            .drive(data)
            .addDisposableTo(bag)
        
        providerViewModel.loadingBatchDriver
            .drive( onNext: { [unowned h = handler] batch in
                
                var shouldAnimate = false
                if let b = batch, b.offset == 0 { ///animating only for the very first batch
                    shouldAnimate = true
                }
                
                h.changedAnimationStatusTo(status: shouldAnimate)
            })
            .addDisposableTo(bag)

        /////progress indicator
        
        indicator.asDriver()
            .drive(onNext: { [weak h = handler] (loading) in
                h?.changedAnimationStatusTo(status: loading)
            })
            .addDisposableTo(bag)
        
    }
    
    fileprivate let data = Variable<[InfoSource]>([])
    var displayData: Driver<[AnimatableSectionModel<String, InfoSource>]> {
        return data.asDriver().map { (data) in
            return [AnimatableSectionModel(model: "",
                                           items: data)]
        }
    }
    
    let providerViewModel: FeedViewModel<InfoSourcesProvider> = FeedViewModel()
    let externalActions: ExternalActionsViewModel
    fileprivate let indicator: ViewIndicator = ViewIndicator()
    
}

extension InfoSourcesViewModel {
    func openWebSite(at: IndexPath) {
        let item = data.value[at.row]
        externalActions.handleTrait(trait: .website, content: item.url)
    }
}

extension InfoSourcesViewModel {
    
    struct InfoSourcesProvider: DataProvider {
        
        typealias DataType = InfoSource
        
        func loadBatch(batch: Batch) -> Observable<[InfoSource]> {
            
            if batch.offset > 0 { return Observable.just([]) }
            
            return InfoSource.retriewSources(query : nil, batch : batch)
            
        }
        
    }
    
}
