//
//  LocationAccessoryViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 07.11.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import Foundation
import RxCocoa
import RxSwift


struct LocationAccessoryViewModel {
    
    let selectedLocation: Variable <SearchLocation?> = Variable(nil)
    
    let foundLocations: Variable <[SearchLocation]> = Variable([])
    let query: Variable <String?> = Variable(nil)
    
    init () {
        
        query.asObservable()
            .notNil()
            .debounce(0.2, scheduler: MainScheduler.instance)
            .filter { $0.lengthOfBytes(using: String.Encoding.utf8) > 2 }
            .flatMapLatest {
                LocationSearchManager.retreiveAppropriateLocation(location: $0)
                    .catchErrorJustReturn([])
            }
            .bindTo(foundLocations)
            .addDisposableTo(bag)
    }
    
    private let bag = DisposeBag()
    
}

extension LocationAccessoryViewModel {
    
    func locationClicked(at index:Int) {
        guard foundLocations.value.count > index else { return }
        
        let location = foundLocations.value[index]
        
        selectedLocation.value = location
    }
    
}
