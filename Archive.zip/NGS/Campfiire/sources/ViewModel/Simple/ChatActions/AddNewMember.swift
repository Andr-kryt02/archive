//
//  AddNewMember.swift
//  Campfiire
//
//  Created by Andrew Seregin on 1/16/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import Foundation
import RxSwift

class AddNewMember : TagSelectActionViewModel {
    
    weak var handler: UIViewController?
    unowned var chatReference: Variable<MultiuserChat>
    
    init(handler: UIViewController?, chatReference: Variable<MultiuserChat>) {
        self.handler = handler
        self.chatReference = chatReference
    }
    
    func performSelectAction() {
        
        let controller = R.storyboard.chats.membersViewController()!
        let viewModel = MembersViewModel(handler : controller)
                                         
        controller.viewModel = viewModel
        handler?.navigationController?.pushViewController(controller, animated: true)

        
    }
}
