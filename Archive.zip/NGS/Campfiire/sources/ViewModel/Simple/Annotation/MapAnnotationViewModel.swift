//
//  MapAnnotationViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/13/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

struct MapAnnotationViewModel {
    
    let pinImage: UIImage
    let showsReportButton: Bool
    
    init(pinImage: UIImage = R.image.locationPin()!,
         showsReportButton: Bool) {
        self.pinImage = pinImage
        self.showsReportButton = showsReportButton
    }
    
}
