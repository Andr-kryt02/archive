//
//  TraitCellViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/18/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import RxSwift
import RxCocoa
import RxDataSources

protocol TraitPresentable {
    func content(of trait: TraitType) -> String?
}

protocol TraitUpdateDelegate: class {
    func didUpdateItem(trait: TraitType, content: String?)
}

struct TraitCellViewModel {
    
    private let bag = DisposeBag()
    
    let title: String?
    let placeholder: String
    let image: UIImage
    let editable: Bool
    
    let traitType: TraitType
    weak var delegate: TraitUpdateDelegate?
    
    init?(traitType: TraitType,
          editable: Bool,
          value: TraitPresentable,
          hideOnEmptyContent: Bool,
          delegate: TraitUpdateDelegate? = nil) {
    
        let content = value.content(of: traitType)
        
        if hideOnEmptyContent && content.isEmpty {
            return nil
        }
        
        self.traitType = traitType
        self.editable = editable
        self.delegate = delegate
        self.title = content
        
        self.image = traitType.image
        self.placeholder = traitType.placeholder
        
    }
    
    func updateTrait(string: String) {
        
        var input: String? = nil
        if string.lengthOfBytes(using: .utf8) > 0 {
            input = string
        }
        
        delegate?.didUpdateItem(trait: traitType, content: input)
        
    }
    
}

extension TraitCellViewModel: IdentifiableType, Equatable {
    
    var identity: Int { return self.traitType.rawValue }
    
}

func ==(lhs: TraitCellViewModel, rhs: TraitCellViewModel) -> Bool {
    
    var equal = lhs.traitType == rhs.traitType &&
                lhs.editable == rhs.editable
    
    if !lhs.editable {
        equal = equal && (lhs.title == rhs.title)
    }
    
    return equal
}
