//
//  ExternalActionsViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/12/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

struct ExternalActionsViewModel: ViewModel {
    
    weak var handler: UIViewController?
    init(handler: UIViewController) {
        
        self.handler = handler
        
    }
    
    func handleTrait(trait: TraitType, content: String?) {
        
        guard let content = content else { return }
        
        switch trait {
        case .email: email(content)
        case .phoneNumber: call(content)
        case .location: fallthrough
        case .town: map(content)
        case .website: webSite(content)
        default: break
            
        }
        
    }
    
    func video(_ content: String) {
        guard let url = URL(string: content),
            UIApplication.shared.canOpenURL(url) else {
                handler?.presentErrorMessage(error: "Sorry, can open \(content)")
                return
        }
        
        guard UIApplication.shared.openURL(url) else {
            handler?.presentErrorMessage(error: "Seems like \(content) is invalid video")
            return
        }
    }
    
    private func call (_ content: String) {
        
        guard let url = URL(string:"tel://\(content)"),
            UIApplication.shared.canOpenURL(url) else {
            handler?.presentErrorMessage(error: "Seems like your device does not support calls")
                return
        }
        
        guard UIApplication.shared.openURL(url) else {
            handler?.presentErrorMessage(error: "Seems like \(content) is invalid phoneNumber")
            return
        }
        
        
    }
    
    
    private func email (_ content: String) {
    
        guard let mailURL = URL(string: "mailto://\(content)"),
            UIApplication.shared.canOpenURL(mailURL),
            UIApplication.shared.openURL(mailURL) else {
                handler?.presentErrorMessage(error: "Seems like your device is not configured for sending emails")
                return
        }
        
    }
    
    
    private  func map (_ content: String) {
        
        let url = "http://maps.apple.com/?q=" + content.replacingOccurrences(of: " ", with: "+")
        
        guard let mapUrl = URL(string: url),
            UIApplication.shared.canOpenURL(mapUrl),
            UIApplication.shared.openURL(mapUrl) else {
                handler?.presentErrorMessage(error: "Seems like your device is not configured for showing locations")
                return
        }
        
    }
    
    
    
    private func webSite (_ content: String) {
        
        guard let mapUrl = URL(string: content),
            UIApplication.shared.canOpenURL(mapUrl),
            UIApplication.shared.openURL(mapUrl) else {
                handler?.presentErrorMessage(error: "Seems like \"\(content)\" is invalid website")
                return
        }
        
    }
    
}
