//
//  File.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/18/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import RxDataSources

protocol TagSelectActionViewModel {
    
    func performSelectAction()
    
}

struct TagCellViewModel {
    
    let closeButtonHidden: Bool
    let containerColor: UIColor
    let title: String
    let titleAlignment: NSTextAlignment
    let action: TagSelectActionViewModel?
    
    init(title: String,
         color: UIColor,
         titleAlignment: NSTextAlignment = NSTextAlignment.left ,
         closeButtonHidden: Bool = true,
         action: TagSelectActionViewModel? = nil) {
        
        self.closeButtonHidden = closeButtonHidden
        self.containerColor = color
        self.titleAlignment = titleAlignment
        self.title = title
        self.action = action
        
    }
    
    func tagSelected() {
        action?.performSelectAction()
    }
    
}


extension TagCellViewModel: IdentifiableType, Equatable {
    
    var identity: String { return self.title }
    
}

func ==(lhs: TagCellViewModel, rhs: TagCellViewModel) -> Bool {
    
    return lhs.identity == rhs.identity &&
        lhs.closeButtonHidden == rhs.closeButtonHidden
    
}

extension TagCellViewModel : CustomStringConvertible {
    
    var description :String { return identity }
    
}
