//
//  AddHotspotTagAction.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/3/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift

class AddHotspotTagAction : TagSelectActionViewModel {
    
    internal weak var handler: UIViewController?
    unowned var hotspotReference: Variable<HotSpot>
    init(handler: UIViewController?, hotspotReference: Variable<HotSpot>) {
        
        self.handler = handler
        self.hotspotReference = hotspotReference
        
    }
    
    func performSelectAction() {
        
        let _ =
        handler?.presentTextQuestion(question: DisplayMessage(title: "New tag",
                                                             description: "What's it's name?"))
            .subscribe(onNext: { [unowned h = hotspotReference] text in
                
                var hotspot = h.value
                hotspot.tags.append( Tag(name: text) )
                h.value = hotspot
                
            })
    }
    
}

