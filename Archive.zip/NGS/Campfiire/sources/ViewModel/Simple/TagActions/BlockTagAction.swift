//
//  BlockTagAction.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/1/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift

class BlockTagAction : TagSelectActionViewModel {
    
    internal weak var handler: UIViewController?
    unowned var userReference: Variable<User?>
    init(handler: UIViewController, userReference: Variable<User?>) {
        self.handler = handler
        self.userReference = userReference
    }
    
    func performSelectAction() {
        
        let user = userReference.value!
        
        var observable: Observable<User>!
        
        if (user.isBlocked) {
            observable = FriendsManager.unblock(user: user)
        }
        else {
            observable = FriendsManager.block(user: user)            
        }
        
        observable
            .silentCatch(handler: handler)
            .subscribe(onNext: { [unowned r = userReference] (u) in
                r.value = u
            })
            .addDisposableTo(bag)
        
    }
    
    fileprivate let bag = DisposeBag()
    
}
