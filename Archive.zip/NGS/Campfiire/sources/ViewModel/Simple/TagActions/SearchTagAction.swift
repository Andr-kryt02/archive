//
//  SearchTagAction.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/25/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import RxSwift

class SearchTagAction: TagSelectActionViewModel {
    
    private unowned var searchFilterReference: Variable<SearchUsersFilter?>
    
    private let tag: Tag
    
    init(tag: Tag,
         searchFilterReference: Variable<SearchUsersFilter?>) {
        
        self.tag = tag
        self.searchFilterReference = searchFilterReference
    }
    
    func performSelectAction() {
        
        searchFilterReference.value = SearchUsersFilter(query: nil,
                                                   ageRange: nil,
                                                   gender: nil,
                                                   location: nil,
                                                   tag: tag)
        
    }
    
}
