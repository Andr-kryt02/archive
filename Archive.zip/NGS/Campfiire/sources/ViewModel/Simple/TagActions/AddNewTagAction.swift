//
//  AddNewTagAction.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/1/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift

class AddNewTagAction : TagSelectActionViewModel {
    
    internal weak var handler: UIViewController?
    unowned var userReference: Variable<User?>
    init(handler: UIViewController, userReference: Variable<User?>) {
        
        self.handler = handler
        self.userReference = userReference
        
    }
    
    func performSelectAction() {
        
        let _ =
        handler?.presentTextQuestion(question: DisplayMessage(title: "New tag",
                                                       description: "What's it's name?"))
            .subscribe(onNext: { [unowned r = userReference] text in
                
                var user = r.value!
                user.tags.append( Tag(name: text) )
                r.value = user
                
            })
    }
    
}
