//
//  ChangePasswordAction.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/1/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire

class ChangePasswordAction: TagSelectActionViewModel {
    
    weak var handler: UIViewController?
    unowned var userReference: Variable<User?>
    
    init(handler: UIViewController, userReference: Variable<User?>) {
        self.handler = handler
        self.userReference = userReference
    }
    
    func performSelectAction() {
        
        handler?.presentMessage(message: DisplayMessage(title: "Sorry",
                                                        description: "It's not currently possible to chage password within an App"))
        
        return;
        
        let _ =
        handler?.presentcChangePasvordForm(question: DisplayMessage(title: "Change password",
                                                             description: "What's your new password?"))
            .filter { [weak h = handler] input in
                
                let validator = RegistrationValidation(email: Observable.just(nil),
                                                       password: Observable.just(input.1),
                                                       confirmPassword: Observable.just(input.2),
                                                       name: Observable.just(nil),
                                                       location: Observable.just(nil))
                
                let outcome = validator.passwordValid.value
                
                guard outcome.isValid else {
                    
                    h?.presentErrorMessage(error: outcome.failReason!)
                    
                    return false
                }
                
                return true
            }
            .flatMap { (input) -> Observable<User> in
                
                let request = UserAuthorizationRouter.changePassword(oldPassword: input.0,
                                                            newPassword: input.1)
                                                            
                
                return Alamofire.request(request)
                    .rx_campfiireResponse(CampfiireResponse<User>.self)
                
            }
            .silentCatch(handler: handler)
            .subscribe(onNext: { [weak h = handler] text in
                
                h?.presentMessage(message: DisplayMessage(title: "Success",
                                                          description: "Your password has been changed"))
                
            })

    }
    
}
