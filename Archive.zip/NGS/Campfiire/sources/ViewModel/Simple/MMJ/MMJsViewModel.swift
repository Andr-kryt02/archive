//
//  MMJViewModel.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 12.12.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa
import RxDataSources

struct MMJsViewModel : ViewModel {

    let title = "Newsfeeds"
    private let bag = DisposeBag()
    
    weak var handler: UIViewController?
    
    init (handler: UIViewController) {
        self.handler = handler
        
        externalActions = ExternalActionsViewModel(handler: handler)
        
        providerViewModel.dataProvider.value = DataMMJsProvider()
        
    }
   
    var displayData: Driver<[AnimatableSectionModel<String, MMJ>]> {
        return providerViewModel.displayDataDriver.map { (data) in
            return [AnimatableSectionModel(model: "",
                                           items: data)]
        }
    }

    let providerViewModel: FeedViewModel<DataMMJsProvider> = FeedViewModel()
    let externalActions: ExternalActionsViewModel
    
    func openWebSite(item : MMJ) {
        externalActions.handleTrait(trait: .website, content: item.url)
    }
    
}


extension MMJsViewModel {
    
    struct DataMMJsProvider: DataProvider {
        
        typealias DataType = MMJ
        
        func loadBatch(batch: Batch) -> Observable<[MMJ]> {
            
            return MMJ.retrieveWebNews(batch : batch)
            
        }
        
    }
    
}
