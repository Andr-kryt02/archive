//
//  MainViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/25/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

class MainViewModel {
    
    static let shared = MainViewModel()
    
    let router = MainRouter()
    
    func logout() {
        //NotificationManager.flushDeviceToken()
        //LocationManager.instance.endMonitoring()
        
        ImageRetreiver.flushCache()
        
        let _ = ChatManager.disconnect().subscribe(onCompleted: {})
        
        AccessToken.token = nil
        User.currentUser()?.logout()
        
        User.storage = [:]
        HotSpot.storage = [:]
        Camp.storage = [:]
        
        router.authorizationRout(animated: true)
    }
    
}
