//
//  SettingsViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/25/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift

struct SettingsViewModel: ViewModel {
    
    
    internal weak var handler: UIViewController?
    init(handler: UIViewController) {
        self.handler = handler
        
    }
    
    fileprivate let settingsManager = SettingsManager()
    
    var pushObservable: Observable<Bool> {
        return settingsManager.pushEnabled.observable
    }
    
    var eventObservable: Observable<Bool> {
        return settingsManager.showEventsInFeed.observable
    }
    
    var attachmentsObservable: Observable<Bool> {
        return settingsManager.attachmentsInCellular.observable
    }
    
    var dateFormatObservable: Observable<Bool> {
        return settingsManager.timeFormat24.observable
    }
    
    var profileVisibilityObservable: Observable<Int> {
        return settingsManager.profileVisibility.observable
            .map {
                switch $0 {
                    
                case .nobody: return 0
                case .friendsOnly: return 1
                case .allUsers: return 2
                    
                }
            }
    
    }
}

extension SettingsViewModel {
    
    func pushSwitchChanged(status: Bool) {
        settingsManager.pushEnabled.update(with: status)
    }
    
    func eventInFeedChanged(status: Bool) {
        settingsManager.showEventsInFeed.update(with: status)
    }
    
    func attachmentCellularChanged(status: Bool) {
        settingsManager.attachmentsInCellular.update(with: status)
    }
    
    func dateFormatChanged(status: Bool) {
        settingsManager.timeFormat24.update(with: status)
    }
    
    
    func profileVisibilityChanged(selectedIndex : Int) {
    
        var visibility : ProfileVisibility
        
        switch selectedIndex {
        
        case 0 : visibility = .nobody
        case 1 : visibility = .friendsOnly
        default : visibility = .allUsers
            
        }
        
        settingsManager.profileVisibility.update(with: visibility)
    }
    
    
    
}
