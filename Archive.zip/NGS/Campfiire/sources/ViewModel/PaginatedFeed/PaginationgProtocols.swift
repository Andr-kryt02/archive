//
//  Protocols.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/18/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift

protocol DataProvider {
    
    associatedtype DataType
    associatedtype BatchType
    
    func nextBatch(loadedData: [DataType]) -> BatchType
    func loadBatch(batch: BatchType) -> Observable<[DataType]>
}


////default batch provider
struct Batch {
    let offset:Int
    let limit:Int
}

extension DataProvider where Self.BatchType == Batch {
    
    func nextBatch(loadedData: [DataType]) -> BatchType {
        return Batch(offset: loadedData.count, limit: 10)
    }
    
}
