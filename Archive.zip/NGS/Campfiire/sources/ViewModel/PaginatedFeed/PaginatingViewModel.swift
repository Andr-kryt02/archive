//
//  PaginatingViewModel.swift
//  Night Life
//
//  Created by Vlad Soroka on 2/15/16.
//  Copyright © 2016 com.NightLife. All rights reserved.
//

import Foundation
import RxSwift

class PaginatingViewModel<S: DataProvider> {
    
    fileprivate let dataProvider: S
    init(dataProvider: S) {
        
        self.dataProvider = dataProvider
        
    }
    
    func load (nextPageTrigger: Observable<Void>) -> Observable<[S.DataType]> {
        
        return recursivelyLoad(  loadedSoFar: [],
                    dataProvider: dataProvider,
                 nextPageTrigger: nextPageTrigger)
                //.startWith([])
    }
    
    /////loading progress
    
    var loadingBatchObservable: Observable<S.BatchType?> {
        return loadingBatchVariable.asObservable()
    }
    
    fileprivate let loadingBatchVariable: Variable<S.BatchType?> = Variable(nil)
    
}

extension PaginatingViewModel {
    
    fileprivate func recursivelyLoad
        (loadedSoFar: [S.DataType],
        dataProvider: S,
        nextPageTrigger: Observable<Void>) -> Observable<[S.DataType]> {
        
        let batch = dataProvider.nextBatch( loadedData: loadedSoFar )
        self.loadingBatchVariable.value = batch
        
        return Observable.just(0)
            .subscribeOn(OperationQueueScheduler(operationQueue: OperationQueue()))
            .flatMap { _ -> Observable<[S.DataType]> in
                dataProvider.loadBatch(batch: batch)
            }
            .do(onNext: { [unowned self] _ in
                self.loadingBatchVariable.value = nil
            }, onError: { [unowned self] _ in
                self.loadingBatchVariable.value = nil
            }, onCompleted: { [unowned self] in
                self.loadingBatchVariable.value = nil    
            })
            .flatMap { loadedNew -> Observable<[S.DataType]> in
                
                guard loadedNew.count > 0 else {
                    
                    let endSignal = Observable<[S.DataType]>.empty()
                    
                    if loadedSoFar.count == 0 {
                        return Observable.just([]).concat(endSignal)
                    }
                    
                    return endSignal
                }
                
                var totalResults = loadedSoFar
                totalResults.append(contentsOf: loadedNew)
                
                return Observable
                    .concat([
                    // return loaded immediately
                    Observable.just(totalResults),
                    // wait until next page can be loaded
                    Observable.never().takeUntil(nextPageTrigger),
                    // load next page
                    self.recursivelyLoad(loadedSoFar: totalResults, dataProvider: dataProvider, nextPageTrigger: nextPageTrigger)
                    ])
                
                
        }
    }

}

