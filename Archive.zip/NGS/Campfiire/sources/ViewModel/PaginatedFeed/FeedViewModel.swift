//
//  FeedViewModel.swift
//  Night Life
//
//  Created by Vlad Soroka on 3/17/16.
//  Copyright © 2016 com.NightLife. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa

class FeedViewModel<DP: DataProvider> where DP.DataType : Equatable {
    
    var currentData : [DP.DataType] {
        return displayData.value
    }
    
    var displayDataDriver : Driver<[DP.DataType]> {
        return displayData.asDriver()
            .skip(1)///initial empty value of variable
    }
    
    var loadingBatchDriver: Driver<DP.BatchType?> {
        return paginatedFeedVariable
            .asObservable()
            .notNil()
            .flatMapLatest { $0.loadingBatchObservable }
            .asDriver(onErrorJustReturn: nil)
    }
    
    ///these are inputs for FeedViewModel
    ///changing of any of them causes reload for displayData
    ///make sure to set some values or feed will remain empty
    let dataProvider: Variable<DP?> = Variable(nil)
    let pageTrigger: Variable<Observable<Void>?> = Variable(nil)
    
    weak var handler: UIViewController?
    
    convenience init(dataProvider: DP) {
        self.init()
        
        self.dataProvider.value = dataProvider
    }
    
    init() {
        
        let trigger = pageTrigger.asObservable().notNil()
        let dp = dataProvider.asObservable().notNil()
    
        let paginatedFeedSignal =
            Observable.combineLatest(trigger, dp) { ($0, $1) }
                .map { (trigger, dp) -> (PaginatingViewModel<DP>, Observable<[DP.DataType]>) in
                    
                    ///happens when feed will be reloaded (probably worth cleaning in memmory cache here?)
                    
                    ///retreiving observable from paginatingViewModel
                    
                    let pf = PaginatingViewModel(dataProvider: dp)
                    
                    return (pf,  pf.load(nextPageTrigger: trigger))
                }
                .share()
        
        ///keeping strong ref
        paginatedFeedSignal.map { $0.0 }
            .bindTo(paginatedFeedVariable)
            .addDisposableTo(disposeBag)
                
        
        paginatedFeedSignal
            .flatMapLatest{ [unowned self] (pf) -> Observable<[DP.DataType]> in
        
                let paginatedFeed = pf.1
                    .silentCatch(handler: self.handler)
                
                ///on dataSource changing we must clear stored addedFeedDataItem
                ///not the best solution to do this manually though
                self.addedFeedDataItem.value = nil
                self.removedFeedDataItem.value = nil
                
                ///keeping track of items that might will have been added
                let addedItems = self.addedFeedDataItem.asObservable()
                    .filter { $0 != nil }.map { $0! }
                    .scan([]) { [$1] + $0 }
                    .startWith([])
                
                let removedItems = self.removedFeedDataItem.asObservable()
                    .filter { $0 != nil }.map { $0! }
                    .scan([]) { $0 + [$1] }
                    .startWith([])
                
                ///binding result to display data
                return Observable.combineLatest(addedItems, paginatedFeed, removedItems) { a, p, r -> [DP.DataType] in
                    (a + p).filter {  !r.contains($0) }
                }
                
            }
            .bindTo(displayData)
            .addDisposableTo(disposeBag)
    }


    private let disposeBag = DisposeBag()
    
    ////current paginated loader
    ///we need a strong ref to it to be able to track loading progress
    fileprivate let paginatedFeedVariable: Variable<PaginatingViewModel<DP>?> = Variable(nil)
    
    ///data that is to be displayed (output)
    fileprivate var displayData : Variable<[DP.DataType]> = Variable([])
    
    ///items that are to be inserted to the head of items sequence
    ///can be altered with insertFeedItemAtBegining: method
    fileprivate let addedFeedDataItem : Variable<DP.DataType?> = Variable(nil)
    fileprivate let removedFeedDataItem : Variable<DP.DataType?> = Variable(nil)
    
}

extension FeedViewModel {
    
    func insertFeedItemAtBegining(item: DP.DataType) {
        addedFeedDataItem.value = item
    }
    
    func removeFeedItem(item: DP.DataType) {
        removedFeedDataItem.value = item
    }
    
    func item(at index: Int) -> DP.DataType {
        return displayData.value[index]
    }
    
}
 
