//
//  EventsViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/29/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

import RxSwift
import RxCocoa
import Alamofire

struct EventsViewModel: ViewModel {
    
    let feedViewModel: NewsFeedTableViewModel<EventsProvider>
    
    var dataRepresentationButtonImage: Driver<UIImage> {
        return showsCalendar.asDriver().map {
            $0 ? R.image.eventsListIcon()! : R.image.eventsCalendarIcon()!
        }
    }
    
    let showsCalendar = Variable(true)
    
    let highlightDates = Variable<[Date]>([])
    
    weak var handler: UIViewController?
    init (handler: UIViewController) {
        self.handler = handler
        
        feedViewModel = NewsFeedTableViewModel(handler: handler)
        
        feedViewModel.paginatedViewModel.dataProvider.value = EventsProvider(date: nil)
        
        feedViewModel.paginatedViewModel.loadingBatchDriver
            .drive( onNext: { [unowned h = handler] batch in
                
                var shouldAnimate = false
                if let b = batch, b.offset == 0 { ///animating only for the very first batch
                    shouldAnimate = true
                }
                
                h.changedAnimationStatusTo(status: shouldAnimate)
            })
            .addDisposableTo(bag)
        
        EventManager.monthHighlightDates()
            .bindTo(highlightDates)
            .addDisposableTo(bag)
        
    }
 
    fileprivate let bag = DisposeBag()
}

extension EventsViewModel {
    
    func changeDataRepresentationStyle() {
        showsCalendar.value = !showsCalendar.value
    }
    
    func changeEventsDate(date: Date) {
        
        feedViewModel.paginatedViewModel.dataProvider.value = EventsProvider(date: date)
        
    }
    
}

extension EventsViewModel {
    
    struct EventsProvider: DataProvider {
        
        typealias DataType = NewsFeedTypes
        
        let date: Date?
        
        func loadBatch(batch: Batch) -> Observable<[NewsFeedTypes]> {
            
            let request = EventRouter.list(date: date,
                                           batch: batch)
            return Alamofire.request(request)
                    .rx_campfiireResponse(CampfiireArrayResponse<Campfiire.Event>.self)
                    .map { events in
                        events.map { event in
                            
                            event.saveEntity()
                            
                            return .event(event: event)
                        }
            }
            
            ///uncomment for fake events
            
//            guard batch.offset < 10 else { return Observable.just([]) }
//            
//            var fakeEvents: [Event] = []
//            for _ in 0...batch.limit / 2 {
//                
//                let fakeEvent = Event.fakeEntity()
//                fakeEvent.saveEntity()
//                
//                fakeEvents.append( fakeEvent )
//            }
//            
//            return Observable.create({ (observer) -> Disposable in
//                
//                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
//                    observer.onNext( fakeEvents.map { .event(event: $0) } )
//                    observer.onCompleted()
//                }
//                
//                return Disposables.create()
//            })
            
        }
        
    }
    
}
