//
//  EventDetailViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/29/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa

struct EventDetailsViewModel: ViewModel {
    
    private let bag = DisposeBag()
    
    let indicator = ViewIndicator()
    
    var eventDriver: Driver<Event> {
        return eventVariable.asDriver().notNil()
    }
    fileprivate let eventVariable: Variable<Event?> = Variable(nil)
    
    
    weak var handler: UIViewController?
    init (handler: UIViewController, event: Event) {
        self.handler = handler
        
        EventManager.details(of: event)
            .trackView(viewIndicator: indicator)
            .silentCatch(handler: handler)
            .bindTo(eventVariable)
            .addDisposableTo(bag)
        
        
        indicator.asDriver()
            .drive(onNext: { [weak h = handler] (loading) in
                h?.changedAnimationStatusTo(status: loading)
            })
            .addDisposableTo(bag)
        
    }
    
}
