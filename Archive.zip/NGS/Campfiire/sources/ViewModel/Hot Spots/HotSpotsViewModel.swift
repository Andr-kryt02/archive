//
//  HotSpotsViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/25/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import MapKit

struct HotSpotsViewModel: ViewModel {
    
    weak var handler: UIViewController?
    init(handler: UIViewController,
         initialRegion: MKCoordinateRegion) {
        self.handler = handler
        
        visibleRegion = Variable(initialRegion)
        requestRegionVariable = Variable(initialRegion)

        
        
//        searchBarHidden.asObservable()
//            .filter { $0 }
//            .subscribe(onNext: { [weak q = query] (_) in
//                q?.value = ""
//            })
//            .addDisposableTo(bag)
        
        let a = requestRegionVariable.asObservable()
            .distinctUntilChanged()
        
        let b = query.asObservable()
            .debounce(0.2, scheduler: MainScheduler.instance)
        
        let c = followedOnlyHotspots.asObservable()
        let d = refreshTrigger.asObservable()
        
        Observable.combineLatest(a,b,c,d) { ($0, $1, $2, $3) }
            .flatMapLatest { q in
                HotspotManager.retreiveHotspots(for: q.0,
                                                query: q.1,
                                                followedOnly: q.2)
            }
            .silentCatch(handler: handler)
            .bindTo(annotations)
            .addDisposableTo(bag)
        
    }
    
    let searchBarHidden = Variable(true)
    let followedOnlyHotspots = Variable(false)
    fileprivate let refreshTrigger = Variable(false)
    
    let annotations: Variable<[AnnotationWrapper]> = Variable([])
    let visibleRegion: Variable<MKCoordinateRegion> /// used for changing map visible region
    
    let presentHotspotTrigger: Variable<HotSpot?> = Variable(nil)
    
    fileprivate let bag = DisposeBag()
    fileprivate let query: Variable<String?> = Variable(nil)
    /// used as trigger to request new annotations
    fileprivate let requestRegionVariable: Variable<MKCoordinateRegion>
    
}

extension HotSpotsViewModel {
    
    func annotationClicked(annotation: AnnotationWrapper) {
        
        if let cluster = annotation.state as? HotSpotCluster {
            visibleRegion.value = cluster.nextCoordinateRegion
        }
        else if let hotspot = annotation.state as? HotSpot {
            presentHotspotTrigger.value = hotspot
        }
        
    }
    
    func reportRegionChange(region: MKCoordinateRegion) {
        requestRegionVariable.value = region
    }
    
    
    func searchQueryChanged(query: String) {
        self.query.value = query
    }
    
    func switchSearchBarStatus() {
        
        let isHidden = searchBarHidden.value
        
        searchBarHidden.value = !isHidden
    }
    
    func switchFollowedOnlyStatus() {
        let isFollowedOnly = followedOnlyHotspots.value
        
        followedOnlyHotspots.value = !isFollowedOnly
    }
    
    func reportHotspotClicked(wrapper: AnnotationWrapper) {
        
        guard let hotspot = wrapper.state as? HotSpot else {
            fatalError("AnnotationWrapper is not a HotSpot as required")
        }
        
        HotspotManager.reportHotSpot(hotspot: hotspot)
            .silentCatch()
            .subscribe(onNext: { [weak h = handler] _ in
                h?.presentMessage(message: DisplayMessage(title: "Thank you",
                                                                     description: "Our moderators will take it from here"))
                
            }).addDisposableTo(bag)

    }
    
    func refreshMap() {
        refreshTrigger.value = true
    }
    
    func annotationViewModel(for wrapper: AnnotationWrapper) -> MapAnnotationViewModel {
        
        guard let hotspot = wrapper.state as? HotSpot else {
            fatalError("HotspotViewModel can provide AnnotationViewModels only for hotspots")
        }
        
        let isOwnHotspot = hotspot.author! == User.currentUser()!
        let image = isOwnHotspot ? R.image.locationPinOwn()! : R.image.locationPin()!
        
        return MapAnnotationViewModel(pinImage: image,
                                      showsReportButton: !isOwnHotspot)
        
    }
    
}
