//
//  HotspotDetailsViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/1/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa
import RxDataSources

struct HotspotDetailsViewModel: ViewModel {
    
    weak var handler: UIViewController?
    
    let hotSpotVariable: Variable<HotSpot>
    var hotSpotDriver: Driver<HotSpot> {
        return hotSpotVariable.asDriver()
    }
    
    let paginatedViewModel: FeedViewModel<CommentProvider> = FeedViewModel(  )
    var commentsDataSource: Driver<[AnimatableSectionModel<String, Comment>] > {
        return paginatedViewModel.displayDataDriver.map {
            [AnimatableSectionModel(model: "", items: $0)]
        }
        
    }
    
    var starIconImage: UIImage {
        return hotSpotVariable.value.isFolowedByCurrentUser ? R.image.startFavorite()! : R.image.uNstartFavorite()!
    }
    
    let indicator = ViewIndicator()
    let rightButtons: Variable<RightButtons> = Variable([])
    
    ////triggers
    let photoIndexTrigger: Variable<Int> = Variable(0)
    let nextUserTrigger: Variable<User?> = Variable(nil)
    
    init(handler: UIViewController,
         hotSpot: HotSpot,
         startWith initialPhoto: Photo? = nil) {
        self.handler = handler
        
        var o: Variable<HotSpot>! = hotSpot.observableEntity()
        if o == nil {
            hotSpot.saveEntity()
            o = hotSpot.observableEntity()!
        }
        hotSpotVariable = o
        
        ///refreshing hotspot with latest data
        HotspotManager.refreshHotSpot(hotspot: hotSpot)
            .trackView(viewIndicator: indicator)
            .do(onError: { [weak h = handler] (error) in
                h?.popBack(animated: true)
            })
            .silentCatch(handler: handler)
            .subscribe(onNext: { [unowned m = optimisticManager,
                                  weak photoTrigger = photoIndexTrigger] hotspot in
                m.confirmedModel = hotspot

                if let p = initialPhoto,
                   let index = hotspot.photos.index(of: p) {
                    
                    photoTrigger?.value = index
                }
                
            })
            .addDisposableTo(bag)
        
        ////optimisticManager
        optimisticManager.likeActionOutcome
            .subscribe(onNext: { (hotspot) in
                hotspot.saveEntity()
            })
            .addDisposableTo(bag)
        
        
        ///indicator
        indicator.asDriver()
            .drive(onNext: { [weak h = handler] (loading) in
                h?.changedAnimationStatusTo(status: loading)
            })
            .addDisposableTo(bag)
        
        ///photo added
        fdTakeController.rxex_photo()
            .flatMap { [unowned i = indicator] image in
                return HotspotManager.addNew(image: image, for: hotSpot)
                            .trackView(viewIndicator: i)
            }
            .silentCatch(handler: handler)
            .map { _ in 0 }
            .bindTo(photoIndexTrigger)
            .addDisposableTo(bag)
    
        ////right buttons
        hotSpotVariable.asObservable() ////it also depends on isFollowed status. Because star icon has different states based on it
            .map { $0.author }
            .notNil()
            .map { u -> RightButtons in
                return u == User.currentUser()! ? [.edit] : [.star]
            }
            .bindTo(rightButtons)
            .addDisposableTo(bag)
        
        ////animated comments datasource
        paginatedViewModel.dataProvider.value = CommentProvider(hotspot: hotSpot)
        
    }
    
    fileprivate var fdTakeController: FDTakeController = {
        let d = FDTakeController()
        d.allowsVideo = false
        return d
    }()
    fileprivate let optimisticManager = OptimisticModelManager<HotSpot>()
    fileprivate let bag = DisposeBag()
    
    struct RightButtons: OptionSet {
        let rawValue: Int
        
        static let edit = RightButtons(rawValue: 1)
        static let star = RightButtons(rawValue: 2)
        
    }
}

extension HotspotDetailsViewModel {
    
    func postPhotoTapped() {
        fdTakeController.present()
    }
    
    func newCommentTapped() {
        
        let hotspot = hotSpotVariable.value
        
        handler?.presentTextQuestion(question: DisplayMessage(title: "New comment",
                                                             description: "Type in your comment"))
            .flatMap { HotspotManager.postCommentWithText(text: $0, for: hotspot) }
            .subscribe(onNext: { [weak feed = paginatedViewModel] comment in
                
                feed?.insertFeedItemAtBegining(item: comment)
            })
            .addDisposableTo(bag)
        
        
    }
    
    func commentAuthorTapped(at ip: IndexPath) {
        
        nextUserTrigger.value = paginatedViewModel.item(at: ip.row).author
        
    }
    
    func reportCommentTapped(at ip: IndexPath) {
        
        let comment = paginatedViewModel.item(at: ip.row)
        
        HotspotManager.reportHotSpotComment(comment: comment)
        .silentCatch()
        .subscribe(onNext: { [weak h = handler] _ in
            h?.presentMessage(message: DisplayMessage(title: "Thank you",
                                                            description: "Comment has been reported"))

        }).addDisposableTo(bag)
        
        
        
        
    }
    
    func reportPhotoTapped(at index: Int) {
        
        let photo = hotSpotVariable.value.photos[index]
        
        HotspotManager.reportHotSpotPhoto(photo: photo)
            .silentCatch()
            .subscribe(onNext: { _ in
                self.handler?.presentMessage(message: DisplayMessage(title: "Thank you",
                                                                     description: "Our moderators will take it from here"))
                
            }).addDisposableTo(bag)
        
    }
    
    func switchFollowStatus() {
        
        optimisticManager.queueChange(change: !hotSpotVariable.value.isFolowedByCurrentUser,
                                      model: hotSpotVariable.value)
        
    }
    
}

extension HotspotDetailsViewModel {
    
    struct CommentProvider : DataProvider {
        
        typealias DataType = Comment
        
        let hotspot: HotSpot
        
        func loadBatch(batch: Batch) -> Observable<[Comment]> {
            return HotspotManager.retreiveComments(for: hotspot, batch: batch)
        }
        
    }
    
    func commentViewModel(for comment: Comment) -> CommentViewModel {
        return CommentViewModel(topBarColor: UIColor.hotspotCommentTopBar,
                                headerTextColor: UIColor.hotspotCommentTopBarFont,
                                comment: comment)
    }
    
}
