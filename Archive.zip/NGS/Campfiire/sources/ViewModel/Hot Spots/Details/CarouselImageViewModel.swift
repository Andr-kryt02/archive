//
//  CarouselImageViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/22/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import RxSwift
import RxCocoa

struct CarouselImageViewModel {
    
    let photoVariable: Variable<HotspotPhoto>
    var photoDriver: Driver<Photo> {
        return photoVariable.asDriver().map { $0.photo }
    }
    
    init(photo: Photo) {
        
        let hotspotPhoto = HotspotPhoto(photo: photo,
                                        hotspot: nil)
        
        photoVariable = Variable( hotspotPhoto )
        
        optimisticManager.confirmedModel = hotspotPhoto
        optimisticManager.likeActionOutcome
            .bindTo(photoVariable)
            .addDisposableTo(bag)
    }
    
    func likePhotoTapped() {
        
        ///here we have just a snippet of what might have been stored in Hotspot entity
        let photo = photoVariable.value
        
        optimisticManager.queueChange(change: !photo.photo.isLikedByCurrentUser,
                                      model: photo)
        
    }
    
    fileprivate let optimisticManager = OptimisticModelManager<HotspotPhoto>()
    fileprivate let bag = DisposeBag()
    
}
