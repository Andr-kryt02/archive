//
//  UpsertHotspotViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/3/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

import RxSwift
import RxDataSources

struct UpsertHotspotViewModel : ViewModel {
 
    var commitButtonTitle: String { return isEditing ? "Delete Hot Spot" : "Create Hot Spot" }
    var commitButtonColor: UIColor { return isEditing ? UIColor.destructiveRed : UIColor.acceptanceGreen }
    
    var followersHidden: Bool { return !isEditing }
    var applyButtonHidden: Bool { return !isEditing }
    
    var observableHotspot: Observable<HotSpot> {
        return discardableHotspot.asObservable()
    }
    var navigationTitleString: Observable<String> {
        return observableHotspot
            .map { $0.name }
            .map { $0.lengthOfBytes(using: .utf8) > 0 ? $0 : "New Hot Spot" }
    }
    
    var titleText: String { return discardableHotspot.value.name }
    var descriptionText: String { return discardableHotspot.value.description }
    
    var tags: Observable<[AnimatableSectionModel<String, TagCellViewModel>]> {
        return observableHotspot
            .map { $0.tags }
            .map { [weak h = handler,
                    unowned hs = discardableHotspot] tags -> [TagCellViewModel] in
                
                var answer = tags.map { tag in
                    TagCellViewModel(title: tag,
                                     color: UIColor.userTagRegular,
                                     closeButtonHidden: false)
                }
                
                answer.append( TagCellViewModel(title: "Add new tag...",
                                                color: UIColor.userTagRegular,
                                                titleAlignment: .center,
                                                action: AddHotspotTagAction(handler: h,
                                                                            hotspotReference: hs))
                )
                
                return answer
            }
            .map { return [AnimatableSectionModel(model: "",
                                                  items: $0)] }
        
    }
    
    fileprivate var avatar : Variable<UIImage?> = Variable(nil)
    
    let indicator = ViewIndicator()
    
    weak var handler: UIViewController?
    init(handler: UIViewController, initialHotspot: HotSpot?) {
        self.handler = handler
        
        isEditing = initialHotspot != nil
        
        ///hotspot initializatino
        
        var hotspotToUpsert: HotSpot! = initialHotspot
        if hotspotToUpsert == nil {
            var emptyHotspot = HotSpot(JSON: [:])!
            emptyHotspot.id = 0
            emptyHotspot.author = User.currentUser()!
            emptyHotspot.saveEntity()
            hotspotToUpsert = emptyHotspot
        }
        
        discardableHotspot = Variable(hotspotToUpsert)
        
        ///avatar selection
        avatar.asObservable()
            .notNil()
            .map { image -> String in
                
                let fakeURL = "com.campfire.fakeURL.hotspot.\(image.hashValue)"
                
                ImageRetreiver.registerImage(image: image, forKey: fakeURL)
                
                return fakeURL
            }
            .map { [unowned d = discardableHotspot] fakeURL in
                var hs = d.value
                hs.imageURL = fakeURL
                return hs
            }
            .bindTo(discardableHotspot)
            .addDisposableTo(bag)
        
        ///avatar selection
        /*fdTakeController.rxex_photo()
            .map { image -> String in

                let fakeURL = "com.campfire.fakeURL.hotspot.\(image.hashValue)"
                
                ImageRetreiver.registerImage(image: image, forKey: fakeURL)
                
                return fakeURL
            }
            .map { [unowned d = discardableHotspot] fakeURL in
                var hs = d.value
                hs.imageURL = fakeURL
                return hs
            }
            .bindTo(discardableHotspot)
            .addDisposableTo(bag)*/
        
        ///location updating
        let editing = isEditing
        LocationManager.instance.lastRecordedLocationObservable
            .filter { _ in !editing } /// in case hotspot is in editing mode we don't want to alter it's location
            .map { [unowned d = discardableHotspot] location in
                var hs = d.value
                hs.location = location
                return hs
            }
            .bindTo(discardableHotspot)
            .addDisposableTo(bag)
        
        ////address binding
        if !editing { /// on hotspot creation
            
            discardableHotspot.asObservable()
                .distinctUntilChanged { (lhs, rhs) -> Bool in
                    return lhs.latitude == rhs.latitude && lhs.longitude == rhs.longitude
                }
                .map { $0.location }
                .flatMap { LocationSearchManager.retreiveAdressFor(location: $0) }
                .map { [unowned d = discardableHotspot] adress in
                    var hs = d.value
                    hs.adress = adress
                    return hs
                }
                .bindTo(discardableHotspot)
                .addDisposableTo(bag)
            
        }
        
        
        ////spinner binding
        indicator.asDriver()
            .drive(onNext: { [weak h = handler] (loading) in
                h?.changedAnimationStatusTo(status: loading)
            })
            .addDisposableTo(bag)
        
    }

    fileprivate let isEditing: Bool
    fileprivate let discardableHotspot: Variable<HotSpot>
    fileprivate var fdTakeController: FDTakeController = {
        let d = FDTakeController()
        d.allowsVideo = false
        d.allowsEditing = false
        return d
    }()
    
    fileprivate let bag = DisposeBag()
    
}

extension UpsertHotspotViewModel {
    
    func selectAvatarClicked(cropFunction : @escaping (UIImage) -> ()) {
        fdTakeController.present()
        
        fdTakeController.didGetPhoto = { (image, _) in
            cropFunction(image)
            //self.avatar.value = image
        }
    }
    
    func titleChanged(text: String) {
        var hs = discardableHotspot.value
        hs.name = text
        discardableHotspot.value = hs
    }
    
    func descriptionChanged(text: String) {
        var hs = discardableHotspot.value
        hs.description = text
        discardableHotspot.value = hs
    }
    
    func approveClicked() {
        
        let hs = discardableHotspot.value
        
        guard hs.latitude != 0, hs.longitude != 0 else {
            
            handler?.presentErrorMessage(error: "We can't determine your location. Please, make sure that you enabled location services for Campfiire")
            
            return;
        }
        
        guard hs.tags.count > 0 else {
            
            handler?.presentErrorMessage(error: "Please, use at least one tag for the hotspot")
            
            return;
        }
        
        ///TODO: redirect map to newly created hotspot
        HotspotManager.upsert(hotspot: discardableHotspot.value)
            .trackView(viewIndicator: indicator)
            .silentCatch(handler: handler)
            .subscribe( onCompleted: { [weak h = handler] in
                h?.popBack(animated: true)
            })
            .addDisposableTo(bag)
        
    }
    
    func commitButtonSelected() {
        
        guard isEditing else { return approveClicked() }
        
        handler?.presentConfirmQuestion(question: DisplayMessage(title: "Please confirm",
                                                    description: "Are you sure you want to delete hotspot"))
            .filter { $0 }
            .flatMap { [unowned d = discardableHotspot] (_) in
                return HotspotManager.delete(hotspot: d.value)
            }
            .trackView(viewIndicator: indicator)
            .silentCatch(handler: handler)
            .subscribe( onCompleted: { [weak h = handler] in
                h?.popBackToRoot(animated: true)
            })
            .addDisposableTo(bag)
        
    }
 
    func closeClicked(at indexPath: IndexPath) {
        var hotspot = discardableHotspot.value
        
        guard indexPath.row < hotspot.tags.count else { return }
        
        hotspot.tags.remove(at: indexPath.row)
        discardableHotspot.value = hotspot
    }
    
    func confirmCrop (image : UIImage)
    {
        self.avatar.value = image
    }
    
}
