//
//  TagButtonViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/22/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import RxSwift

struct TagButtonViewModel: ViewModel {
    
    var title: Observable<String> {
        return self.tag.asObservable()
            .map { $0 ?? "Add tag\n+" }
    }
    
    var color: Observable<UIColor> {
        return self.selected.asObservable()
            .map { $0 ? UIColor.tagSelected : UIColor.tagDeselected }
        
    }
    
    let selected: Variable<Bool> = Variable(false)
    
    let tag: Variable<Tag?>
    
    
    weak var handler: UIViewController?
    init(handler: UIViewController, tag: Tag?) {
        
        self.handler = handler
        self.tag = Variable(tag)
        
    }
    
    
    func clickReported() {
        
        guard tag.value != nil else {
            
            handler?.presentTextQuestion(question: DisplayMessage(title: "New Tag",
                                                                 description: "What's it's name?"))
                .map { [weak h = handler] name -> String? in
                    
                    let regEx = "^[\\w-]{2,15}$"
                    guard NSPredicate(format:"SELF MATCHES %@", regEx).evaluate(with: name) else {
                        h?.presentErrorMessage(error: "Tag can contain only letters or numbers, must be at least 2 characters and not be longer than 16 characters")
                        return nil
                    }
                    
                    return name
                }
                .notNil()
                .map { Tag(name: $0) }
                .subscribe(onNext: { (tag) in
                    self.selected.value = true
                    self.tag.value = tag
                })
                .addDisposableTo(bag)
            
            return
        }
        
        selected.value = !selected.value
        
    }
    
    fileprivate let bag = DisposeBag()
    
}
