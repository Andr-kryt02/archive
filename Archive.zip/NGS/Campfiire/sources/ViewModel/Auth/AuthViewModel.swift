//
//  AuthViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/15/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire

extension AuthViewModel {
    
    func facebookButtonTapped() {
        
        self.authenticator.value = FacebookAuthenticator()
    }
    
    func instagramButtonTapped() {
        
        ///self.handler?.presentErrorMessage(error: "Currently Instagram auth is unavailable")
        
//        return
        
        self.authenticator.value = InstagramAuthenticator()
    }
    
    func googlePlusButtonTapped() {
        
        ///self.handler?.presentErrorMessage(error: "Currently Google auth is unavailable")
//        
//        return ()
        
        self.authenticator.value = GoogleAuthenticator()
    }
    
    func login(email: String, password: String) {
        self.authenticator.value = CredentialsAuthenticator(email: email,
                                                            password: password)
    }
    
    func register(email: String,
                  password: String,
                  name: String,
                  location: String?,
                  favoriteProduct: String?) {
        
        guard registerUserViewModel.validateRegistrationInput(),
              registerUserViewModel.validateTagsInput() else { return }
        
        let tags = registerUserViewModel.tagButtonsViewModel
            .filter { $0.selected.value }
            .flatMap { $0.tag.value }
        
        let gender = registerUserViewModel.selectedGender.value
        
        let data = RegistrationData(username: name,
                                    password: password,
                                    email: email,
                                    birthdate: registerUserViewModel.selectedBirthDate.value,
                                    location: location,
                                    gender:  gender,
                                    favoriteProduct: favoriteProduct,
                                    tags: tags,
                                    tempImageURL: registerUserViewModel.tempAvatarImage.value)
        
        self.authenticator.value = RegistrationAuthenticator(data: data)
        
    }
    
    func forgotPassword(){
        
        self.handler?.presentTextQuestion(question: DisplayMessage(title: "Enter email",
                                                                   description : "Email must be the same with which you registered"),
                                          buttonSuccessName : "OK")
            .silentCatch()
            .flatMapLatest{ (email) -> Observable<CampfiireEmptyResponse.DataType> in
                
                let validator = RegistrationValidation(email: Observable.just(email))
                let validationResult = validator.emailValid.value
                
                guard validationResult.isValid else {
                    return Observable.error(CampfiireError.generic(description: validationResult.failReason!))
                }
                
                return AuthorizationManager.passwordRecover(email: email)
                    .trackView(viewIndicator: self.indicator)
                
            }.subscribe(onNext: {
                self.handler?.presentMessage(message: DisplayMessage(title: "Success", description: "We sent passwod to your email."))
            }, onError: { error in
                self.handler?.presentError(error: error)
            }).addDisposableTo(disposeBag)
        
    }
 
}

struct AuthViewModel: ViewModel {

    weak var handler: UIViewController?
    let registerUserViewModel: RegisterUserViewModel
 
    init(handler: UIViewController, registrationValidator: RegistrationValidation) {
        self.handler = handler
        self.registerUserViewModel = RegisterUserViewModel(handler: handler,
                                                           validator: registrationValidator)
        
        authenticator.asObservable()
            .notNil()
            .flatMapLatest { [unowned h = handler, unowned i = indicator] authenticator in
                authenticator
                    .authenticateUser(onController: h) ///get data from authenticator
                    .flatMap { AuthorizationManager.loginWith(data: $0) }///obtain AccessToken from server, and get current user
                    .trackView(viewIndicator: i)
                    .silentCatch(handler: h)
            }
            .subscribe (onNext: { (resp) in
                
                let _ = try? NotificationManager.saveDeviceToken()
                
                let user = resp.user!
                let isNew = resp.isNew
                
                MainViewModel.shared.router.postLoginRout(loggedInUser: user,
                                                          startFromUserProfile: isNew)
                
            })
            .addDisposableTo(disposeBag)
        
        self.indicator.asDriver()
            .drive(onNext: { [weak h = handler] (loading) in
                h?.changedAnimationStatusTo(status: loading)
            })
            .addDisposableTo(disposeBag)
        
    }
    
    
    fileprivate var disposeBag = DisposeBag()
    fileprivate var authenticator: Variable<Authenticator?> = Variable(nil)
    fileprivate let indicator = ViewIndicator()
    
}

