//
//  RegisterUserViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/19/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift

struct RegisterUserViewModel: ViewModel {
    
    weak var handler: UIViewController?
    
    init(handler: UIViewController, validator: RegistrationValidation) {
        self.handler = handler
        self.validator = validator
        
        let initialTags: [Tag?] = [
            Tag(name: "clubs"),
            Tag(name: "games"),
            Tag(name: "cars"),
            Tag(name: "business"),
            Tag(name: "sports"),
            Tag(name: "music"),
            Tag(name: "shops"),
            nil,
            nil,
            nil
        ]
        
        tagButtonsViewModel = initialTags.map { TagButtonViewModel(handler: handler,
                                                                   tag: $0) }
        
    }
    
    let tagButtonsViewModel: [TagButtonViewModel]
    let currentPage: Variable<Int> = Variable(0)
    
    let validator: RegistrationValidation
    
    let selectedBirthDate: Variable<Date?> = Variable(nil)
    let selectedGender : Variable<Gender?> = Variable(nil)
    let tempAvatarImage: Variable<String?> = Variable(nil)
    
    ///validation UI
    
    let emailUnderlineColor: Variable<UIColor> = Variable(UIColor.white)
    let passwordUnderlineColor: Variable<UIColor> = Variable(UIColor.white)
    let nameUnderlineColor: Variable<UIColor> = Variable(UIColor.white)
    let dateUnderlineColor: Variable<UIColor> = Variable(UIColor.white)
    
    var avatar : Variable<UIImage?> = Variable(nil)
    
    fileprivate let bag = DisposeBag()
    
    fileprivate var fdTakeController: FDTakeController = {
        let d = FDTakeController()
        d.allowsVideo = false
        d.allowsEditing = false
        return d
    }()
    
}

extension RegisterUserViewModel {
    
    func reportSignInClicked() {
        
        currentPage.value = 0
        
    }
    
    func reportSignUpClicked() {
        
        currentPage.value = 1
        
    }
    
    func reportNextStepClicked() {
       
        guard validateRegistrationInput() else { return }
       
        currentPage.value = 2
        
    }
    
    func validateRegistrationInput() -> Bool {
        
        let birthdayValidation = validator.validateBirthday(date: selectedBirthDate.value)
        
        let errors = [
            validator.emailValid.value.failReason,
            validator.passwordValid.value.failReason,
            validator.nameValid.value.failReason,
            validator.locationValid.value.failReason,
            validator.favoriteProductValid.value.failReason,
            birthdayValidation.failReason
            ].flatMap { $0 }
        
        emailUnderlineColor.value = validator.emailValid.value.isValid ? UIColor.white : UIColor.red
        nameUnderlineColor.value = validator.nameValid.value.isValid ? UIColor.white : UIColor.red
        passwordUnderlineColor.value = validator.passwordValid.value.isValid ? UIColor.white : UIColor.red
        dateUnderlineColor.value = birthdayValidation.isValid ? UIColor.white : UIColor.red
        
        guard errors.count == 0 else {
            
            self.handler?.presentMessage(message: DisplayMessage(title: "There's a problem with your registration.",
                                                                description: errors.joined(separator: "\n ")))
            return false
        }
        
        return true
    }
    
    func validateTagsInput() -> Bool {
        
        let errorReason =
        validator.validateTags(tags: tagButtonsViewModel
            .filter { $0.selected.value }
            .flatMap { $0.tag.value }).failReason
        
        guard errorReason == nil else {
            
            handler?.presentErrorMessage(error: errorReason!)
            return false

        }
        
        return true
    }
    
    func updateAvatarClicked() {
        
        fdTakeController.present()
        
        fdTakeController.didGetPhoto = { (image, _) in
            self.avatar.value = image
        }
    }
    
    func uploadingCroppedImage (image : UIImage)
    {
        let tempURL = "com.campfiire.temporayAvatar"
        ImageRetreiver.registerImage(image: image,
                                     forKey: tempURL)
         
        self.tempAvatarImage.value = tempURL
        
    }
    
}
