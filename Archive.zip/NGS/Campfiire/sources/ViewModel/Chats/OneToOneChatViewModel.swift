//
//  OneToOneChatViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 1/17/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa
import RxDataSources

extension OneToOneChatViewModel: ChatMessagesProvider {
    
    var displayLatestMessageTriggerAnimated: Driver<Bool> {
        return displayLatestMessageTriggerVariable.asDriver().notNil()
    }
    
    var dataSource: Driver<[AnimatableSectionModel<String, ChatMessage>]> {
        return messagesVariable.asDriver()
            .map { [AnimatableSectionModel(model: "", items: $0.reversed())] }
    }
    
    var title: Driver<String> {
        return peer.asDriver()
            .map { $0.name }
    }
    
    var imageURL: Driver<String> {
        return peer.asDriver()
            .map { $0.pictureURL }
    }
    
}

struct OneToOneChatViewModel: ViewModel {
    
    func heightForRow(at: IndexPath, width: CGFloat) -> CGFloat {
        
        let messages = messagesVariable.value
        
        let message = messages[ messages.count - at.row - 1 ]
        
        let h = heightCalculator.height(of: message, for: width)
        return h
    }
    
    fileprivate var messagesVariable = Variable<[ChatMessage]>([])
    
    fileprivate let peer: Variable<User>
    fileprivate let loadMoreTrigger: Variable<Void> = Variable(  )
    
    fileprivate let displayLatestMessageTriggerVariable = Variable<Bool?>(nil)
    
    fileprivate let heightCalculator = ChatCellCalculator()
    
    fileprivate let fdTakeController: FDTakeController = {
        let d = FDTakeController()
        d.allowsVideo = false
        d.allowsEditing = false
        return d
    }()
    
    weak var handler: UIViewController?
    init(handler: UIViewController, peer: User) {
        
        self.peer = Variable(peer)
        self.handler = handler
        
        ////getting most recent user data for chat display
        UsersManager.mostRecentUserData(user: peer)
            .bindTo(self.peer)
            .addDisposableTo(bag)
        
        loadMoreTrigger.asObservable()
            .map { [unowned m = messagesVariable] in
                return Batch( offset: m.value.count, limit:20 )
            }
            .flatMapLatest { batch -> Observable<([ChatMessage] , Bool)> in
                
                return ChatManager.messagesWithUser(peer: peer, batch: batch)
                    .silentCatch()
                    .map { ($0, batch.offset == 0 ) }
                
            }
            .subscribe ( onNext: { [unowned m = messagesVariable,
                unowned d = displayLatestMessageTriggerVariable] resp in
                
                let newMessages = resp.0
                let shouldScrollToBottom = resp.1
                
                let copy = m.value
                m.value = copy + newMessages

                if (shouldScrollToBottom) { d.value = false }
                
            })
            .addDisposableTo(bag)
        
        ///making new messages appear at the beggining of the list
        
        ChatManager.receiveRealTimeMessagesFrom(user: peer, from: Date())
            .subscribe(onNext: { [unowned messagesVariable = self.messagesVariable ,
                                  unowned t = displayLatestMessageTriggerVariable] (message) in
                var copy = messagesVariable.value
                copy.insert(message, at: 0)
                messagesVariable.value = copy
                
                t.value = true
            })
            .addDisposableTo(bag)
        
        ///upload media 
        fdTakeController.rxex_photo()
            .flatMap { [unowned h = handler,
                        unowned i = indicator] image -> Observable<String> in
                ChatAttachmentManager.uploadImage(image: image)
                    .trackView(viewIndicator: i)
                    .silentCatch(handler: h)
            }
            .flatMap { [unowned m = messagesVariable,
                        unowned o = displayLatestMessageTriggerVariable] url -> Observable<Void> in
                let message = ChatMessage(text: "", pictureURL: url)
                
                var copy = m.value
                copy.insert(message, at: 0)
                m.value = copy
                
                o.value = true
                
                return ChatManager.sendMessage(chatMessage: message, to: peer)
            }
            .subscribe(onCompleted: {
                ////nothing so far
            })
            .addDisposableTo(bag)
        
        ////spinner binding
        indicator.asDriver()
            .drive(onNext: { [weak h = handler] (loading) in
                h?.changedAnimationStatusTo(status: loading)
            })
            .addDisposableTo(bag)
        
    }
    
    fileprivate let bag = DisposeBag()
    fileprivate let indicator = ViewIndicator()
}

extension OneToOneChatViewModel {
    
    func sendMessage(content: String) {
        
        let message = ChatMessage(text: content)
        
        var copy = messagesVariable.value
        copy.insert(message, at: 0)
        messagesVariable.value = copy
        
        displayLatestMessageTriggerVariable.value = true
        
        ChatManager.sendMessage(chatMessage: message, to: peer.value)
            .subscribe(onCompleted: {
                ///nothing so far
            })
            .addDisposableTo(bag)
        
    }
    
    func loadMore() {
        loadMoreTrigger.value = ()
    }
    
    func uploadMedia() {
        fdTakeController.present()
    }
    
}
