//
//  UpsertChatViewModel.swift
//  Campfiire
//
//  Created by Andrew Seregin on 1/5/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import Foundation

import RxSwift
import RxDataSources

struct UpsertChatViewModel : ViewModel
{
//    var commitButtonTitle: String { return isEditing ? "Delete Chat" : "Create Chat" }
//    var commitButtonColor: UIColor { return isEditing ? UIColor.destructiveRed : UIColor.acceptanceGreen }
//    
//    var membersHidden: Bool { return !isEditing }
//    var settingButtonsHidden : Bool { return !isEditing }
//    
//    var observableChat: Observable<Chat> {
//        return discardableChat.asObservable()
//    }
//    
//    let canEnterInfo : Variable<Bool> = Variable(true);
//    
//    var navigationTitleString: Observable<String> {
//        return observableChat
//            .map { $0.name }
//            .map { $0.lengthOfBytes(using: .utf8) > 0 ? $0 : "New Chat" }
//    }
//    
//    var titleText : String { return discardableChat.value.name }
//    var descriptionText : String { return discardableChat.value.description }
//    
//    var users: Observable<[AnimatableSectionModel<String, TagCellViewModel>]> {
//        return observableChat
//            .map { $0.members }
//            .map { [weak h = handler,
//                unowned chat = discardableChat] members -> [TagCellViewModel] in
//                
//                var answer = members.map { member in
//                    TagCellViewModel(title: member.name,
//                                     color: UIColor.userTagRegular,
//                                     closeButtonHidden: false)
//                }
//                
//                answer.append( TagCellViewModel(title: "Add members...",
//                                                color: UIColor.userTagRegular,
//                                                titleAlignment: .center,
//                                                action: AddNewMember(handler : h,
//                                                                     chatReference: chat))
//                )
//                
//                return answer
//            }
//            .map { return [AnimatableSectionModel(model: "",
//                                                  items: $0)] }
//    }
//    
    weak var handler: UIViewController?
//    init(handler : UIViewController, initialChat: Chat?)
//    {
//        self.handler = handler
//        isEditing = initialChat != nil
//        
//        var chatToUpsert : Chat! = initialChat
//        if initialChat == nil {
//            var emptyChat = Chat()
//            emptyChat.id = 0
//            emptyChat.author = User.currentUser()!
//            emptyChat.saveEntity()
//            chatToUpsert = emptyChat
//        }
//        
//        discardableChat = Variable(chatToUpsert)
//        
//        observableChat
//            .map { $0.members.count > 2 }
//            .bindTo(canEnterInfo)
//            .addDisposableTo(bag)
//
//        ///avatar selection
//        avatar.asObservable()
//            .notNil()
//            .map { image -> String in
//                
//                let fakeURL = "com.campfire.fakeURL.hotspot.\(image.hashValue)"
//                
//                ImageRetreiver.registerImage(image: image, forKey: fakeURL)
//                
//                return fakeURL
//            }
//            .map { [unowned d = discardableChat] fakeURL in
//                var chat = d.value
//                
//                chat.pictureURL = fakeURL
//                return chat
//            }
//            .bindTo(discardableChat)
//            .addDisposableTo(bag)
//        
//        indicator.asDriver()
//            .drive(onNext: { [weak h = handler] (loading) in
//                h?.changedAnimationStatusTo(status: loading)
//            })
//            .addDisposableTo(bag)
//    }
//    
//    fileprivate let isEditing: Bool
//    fileprivate let discardableChat: Variable<Chat>
//    fileprivate var avatar : Variable<UIImage?> = Variable(nil)
//    fileprivate var fdTakeController: FDTakeController = {
//        let d = FDTakeController()
//        d.allowsVideo = false
//        d.allowsEditing = false
//        return d
//    }()
//    
//    let indicator = ViewIndicator()
//    
//    fileprivate let bag = DisposeBag()
}

extension UpsertChatViewModel
{
    
//    func selectAvatarClicked(cropFunction : @escaping (UIImage) -> ())
//    {
//        if self.canEnterInfo.value
//        {
//            fdTakeController.present()
//            
//            fdTakeController.didGetPhoto = { (image, _) in
//                cropFunction(image)
//            }
//        }
//    }
//    
//    func titleChanged(text: String)
//    {
//        var chat = discardableChat.value
//        chat.name = text
//        discardableChat.value = chat
//    }
//    
//    func descriptionChanged(text : String)
//    {
//        var chat = discardableChat.value
//        chat.description = text
//        discardableChat.value = chat
//    }
//    
//    func approveClicked()
//    {
//        let chat = discardableChat.value
//        
//        guard chat.members.count > 0 else {
//            handler?.presentErrorMessage(error: "Please, add at least one member for the chat")
//            return;
//        }
//        
//        //TODO: Manager
//        
//        /*///TODO: redirect map to newly created hotspot
//        HotspotManager.upsert(hotspot: discardableHotspot.value)
//            .trackView(viewIndicator: indicator)
//            .silentCatch(handler: handler)
//            .subscribe( onCompleted: { [weak h = handler] in
//                h?.popBack(animated: true)
//            })
//            .addDisposableTo(bag)*/
//        
//    }
//    
//    func confirmCrop (image : UIImage)
//    {
//        self.avatar.value = image
//    }
//    
//    func prepareAllert(onEdit : () -> (), onCreate : () -> () )
//    {
//        guard !isEditing else { return onCreate() }
//        onEdit()
//    }
//    
//    func applyAction(response : (Bool, Bool))
//    {
//        guard response.0 || response.1 else { return }
//        if response.0 { approveClicked() }
//        handler?.popBackToRoot(animated: true)
//    }
//    
//    func closeClicked(at indexPath: IndexPath) {
//        var chat = discardableChat.value
//        
//        guard indexPath.row < chat.members.count else { return }
//        chat.members.remove(at: indexPath.row)
//        
//        discardableChat.value = chat
//    }
//    
//    func commitButtonSelected(){
//        
//        guard isEditing else { return approveClicked() }
//        
//        handler?.presentConfirmQuestion(question: DisplayMessage(title: "Please confirm",
//                                                                 description: "Are you sure you want to delete Chat"))
//            .filter { $0 }
//            .flatMap { [unowned chat = discardableChat] (_) in
//                return Observable.just()// ChatManager.remove(chat: chat.value)
//            }
//            .trackView(viewIndicator: indicator)
//            .silentCatch(handler: handler)
//            .subscribe( onCompleted: { [weak h = handler] in
//                h?.popBackToRoot(animated: true)
//            })
//            .addDisposableTo(bag)
//        
//    }
}
