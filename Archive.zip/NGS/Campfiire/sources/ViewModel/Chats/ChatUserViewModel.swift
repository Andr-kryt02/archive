//
//  ChatUserViewModel.swift
//  Campfiire
//
//  Created by Andrew Seregin on 1/4/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import Foundation

import RxSwift
import RxDataSources

struct ChatUserViewModel : ViewModel  {
    
    weak var handler: UIViewController?
    
    let user : User
    let isInChat : Variable<Bool> = Variable(false)
    
    init(user : User, isIn : Bool) {
        self.user = user
        self.isInChat.value = isIn
    }
}

extension ChatUserViewModel : IdentifiableType, Equatable {
    
    var identity: String {
        return "\(user.id)"
    }
    
}

func ==(lhs: ChatUserViewModel,
        rhs: ChatUserViewModel) -> Bool {
    return lhs.user == rhs.user
}

extension ChatUserViewModel {
    
    func changeStatusInChat() {
        let isIn = isInChat.value
        isInChat.value = !isIn
    }
        
}
