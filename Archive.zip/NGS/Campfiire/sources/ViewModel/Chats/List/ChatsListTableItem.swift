//
//  ChatsListTableItem.swift
//  Campfiire
//
//  Created by Andrew Seregin on 12/1/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import RxDataSources
import XMPPFramework

enum ChatsListTableItem {
    
    case group (chat : MultiuserChat)
    case personal (chat : OneToOneChat)
    
    init?(xml: DDXMLElement) {
        
        if let n = xml.name, n == "chat",
            let chat = OneToOneChat(xml: xml) {
            self = .personal(chat: chat)
            return;
        }
        
        if let n = xml.name, n == "group-chat"
        //    ,let chat = OneToOneChat(xml: xml)
        {
            
            //self = .group(chat: chat)
            //return;
        }
        
        return nil
    }
    
//    var chat : Chat {
//        switch self {
//        case .group(let c) : return c
//        case .personal(let c) : return c
//        }
//    }
}


extension ChatsListTableItem : IdentifiableType, Equatable {
        
    var identity: Int {
        switch self {
        case .group (let chat) : return chat.id
        case .personal (let chat) : return -1 * chat.peer.id
        }
    }
}
    
func ==(lhs: ChatsListTableItem,
            rhs: ChatsListTableItem) -> Bool {
        
        switch (lhs, rhs) {
            
        case (.group(let lhs) , .group(let rhs)):
            return lhs == rhs
            
        case (.personal(let lhs) , .personal(let rhs)):
            return lhs == rhs
            
        default:
            return false
        }
        
}
