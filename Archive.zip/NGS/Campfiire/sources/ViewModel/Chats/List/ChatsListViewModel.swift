//
//  ChatsListViewModel.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/30/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

import RxSwift
import RxCocoa
import RxDataSources

extension ChatsListViewModel {
    var displayData : Driver<[AnimatableSectionModel<String, ChatsListTableItem>]> {
        
        return providerViewModel.displayDataDriver.map {
            return [AnimatableSectionModel(model: "",
                                           items: $0)]
        }
        
    }
    var showsEmptyState: Driver<Bool> {
        return providerViewModel.displayDataDriver
            .map { $0.count == 0 }
    }
}

struct ChatsListViewModel : ViewModel {
    
    weak var handler: UIViewController?
    
    init(handler : UIViewController) {
        
        self.handler = handler
        providerViewModel.handler = handler
        
        query.asObservable()
            .distinctUntilChanged()
            .debounce(0.4, scheduler: MainScheduler.asyncInstance)
            .map { ChatsSearchDataProvider(seqrchQuery: $0) }
            .bindTo (providerViewModel.dataProvider)
            .addDisposableTo(bag)
        
        providerViewModel.loadingBatchDriver
            .drive( onNext: { [unowned h = handler] batch in
                
                var shouldAnimate = false
                if let b = batch, b.offset == 0 { ///animating only for the very first batch
                    shouldAnimate = true
                }
                
                h.changedAnimationStatusTo(status: shouldAnimate)
            })
            .addDisposableTo(bag)
        
        searchBarHidden.asObservable()
            .filter { $0 }
            .map { _ in "" }
            .bindTo(query)
            .addDisposableTo(bag)
    }
    
    let searchBarHidden: Variable<Bool> = Variable(true)
    
    let providerViewModel: FeedViewModel<ChatsSearchDataProvider> = FeedViewModel()
    
    fileprivate let query: Variable<String> = Variable("")
    fileprivate let indicator = ViewIndicator()
    let bag = DisposeBag()
}

extension ChatsListViewModel {
    
    func switchSearchBarStatus() {
        searchBarHidden.value = !searchBarHidden.value
    }
    
    func removeChat(at: IndexPath){
        
        let item = providerViewModel.item(at: at.row)
        //let chat = item.chat
        
        let message = DisplayMessage(title: "Please confirm",
                                     description: "Would you like to delete from your chats list")
        
        handler?.presentConfirmQuestion(question: message)
            .filter { return $0 }
            .flatMapLatest { [unowned data = providerViewModel] _ -> Observable<Void> in
                
                data.removeFeedItem(item: item)
                
                return Observable.just() //ChatManager.remove(chat: chat)
            }
            .subscribe(onCompleted: {
                ////nothing so far. Just silently succed or fail
            })
            .addDisposableTo(bag)
        
    }
    
    func searchQueryChanged(query: String) {
        self.query.value = query
    }
    
    func chatViewModelForItem(at ip: IndexPath, for handler: UIViewController) -> ChatMessagesProvider {
        let item = providerViewModel.currentData[ip.row]
        
        switch item {
        case .group(let chat):
            fatalError("Can't present group chat for now")
        case .personal(let chat):
            return OneToOneChatViewModel(handler: handler, peer: chat.peer)
        }
    }
}

extension ChatsListViewModel {
    
    struct ChatsSearchDataProvider : DataProvider {
        
        typealias DataType = ChatsListTableItem
        
        let seqrchQuery : String
        
        func loadBatch(batch: Batch) -> Observable<[ChatsListTableItem]> {
            
            if batch.offset > 0 { return Observable.just([]) }
            
            return ChatManager.chatList() // ChatManager.list(query: seqrchQuery, batch: batch)
            
        }
        
    }
}
