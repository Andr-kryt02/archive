//
//  ViewModel.swift
//  Campfiire
//
//  Created by Andrew Seregin on 1/17/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import Foundation

import RxSwift
import RxCocoa
import RxDataSources

struct MembersViewModel : ViewModel {
    
    weak var handler : UIViewController?
    //unowned var chatReference: Variable<Chat>
    init(handler : UIViewController) {
        
        self.handler = handler
        //self.chatReference = chatReference
        
//        Observable.just(Array<User>()) // ChatManager.potentialMembersList()
//            .map {
//                $0.map{ user -> ChatUserViewModel in
//                    let c = chatReference.value
//                    return ChatUserViewModel(user : user, isIn : c.members.contains(user))
//                }
//            }
//            .trackView(viewIndicator: indicator)
//            .silentCatch(handler: handler)
//            .bindTo(memeberScreenList)
//            .addDisposableTo(bag)
        
        indicator.asDriver()
            .drive(onNext: { [weak h = handler] (loading) in
                h?.changedAnimationStatusTo(status: loading)
            })
            .addDisposableTo(bag)
    }
    
    var datasource: Driver<[AnimatableSectionModel<String, ChatUserViewModel>]> {
        return memeberScreenList.asDriver()
            .map { (data) in
                return [AnimatableSectionModel(model: "",
                                               items: data)]
        }
    }
    
    var showsEmptyState: Driver<Bool> {
        return memeberScreenList.asDriver()
            .map { $0.count == 0 }
            .skip(1) /// until we load at least one batch
    }
    
    fileprivate let memeberScreenList: Variable<[ChatUserViewModel]> = Variable([])
    fileprivate let indicator = ViewIndicator()
    let bag = DisposeBag()
    
}

extension MembersViewModel {
    
    func configureMemberStatus(at : IndexPath) {
        var list = memeberScreenList.value
        let member = list[at.row]
        
        member.changeStatusInChat()
    }
    
    func approveClicked() {
        
        let members = memeberScreenList.value
            .filter { $0.isInChat.value }
            .map { $0.user }
        
//        var chat = chatReference.value
//        chat.members = members
//        
//        chatReference.value = chat
    }
}
