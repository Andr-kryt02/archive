//
//  PhotosViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/21/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import RxSwift
import RxCocoa
import Alamofire

struct PhotosViewModel: ViewModel {
    
    let feedViewModel: NewsFeedTableViewModel<PhotosProvider>
    
    weak var handler: UIViewController?
    init (handler: UIViewController) {
        self.handler = handler
        
        feedViewModel = NewsFeedTableViewModel(handler: handler)
        feedViewModel.paginatedViewModel.dataProvider.value = PhotosProvider(friendsPhotos: false)
        
        feedViewModel.paginatedViewModel.loadingBatchDriver
            .drive( onNext: { [unowned h = handler] batch in
                
                var shouldAnimate = false
                if let b = batch, b.offset == 0 { ///animating only for the very first batch
                    shouldAnimate = true
                }
                
                h.changedAnimationStatusTo(status: shouldAnimate)
            })
            .addDisposableTo(bag)
        
        ////new photo
        fdTakeController.rxex_photo()
            .flatMap { [unowned i = indicator] image in
                NewsFeedManager.postUserPhoto(image: image)
                    .trackView(viewIndicator: i)
            }
            .subscribe(onNext: { [unowned feed = feedViewModel.paginatedViewModel,
                                  unowned friendOnly = friendPhotosVariable] photo in
                
                ///we don't need photo to be inserted into list if we're on friendsPhotos tab
                guard friendOnly.value == false else { return }
                
                let userPhoto = NewsFeedTypes.userPhoto(userPhoto: photo)
                
                feed.insertFeedItemAtBegining(item: userPhoto)
                
            })
            .addDisposableTo(bag)
        
        /////progress indicator
        
        indicator.asDriver()
            .drive(onNext: { [weak h = handler] (loading) in
                h?.changedAnimationStatusTo(status: loading)
            })
            .addDisposableTo(bag)
        
        ///friendsPhoto switching
        
        friendPhotosVariable.asObservable()
            .distinctUntilChanged()
            .map { PhotosProvider(friendsPhotos: $0) }
            .bindTo(feedViewModel.paginatedViewModel.dataProvider)
            .addDisposableTo(bag)

    }
    
    fileprivate var fdTakeController: FDTakeController = {
        let d = FDTakeController()
        d.allowsVideo = false
        return d
    }()
    fileprivate let bag = DisposeBag()
    fileprivate let indicator: ViewIndicator = ViewIndicator()
    fileprivate let friendPhotosVariable = Variable(false)
}

extension PhotosViewModel {
    
    func addPhotoTapped() {
        fdTakeController.present()
    }
    
    func providerChanged(friendsPhoto: Bool) {
        friendPhotosVariable.value = friendsPhoto
    }
    
    
}

extension PhotosViewModel {
    
    struct PhotosProvider: DataProvider {
        
        typealias DataType = NewsFeedTypes
        
        let friendsPhotos: Bool
        
        func loadBatch(batch: Batch) -> Observable<[NewsFeedTypes]> {
            
            return NewsFeedManager.userPhotos(friendsPhotos: friendsPhotos, for: batch)
                .map { photos in
                    photos.map { .userPhoto( userPhoto: $0 ) }
                }
            
        }
        
    }
    
}
