//
//  CampsListViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/16/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import RxSwift
import RxCocoa
import RxDataSources

protocol Reloadable {
    func reload()
}

struct CampsListViewModel: ViewModel {
    
    var followedOnlySelected: Driver<Bool> {
        return followedOnly.asDriver()
    }
    
    var displayData: Driver<[AnimatableSectionModel<String, Camp>]> {
        return providerViewModel.displayDataDriver.map { (data) in
            return [AnimatableSectionModel(model: "",
                                           items: data)]
        }
        
    }
    var showsEmptyState: Driver<Bool> {
        return providerViewModel.displayDataDriver
            .map { $0.count == 0 }
            .skip(1) /// until we load at least one batch
    }
    
    let providerViewModel: FeedViewModel<CampDataProvider> = FeedViewModel()
    
    init(handler: UIViewController) {
        self.handler = handler
        providerViewModel.handler = handler
        
        let queryObservable = query.asObservable()
            .debounce(0.3, scheduler: MainScheduler.instance)
            .filter { maybeQuery in
                guard let q = maybeQuery,
                      q.lengthOfBytes(using: String.Encoding.utf8) < 3 else { return true }
                
                ///if q != nil && (q == 0 || q > 2)
                
                return q.lengthOfBytes(using: String.Encoding.utf8) == 0
            }
        
        let followedObservable = followedOnly.asObservable().distinctUntilChanged()
        let reloadObservable = reloadTrigger.asObservable()
        
        Observable
            .combineLatest(queryObservable,
                           followedObservable,
                           reloadObservable) { (q, f, _) -> CampDataProvider in
                            
                            return CampDataProvider(query: q,
                                                    followedOnly: f)
            }
            .bindTo(providerViewModel.dataProvider)
            .addDisposableTo(bag)
        
        ////spinner on empty data set loading
        providerViewModel.loadingBatchDriver
            .drive( onNext: { [unowned h = handler] batch in
                
                var shouldAnimate = false
                if let b = batch, b.offset == 0 { ///animating only for the very first batch
                    shouldAnimate = true
                }
                
                h.changedAnimationStatusTo(status: shouldAnimate)
            })
            .addDisposableTo(bag)
        
    }
    
    
    fileprivate let bag: DisposeBag = DisposeBag()

    fileprivate let query: Variable<String?> = Variable(nil)
    fileprivate let followedOnly: Variable<Bool> = Variable(false)
    fileprivate let reloadTrigger: Variable<Bool> = Variable(false)
    
    internal weak var handler: UIViewController?
}

extension CampsListViewModel : Reloadable {
    
    struct CampDataProvider: DataProvider {
        typealias DataType = Camp
        
        let query: String?
        let followedOnly: Bool
        
        func loadBatch(batch: Batch) -> Observable<[Camp]> {
            return Camp.list(query: query, followedOnly: followedOnly, batch: batch)
        }
        
    }
    
    func followOnlyStatusChanged(to followedOnly: Bool) {
        
        self.followedOnly.value = followedOnly
        
    }
    
    func queryChanged(query: String?) {
        self.query.value = query
    }
    
    func reload() {
        reloadTrigger.value = true
    }
    
}
