//
//  UpsertCampViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/3/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

import RxSwift

struct UpsertCampViewModel : ViewModel {
 
    var commitButtonTitle: String { return isEditing ? "Delete Camp" : "Create Camp" }
    var commitButtonColor: UIColor { return isEditing ? UIColor.destructiveRed : UIColor.acceptanceGreen }
    
    var applyButtonHidden: Bool { return !isEditing }
    var navigationTitleString: Observable<String> {
        return observableCamp
            .map { $0.title }
            .map { $0.lengthOfBytes(using: .utf8) > 0 ? $0 : "New Camp" }
    }
    
    var observableCamp: Observable<Camp> {
        return discardableCamp.asObservable()
    }
    
    let indicator = ViewIndicator()
    
    weak var handler: UIViewController?
    init(handler: UIViewController,
         initialCamp: Camp?,
         reloadable: Reloadable? = nil) {
        self.handler = handler
        self.reloadable = reloadable
        
        isEditing = initialCamp != nil
        
        ///camp initializatino
        
        var campToUpsert: Camp! = initialCamp
        if campToUpsert == nil {
            var emptyCamp = Camp(JSON: [:])!
            emptyCamp.id = 0
            
            emptyCamp.topic = Comment(JSON: [:])!
            emptyCamp.topic?.author = User.currentUser()!
                
            emptyCamp.saveEntity()
            campToUpsert = emptyCamp
        }
        
        discardableCamp = Variable(campToUpsert)
        
        ////spinner binding
        indicator.asDriver()
            .drive(onNext: { [weak h = handler] (loading) in
                h?.changedAnimationStatusTo(status: loading)
            })
            .addDisposableTo(bag)
        
    }

    internal let isEditing: Bool
    internal let discardableCamp: Variable<Camp>
    fileprivate var reloadable: Reloadable? = nil
    
    fileprivate let bag = DisposeBag()
    
}

extension UpsertCampViewModel {
    
    func titleChanged(text: String) {
        var camp = discardableCamp.value
        camp.title = text
        discardableCamp.value = camp
    }
    
    func descriptionChanged(text: String) {
        var camp = discardableCamp.value
        camp.topic?.text = text
        discardableCamp.value = camp
    }
    
    func approveClicked() {
        
        let camp = discardableCamp.value

        ///add more validation if needed
        guard camp.category != nil else {
            handler?.presentErrorMessage(error: "Please, select a category for your camp")
            return;
        }
        
        guard camp.title.lengthOfBytes(using: .utf8) > 0 else {
            handler?.presentErrorMessage(error: "Please, type in the title")
            return;
        }
        
        camp.upsert()
            .trackView(viewIndicator: indicator)
            .silentCatch(handler: handler)
            .subscribe( onCompleted: { [weak h = handler] in
                
                if !self.isEditing {
                    ////this is create operation
                    self.reloadable?.reload()
                }
                
                h?.popBack(animated: true)
            })
            .addDisposableTo(bag)
        
    }
    
    func commitButtonSelected() {
        
        guard isEditing else { return approveClicked() }
        
        handler?.presentConfirmQuestion(question: DisplayMessage(title: "Please confirm",
                                                    description: "Are you sure you want to delete camp"))
            .filter { $0 }
            .flatMap { [unowned d = discardableCamp,
                         unowned i = indicator] (_) in
                return d.value.delete()
                        .trackView(viewIndicator: i)
            }
            .silentCatch(handler: handler)
            .subscribe( onNext: { [weak h = handler] _ in
                
                self.reloadable?.reload()
                
                h?.popBackToRoot(animated: true)
            })
            .addDisposableTo(bag)
        
    }
    
    func updateCategory(category: Camp.Category) {
        var camp = discardableCamp.value
        camp.category = category
        discardableCamp.value = camp
    }
    
}
