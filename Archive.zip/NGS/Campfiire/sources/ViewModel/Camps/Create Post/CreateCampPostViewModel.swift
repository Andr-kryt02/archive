//
//  CreateCampPostViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/29/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa


struct CreateCampPostViewModel : ViewModel {
    
    var title: String { return camp.title }
    
    var authorName: String { return User.currentUser()!.name }
    var dateString: String { return Date().campfiireString }
    var authorPictureURL: String { return User.currentUser()!.pictureURL }
    
    var postImageDriver: Driver<UIImage> {
        return postImageVariable.asDriver()
            .map { $0 ?? R.image.postPhotoButton()! }
    }
    
    
    weak var handler: UIViewController?
    weak var parentViewModel: CampDetailsViewModel?
    init(handler: UIViewController?, camp: Camp, parentViewModel: CampDetailsViewModel?) {
        self.handler = handler
        self.camp = camp
        self.parentViewModel = parentViewModel
     
        fdTakeController.rxex_photo()
            .bindTo(postImageVariable)
            .addDisposableTo(bag)
        
        indicator.asDriver()
            .drive(onNext: { [weak h = handler] (loading) in
                h?.changedAnimationStatusTo(status: loading)
            })
            .addDisposableTo(bag)
    }
 
    fileprivate let bag = DisposeBag()
    
    fileprivate let camp: Camp
    fileprivate let postImageVariable: Variable<UIImage?> = Variable( nil )
    fileprivate let postTextVariable: Variable<String?> = Variable(nil)
    fileprivate let indicator: ViewIndicator = ViewIndicator()
    
    fileprivate var fdTakeController: FDTakeController = {
        let d = FDTakeController()
        d.allowsVideo = false
        return d
    }()
}

extension CreateCampPostViewModel {
    
    func pickPhotoTapped() {
        fdTakeController.present()
    }
    
    func textChanged(text: String) {
        postTextVariable.value = text
    }
    
    func uploadPostTapped() {
    
        guard let text = postTextVariable.value,
              text.lengthOfBytes(using: String.Encoding.utf8) > 0  else {
            handler?.presentErrorMessage(error: "Post text can't be empty")
            return
        }
        
        var camp = self.camp
        
        camp.post(text: text,
                  image: postImageVariable.value)
            .trackView(viewIndicator: indicator)
            .silentCatch(handler: handler)
            .subscribe( onNext: { [weak h = handler,
                                   weak parent = parentViewModel] comment in
                
                ///this logic better be happening on the server
                camp.totalComments += 1
                camp.saveEntity()
                
                parent?.reload()
                
                h?.popBack(animated: true)
            })
            .addDisposableTo(bag)

        
    }
    
}
