//
//  CampDetailsViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/16/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa

class CampDetailsViewModel: ViewModel {
    
    var comment : Comment?
    
    let rightButtons: Variable<RightButtons> = Variable([])
    let nextUserTrigger: Variable<User?> = Variable(nil)
    
    var followHidden: Driver<Bool> {
        return campVariable.asDriver()
            .map { $0.topic?.author }
            .notNil()
            .map { $0 == User.currentUser()! }
    }
    var followButtonImage: Driver<UIImage> {
        return campVariable.asDriver()
            .map { $0.isFollowedByCurrentUser }
            .distinctUntilChanged()
            .map { $0 ? R.image.startFavorite()! : R.image.uNstartFavorite()! }
    }
    
    var totalCampPages: Int {
        return Int( CampPageBuilder(camp: campVariable.value).pagesCount )
    }
    
    let campVariable: Variable<Camp>
    var campDriver: Driver<Camp> {
        return campVariable.asDriver()
    }
    
    var reloadPageDriver: Driver<Int?> {
        return reloadPageTrigger.asDriver()
    }
    fileprivate let reloadPageTrigger: Variable<Int?> = Variable(nil)
    fileprivate let optimisticManager: OptimisticModelManager<Camp> = OptimisticModelManager()
    
    init(handler: UIViewController, camp: Camp,
         parentViewModel: CampsListViewModel? = nil) {
        self.handler = handler
        self.parentViewModel = parentViewModel
        
        ////aquire details, then proceed
        camp.details()
            .trackView(viewIndicator: indicator)
            .do(onError: { [weak h = handler] (error) in
                h?.popBack(animated: true)
            })
            .silentCatch(handler: handler)
            .subscribe(onNext: { [unowned m = optimisticManager] camp in
                m.confirmedModel = camp
            })
            .addDisposableTo(bag)
        
        ///
        guard let observableCamp = camp.observableEntity() else {
            fatalError("Can't work with camp that is not in the storage - \(camp)")
        }
        campVariable = observableCamp
        
        ////optimisticManager
        optimisticManager.likeActionOutcome
            .subscribe(onNext: { (camp) in
                camp.saveEntity()
            })
            .addDisposableTo(bag)
        
        ///indicator
        indicator.asDriver()
            .drive(onNext: { [weak h = handler] (loading) in
                h?.changedAnimationStatusTo(status: loading)
            })
            .addDisposableTo(bag)
        
        ////right buttons
        observableCamp.asObservable()
            .map { $0.topic?.author }
            .notNil()
            .map { u -> RightButtons in
                return u == User.currentUser()! ? [.edit] : [.report]
            }
            .bindTo(rightButtons)
            .addDisposableTo(bag)
        
    }
    
    struct RightButtons: OptionSet {
        let rawValue: Int
        
        static let edit = RightButtons(rawValue: 1)
        static let report = RightButtons(rawValue: 2)
        
    }
    
    internal let bag = DisposeBag()
    internal let indicator = ViewIndicator()
    internal weak var handler: UIViewController?
    fileprivate(set) var parentViewModel: CampsListViewModel?
    
    fileprivate var pageStartsAtBottom: Bool = false
    fileprivate var shouldStartFromBottom: Bool {
        if (pageStartsAtBottom) {
            pageStartsAtBottom = false
            return true
        }
        
        return pageStartsAtBottom
    }

}

extension CampDetailsViewModel {
    
    func reportCampTapped() {
        
      Camp.reportCamp(campVariable.value)()
            .silentCatch(handler : handler)
            .subscribe(onNext: { [weak self] _ in
                self?.handler?.presentMessage(message: DisplayMessage(
                                                                title: "Thank you",
                                                                description: "Our moderators will take it from here"))
            })
            .addDisposableTo(bag)
      
        
    }
    
    func switchFollowState() {
        
        let camp = campVariable.value
        
        optimisticManager.queueChange(change: !camp.isFollowedByCurrentUser,
                                      model: camp)
//        campVariable.value.switchFollowState()
//            .subscribe(onCompleted: {
//                ///nothing so far
//            })
//            .addDisposableTo(bag)
        
    }
    
    func presentUser(user: User) {
        nextUserTrigger.value = user
    }
    
    func reportComment(comment: Comment!) {
    
        Camp.reportCampMessage(comment: comment!)
            .silentCatch(handler : handler)
            .subscribe(onNext: { [weak self] _ in
                self?.handler?.presentMessage(message: DisplayMessage(
                    title: "Thank you",
                    description: "Our moderators will take it from here"))
            })
            .addDisposableTo(bag)
        
    }
    
    func reportInitialComment(comment: Comment!) {
        reportComment(comment: comment)
    }
    
    func presentTopicStarter() {
        presentUser(user: campVariable.value.topic!.author)
    }
    
}

extension CampDetailsViewModel : Reloadable {
    
    func pageViewModel(at index: Int, handler: UIView?) -> CampPageViewModel {
        
        let camp = campVariable.value
        
        return CampPageViewModel(camp: camp,
                                 pageNumber: index + 1,
                                 handler: handler,
                                 pageStartsAtBottom: shouldStartFromBottom)
        
    }
    
    func reload() {
        pageStartsAtBottom = true
        
        let builder = CampPageBuilder(camp: campVariable.value)
        
        reloadPageTrigger.value = builder.pagesCount - 1
    }
    
}
