//
//  CampPageViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/19/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa
import RxDataSources

class CampPageViewModel {
    
    var commentsDataSource: Driver<[AnimatableSectionModel<String, Comment>] > {
        return pageVariable.asDriver().notNil().map {
            [AnimatableSectionModel(model: "", items: $0.comments)]
        }
    }
    
    var commentsCount: Int { return pageVariable.value?.comments.count ?? 1 }
    
    var shouldScrollToBottom: Bool {
        if (pageStartsAtBottom) {
            pageStartsAtBottom = false
            return true
        }
        
        return pageStartsAtBottom
    }

    init(camp: Camp, /// camp for which comments are gonna be presented
         pageNumber: Int, /// page number of the comments
         handler: UIView?, //// viewModel's handler
         pageStartsAtBottom: Bool) {
        
        self.handler = handler
        self.pageStartsAtBottom = pageStartsAtBottom
        
        ///obtaining page latest data
        camp.page(pageNumber)
            .trackView(viewIndicator: indicator)
            .silentCatch()
            .bindTo(pageVariable)
            .addDisposableTo(bag)
        
        ///indicator
        indicator.asDriver()
            .drive(onNext: { [weak h = handler] (loading) in
                h?.changedAnimationStatusTo(status: loading)
            })
            .addDisposableTo(bag)
        
    }
    
    weak var handler: UIView?
    internal let indicator = ViewIndicator()
    internal let bag = DisposeBag()
    internal let pageVariable: Variable<CampPage?> = Variable(nil)
    
    private var pageStartsAtBottom: Bool
    
}

extension CampPageViewModel {
    
    func commentViewModel(for comment: Comment) -> CommentViewModel {
        return CommentViewModel (topBarColor: UIColor.campCommentTopBar,
                                 headerTextColor: UIColor.white,
                                 comment: comment)
    }
    
    func commentAuthor(at index: IndexPath) -> User {
        return pageVariable.value!.comments[index.row].author
    }
    
    func comment(at index: IndexPath) -> Comment {
        return pageVariable.value!.comments[index.row]
    }
    
}
