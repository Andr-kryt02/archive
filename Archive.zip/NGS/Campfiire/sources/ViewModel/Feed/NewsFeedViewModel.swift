//
//  NewsFeedViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/13/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire

struct NewsFeedViewModel : ViewModel {
    
    var handler: UIViewController?
    let feedViewModel: NewsFeedTableViewModel<NewsProvider>
    
    init(handler: UIViewController) {
        self.handler = handler
        
        feedViewModel = NewsFeedTableViewModel(handler: handler)
        feedViewModel.paginatedViewModel.dataProvider.value = NewsProvider()
        
        feedViewModel.paginatedViewModel.loadingBatchDriver
            .drive( onNext: { [unowned h = handler] batch in
                
                var shouldAnimate = false
                if let b = batch, b.timesLoaded == 0 { ///animating only for the very first batch
                    shouldAnimate = true
                }
                
                h.changedAnimationStatusTo(status: shouldAnimate)
            })
            .addDisposableTo(bag)
        
        ////new photo
        fdTakeController.rxex_photo()
            .flatMap { [unowned i = indicator] image in
                NewsFeedManager.postUserPhoto(image: image)
                    .trackView(viewIndicator: i)
            }
            .subscribe(onNext: { [unowned feed = feedViewModel.paginatedViewModel] photo in
                
                let userPhoto = NewsFeedTypes.userPhoto(userPhoto: photo)
                
                feed.insertFeedItemAtBegining(item: userPhoto)
                
            })
            .addDisposableTo(bag)
        
        /////progress indicator
        
        indicator.asDriver()
            .drive(onNext: { [weak h = handler] (loading) in
                h?.changedAnimationStatusTo(status: loading)
            })
            .addDisposableTo(bag)
        
    }
    
    fileprivate var fdTakeController: FDTakeController = {
        let d = FDTakeController()
        d.allowsVideo = false
        return d
    }()
    fileprivate let bag = DisposeBag()
    fileprivate let indicator: ViewIndicator = ViewIndicator()
    
}

extension NewsFeedViewModel {
    
    func addPhotoTapped() {
        fdTakeController.present()
    }
    
}

extension NewsFeedViewModel {
    
    struct NewsProvider : DataProvider {
        
        typealias DataType = NewsFeedTypes
        typealias BatchType = State
        
        func nextBatch(loadedData: [NewsFeedTypes]) -> State {
            
            for feedItem in loadedData {
                switch feedItem {
                case .hotSpotPhoto(let hotspotPhoto):
                    state.lastTimestamp = hotspotPhoto.photo.datePosted; break;
                case .userPhoto(let userPhoto):
                    state.lastTimestamp = userPhoto.photo.datePosted; break;
                    
                case .event(_): fallthrough
                default: continue
                }
            }
            
            ////this is actually awfull decision to keep track of state internally, rather than rely on pure functions nextBatch and loadBatch
            ////we do not count on parametrs and just use internal variable
            ////so we don'treally need to provide proper object for PaginatedFeed
            return state
        }
        
        func loadBatch(batch: State) -> Observable<[NewsFeedTypes]> {
            
            ///please do not rely on input parametr batch. For this DataProvider it is of no use
            ///us local variable |state| that contains info for populating next Feed batch
            
            let request = NewsFeedManager.feed(for: state)
            
            state.timesLoaded += 1
            
            return request
        }
     
        let state = State()
        class State {
            var timesLoaded: Int = 0
            var lastTimestamp: Date?
        }
        
    }
    
}
