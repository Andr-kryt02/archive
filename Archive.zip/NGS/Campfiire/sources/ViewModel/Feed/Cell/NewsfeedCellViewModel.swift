//
//  NewsfeedCellViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/13/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa

struct NewsFeedCellIconTapAction<T> {
    let actionIcon: UIImage
    let action: (T) -> Void
}

struct NewsFeedCellViewModel<T: NewsItemViewModelProtocol>: NewsFeedCellViewModelProtocol {

    var item: Driver<NewsItemViewModelProtocol> {
        return itemVariable.asDriver().map { $0 as NewsItemViewModelProtocol }
    }
    var upperRightButtonImageDriver: Driver<UIImage?> { return Driver.just(tapIconAction?.actionIcon) }
    
    init(item: T,
         tapIconAction: NewsFeedCellIconTapAction<T>? = nil,
         newsNameTapAction: ((T) -> Void)? = nil,
         handler: UIViewController? = nil) {
        self.init(item: Variable(item),
                  tapIconAction: tapIconAction,
                  newsNameTapAction: newsNameTapAction,
                  handler: handler)
    }
    
    fileprivate init(item: Variable<T>,
                     tapIconAction: NewsFeedCellIconTapAction<T>? = nil,
                     newsNameTapAction: ((T) -> Void)?,
                     handler: UIViewController?) {
        
        itemVariable = item
        self.tapIconAction = tapIconAction
        self.handler = handler
        self.newsNameTapAction = newsNameTapAction
    }
    
    weak var handler: UIViewController?
    fileprivate let itemVariable: Variable<T>
    fileprivate var tapIconAction: NewsFeedCellIconTapAction<T>?
    fileprivate var newsNameTapAction: ((T) -> Void)?
    
    func upperRightButtonTap() {
        tapIconAction?.action(itemVariable.value)
    }
    
    var newsNameTappable: Bool { return newsNameTapAction != nil }
    func newsNameTapped() {
        newsNameTapAction?(itemVariable.value)
    }
}

extension NewsFeedCellViewModel where T : Storable {
    
    init(storable item: T,
         tapIconAction: NewsFeedCellIconTapAction<T>? = nil,
         newsNameTapAction: ((T) -> Void)? = nil,
         handler: UIViewController? = nil) {

        guard let variable = item.observableEntity() else {
            fatalError("NewsFeedStorableCellViewModel should not receive items that are not in the store")
        }

        self.init(item: variable,
                  tapIconAction: tapIconAction,
                  newsNameTapAction: newsNameTapAction,
                  handler: handler)
        
    }
    
}


struct NewsFeedLikableCellViewModel <T: NewsItemViewModelProtocol & Likable>: NewsFeedCellViewModelProtocol {
    
    var item: Driver<NewsItemViewModelProtocol> {
        return cellViewModel.item
    }
    var upperRightButtonImageDriver: Driver<UIImage?> {
        return cellViewModel.itemVariable.asDriver()
            .map { $0.isLiked ? R.image.hearted()! : R.image.likeButton()! }
    }
    
    fileprivate let cellViewModel: NewsFeedCellViewModel<T>
    
    var handler: UIViewController? { return cellViewModel.handler }
    fileprivate let optimisticManager: OptimisticModelManager<T>
    fileprivate let bag = DisposeBag()
    
    init(item: T,
         newsNameTapAction: ((T) -> Void)? = nil,
         handler: UIViewController? = nil) {
        
        cellViewModel = NewsFeedCellViewModel(item: item,
                                              newsNameTapAction: newsNameTapAction,
                                              handler: handler )
        
        self.optimisticManager = OptimisticModelManager()
        self.optimisticManager.confirmedModel = item
        
        optimisticManager.likeActionOutcome
            .bindTo(cellViewModel.itemVariable)
            .addDisposableTo(bag)
        
    }
    
    func upperRightButtonTap() {
        
        optimisticManager.queueChange(change: !cellViewModel.itemVariable.value.isLiked,
                                      model: cellViewModel.itemVariable.value)
        
    }
    
    var newsNameTappable: Bool { return cellViewModel.newsNameTappable }
    func newsNameTapped() {
        cellViewModel.newsNameTapped()
    }
    
}

