//
//  NewsItemViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/29/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

protocol NewsItemViewModelProtocol {
    
    var backgroundImageURL: String { get }
    
    var newsTypeLabelText: String { get }
    var newsTypeLabelColor: UIColor { get }
    
    var newsNameSectionTitle: String { get }
    var newsNameSectionImageURL: String? { get }
    
    var bottomLeftString: String? { get }
    var bottomRightString: String? { get }
    var upperRightString: String? { get }
    
}
