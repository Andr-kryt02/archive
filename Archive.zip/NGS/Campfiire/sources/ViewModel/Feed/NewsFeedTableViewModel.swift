//
//  NewsFeedTableViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/29/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

import RxSwift
import RxCocoa
import RxDataSources

struct NewsFeedTableViewModel<T: DataProvider>: ViewModel
        where T.DataType == NewsFeedTypes {

    weak var handler: UIViewController?
    init(handler: UIViewController) {
        self.handler = handler
        paginatedViewModel.handler = handler
        
    }
    
    var displayData: Driver<[AnimatableSectionModel<String, T.DataType>]> {
        
        return paginatedViewModel.displayDataDriver
            .map { [AnimatableSectionModel(model: "", items: $0)] }
        
    }
    var showsEmptyData: Driver<Bool> {
        return paginatedViewModel.displayDataDriver
            .map { $0.count == 0 }
    }
    
    var nextUserDriver: Driver<User> { return nextUserTrigger.asDriver().notNil() }
    let nextUserTrigger: Variable<User?> = Variable(nil)
    
    let paginatedViewModel: FeedViewModel<T> = FeedViewModel()
    
    fileprivate let bag = DisposeBag()
    
}

extension NewsFeedTableViewModel : NewsFeedTableViewModelProtocol {
    
    internal func cellViewModel(for item: NewsFeedTypes) -> NewsFeedCellViewModelProtocol {
        switch item {
        case .event(let event):
            return NewsFeedCellViewModel(item: event)
            
        case .hotSpotPhoto(let hsPhoto):
            
            ////picking up the most recent available Value of given photo
            let hotspotPhoto = hsPhoto.refreshed()
            
            let tapAction = { [unowned n = nextUserTrigger] (hotspotPhoto: HotspotPhoto) in
                n.value = hotspotPhoto.photo.author
            }
            
            return NewsFeedLikableCellViewModel(item: hotspotPhoto,
                                                newsNameTapAction: tapAction)
            
        case .userPhoto(let up):
            
            ////picking up the most recent available Value of given photo
            let userPhoto = up.refreshed()
            
            guard let author = userPhoto.photo.author else {
                fatalError("Can't present photo without author")
            }
            
            ///tap on user name or avatar action
            let tapAction = { [unowned n = nextUserTrigger] (userPhoto: UserPhoto) in
                n.value = userPhoto.photo.author
            }
            
            ///not personal photos are likable
            guard author == User.currentUser()! else {
                return NewsFeedLikableCellViewModel(item: userPhoto,
                                                    newsNameTapAction: tapAction,
                                                    handler: handler)
            }
            
            ///personal photos are deletable
            let deleteAction = NewsFeedCellIconTapAction(actionIcon: R.image.deleteic()!)
            { [unowned feed = paginatedViewModel] (tappedUserPhoto: UserPhoto) in

                //initialting fire and forget network request
                let _ =
                NewsFeedManager.deleteUserPhoto(photo: tappedUserPhoto)
                    .subscribe( onCompleted: {
                        ///do nothing so far
                    })

                
                let wrapper = NewsFeedTypes.userPhoto(userPhoto: tappedUserPhoto)
                feed.removeFeedItem(item: wrapper)
                
            }
            
            return NewsFeedCellViewModel(item: userPhoto,
                                         tapIconAction: deleteAction,
                                         newsNameTapAction: tapAction,
                                         handler: handler)
                
        }
    }

    func setPageTrigger(trigger: Observable<Void>) {
        paginatedViewModel.pageTrigger.value = trigger
    }
    
}
