//
//  LocationsViewModel.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 16.11.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa
import MapKit

extension DirectoryMapViewModel : DirectoryMapViewModelProtocol {
    
    ///properties
    var searchBarHiddenDriver: Driver<Bool> { return searchBarHidden.asDriver() }
    var searchBarConstraintDriver: Driver<CGFloat> {
        return searchBarHiddenDriver
            .map { $0 ? -44 : 0 }
            .skip(1)
    }
    
    
    var annotationsDriver: Driver<[AnnotationWrapper]> {
        return annotations.asDriver()
            .map { $0.map { AnnotationWrapper(type: $0) } }
    }
    var visibleRegionDriver: Driver<MKCoordinateRegion> { return visibleRegion.asDriver() }
    
}

struct DirectoryMapViewModel<T: DirectoryMapItemType> {
   
    internal weak var handler: UIViewController?

    init(handler: UIViewController,
         initialRegion: MKCoordinateRegion) {
        self.handler = handler
        
        //self.t = T
        indicator.asDriver()
            .drive(onNext: { [weak h = handler] (loading) in
                h?.changedAnimationStatusTo(status: loading)
            })
            .addDisposableTo(bag)
        
        ////on each hide
        
        searchBarHidden.asObservable()
            .filter { $0 }
            .map { _ in "" }
            .bindTo(query)
            .addDisposableTo(bag)
        
        visibleRegion = Variable(initialRegion)
        requestRegionVariable = Variable(initialRegion)

       
        let first  = requestRegionVariable.asObservable().notNil()
        let sec = query.asObservable()
                  .debounce(0.2, scheduler: MainScheduler.instance)
        
        Observable.combineLatest(first,sec) { ($0, $1) }
            .flatMapLatest { DirectoryManager<T>.mapFor(region: $0.0, query: $0.1) }
            .silentCatch(handler: handler)
            .bindTo(annotations)
            .addDisposableTo(bag)
        
    }
    
    internal var requestRegionVariable: Variable<MKCoordinateRegion?> = Variable(nil)
    
    let searchBarHidden: Variable<Bool> = Variable(true)
    internal let query: Variable<String?> = Variable(nil)
    internal let indicator = ViewIndicator()
    
    var annotations: Variable<[T]> = Variable([])
    
    let visibleRegion: Variable<MKCoordinateRegion>
    
    internal let bag = DisposeBag()
    
    
}

extension DirectoryMapViewModel {
    
    func searchQueryChanged(query: String) {
        self.query.value = query
    }
    
    func switchSearchBarStatus() {
        
        let isHidden = searchBarHidden.value
        
        searchBarHidden.value = !isHidden
    }

    func detailsViewModel(for annotation: AnnotationWrapper,
                          handler: UIViewController) -> DirectoryItemViewModelProtocol {
        
        let model = annotation.state as! T
        
        return DirectoryItemViewModel(handler: handler, item: model)
    }
    
    func reportRegionChange(region: MKCoordinateRegion) {
        requestRegionVariable.value = region
    }
    
    func annotationViewModel(for wrapper: AnnotationWrapper) -> MapAnnotationViewModel {
        
        return MapAnnotationViewModel(showsReportButton: false)
        
    }
    
}
