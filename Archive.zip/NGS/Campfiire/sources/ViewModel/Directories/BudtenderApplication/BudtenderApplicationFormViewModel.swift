//
//  BudtenderApplicationFormViewModel.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/14/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import Alamofire
import RxSwift

struct BudtenderApplicationFormViewModel : ViewModel {
    
    weak var handler: UIViewController?
    
    let backTrigger: Variable<Bool?> = Variable(nil)
    
    init(handler: UIViewController) {
        self.handler = handler
        
        indicator.asDriver()
            .drive(onNext: { [weak h = handler] (loading) in
                h?.changedAnimationStatusTo(status: loading)
            })
            .addDisposableTo(bag)
        
    }
    
    func apply(phone: String, reason: String) {
        
        guard phone.lengthOfBytes(using: .utf8) > 0 else {
            handler?.presentErrorMessage(error: "Please, provide valid phone")
            return
        }
        
        guard reason.lengthOfBytes(using: .utf8) > 0 else {
            handler?.presentErrorMessage(error: "Please, provide valid reasoning")
            return
        }
     
        Alamofire.request(BudtenderRouter.apply(phone: phone, reason: reason))
            .rx_campfiireResponse(CampfiireEmptyResponse.self)
            .silentCatch(handler: handler)
            .trackView(viewIndicator: indicator)
            .map { _ in
                return true
            }
            .bindTo(backTrigger)
            .addDisposableTo(bag)
        
    }
    
    fileprivate let bag = DisposeBag()
    fileprivate let indicator: ViewIndicator = ViewIndicator()
    
}
