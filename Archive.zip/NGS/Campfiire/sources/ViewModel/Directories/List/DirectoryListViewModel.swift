//
//  DespensariesViewModel.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 15.11.16.
//  Copyright © 2016 campfiire. All rights reserved.
//
import Foundation
import RxDataSources
import RxSwift
import RxCocoa
import MapKit
import ObjectMapper

struct DirectoryListViewModel<T: DirectoryListItemType> {
    
    weak var handler: UIViewController?
   
    init (handler: UIViewController, title: String,
          topAction: DirectoryListTopBarAction?,
          detailsViewModelProvider: ((UIViewController, T) -> DirectoryItemViewModelProtocol)? = nil,
          cellProvider: @escaping (UITableView, T) -> UITableViewCell) {
        
        self.handler = handler
        self.title = title
        self.topBarAction = topAction
        self.detailsViewModelProvider = detailsViewModelProvider
        self.cellProvider = cellProvider
        
        ////search bindings
        query.asObservable()
            .distinctUntilChanged()
            .debounce(0.4, scheduler: MainScheduler.asyncInstance)
            .map { DirectoryListDataProvider(query : $0)}
            .silentCatch(handler: handler)
            .bindTo(providerViewModel.dataProvider)
            .addDisposableTo(self.bag)
        
        searchBarHidden.asObservable()
            .filter { $0 }
            .map { _ in "" }
            .bindTo(query)
            .addDisposableTo(self.bag)
        
        
        ////data provider bindings
        self.providerViewModel.displayDataDriver
            .drive(dataTable)
            .addDisposableTo(self.bag)
        
        providerViewModel.loadingBatchDriver
            .drive( onNext: { [weak h = handler] batch in
                
                var shouldAnimate = false
                if let b = batch, b.offset == 0 { ///animating only for the very first batch
                    shouldAnimate = true
                }
                
                h?.changedAnimationStatusTo(status: shouldAnimate)
            })
            .addDisposableTo(bag)
        
    }
    
    let dataTable = Variable<[T]>([])
    
    let providerViewModel: FeedViewModel<DirectoryListDataProvider<T>> = FeedViewModel()

    internal let query: Variable<String> = Variable("")
    internal let bag: DisposeBag = DisposeBag()
    let searchBarHidden: Variable<Bool> = Variable(true)
    
    internal let title : String
    internal var topBarButtonImage: UIImage? {
        return topBarAction?.icon
    }
    
    typealias DataSourceType = AnimatableSectionModel<String, T>
    fileprivate let dataSource = RxTableViewSectionedAnimatedDataSource<DataSourceType>()
    
    fileprivate var topBarAction: DirectoryListTopBarAction?
    fileprivate var detailsViewModelProvider: ((UIViewController, T) -> DirectoryItemViewModelProtocol)?
    fileprivate let cellProvider: (UITableView, T) -> UITableViewCell
}

extension DirectoryListViewModel: DirectoryListViewModelProtocol {
    
    var searchBarHiddenObservable: Observable<Bool> {
        return searchBarHidden.asObservable()
    }
    
    var searchBarConstraintObservable: Observable<CGFloat> {
        return searchBarHidden.asObservable().map { $0 ? 44 : 0 }
    }
    
    var showsEmptyData: Driver<Bool> {
        return dataTable.asDriver()
            .map { $0.count == 0 }
            .skip(1)
    }
    
    func configureTableView(tableView: UITableView) {
        dataSource.configureCell = { (_, tv, _, item) in
            
            return self.cellProvider(tv, item)

        }
        
        dataTable.asDriver()
            .map {
                [AnimatableSectionModel(model: "", items: $0 )]
            }
            .drive(tableView.rx.items(dataSource: dataSource))
            .addDisposableTo(bag)
    }
    
    func detailViewModel(at: IndexPath, handler: UIViewController) -> DirectoryItemViewModelProtocol {
        
        let model = dataTable.value[at.row]
     
        return detailsViewModelProvider?(handler, model) ??
            DirectoryItemViewModel( handler: handler, item: model )
    }
    
    func topActionController() -> UIViewController? {
        return topBarAction?.screenProvider()
    }
    
    func setPageTrigger(trigger: Observable<Void>) {
        self.providerViewModel.pageTrigger.value = trigger
    }
    
    func searchQueryChanged(query: String) {
        self.query.value = query
    }
    
    func switchSearchBarStatus() {
        let isHidden = searchBarHidden.value
        searchBarHidden.value = !isHidden
    }
    
}

struct DirectoryListDataProvider<T: DirectoryListLoadType> : DataProvider {
    
    typealias DataType = T
    
    let query : String
    
    func loadBatch(batch: Batch) -> Observable<[T]> {
        return DirectoryManager<T>.entitiesFor(query: query, batch: batch)
    }
}
