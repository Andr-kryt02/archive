//
//  DirectoryListTopBarAction.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/12/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

struct DirectoryListTopBarAction {
 
    let icon: UIImage
    let screenProvider: () -> UIViewController?
    
}
