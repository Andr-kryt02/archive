//
//  DirectoryItemBottomButtonAction.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/12/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

struct DirectoryItemBottomButtonAction {
    
    let buttonTitle: String
    let screenProvider: () -> UIViewController?
    
}
