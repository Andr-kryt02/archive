//
//  PainClinicViewModel.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 15.11.16.
//  Copyright © 2016 campfiire. All rights reserved.
//


import RxSwift
import RxDataSources
import RxCocoa
import ObjectMapper

extension DirectoryItemViewModel: DirectoryItemViewModelProtocol {
    
    var isLikedDriver: Driver<Bool> {
        return item.asDriver()
            .map { $0.isLiked }
            .distinctUntilChanged()
    }
    var likeCountDriver: Driver<Int> {
        return item.asDriver()
            .map { $0.likesCount }
            .distinctUntilChanged()
    }
    
    var itemName: String { return item.value.directoryDetailsTitle }
    var itemDetails: String? { return item.value.directoryDetailsSubtitle }
    var itemPictureURL: String { return item.value.directoryDetailsPictureURL }
    
    var leftDescription: String? { return item.value.leftDescription }
    var rightDescription: String? { return item.value.rightDescription }
    var bottomButtonTitle: String? { return bottomAction?.buttonTitle }
    
    func configureTableView(tableView: UITableView,
                            cellProvider: @escaping (TraitCellViewModel) -> UITableViewCell) {
        
        dataSource.configureCell = { (_, _, _, item) in
            return cellProvider(item)
        }
        
        traitData.asDriver()
            .map { [AnimatableSectionModel(model: "", items: $0 )] }
            .drive(tableView.rx.items(dataSource: dataSource))
            .addDisposableTo(bag)
        
    }
 
    func bottomActionController() -> UIViewController? {
        return bottomAction?.screenProvider()
    }
    
}

struct DirectoryItemViewModel<T: DirectoryItemType>: ViewModel  {
    
    internal weak var handler: UIViewController?
    
    init(handler: UIViewController,
         item: T,
         bottomAction: DirectoryItemBottomButtonAction? = nil) {
        self.handler = handler
        self.item = Variable(item)
        self.bottomAction = bottomAction
        self.externalActions = ExternalActionsViewModel(handler: handler)
        
        ///retreive details, then proceed
        DirectoryManager<T>.details(of: item)
            .trackView(viewIndicator: indicator)
            .retry(1)
            .silentCatch(handler: handler)
            .subscribe(onNext: { [weak i = self.item,
                                  weak m = optimisticManager] item in
                m?.confirmedModel = item
                i?.value = item
            })
            .addDisposableTo(bag)
        
        ////optimisticManager
        optimisticManager.likeActionOutcome
            .bindTo(self.item)
            .addDisposableTo(bag)
        
        ////indicator
        indicator.asDriver()
            .drive(onNext: { [weak h = handler] (loading) in
                h?.changedAnimationStatusTo(status: loading)
            })
            .addDisposableTo(bag)
        
        ///traits data binding
        self.item.asDriver()
            .map { item in
                let traits = item.traits
                return traits.flatMap { trait in
                    return TraitCellViewModel(traitType: trait,
                                              editable: false,
                                              value: item,
                                              hideOnEmptyContent: true)
                }
            }
            .drive(traitData)
            .addDisposableTo(bag)

    }
    
    fileprivate let item: Variable<T>
    
    typealias DataSourceType = AnimatableSectionModel<String, TraitCellViewModel>
    fileprivate let dataSource = RxTableViewSectionedAnimatedDataSource<DataSourceType>()
    fileprivate let traitData: Variable<[TraitCellViewModel]> = Variable([])
    
    fileprivate let optimisticManager: OptimisticModelManager<T> = OptimisticModelManager()
    fileprivate var bottomAction: DirectoryItemBottomButtonAction?
    fileprivate var externalActions :ExternalActionsViewModel
    
    internal let bag = DisposeBag()
    internal let indicator: ViewIndicator = ViewIndicator()
    
    
    
}

extension DirectoryItemViewModel {
    
    func switchLikeStatus() {
        
        let model = item.value
        
        optimisticManager.queueChange(change: !model.isLiked, model: model)
        
    }
    
    func traitSelected(at: IndexPath) {
        let trait = traitData.value[at.row].traitType
        let data = traitData.value[at.row].title
        
        externalActions.handleTrait(trait: trait, content: data)
        
    }
    

    
}
