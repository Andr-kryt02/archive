//
//  TopRatedCategoryListViewModel.swift
//  Campfiire
//
//  Created by Andrew Seregin on 12/9/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa
import RxDataSources

struct TopRatedListViewModel<T: IdentifiableType & Equatable,
                             S: TopRatedListProvider> : ViewModel where S.DataType == T {
    
    internal weak var handler: UIViewController?
    let title: String
    
    init(handler: UIViewController,
         title: String,
         detailsProvider: @escaping (T) -> UIViewController,
         cellProvider: @escaping (UITableView, IndexPath, T) -> UITableViewCell,
         listProvider: S.Type) {
        self.handler = handler
        self.title = title
        self.detailsViewModelProvider = detailsProvider
        self.cellProvider = cellProvider
        
        listProvider.top10List
            .silentCatch(handler: handler)
            .trackView(viewIndicator: indicator)
            .bindTo(data)
            .addDisposableTo(bag)
        
        indicator.asDriver()
            .drive(onNext: { [weak h = handler] (loading) in
                h?.changedAnimationStatusTo(status: loading)
            })
            .addDisposableTo(bag)
        
    }
 
    typealias DataSourceType = AnimatableSectionModel<String, T>
    fileprivate let dataSource = RxTableViewSectionedAnimatedDataSource<DataSourceType>()
    
    fileprivate let detailsViewModelProvider: (T) -> UIViewController
    fileprivate let cellProvider: (UITableView, IndexPath, T) -> UITableViewCell
    
    fileprivate let data: Variable<[T]> = Variable([])
    fileprivate let bag = DisposeBag()
    fileprivate let indicator: ViewIndicator = ViewIndicator()
}


extension TopRatedListViewModel : TopRatedListViewModelProtocol {
    
    func configureTableView(tableView: UITableView) {
        dataSource.configureCell = { (_, tv, ip, item) in
            
            return self.cellProvider(tv, ip, item)
            
        }
        
        data.asDriver()
            .map {
                [AnimatableSectionModel(model: "", items: $0 )]
            }
            .drive(tableView.rx.items(dataSource: dataSource))
            .addDisposableTo(bag)
    }
    
    func detailScreen(at: IndexPath) -> UIViewController {
        
        let model = data.value[at.row]
        
        return detailsViewModelProvider(model)
    }
    
}
