//
//  TopRatedListProvider.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/14/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire
import ObjectMapper

protocol TopRatedListProvider {
    
    associatedtype DataType
    
    static var top10List: Observable<[DataType]> { get }
    
}

struct AlamofireTopRatedProvider<T: Top10RoutProvidable & Mappable & Fakeble> : TopRatedListProvider {
    typealias DataType = T

    static var top10List: Observable<[T]> {
        
//        var fakes: [T] = []
//        for _ in 0...10 {
//            fakes.append( T.fakeEntity() )
//        }
//        
//        return Observable.create({ (observer) -> Disposable in
//            
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
//                observer.onNext(fakes)
//                observer.onCompleted()
//            }
//            
//            return Disposables.create()
//        })

        return Alamofire.request( T.top10Rout )
                    .rx_campfiireResponse(CampfiireArrayResponse<T>.self)
    }
}
