//
//  DirectoriesViewModel.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 11.11.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation


struct DirectoriesViewModel : ViewModel {


    internal weak var handler: UIViewController?

    
}
