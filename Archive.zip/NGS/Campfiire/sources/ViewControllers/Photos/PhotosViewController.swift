//
//  PhotosViewController.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/21/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

class PhotosViewController: UIViewController, ViewController {
    
    lazy var viewModel: PhotosViewModel! = PhotosViewModel(handler: self)
    
    @IBOutlet weak var myPhotosButton: UIButton!
    @IBOutlet weak var underlineView: UIView!
    @IBOutlet weak var friendsPhotosButton: UIButton!
    
    fileprivate var percent: CGFloat = 0 {
        didSet {
            if percent < 0 { percent = 0; return }
            if percent > 1 { percent = 1; return }
            
            let left: UIButton = myPhotosButton
            let right: UIButton = friendsPhotosButton
            
            let frame = CGRect(x: transformer( left.frame.origin.x + 5, right.frame.origin.x + 5 ),
                               y: transformer( left.frame.origin.y, right.frame.origin.y ) + 30,
                               width: transformer( left.frame.size.width - 10, right.frame.size.width - 10 ),
                               height: 1)
            
            UIView.animate(withDuration: 0.3) {
                self.underlineView.frame = frame
            }
            
        }
    }
    lazy var transformer: (CGFloat, CGFloat) -> CGFloat =
        { [unowned self] (x: CGFloat, y: CGFloat) -> CGFloat in
            
            return (1 - self.percent) * x + self.percent * y
            
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "embed photo feed" {
            
            let controller = segue.destination as! NewsFeedTableViewController
            
            controller.viewModel = viewModel.feedViewModel
            
        }
        
    }
}

extension PhotosViewController {
    
    @IBAction func addPhotoTapped(_ sender: Any) {
        viewModel.addPhotoTapped()
    }
    
    @IBAction func friendsButtonTapped(_ sender: Any) {
        percent = 1
        viewModel.providerChanged(friendsPhoto: true)
    }
    
    @IBAction func myPhotosTapped(_ sender: Any) {
        percent = 0
        viewModel.providerChanged(friendsPhoto: false)
    }
    
}
