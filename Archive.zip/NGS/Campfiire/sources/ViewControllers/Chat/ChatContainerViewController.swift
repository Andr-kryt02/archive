//
//  ChatViewController.swift
//  Campfiire
//
//  Created by Andrew Seregin on 1/18/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import Foundation
import RxSwift

class ChatContainerViewController : UIViewController {

    var viewModel: ChatMessagesProvider!
    
    @IBOutlet weak var imageView: UIImageView! {
        didSet {
            imageView.layer.cornerRadius = imageView.frame.size.height / 2
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        viewModel.title
            .drive(rx.title)
            .addDisposableTo(rx_disposeBag)
        
        viewModel.imageURL
            .flatMap { ImageRetreiver.imageAuthorizedWithoutProgress(at: $0) }
            .map { $0 ?? R.image.logoLast()! }
            .drive( imageView.rx.image(transitionType: kCATransitionFade) )
            .addDisposableTo(rx_disposeBag)
        
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier! == R.segue.chatContainerViewController.presentChatScreen.identifier {
            let controller = segue.destination as! ChatViewController
            controller.viewModel = viewModel
        }
        
    }

    
}
