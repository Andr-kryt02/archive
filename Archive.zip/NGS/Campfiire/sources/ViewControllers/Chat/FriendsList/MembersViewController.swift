//
//  MembersViewController.swift
//  Campfiire
//
//  Created by Andrew Seregin on 1/17/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import Foundation

import RxSwift
import RxCocoa
import RxDataSources

class MembersViewController: UIViewController, ViewController {
    
    @IBOutlet var tableView: UITableView!
    
    var viewModel: MembersViewModel!
    
    let dataSource : RxTableViewSectionedAnimatedDataSource<AnimatableSectionModel<String, ChatUserViewModel>> = RxTableViewSectionedAnimatedDataSource()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let backButton = UIBarButtonItem(image: R.image.backButton(),
                                         style : .plain,
                                         target : self,
                                         action : #selector(MembersViewController.safePop))
        navigationItem.leftBarButtonItem = backButton
        
        dataSource.configureCell = { [unowned self] (dataSource, tableView, indexPath, item) in
            
            let cell = tableView.dequeueReusableCell(withIdentifier: R.reuseIdentifier.chatMemberTableCell,
                                                     for: indexPath)!
            cell.delegate = self
            cell.cellConfigure(viewModel: item)
            
            return cell
        }
        
        ////bind friend list
        viewModel.datasource
            .drive(tableView.rx.items(dataSource: dataSource))
            .addDisposableTo(rx_disposeBag)
        
        ///empty state
        tableView.bindEmptyStateTo = viewModel.showsEmptyState
        
    }
    
    @IBAction func confirmationPressed(_ sender: Any) {
        viewModel.approveClicked()
        let _ = self.navigationController?.popViewController(animated: true)
    }
}

extension MembersViewController {
    
    func safePop() {
        presentConfirmQuestion(question: DisplayMessage(title: "Warning",
                                                        description: "All unsaved data will be lost. Proceed?"))
            .filter { $0 }
            .subscribe(onNext: { [weak n = navigationController] (_) in
                let _ = n?.popViewController(animated: true)
            })
            .addDisposableTo(rx_disposeBag)
    }
}

extension MembersViewController : MemberCellDelegate {
    
    func changeMemberStatus(cell: ChatMemberCell) {
        viewModel.configureMemberStatus(at: tableView.indexPath(for: cell)! )
    }
    
}
