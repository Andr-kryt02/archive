//
//  ChatsListViewController.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/30/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import RxSwift
import RxCocoa
import RxDataSources

class ChatsListViewController: UIViewController, ViewController, UISearchBarDelegate {

    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var searchButton: UIButton!
    @IBOutlet var searchBarHideConstraint: NSLayoutConstraint!
    @IBOutlet var tableView: UITableView!
    
    @IBOutlet weak var addChatBarButton: UIBarButtonItem!
    
    lazy var viewModel: ChatsListViewModel! = ChatsListViewModel(handler: self)
    
    let dataSource: RxTableViewSectionedAnimatedDataSource<AnimatableSectionModel<String, ChatsListTableItem>> = RxTableViewSectionedAnimatedDataSource()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.allowsMultipleSelectionDuringEditing = false
        
        viewModel.providerViewModel.pageTrigger.value =
            tableView!.rxex_simpleBottomShownTrigger()
        
        self.dataSource.configureCell = { (dataSourse, tableView, indexPath, item) in
            
            let cell = tableView.dequeueReusableCell(withIdentifier: R.reuseIdentifier.chatsListTableCell , for: indexPath)!
            
            switch item {
            case .group(let chat): cell.cellPresentable = chat
            case .personal(let chat): cell.cellPresentable = chat
            }
            
            return cell
            
        }
        
        dataSource.canEditRowAtIndexPath = { (_, ip) -> Bool in
            return true
        }
        
        viewModel.displayData
            .drive(tableView.rx.items(dataSource: self.dataSource))
            .addDisposableTo(rx_disposeBag)
        
        viewModel.searchBarHidden.asObservable()
            .do(onNext: { [unowned self] (hidden) in
                
                self.searchBar.isUserInteractionEnabled = !hidden
                
                let _ = hidden ?
                    self.searchBar.resignFirstResponder() :
                    self.searchBar.becomeFirstResponder()
                
            })
            .map { $0 ? 44 : 0 }
            .skip(1)
            .subscribe(onNext: { [unowned self] (value) in
                
                self.searchBarHideConstraint.constant = CGFloat(value)
                UIView.animate(withDuration: 0.3) {
                    self.view.layoutIfNeeded()
                }
            })
            .addDisposableTo(rx_disposeBag)
        
        ////select chat
        tableView.rx.itemSelected
            .asDriver()
            .drive(onNext: { [unowned self,
                weak n = navigationController,
                weak t = tableView] ip in
                
                t?.deselectRow(at: ip, animated: true)
                
                let controller = R.storyboard.chats.chatContainerViewController()!
                controller.viewModel = self.viewModel.chatViewModelForItem(at: ip, for: controller)
                
                n?.pushViewController(controller, animated: true)
                
            }).addDisposableTo(rx_disposeBag)

        
        tableView.rx.itemDeleted.asDriver()
            .drive(onNext: { [unowned self] (ip) in
                self.viewModel.removeChat(at: ip)
            })
            .addDisposableTo(rx_disposeBag)
        
        searchButton
            .rx.tap.subscribe(onNext: { [unowned self] in
                self.viewModel.switchSearchBarStatus()
            }).addDisposableTo(rx_disposeBag)
        
        view.bindEmptyStateTo = viewModel.showsEmptyState
        
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        viewModel.searchQueryChanged(query: searchText)
    }
    
    @IBAction func addChat(_ sender: Any) {
        
//        let controller = R.storyboard.chats.upsertChatViewController()!
//        
//        controller.viewModel = UpsertChatViewModel(handler: controller, initialChat: nil)
//        
//        navigationController?.pushViewController(controller, animated: true)
        
    }
    
}


