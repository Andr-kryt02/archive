//
//  UpsertChatViewController.swift
//  Campfiire
//
//  Created by Andrew Seregin on 1/5/17.
//  Copyright © 2017 campfiire. All rights reserved.
//


import Foundation
import TOCropViewController

class UpsertChatViewController  : UIViewController, ViewController
{
    
    var viewModel : UpsertChatViewModel!
    
    @IBOutlet var upsertView: UpsertChatView!
    
    @IBOutlet var skinsItem: UIBarButtonItem! {
        didSet {
            skinsItem.target = self
            skinsItem.action = #selector(UpsertChatViewController.skinsTapSave)
        }
    }
    
    @IBOutlet var notificationItem: UIBarButtonItem! {
        didSet {
            notificationItem.target = self
            notificationItem.action = #selector(UpsertChatViewController.notificationTapSave)
        }
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        upsertView.viewModel = viewModel

//        if !viewModel.settingButtonsHidden
//        {
//            navigationItem.rightBarButtonItems = [notificationItem, skinsItem]
//        }
//        
//        viewModel.navigationTitleString
//            .bindTo(self.rx.title)
//            .addDisposableTo(rx_disposeBag)
//        
//        let backButton = UIBarButtonItem(image: R.image.backButton(),
//                                         style: .plain,
//                                         target: self,
//                                         action: #selector(UpsertChatViewController.safePop))
//        navigationItem.leftBarButtonItem = backButton
    }
    func safePop()
    {
//        viewModel.prepareAllert(onEdit:
//            {
//                presentSaveAndExitQuestion(question: DisplayMessage(title: "Attention",
//                                                                    description: "Please select one of the following actions."))
//                    .subscribe(onNext: { [unowned self] result in
//                        self.viewModel.applyAction(response: result)
//                    })
//                    .addDisposableTo(rx_disposeBag)
//            },
//                                onCreate:
//            {
//                presentConfirmQuestion(question: DisplayMessage(title : "Warning",
//                                                                description: "All unsaved data will be lost. Proceed?"))
//                    .filter { $0 }
//                    .subscribe(onNext: { [weak n = self.navigationController] (_) in
//                        let _ = n?.popViewController(animated: true)
//                    })
//                    .addDisposableTo(rx_disposeBag)
//                
//            })
//        
    }
    
    
    
    
    @IBAction func changeAvatar(_ sender: Any) {
        
//        viewModel.selectAvatarClicked(){ [unowned self] image in
//            
//            let cropController : TOCropViewController = TOCropViewController(croppingStyle: .circular, image: image)
//            cropController.delegate = self
//            
//            self.navigationController?.pushViewController(cropController, animated: true)
//            
//        }
    }
}

extension UpsertChatViewController
{
    func skinsTapSave()
    {
        //TODO: Redirect to Skin controller
    }
    
    func notificationTapSave()
    {
        
    }
}

extension UpsertChatViewController : TOCropViewControllerDelegate
{
    func cropViewController(_ cropViewController: TOCropViewController, didCropToCircularImage image: UIImage, with cropRect: CGRect, angle: Int)
    {
     //   viewModel.confirmCrop(image: image)
//        let _ = self.navigationController?.popViewController(animated: true)
    }
}
