//
//  MessageListViewController.swift
//  Campfiire
//
//  Created by Andrew Seregin on 1/18/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import Foundation

import RxSwift
import RxCocoa
import RxDataSources

import SlackTextViewController

protocol ChatMessagesProvider: ViewModel {
    
    var displayLatestMessageTriggerAnimated: Driver<Bool> { get }
    
    var dataSource: Driver<[AnimatableSectionModel<String, ChatMessage>]> { get }
 
    var title: Driver<String> { get }
    var imageURL: Driver<String> { get }
    
    func heightForRow(at: IndexPath, width: CGFloat) -> CGFloat
    
    func sendMessage(content: String)
    func loadMore()
    func uploadMedia()
}

class ChatViewController : SLKTextViewController {
 
    override class func tableViewStyle(for decoder: NSCoder) -> UITableViewStyle {
        return .plain
    }
    
    var viewModel: ChatMessagesProvider!
    
    lazy var refreshControl: UIRefreshControl = {
        let r = UIRefreshControl()
        
        r.addTarget(self, action: #selector(ChatViewController.loadMore), for: .valueChanged)
        
        return r
    }()
    
    let dataSource: RxTableViewSectionedReloadDataSource<AnimatableSectionModel<String, ChatMessage>> = RxTableViewSectionedReloadDataSource()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        isInverted = false
        
        tableView?.separatorStyle = .none
        
        tableView!.addSubview(refreshControl)
        tableView!.dataSource = nil
        
        textView.placeholder = "Type here"
        textView.keyboardType = .default
        
        tableView?.register(R.nib.chatImageCell)
        tableView?.register(R.nib.chatMessageCell)
        
        leftButton.setImage(R.image.add()!, for: .normal)
        leftButton.tintColor = UIColor.gray
        
        rightButton.setBackgroundImage(R.image.textInput()!, for: .normal)
        rightButton.setTitle(nil, for: .normal)
        
        dataSource.configureCell = { (dataSource, tableView, indexPath, item) in
            
            guard !item.isImageMessage else {
                let cell = tableView.dequeueReusableCell(withIdentifier: R.reuseIdentifier.chatImageCell)!
                
                cell.chatMessage = item
                
                return cell
            }
            
            let cell = tableView.dequeueReusableCell(withIdentifier: R.reuseIdentifier.chatMessageCell)!
            
            cell.chatMessage = item
            
            return cell
        }
        
        ////bind chat list
        viewModel.dataSource
            .drive(tableView!.rx.items(dataSource: dataSource))
            .addDisposableTo(rx_disposeBag)
        
        ///
        viewModel.dataSource
            .drive(onNext: { [unowned self] _ in
                self.refreshControl.endRefreshing()
            })
            .addDisposableTo(rx_disposeBag)
        
        ////
        ///------
        ////
        viewModel.displayLatestMessageTriggerAnimated
            .drive(onNext: { [unowned self] animated in
                self.tableView!.scrollToBottom(animated: animated)
            })
            .addDisposableTo(rx_disposeBag)
        
    }
    
//    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        
//        let cell = super.collectionView(collectionView, cellForItemAt: indexPath) as! JSQMessagesCollectionViewCell
//        
//        cell.textView?.textColor = UIColor.chatTextColor
//        
//        return cell
//    }
//    
    
    override func tableView(_ tableView: UITableView,
                            heightForRowAt indexPath: IndexPath) -> CGFloat {
        return viewModel.heightForRow(at: indexPath, width: ChatMessageCell.bubleWidth)
    }
    
    override func didPressRightButton(_ sender: Any?) {
        let t: String = textView.text
        viewModel.sendMessage(content: t)
        
        super.didPressRightButton(sender)
    }
    
    override func didPressLeftButton(_ sender: Any?) {
        viewModel.uploadMedia()
    }
    
    func loadMore() {
        viewModel.loadMore()
    }
    
}

 
