//
//  SettingsViewController.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/25/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa


class SettingsViewController : UIViewController, ViewController {
    
    lazy var viewModel: SettingsViewModel! = SettingsViewModel(handler: self)
    
    @IBOutlet weak var timeFormatSwitch: UISwitch!
    @IBOutlet weak var attachmentsSwitch: UISwitch!
    @IBOutlet weak var eventsSwitch: UISwitch!
    @IBOutlet weak var pushSwitch: UISwitch!
    @IBOutlet weak var visibilitySegments: UISegmentedControl!
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewModel.profileVisibilityObservable
            .distinctUntilChanged()
            .subscribe(onNext: { [weak self] (ind: Int) in
                self?.visibilitySegments.selectedSegmentIndex = ind
            }).addDisposableTo(rx_disposeBag)
        
        viewModel.dateFormatObservable
            .distinctUntilChanged()
            .bindTo(timeFormatSwitch.rx.value)
            .addDisposableTo(rx_disposeBag)
        
        viewModel.pushObservable
            .distinctUntilChanged()
            .bindTo(pushSwitch.rx.value)
            .addDisposableTo(rx_disposeBag)
        
        viewModel.eventObservable
            .distinctUntilChanged()
            .bindTo(eventsSwitch.rx.value)
            .addDisposableTo(rx_disposeBag)
        
        viewModel.attachmentsObservable
            .distinctUntilChanged()
            .bindTo(attachmentsSwitch.rx.value)
            .addDisposableTo(rx_disposeBag)
        
    }
 

    @IBAction func pushSwitchChanged(_ sender: UISwitch) {
        viewModel.pushSwitchChanged(status: sender.isOn)
    }
    
    @IBAction func eventInFeedChanged(_ sender: UISwitch) {
        viewModel.eventInFeedChanged(status: sender.isOn)
    }
    
    @IBAction func attachmentCellularChanged(_ sender: UISwitch) {
        viewModel.attachmentCellularChanged(status: sender.isOn)
    }
    
    @IBAction func dateFormatChanged(_ sender: UISwitch) {
        viewModel.dateFormatChanged(status: sender.isOn)
    }
    
    
    @IBAction func profileVisibilityChanged(_ sender: UISegmentedControl) {        
         viewModel.profileVisibilityChanged(selectedIndex: sender.selectedSegmentIndex)
    }
    
    @IBAction func infoAboutDeveloperTapped(_ sender: AnyObject) {
        performSegue(withIdentifier: "showAboutUs",
                     sender: self)
    }
    
}
