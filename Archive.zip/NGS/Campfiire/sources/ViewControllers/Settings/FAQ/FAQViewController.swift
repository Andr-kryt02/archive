//
//  FAQViewController.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/6/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import UIKit
import RxSwift
import RxDataSources

struct FAQItem {
    
    let title: String
    let body: String
    var expanded: Bool
    
}

class FAQViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var tableViewConstraint: NSLayoutConstraint!
    
    var data = [ FAQItem(title: User.fakeString(), body: User.fakeString(components: 50), expanded: false),
                 FAQItem(title: User.fakeString(), body: User.fakeString(components: 50), expanded: false),
                 FAQItem(title: User.fakeString(), body: User.fakeString(components: 50), expanded: false),
                 FAQItem(title: User.fakeString(), body: User.fakeString(components: 50), expanded: false) ]
        
    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.delegate = self
        
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 200

        
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: R.reuseIdentifier.fAQTableViewCell)!
        
        let data = self.data[indexPath.row]
        
        cell.nameLabel.text = data.title
        cell.textView.text = data.body
        cell.expanded = data.expanded
        
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt ip: IndexPath) {
        
        var v = data[ip.row]
        v.expanded = !v.expanded
        data[ip.row] = v
        
        tableView.reloadRows(at: [ip], with: UITableViewRowAnimation.automatic)
        
    }
    
}
