//
//  AppNavigationController.swift
//  Night Life
//
//  Created by Vlad Soroka on 3/29/16.
//  Copyright © 2016 com.NightLife. All rights reserved.
//

import UIKit

class AppNavigationController : UINavigationController, UINavigationControllerDelegate {
    
    override func loadView() {
        super.loadView()
        
        self.delegate = self
        
        self.navigationBar.setBackgroundImage(UIImage(),
                                              for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationBar.backgroundColor = UIColor.clear

        self.navigationBar.tintColor = UIColor.white
        
    }
    
    func navigationController(_ navigationController: UINavigationController,
                              willShow viewController: UIViewController,
                              animated: Bool) {
        
        guard let first = navigationController.viewControllers.first
        else { return }
        
        if viewController === first {
            
            viewController.navigationItem.leftBarButtonItem = drawerButton
            
        }
    }
    
    
    lazy var drawerButton: UIBarButtonItem = {
        let button = UIBarButtonItem(image: R.image.hamburger(), style: .plain,
                                     target: self.revealViewController()!,
                                     action: #selector(SWRevealViewController.revealToggle(_:)))
        
        button.accessibilityIdentifier = "hamburger"
        return button
    }()
    
}
