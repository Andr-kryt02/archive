//
//  SideViewController.swift
//  Night Life
//
//  Created by Vlad Soroka on 2/4/16.
//  Copyright © 2016 com.NightLife. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

class SideViewController : UITableViewController {
    
    @IBOutlet weak var avatarWidthConstr: NSLayoutConstraint!
    @IBOutlet weak var avatarImageView: UIImageView! {
        didSet {
            avatarImageView.layer.borderWidth = 1
            avatarImageView.layer.borderColor = UIColor.white.cgColor
        }
    }
    
    @IBOutlet weak var friendRequestsLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!

    
    let bag = DisposeBag()
    
    override func loadView() {
        super.loadView()
        
        avatarImageView.layer.cornerRadius = avatarWidthConstr.constant / 2
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        guard let u = User.currentUser()?.observableEntity()?.asDriver() else {
            fatalError("Side viewController is created earlier that current user exist")
        }
        
        u.map { $0.name }
            .drive(nameLabel.rx.text)
            .addDisposableTo(rx_disposeBag)
        
        u.map { $0.pictureURL }
            .flatMap { ImageRetreiver.imageForURLWithoutProgress(url: $0) }
            .map { $0 ?? R.image.noImagenoShadow() }
            .drive(avatarImageView.rx.image(transitionType: kCATransitionFade))
            .addDisposableTo(bag)
        
        ////Friend Request counter
        
        let requestCountDriver = FriendRequestManager
            .requestsCount
            .asDriver()
        
        requestCountDriver.map { $0 == 0 }
            .drive(friendRequestsLabel.rx.isHidden)
            .addDisposableTo(bag)
        
        requestCountDriver.map { "+\($0)" }
            .drive(friendRequestsLabel.rx.text)
            .addDisposableTo(bag)
        
        FriendRequestManager.refreshRequestsCount()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        ///SWRevealViewController force adjusts contentInset if UIViewController's view is UIScrollView subclass (which is the case for this class)
        ///We require total control over TableViewLayout so we are canceling SWRevealViewController's rules
        self.tableView.contentInset = UIEdgeInsets.zero
        
        ///TODO: |Vlad| there must be a better way of updating storage rather than quering server on each appearence
        FriendRequestManager.refreshRequestsCount()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
       // avatarImageView.layer.cornerRadius = avatarImageView.frame.size.height / 2
        
        //unreadMessagesLabel.layer.cornerRadius = unreadMessagesLabel.frame.size.height / 2
     //   self.tableView.contentInset = UIEdgeInsetsZero
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let identifier = segue.identifier else { return }
        
        switch identifier {
            
        case R.segue.sideViewController.toUserProfile.identifier:
            let controller = (segue.destination as! UINavigationController).viewControllers.first! as! UserProfileViewController
            
            if User.currentUser() == nil {
                let user = User.fakeEntity()
                user.becomeCurrent()
            }
            
            controller.viewModel = UserProfileViewModel(handler: controller,
                                                        user: User.currentUser()!)
            
        case R.segue.sideViewController.toHotSpots.identifier:
        
            ////making sure location is at least tried to be requested
            let _ = LocationManager.instance.lastRecordedLocationObservable
            
        default: break
            
            
        }
    }

}
