//
//  DespensariesTableViewController.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 15.11.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

import MapKit

protocol DirectoryListViewModelProtocol: ViewModel {
    
    ///things I need
    var title: String { get }
    var searchBarHiddenObservable: Observable<Bool> { get }
    var searchBarConstraintObservable: Observable<CGFloat> { get }
    var topBarButtonImage: UIImage? { get }
    var showsEmptyData: Driver<Bool> { get }
    
    func topActionController() -> UIViewController?
    
    ///viewModels I can present
    func detailViewModel(at: IndexPath,
                         handler: UIViewController) -> DirectoryItemViewModelProtocol
    
    ///thing#
    func configureTableView(tableView: UITableView)
    
    func setPageTrigger(trigger: Observable<Void>)
    func searchQueryChanged(query: String)
    func switchSearchBarStatus()
    
}



class DirectoryListViewController : UIViewController, UISearchBarDelegate  {
    
    
    @IBOutlet weak var showLocations: UIButton!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var searchBarHideConstraint: NSLayoutConstraint!
    @IBOutlet weak var tableView: UITableView! {
        didSet {
            tableView.estimatedRowHeight = 63
            tableView.rowHeight = UITableViewAutomaticDimension
        }
    }
    
    var viewModel: DirectoryListViewModelProtocol!
  
    override func loadView() {
        super.loadView()
        
        tableView.register(R.nib.userSearchResultCell)
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
   
        tableView.delegate = nil
        tableView.dataSource = nil
        
        self.title = viewModel.title
        
        let image = viewModel.topBarButtonImage
        self.showLocations.setImage(image, for: .normal)
        self.showLocations.isHidden = image == nil
        
        viewModel.setPageTrigger(trigger: tableView!.rxex_simpleBottomShownTrigger())
        
        viewModel.searchBarHiddenObservable
            .subscribe(onNext: { [unowned self] (hidden) in
                let _ = hidden ?
                    self.searchBar.resignFirstResponder() :
                    self.searchBar.becomeFirstResponder()
            })
            .addDisposableTo(rx_disposeBag)
        
        viewModel.searchBarConstraintObservable
            .subscribe(onNext: { [unowned self] (value) in
                self.searchBarHideConstraint.constant = CGFloat(value)
                UIView.animate(withDuration: 0.3) {
                    self.view.layoutIfNeeded()
                }
            })
            .addDisposableTo(rx_disposeBag)

        
        viewModel.configureTableView(tableView: tableView)
        
        tableView.rx.itemSelected
            .asDriver()
            .drive(onNext: { [weak self,
                             weak tv = tableView] (indexPath: IndexPath) in
                
                tv?.deselectRow(at: indexPath, animated: true)
                
                let contr = R.storyboard.directories.directoryItemViewController()!
                let viewModel = self?.viewModel.detailViewModel(at: indexPath, handler: contr)
                
                contr.viewModel = viewModel
                
                self?.navigationController?.pushViewController(contr,
                                                               animated: true)
                
            })
            .addDisposableTo(rx_disposeBag)
        
        ////empty state
        tableView.bindEmptyStateTo = viewModel.showsEmptyData
        
    }
    
  
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        viewModel.searchQueryChanged(query: searchText)
    }
    
    
    @IBAction func openSearchBar(_ sender: UIBarButtonItem) {        
        
        viewModel.switchSearchBarStatus()
    }
    
   
    @IBAction func showLocations(_ sender: UIButton) {
        
        guard let contr = self.viewModel.topActionController() else {
            presentMessage(message: DisplayMessage(title: "Ouch",
                                                   description: "Action is not implemented yet"))
            return
        }
            
        self.navigationController?.pushViewController(contr,
                                                      animated: true)
    }
  
}
