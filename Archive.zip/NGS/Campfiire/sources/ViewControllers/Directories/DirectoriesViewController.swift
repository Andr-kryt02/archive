//
//  DirectoriesViewController.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 11.11.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import MapKit

class DirectoriesViewController : UIViewController, ViewController {

    lazy var viewModel: DirectoriesViewModel! = DirectoriesViewModel(handler: self)

    @IBAction func showDoctors(_ sender: UIButton) {
        
        let contr = R.storyboard.directories.directoryListViewController()!
        
        let cellProvider = directoryCellProvider(Doctor.self)
        let topBar = mapTopBarAction(Doctor.self)
        
        let viewModel = DirectoryListViewModel<Doctor>(handler: contr,
                                                       title: "Doctors",
                                                       topAction: topBar,
                                                       cellProvider: cellProvider)
        contr.viewModel = viewModel
        
        self.navigationController?.pushViewController(contr,
                                                      animated: true)
        
    }
    
    
    
    @IBAction func showPainClinics(_ sender: UIButton) {
    
        let contr = R.storyboard.directories.directoryListViewController()!
        
        let cellProvider = directoryCellProvider(PainClinic.self)
        let topBar = mapTopBarAction(PainClinic.self)
        
        let viewModel = DirectoryListViewModel<PainClinic>(
            handler: contr,
            title: "Pain Clinics",
            topAction: topBar,
            cellProvider: cellProvider)
        contr.viewModel = viewModel
        
        self.navigationController?.pushViewController(contr,
                                                      animated: true)
    }
    
    
    
    @IBAction func showProducers(_ sender: UIButton) {

        let contr = R.storyboard.directories.directoryListViewController()!
        
        let cellProvider = directoryCellProvider(LicensedProducer.self)
        let topBar = mapTopBarAction(LicensedProducer.self)
        
        let viewModel = DirectoryListViewModel<LicensedProducer>(
            handler: contr,
            title: "Licensed Producer",
            topAction: topBar,
            cellProvider: cellProvider)
        
        contr.viewModel = viewModel
        
        self.navigationController?.pushViewController(contr,
                                                      animated: true)
        
    }
    
    
    
    @IBAction func showOnlineStores(_ sender: UIButton) {
        
        let contr = R.storyboard.directories.directoryListViewController()!
        
        let cellProvider = directoryCellProvider(OnlineStore.self)
        
        let viewModel = DirectoryListViewModel<OnlineStore>(
            handler: contr,
            title: "Online Stores",
            topAction: nil,
            cellProvider: cellProvider)
        
        contr.viewModel = viewModel
        
        self.navigationController?.pushViewController(contr,
                                                      animated: true)

    }
    
    
    @IBAction func showDispensaries(_ sender: UIButton) {
    
        let contr = R.storyboard.directories.directoryListViewController()!
        
        let cellProvider = directoryCellProvider(Dispensary.self)
        let topBar = mapTopBarAction(Dispensary.self)
        
        let viewModel = DirectoryListViewModel<Dispensary>(
            handler: contr,
            title: "Dispensaries",
            topAction: topBar,
            cellProvider: cellProvider)

        contr.viewModel = viewModel
        
        self.navigationController?.pushViewController(contr,
                                                      animated: true)
    }
    
    
    @IBAction func showBudtenders(_ sender: UIButton) {
        
        let contr = R.storyboard.directories.directoryListViewController()!
        
        let cellProvider =  { (tableView: UITableView, item: Budtender) -> UITableViewCell in
            let cell = tableView.dequeueReusableCell(withIdentifier: R.reuseIdentifier.userTableCell)!
            
            cell.configureWithUser(user: item, showsChatIcon: false)
            
            return cell
        }
        
        let topBar = DirectoryListTopBarAction(icon: R.image.applyIcon()!) {
            
            return R.storyboard.directories.budtenderApplicationFormViewController()!
            
        }
        
        let detailsProvider = { (vc: UIViewController, i: Budtender) -> DirectoryItemViewModelProtocol in
            
            let bottomAction = DirectoryItemBottomButtonAction(buttonTitle: "Contact this budtender") {
                
                let controller = R.storyboard.chats.chatContainerViewController()!
                controller.viewModel = OneToOneChatViewModel(handler: controller,
                                                             peer: i.user)
                
                return controller
            }
            
            return DirectoryItemViewModel<Budtender>(handler: vc,
                                                     item: i,
                                                     bottomAction: bottomAction)
        }
        
        let viewModel = DirectoryListViewModel<Budtender>(
            handler: contr,
            title: "Budtenders",
            topAction: topBar,
            detailsViewModelProvider: detailsProvider,
            cellProvider: cellProvider)
        
        contr.viewModel = viewModel
        
        self.navigationController?.pushViewController(contr,
                                                      animated: true)
        
    }


    private func mapTopBarAction<T: DirectoryMapItemType>(_ type: T.Type) -> DirectoryListTopBarAction {
        
        return DirectoryListTopBarAction(icon: R.image.mapIcon()!) {
            let contr = R.storyboard.directories.directoryMapViewController()!
        
            var initialRegion = MKCoordinateRegion.worldRegion
            
            if let l = LocationManager.instance.lastRecordedLocation {
                initialRegion = MKCoordinateRegionMakeWithDistance(l.coordinate, 5000, 5000)
            }
            
            let viewModel = DirectoryMapViewModel<T>(handler: contr,
                                                     initialRegion: initialRegion)
            contr.viewModel = viewModel
            
            return contr
        }
        
    }
    
    private func directoryCellProvider<T: DirectoryCellPresentable>(_ type: T.Type)
        -> ((UITableView, T) -> UITableViewCell) {
            
            return { (tableView: UITableView, item: T) -> UITableViewCell in
                let cell = tableView.dequeueReusableCell(withIdentifier: R.reuseIdentifier.directoryCell)!
                
                cell.item = item
                
                return cell
            }
            
    }
    
}
