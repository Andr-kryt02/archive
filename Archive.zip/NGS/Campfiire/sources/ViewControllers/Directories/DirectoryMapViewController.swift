//
//  EntityLocationsViewController.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 28.11.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import MapKit
import RxCocoa

protocol DirectoryMapViewModelProtocol: ViewModel {
    
    ///properties
    var searchBarHiddenDriver: Driver<Bool> { get }
    var searchBarConstraintDriver: Driver<CGFloat> { get }
    
    var annotationsDriver: Driver<[AnnotationWrapper]> { get }
    var visibleRegionDriver: Driver<MKCoordinateRegion> { get }
    
    ///viewModels for request
    func annotationViewModel(for wrapper: AnnotationWrapper) -> MapAnnotationViewModel
    
    ///actions
    func searchQueryChanged(query: String)
    func switchSearchBarStatus()
    func reportRegionChange(region: MKCoordinateRegion)
    func detailsViewModel(for annotation: AnnotationWrapper, handler: UIViewController) -> DirectoryItemViewModelProtocol
    
}

class DirectoryMapViewController : UIViewController, UISearchBarDelegate, AnnotationCalloutDelegate {
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var searchBarHideConstraint: NSLayoutConstraint!
    
    var viewModel: DirectoryMapViewModelProtocol!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewModel.searchBarHiddenDriver
            .drive(onNext: { [unowned self] (hidden) in
                let _ = hidden ?
                    self.searchBar.resignFirstResponder() :
                    self.searchBar.becomeFirstResponder()
            })
            .addDisposableTo(rx_disposeBag)
            
        
        viewModel.searchBarConstraintDriver
            .drive(onNext: { [unowned self] (value) in
                self.searchBarHideConstraint.constant = CGFloat(value)
                UIView.animate(withDuration: 0.3) {
                    self.view.layoutIfNeeded()
                }
            })
            .addDisposableTo(rx_disposeBag)
        
        viewModel.visibleRegionDriver
            .distinctUntilChanged()
            .drive(onNext: { [unowned self] region in
                
                self.mapView.setRegion(region, animated: true)
                
            })
            .addDisposableTo(rx_disposeBag)
        
        viewModel.annotationsDriver
            .drive(onNext: { [unowned self] (annotations) in
                
                self.mapView.removeAnnotations(self.mapView.annotations)
                
                self.mapView.addAnnotations(annotations)
                
            })
            .addDisposableTo(rx_disposeBag)
        
    }
    
    
    @IBAction func backToList(_ sender: UIButton) {
  
        self.popBack(animated: true)

    }
    
    @IBAction func openSearchBar(_ sender: UIBarButtonItem) {
        
        viewModel.switchSearchBarStatus()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        viewModel.searchQueryChanged(query: searchText)
    }
    
    func calloutViewTapped(for annotation: AnnotationWrapper) {
        
        let controller = R.storyboard.directories.directoryItemViewController()!
        
        let viewModel = self.viewModel.detailsViewModel(for: annotation, handler: controller)
        controller.viewModel = viewModel
        
        self.navigationController?.pushViewController(controller, animated: true)
    }
    
    func calloutReportTapped(for annotation: AnnotationWrapper) {} /// no reaction to this
    
}

extension DirectoryMapViewController : MKMapViewDelegate {
    
    func mapView(_ mapView: MKMapView,
                 regionDidChangeAnimated animated: Bool) {
        
        viewModel.reportRegionChange(region: mapView.region)
    }
    
    
    func mapView(_ mapView: MKMapView,
                 viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        if annotation is MKUserLocation { return nil }
        
        let pinId = "com.campfiire.pin"
        
        var view: AnnotationView! = mapView.dequeueReusableAnnotationView(withIdentifier: pinId) as? AnnotationView
        if view == nil {
        
            let v = AnnotationView(annotation: annotation,
                                   reuseIdentifier: pinId)
            
            v.delegate = self
            v.centerOffset = CGPoint(x: 0, y: -v.frame.size.height / 2)
            
            view = v
        }
        view.viewModel = viewModel.annotationViewModel(for: annotation as! AnnotationWrapper)
        
        
        return view
        
    }
    
    
}
