//
//  BudtenderApplicationFormViewController.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/14/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift

class BudtenderApplicationFormViewController: UIViewController, ViewController {
    
    lazy var viewModel: BudtenderApplicationFormViewModel! = BudtenderApplicationFormViewModel(handler: self)
    
    @IBOutlet weak var phoneNumberTextField: UITextField!
    @IBOutlet weak var reasonTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.tapToDismissKeyboard()
        
        let backButton = UIBarButtonItem(image: R.image.backButton(),
                                         style: .plain,
                                         target: self,
                                         action: #selector(BudtenderApplicationFormViewController.safePop))
        navigationItem.leftBarButtonItem = backButton
        
        viewModel.backTrigger.asDriver()
            .notNil()
            .drive(onNext: { [weak self]  (_) in
                let _ = self?.navigationController?.popViewController(animated: true)
            })
            .addDisposableTo(rx_disposeBag)
    }
    
    @IBAction func applyAction(_ sender: Any) {
        viewModel.apply(phone: phoneNumberTextField.text ?? "",
                        reason: reasonTextField.text ?? "")
    }
    
    func safePop() {
        presentConfirmQuestion(question: DisplayMessage(title: "Warning",
                                                        description: "All unsaved data will be lost. Proceed?"))
            .filter { $0 }
            .subscribe(onNext: { [weak n = navigationController] (_) in
                let _ = n?.popViewController(animated: true)
            })
            .addDisposableTo(rx_disposeBag)
    }
    
    
}

extension BudtenderApplicationFormViewController : UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    
}
