//
//  DespensariesProfileViewController.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 15.11.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa

protocol DirectoryItemViewModelProtocol : ViewModel {
 
    var isLikedDriver: Driver<Bool> { get }
    var likeCountDriver: Driver<Int> { get }
    
    var itemName: String { get }
    var itemDetails: String? { get }
    var itemPictureURL: String { get }
    
    var leftDescription: String? { get }
    var rightDescription: String? { get }
    var bottomButtonTitle: String? { get }
    
    func bottomActionController() -> UIViewController?
    
    ///things I report
    func configureTableView(tableView: UITableView,
                            cellProvider: @escaping (TraitCellViewModel) -> UITableViewCell)
    func switchLikeStatus()
    func traitSelected(at: IndexPath)
    
}

class DirectoryItemViewController : UIViewController {

    @IBOutlet weak var leftDetailLabel: UILabel!
    @IBOutlet weak var rightDetailsLabel: UILabel!
    
    @IBOutlet weak var bottomButton: UIButton!
    
    
    @IBOutlet weak var logoImageView: UIImageView!
    @IBOutlet weak var scheduleLabel: UITextField!
    @IBOutlet weak var titleLabel: UITextField!
    @IBOutlet weak var tableView: UITableView!
    lazy var likeBarView: RateBarView = {
        
        let v = R.nib.rateBarView.firstView(owner: nil)!
        v.rateButton
            .addTarget(self,
                       action: #selector(DirectoryItemViewController.didTapOnRightButton),
                       for: .touchUpInside)
        
        return v
    }()
    
    
    var viewModel: DirectoryItemViewModelProtocol!
    
    override func loadView() {
        super.loadView()
        tableView.register(R.nib.traitCell)
        tableView.delegate = self
     
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        guard viewModel != nil else {
            fatalError("viewModel must be instantiated before use of viewController")
        }
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: likeBarView)
        
        viewModel.likeCountDriver
            .map { "\($0)" }
            .drive(likeBarView.ratingLabel.rx.text)
            .addDisposableTo(rx_disposeBag)

        viewModel.isLikedDriver
            .map { $0 ? R.image.hearted()! : R.image.likeButton()! }
            .drive(onNext: { [unowned self] (image) in
                self.likeBarView.rateButton.setImage(image, for: .normal)
            })
            .addDisposableTo(rx_disposeBag)
        
        ImageRetreiver.imageForURLWithoutProgress(url: viewModel.itemPictureURL)
            .map { $0 ?? R.image.noimageIc() }
            .drive(logoImageView.rx.image(transitionType: kCATransitionFade))
            .addDisposableTo(rx_disposeBag)
        
        titleLabel.text = viewModel.itemName
        scheduleLabel.text = viewModel.itemDetails
        
        viewModel.configureTableView(tableView: tableView) { [unowned self] traitViewModel in
            let cell = self.tableView.dequeueReusableCell(withIdentifier: R.nib.traitCell)!
            
            cell.setViewModel(viewModel: traitViewModel)
            
            return cell
        }
        
        leftDetailLabel.isHidden = viewModel.leftDescription == nil
        leftDetailLabel.text = viewModel.leftDescription
        
        rightDetailsLabel.isHidden = viewModel.rightDescription == nil
        rightDetailsLabel.text = viewModel.rightDescription
        
        bottomButton.isHidden = viewModel.bottomButtonTitle == nil
        bottomButton.setTitle(viewModel.bottomButtonTitle, for: .normal)
        
        tableView.backgroundColor = UIColor.clear
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        logoImageView.layer.cornerRadius = logoImageView.frame.size.width / 2
    }
}

extension DirectoryItemViewController : UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        viewModel.traitSelected(at: indexPath)
    }
    
    
    func didTapOnRightButton () {
        viewModel.switchLikeStatus()
    }
    
    @IBAction func contactBudtender(_ sender: UIButton) {
        
        guard let controller = viewModel.bottomActionController() else {
            presentMessage(message: DisplayMessage(title: "Oops",
                                                   description: "Action is not implemented yet"))
            return
        }
        
        navigationController?.pushViewController(controller,
                                                 animated: true)
    }
    
}
