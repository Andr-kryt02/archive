//
//  LegalViewController.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/3/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

class LegalIssuesViewController: UIViewController {
    
    @IBOutlet weak var webView: UIWebView!
    
    var isLegal: Bool = true
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        var request: URLRequest!
        
        if isLegal {
            request = URLRequest(url: URL(string: "http://ru.lipsum.com/feed/html")!)
        }
        else {
            request = URLRequest(url: URL(string: "http://ru.lipsum.com/feed/html")!)
        }
        
        self.webView.loadRequest(request)
    }
    
}

class LegalViewController: LegalIssuesViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        isLegal = true
    }
    
}

class PrivacyViewController: LegalIssuesViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        isLegal = false
    }
    
}
