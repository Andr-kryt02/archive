//
//  MMJViewController.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 12.12.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift
import RxDataSources

class MMJViewController : UIViewController, ViewController {
    
    @IBOutlet weak var tableView: UITableView!
    let dataSource: RxTableViewSectionedAnimatedDataSource<AnimatableSectionModel<String, MMJ>> = RxTableViewSectionedAnimatedDataSource()
        
    lazy var viewModel: MMJsViewModel! = MMJsViewModel(handler : self)
    
    override func loadView() {
        super.loadView()
    
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        tableView.delegate = nil
        tableView.dataSource = nil
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 150
        
        self.title = viewModel.title
        
        viewModel.providerViewModel.pageTrigger.value =
            tableView!.rxex_simpleBottomShownTrigger()
    
        dataSource.configureCell = { (dataSource, tableView, indexPath, item: MMJ) in
            
            let cell = tableView.dequeueReusableCell(withIdentifier: R.reuseIdentifier.mmjCell,
                                                     for: indexPath)!
            cell.configureVithMMJ(item:item)
            return cell
        }
        
        viewModel.displayData
            .drive(tableView.rx.items(dataSource: dataSource))
            .addDisposableTo(rx_disposeBag)
        
        tableView.rx.modelSelected(MMJ.self)
            .asDriver()
            .drive(onNext: { [unowned self] (selectedMMJ: MMJ) in
                self.viewModel.openWebSite(item : selectedMMJ);
            })
            .addDisposableTo(rx_disposeBag)
    }
    
}
