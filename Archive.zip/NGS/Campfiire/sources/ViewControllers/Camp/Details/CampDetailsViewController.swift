//
//  CampDetailsViewController.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/16/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

class CampDetailsViewController: UIViewController, ViewController {
    
    var viewModel: CampDetailsViewModel!
    
    @IBOutlet var editItem: UIBarButtonItem!
    @IBOutlet var reportItem: UIBarButtonItem!
    
    @IBOutlet weak var followButton: UIButton!
    
    @IBOutlet weak var initialCommentView: UIView!
    let initialCommentCell = R.nib.commentCell().instantiate(withOwner: nil, options: nil).first! as! CommentCell 
    
    @IBOutlet weak var carousel: iCarousel! {
        didSet {
            
            carousel.bounces = true
            carousel.bounceDistance = 0.2
            
            carousel.type = .coverFlow
            carousel.clipsToBounds = true
            carousel.decelerationRate = 0.2
            carousel.centerItemWhenSelected = true
            
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initialCommentCell.commentDelegate = self
        
        ///title
        viewModel.campDriver
            .map { $0.title }
            .distinctUntilChanged()
            .drive(rx.title)
            .addDisposableTo(rx_disposeBag)
        
        ////right buttons
        viewModel.rightButtons.asObservable()
            .subscribe(onNext: { [unowned self] (buttons) in
                
                var barButtonItems: [UIBarButtonItem] = []
                
                if buttons.contains(.report) { barButtonItems.append(self.reportItem) }
                if buttons.contains(.edit) { barButtonItems.append(self.editItem) }
                
                self.navigationItem.setRightBarButtonItems(barButtonItems, animated: true)
                
            })
            .addDisposableTo(rx_disposeBag)
        
        ////follow button
        viewModel.followHidden
            .drive(followButton.rx.isHidden)
            .addDisposableTo(rx_disposeBag)
        
        viewModel.followButtonImage
            .drive( onNext: { [unowned self] image in
                self.followButton.setImage(image, for: .normal)
            })
            .addDisposableTo(rx_disposeBag)

        ///initial comment embeding
        
        viewModel.campDriver
            .map { $0.topic }
            .notNil()
            .distinctUntilChanged()
            .map {  CommentViewModel (topBarColor: UIColor.campCommentTopBar,
                                      headerTextColor: UIColor.white,
                                      comment: $0)  }
            .drive(onNext: { [unowned self] (vm) in
                self.initialCommentCell.viewModel = vm
                self.viewModel.comment =  self.initialCommentCell.viewModel?.comment
                ////we need to resize carousel items here
                ///unfortunatelly that's the only way to do it
                self.carousel.reloadData()
                
            })
            .addDisposableTo(rx_disposeBag)
        
        let contentView = initialCommentCell.contentView
        initialCommentView.addSubview(contentView)
        
        contentView.snp.makeConstraints { (make) in
            make.edges.equalTo(initialCommentView)
        }
        
        ///carousel reloading
        viewModel.campDriver
            .map { $0.totalComments }
            .distinctUntilChanged()
            .drive(onNext: { [unowned self] (_) in
                self.carousel.reloadData()
            })
            .addDisposableTo(rx_disposeBag)
        
        viewModel.reloadPageDriver
            .notNil()
            .drive(onNext: { [unowned self] (pageNumber) in
                self.carousel.scrollToItem(at: pageNumber, animated: false)
                self.carousel.reloadItem(at: pageNumber, animated: false)
            })
            .addDisposableTo(rx_disposeBag)
        
        ///user presenting
        
        viewModel.nextUserTrigger.asDriver()
            .notNil()
            .drive(onNext: { [weak n = navigationController] (user) in
                
                let controller = R.storyboard.user.userProfileViewController()!
                
                controller.viewModel = UserProfileViewModel(handler: controller,
                                                            user: user)
                
                let _ = n?.pushViewController(controller, animated: true)
            })
            .addDisposableTo(rx_disposeBag)
        
        
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        ///because cell is not in the hierarchy but might contain layout rules for it's content view
        initialCommentCell.layoutSubviews()

    }
    
}

extension CampDetailsViewController: CampPageTableDelegate, CommentCellDelegate {
    
    @IBAction func reportCampTapped(_ sender: Any) {
        viewModel.reportCampTapped()
    }
    
    @IBAction func followTapped(_ sender: Any) {
        viewModel.switchFollowState()
    }
    
    ////page buttons actions
    
    func toNextPageTriggered() {
        carousel.scroll(byNumberOfItems: 1, duration: 0.3)
    }
    
    func toPreviousPageTriggered() {
        carousel.scroll(byNumberOfItems: -1, duration: 0.3)
    }
    
    ////topic comments actions
    
    func reportCommentTapped(comment: Comment) {
        viewModel.reportComment(comment : comment)
    }
    
    func userAvatarTapped(user: User) {
        viewModel.presentUser(user: user)
    }
    
    ////initial comment action
    
    func commentCellDidReport(cell: CommentCell) {
        viewModel.reportInitialComment(comment : cell.viewModel?.comment)
    }
    
    func commentCellDidTapAvatar(cell: CommentCell) {
        viewModel.presentTopicStarter()
    }
    
    ////edit 
    
    @IBAction func editAction(_ sender: Any) {
        let controller = R.storyboard.camps.upsertCampViewController()!
        
        controller.viewModel = UpsertCampViewModel(handler: controller,
                                                   initialCamp: viewModel.campVariable.value,
                                                   reloadable: viewModel.parentViewModel)
        
        navigationController?.pushViewController(controller, animated: true)
    }
    
    ///post
    
    func userTappedPost() {
        
        let controller = R.storyboard.camps.createCampPostViewController()!
        
        controller.viewModel = CreateCampPostViewModel(handler: controller,
                                                       camp: viewModel.campVariable.value,
                                                       parentViewModel: viewModel)
        
        navigationController?.pushViewController(controller, animated: true)
        
    }
    
}

extension CampDetailsViewController : iCarouselDataSource, iCarouselDelegate {
    
    func numberOfItems(in carousel: iCarousel) -> Int {
        return viewModel.totalCampPages
    }
    
    func carousel(_ carousel: iCarousel,
                  viewForItemAt index: Int,
                  reusing view: UIView?) -> UIView {
        
        var pageView: CampPageTableView! = view as? CampPageTableView
        if pageView == nil {
            pageView = CampPageTableView.pageTableView()
            pageView.campDelegate = self
            
            self.rx.sentMessage(#selector(iCarouselDelegate.carouselDidEndScrollingAnimation(_:)))
                .subscribe(onNext: { [weak c = carousel, weak p = pageView] (_) in
                    
                    guard let p = p else { return }
                    
                    ////everyone but selected item
                    if let currentView = c?.currentItemView,
                        p !== currentView {
                    
                        ///scrolling to top
                        p.setContentOffset(CGPoint.zero, animated: false)
                    }
                    else {
                        ///selected item should have animation enabled
                        p.isUserInteractionEnabled = true
                    }
                    
                    
                })
                .addDisposableTo(rx_disposeBag)
            
            self.rx.sentMessage(#selector(iCarouselDelegate.carouselWillBeginScrollingAnimation(_:)))
                .subscribe(onNext: { [weak p = pageView] (_) in
                    if let p = p { p.isUserInteractionEnabled = false }
                })
                .addDisposableTo(rx_disposeBag)
        }
        pageView.frame = carousel.bounds
        
        let pageViewModel = viewModel.pageViewModel(at: index,
                                                    handler: pageView)
        pageView.viewModel = pageViewModel
        
        return pageView
    }
    
    ////trigger for rx
    func carouselDidEndScrollingAnimation(_ carousel: iCarousel) { }
    func carouselWillBeginScrollingAnimation(_ carousel: iCarousel) {}
    
    
}


