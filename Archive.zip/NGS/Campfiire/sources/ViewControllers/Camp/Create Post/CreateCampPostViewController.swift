//
//  CreateCampPostViewController.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/29/16.
//  Copyright © 2016 campfiire. All rights reserved.
//


class CreateCampPostViewController: UIViewController, ViewController {
    
    var viewModel: CreateCampPostViewModel!

    @IBOutlet weak var scrollContainer: UIScrollView!
    
    @IBOutlet weak var avatarImageView: UIImageView!
    @IBOutlet weak var authorNameLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    
    @IBOutlet weak var postTextView: MPTextView! {
        didSet {
            postTextView.text = ""
            postTextView.placeholderText = "Put your thoughts here..."
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = viewModel.title
        authorNameLabel.text = viewModel.authorName
        dateLabel.text = viewModel.dateString
        
        ImageRetreiver.imageForURLWithoutProgress(url: viewModel.authorPictureURL)
            .drive(avatarImageView.rx.image())
            .addDisposableTo(rx_disposeBag)
        
        self.scrollContainer.keyboardAvoiding()
        
    }
 
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
//        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { [weak tv = self.postTextView] in
//            //tv?.becomeFirstResponder()
//        }
    }
    
}

extension CreateCampPostViewController : UITextViewDelegate {
    
    @IBAction func deleteComment(_ sender: Any) {
        presentConfirmQuestion(question: DisplayMessage(title: "Warning",
                                                        description: "All unsaved data will be lost. Proceed?"))
            .filter { $0 }
            .subscribe(onNext: { [weak n = navigationController] (_) in
                let _ = n?.popViewController(animated: true)
            })
            .addDisposableTo(rx_disposeBag)
    }
    
    @IBAction func uploadButton(_ sender: Any) {
        viewModel.uploadPostTapped()
    }
    
    @IBAction func selectedImageTapped(_ sender: Any) {
        viewModel.pickPhotoTapped()
    }
    
    func textViewDidChange(_ textView: UITextView) {
        viewModel.textChanged(text: textView.text)
    }
    
}
