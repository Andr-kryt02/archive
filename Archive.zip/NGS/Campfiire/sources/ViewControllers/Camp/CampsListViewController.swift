//
//  CampsListViewController.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/16/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import RxSwift
import RxCocoa
import RxDataSources

class CampsListViewController: UIViewController, ViewController {
    
    lazy var viewModel: CampsListViewModel! = CampsListViewModel(handler: self)
    
    @IBOutlet weak var headerView: UIImageView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var allButton: UIButton!
    @IBOutlet weak var followedButton: UIButton!
    @IBOutlet weak var searchTextField: CampfiireTextField! {
        didSet {
            searchTextField.underlineColor = UIColor.clear
            searchTextField.placeholderColor = UIColor.white
        }
    }
    
    @IBOutlet weak var underline: UIView!
    fileprivate var percent: CGFloat = 0 {
        didSet {
            if percent < 0 { percent = 0; return }
            if percent > 1 { percent = 1; return }
            
            let left: UIButton = allButton
            let right: UIButton = followedButton
            
            let frame = CGRect(x: transformer( left.frame.origin.x - 10, right.frame.origin.x - 10 ),
                               y: transformer( left.frame.origin.y, right.frame.origin.y ) + 30,
                               width: transformer( left.frame.size.width + 20, right.frame.size.width + 20 ),
                               height: 1)
            
            UIView.animate(withDuration: 0.3) {
                self.underline.frame = frame
            }
            
        }
    }
    lazy var transformer: (CGFloat, CGFloat) -> CGFloat =
        { [unowned self] (x: CGFloat, y: CGFloat) -> CGFloat in
            
            return (1 - self.percent) * x + self.percent * y
            
    }
    
    let dataSource: RxTableViewSectionedAnimatedDataSource<AnimatableSectionModel<String, Camp>> = RxTableViewSectionedAnimatedDataSource()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewModel.followedOnlySelected
            .map { (followedOnly:Bool) -> CGFloat in
                return followedOnly ? 1 : 0
            }
            .drive(onNext: { [unowned self] (percent) in
                self.percent = percent
            })
            .addDisposableTo(rx_disposeBag)
        
        tableView.delegate = nil
        tableView.dataSource = nil
        
        viewModel.providerViewModel.pageTrigger.value =
            tableView!.rxex_simpleBottomShownTrigger()
        
        dataSource.configureCell = { (dataSource, tableView, indexPath, item: Camp) in
            
            let cell = tableView.dequeueReusableCell(withIdentifier: R.reuseIdentifier.campTableCell,
                                                     for: indexPath)!
            
            cell.set(camp: item)
            
            return cell
        }
        
        tableView.rx.modelSelected(Camp.self)
            .asDriver()
            .drive(onNext: { [weak n = navigationController, weak self] (selectedCamp: Camp) in
                
                let controller = R.storyboard.camps.campDetailsViewController()!
                
                let viewModel = CampDetailsViewModel(handler: controller,
                                                     camp: selectedCamp,
                                                     parentViewModel: self?.viewModel)
                controller.viewModel = viewModel
                n?.pushViewController(controller, animated: true)
                
            })
            .addDisposableTo(rx_disposeBag)
        
        viewModel.displayData
            .drive(tableView.rx.items(dataSource: dataSource))
            .addDisposableTo(rx_disposeBag)
     
        ////empty data
        tableView.bindEmptyStateTo = viewModel.showsEmptyState
        
//        view.tapToDismissKeyboard()
        tableView.keyboardAvoiding(includeTapToDismiss: false)
    }
    
}

extension CampsListViewController {
    
    @IBAction func allCampsAction(_ sender: Any) {
        percent = 0
        viewModel.followOnlyStatusChanged(to: false)
    }
    
    @IBAction func followedCampsAction(_ sender: Any) {
        percent = 1
        viewModel.followOnlyStatusChanged(to: true)
    }
    
    @IBAction func searchQueryChanged(_ sender: Any) {
        viewModel.queryChanged(query: searchTextField.text)
    }
    
    @IBAction func addCamp(_ sender: Any) {
        let controller = R.storyboard.camps.upsertCampViewController()!
        
        controller.viewModel = UpsertCampViewModel(handler: controller,
                                                   initialCamp: nil,
                                                   reloadable: viewModel)
        
        navigationController?.pushViewController(controller, animated: true)
        
    }
    
}
