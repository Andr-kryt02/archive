//
//  UpsertCampViewController.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/3/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

class UpsertCampViewController : UIViewController, ViewController {
    
    var viewModel: UpsertCampViewModel!
    
    @IBOutlet var upsertView: UpsertCampView!
    @IBOutlet var saveItem: UIBarButtonItem! {
        didSet {
            saveItem.target = self
            saveItem.action = #selector(UpsertCampViewController.didTapSave)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        upsertView.viewModel = viewModel
        upsertView.keyboardAvoidingUIView(includeTapToDismiss: true)
        if !viewModel.applyButtonHidden {
            navigationItem.rightBarButtonItem = saveItem
        }
        
        viewModel.navigationTitleString
            .bindTo(self.rx.title)
            .addDisposableTo(rx_disposeBag)
     
        let backButton = UIBarButtonItem(image: R.image.backButton(),
                                         style: .plain,
                                         target: self,
                                         action: #selector(UpsertCampViewController.safePop))
        navigationItem.leftBarButtonItem = backButton
        
        view.tapToDismissKeyboard()
    }
 
    func safePop() {
        presentConfirmQuestion(question: DisplayMessage(title: "Warning",
                                                        description: "All unsaved data will be lost. Proceed?"))
            .filter { $0 }
            .subscribe(onNext: { [weak n = navigationController] (_) in
                let _ = n?.popViewController(animated: true)
            })
            .addDisposableTo(rx_disposeBag)
    }
    
}

extension UpsertCampViewController: UITextFieldDelegate {
    
    func didTapSave() {
        viewModel.approveClicked()
    }
 
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    
}
