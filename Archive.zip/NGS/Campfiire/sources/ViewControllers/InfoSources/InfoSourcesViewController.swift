//
//  InfoSourcesViewController.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 2016-12-20.
//  Copyright © 2016 campfiire. All rights reserved.
//


import Foundation
import RxCocoa
import RxSwift
import RxDataSources

class InfoSourcesViewController : UIViewController, ViewController, UITableViewDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    let dataSource: RxTableViewSectionedAnimatedDataSource<AnimatableSectionModel<String, InfoSource>> = RxTableViewSectionedAnimatedDataSource()
    
    lazy var viewModel: InfoSourcesViewModel! = InfoSourcesViewModel(handler : self)
    
    override func loadView() {
        super.loadView()
        
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = nil
        
        self.title = viewModel.title
        
        viewModel.providerViewModel.pageTrigger.value =
            tableView!.rxex_simpleBottomShownTrigger()
        
        dataSource.configureCell = { (dataSource, tableView, indexPath, item: InfoSource) in
            
            let cell = tableView.dequeueReusableCell(withIdentifier: R.reuseIdentifier.sourceCell,
                                                     for: indexPath)!
            cell.configureVithMMJ(item:item)
            return cell
        }
        
        viewModel.displayData
            .drive(tableView.rx.items(dataSource: dataSource))
            .addDisposableTo(rx_disposeBag)
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        self.viewModel.openWebSite(at : indexPath)
    }
}
