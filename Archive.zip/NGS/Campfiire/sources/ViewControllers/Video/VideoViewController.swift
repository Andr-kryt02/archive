//
//  VideoViewController.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 2016-12-19.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift
import RxDataSources

class VideoViewController : UIViewController, ViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    let dataSource: RxTableViewSectionedAnimatedDataSource<AnimatableSectionModel<String, Video>> = RxTableViewSectionedAnimatedDataSource()
    
    lazy var viewModel: VideosViewModel! = VideosViewModel(handler : self)
    
    override func loadView() {
        super.loadView()
        
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        tableView.delegate = nil
        tableView.dataSource = nil
        
        self.title = viewModel.title
        
        viewModel.providerViewModel.pageTrigger.value =
            tableView!.rxex_simpleBottomShownTrigger()
        
        dataSource.configureCell = { (dataSource, tableView, indexPath, item: Video) in
            
            let cell = tableView.dequeueReusableCell(withIdentifier: R.reuseIdentifier.videoCell,
                                                     for: indexPath)!
            cell.configureVithVideo(item: item)
            return cell
        }
        
        viewModel.displayData
            .drive(tableView.rx.items(dataSource: dataSource))
            .addDisposableTo(rx_disposeBag)
        
        tableView.rx.modelSelected(Video.self)
            .asDriver()
            .drive(onNext: { [unowned self] (selectedVideo: Video) in
                self.viewModel.openVideoPlayer(video : selectedVideo);
            })
            .addDisposableTo(rx_disposeBag)
    }
    
}
