//
//  NewsFeedTableViewController.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/29/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

import RxDataSources
import RxSwift
import RxCocoa

protocol NewsFeedTableViewModelProtocol {
    
    var displayData: Driver<[AnimatableSectionModel<String, NewsFeedTypes>]> { get }
    var showsEmptyData: Driver<Bool> { get }
    var nextUserDriver: Driver<User> { get }
    
    func setPageTrigger(trigger: Observable<Void>)
    func cellViewModel(for item: NewsFeedTypes) -> NewsFeedCellViewModelProtocol
    
}

class NewsFeedTableViewController : UIViewController {
    
    var viewModel: NewsFeedTableViewModelProtocol!
    
    let dataSource: RxTableViewSectionedAnimatedDataSource<AnimatableSectionModel<String, NewsFeedTypes>> = RxTableViewSectionedAnimatedDataSource()
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = nil
        tableView.dataSource = nil
        
        tableView.register(R.nib.newsFeedCell)
        
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 150
        
        viewModel.setPageTrigger(trigger: tableView!.rxex_simpleBottomShownTrigger())
        
        dataSource.configureCell = { [unowned self] (dataSource, tableView, indexPath, item) in
            
            let cell = tableView.dequeueReusableCell(withIdentifier: R.reuseIdentifier.newsFeedCell,
                                                     for: indexPath)!
            
            cell.viewModel = self.viewModel.cellViewModel(for: item)
            
            return cell
        }
        
        viewModel.displayData
            .drive(tableView.rx.items(dataSource: dataSource))
            .addDisposableTo(rx_disposeBag)
        
        tableView.rx.modelSelected(NewsFeedTypes.self)
            .asDriver()
            .drive(onNext: { [unowned self] (selectedEntity: NewsFeedTypes) in
                
                var controller: UIViewController!
                
                switch selectedEntity {
                    
                case .event(let event):
                    let c = R.storyboard.events.eventDetailsController()!
                    c.viewModel = EventDetailsViewModel(handler: c, event: event)
                    
                    controller = c
                    
                case .hotSpotPhoto(let hotspotPhoto):
                    
                    guard let hs = hotspotPhoto.hotspot else {
                        fatalError("Can not present details of HotspotPhoto with missing hotspot value")
                    }
                    
                    let c = R.storyboard.hotSpots.hotspotDetailViewController()!
                    
                    let viewModel = HotspotDetailsViewModel(handler: c,
                                                            hotSpot: hs,
                                                            startWith: hotspotPhoto.photo)
                    c.viewModel = viewModel
                    
                    controller = c
                    
                default: return;
                }
                
                self.navigationController?.pushViewController(controller,
                                                              animated: true)
            })
            .addDisposableTo(rx_disposeBag)
        
        ///user showing
        viewModel.nextUserDriver
            .drive(onNext: { [unowned self] (u) in
                
                let c = R.storyboard.user.userProfileViewController()!
                let vm = UserProfileViewModel(handler: c, user: u)
                c.viewModel = vm
                
                self.navigationController?.pushViewController(c,
                                                              animated: true)
            })
            .addDisposableTo(rx_disposeBag)
        
        ///empty state
        tableView.bindEmptyStateTo = viewModel.showsEmptyData
        
    }
    
    
}
