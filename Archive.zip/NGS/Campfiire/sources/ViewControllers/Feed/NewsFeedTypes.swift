//
//  NewsFeedTypes.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/29/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxDataSources
import ObjectMapper

enum NewsFeedTypes : Equatable {
    
    case event(event: Event)
    case userPhoto(userPhoto: UserPhoto)
    case hotSpotPhoto(hotspotPhoto: HotspotPhoto)
    
    func toNewsFeedItem() -> NewsItemViewModelProtocol {
        switch self {
        case .event(let event):
            return event
            
        case .hotSpotPhoto(let photo):
            return photo
            
        case .userPhoto(let photo):
            return photo
        }
    }
    
}

func ==(l: NewsFeedTypes, r:NewsFeedTypes) -> Bool {
    switch (l , r) {
        
    case (.event(let lhs) , .event(let rhs)):
        return lhs == rhs
        
    case (.userPhoto(let lhs) , .userPhoto(let rhs)):
        return lhs.photo == rhs.photo
        
    case (.hotSpotPhoto(let lhs), .hotSpotPhoto(let rhs)):
        return lhs.photo == rhs.photo
        
    default:
        return false
    }
}

extension NewsFeedTypes : IdentifiableType {
    
    var identity : Int {
        switch self {
        case .event(let event):
            return event.id
        case .hotSpotPhoto(let hotspot):
            return hotspot.photo.id
            
        case .userPhoto(let userPhoto):
            return userPhoto.photo.id
        }
    }
}

extension NewsFeedTypes : Fakeble {
    
    static func fakeEntity() -> NewsFeedTypes {
        
        let type = fakeNumber(bound: 3) + 1
        
        if type == 1 {
            return .event(event: Event.fakeEntity() )
        }
        else if type == 2 {
            
            return .hotSpotPhoto(hotspotPhoto: HotspotPhoto( photo: Photo.fakeEntity(),
                                                        hotspot: HotSpot.fakeEntity() ))
        }
        else {
            
            var p = Photo.fakeEntity()
            p.author = User.currentUser()!
            
            return .userPhoto(userPhoto: UserPhoto(photo: p ) )
        }
        
    }
    
}
