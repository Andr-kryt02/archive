//
//  NewsFeedViewController.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/14/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import UIKit

class NewsFeedViewController : UIViewController, ViewController {
    
    lazy var viewModel: NewsFeedViewModel! = NewsFeedViewModel(handler: self)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == R.segue.newsFeedViewController.newsFeedEmbeded.identifier {
            
            let controller = segue.destination as! NewsFeedTableViewController
            
            controller.viewModel = viewModel.feedViewModel
            
        }
    }
    
    @IBAction func addPhotoTapped(_ sender: Any) {
        
        viewModel.addPhotoTapped()
        
    }
    
    
}
