 //
//  HotspotViewController.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/1/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

class HotspotDetailViewController: UIViewController, ViewController {
    
    var viewModel: HotspotDetailsViewModel!
    
    @IBOutlet var detailsView: HotspotDetailsView!
    
    @IBOutlet var editItem: UIBarButtonItem! {
        didSet {
            editItem.target = self
            editItem.action = #selector(HotspotDetailViewController.editAction(_:))
        }
    }
    var starItem: UIBarButtonItem! {
        
        let item = UIBarButtonItem(image: viewModel.starIconImage,
                                        style: .plain,
                                        target: self,
                                        action: #selector(HotspotDetailViewController.starAction(_:)))
        item.tintColor = UIColor.starIconOrangeTint
        
        return item
        
    }
    
    override func loadView() {
        super.loadView()
        
        navigationItem.backBarButtonItem = UIBarButtonItem(title:" ",
                                                           style:.plain,
                                                           target:nil,
                                                           action:nil)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        detailsView.viewModel = viewModel
        
        viewModel.hotSpotDriver
            .map { $0.name }
            .drive( self.rx.title )
            .addDisposableTo(rx_disposeBag)
        
        viewModel.nextUserTrigger.asDriver()
            .notNil()
            .drive(onNext: { [weak n = navigationController] (user) in
                
                let controller = R.storyboard.user.userProfileViewController()!
                
                controller.viewModel = UserProfileViewModel(handler: controller,
                                                            user: user)
                
                let _ = n?.pushViewController(controller, animated: true)
            })
            .addDisposableTo(rx_disposeBag)
        
        viewModel.rightButtons.asObservable()
            .subscribe(onNext: { [unowned self] (buttons) in
                
                var barButtonItems: [UIBarButtonItem] = []
                
                if buttons.contains(.star) { barButtonItems.append(self.starItem) }
                if buttons.contains(.edit) { barButtonItems.append(self.editItem) }
                
                self.navigationItem.setRightBarButtonItems(barButtonItems, animated: false)
                
            })
            .addDisposableTo(rx_disposeBag)
        
    }
    
    @IBAction func postPhoto(_ sender: Any) {
        viewModel.postPhotoTapped()
    }
    
    @IBAction func postComment(_ sender: Any) {
        viewModel.newCommentTapped()
    }
    
    func editAction(_ sender: Any) {
        
        let controller = R.storyboard.hotSpots.upsertHotspotViewController()!
        
        controller.viewModel = UpsertHotspotViewModel(handler: controller,
                                                      initialHotspot: viewModel.hotSpotVariable.value)
        
        navigationController?.pushViewController(controller, animated: true)
        
    }
    
    func starAction(_ sender: Any) {
        
        viewModel.switchFollowStatus()
        
    }
    
}
