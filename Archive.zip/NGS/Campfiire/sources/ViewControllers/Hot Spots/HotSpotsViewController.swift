//
//  HotSpotsViewController.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/25/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import MapKit
import RxCocoa

class HotSpotsViewController : UIViewController, ViewController {
    
    lazy var viewModel: HotSpotsViewModel! = {
        
        var initialRegion = self.mapView.region

        if let l = LocationManager.instance.lastRecordedLocation {
            initialRegion = MKCoordinateRegionMakeWithDistance(l.coordinate, 5000, 5000)
        }

        return HotSpotsViewModel(handler: self,
                                initialRegion: initialRegion)
    }()
    

    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var topSearchBarConstraint: NSLayoutConstraint!
    @IBOutlet weak var followedOnlyButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewModel.visibleRegion.asDriver()
            .distinctUntilChanged()
            .drive(onNext: { [unowned self] region in
                
                self.mapView.setRegion(region, animated: true)
                
            })
            .addDisposableTo(rx_disposeBag)
        
        viewModel.annotations.asDriver()
            .drive(onNext: { [unowned self] (annotations) in
                
                ///TODO: not remove annotattions that are the same.
                ///Do sets intersection and remove only extra annotations
                
                self.mapView.removeAnnotations(self.mapView.annotations)
                
                self.mapView.addAnnotations(annotations)
                
            })
            .addDisposableTo(rx_disposeBag)
    
        viewModel.presentHotspotTrigger.asDriver()
            .notNil()
            .drive(onNext: { [unowned self] (hp) in
                
                let controller = R.storyboard.hotSpots.hotspotDetailViewController()!
                
                controller.viewModel = HotspotDetailsViewModel(handler: controller, hotSpot: hp)
                
                self.navigationController?.pushViewController(controller,
                                                              animated: true)
                
            })
            .addDisposableTo(rx_disposeBag)
        
        ////search bar
        viewModel.searchBarHidden.asObservable()
            .do(onNext: { [unowned self] (hidden) in
                let _ = hidden ?
                    self.searchBar.resignFirstResponder() :
                    self.searchBar.becomeFirstResponder()
            })
            .map { $0 ? -44 : 0 }
            .skip(1)
            .subscribe(onNext: { [unowned self] (value) in
                self.topSearchBarConstraint.constant = CGFloat(value)
                UIView.animate(withDuration: 0.3) {
                    self.view.layoutIfNeeded()
                }
            })
            .addDisposableTo(rx_disposeBag)
        
        ///
        viewModel.followedOnlyHotspots.asObservable()
            .map { $0 ? "Followed Only Hot Spots" : "All Hot Spots" }
            .bindTo(followedOnlyButton.rx.title(for: .normal))
            .addDisposableTo(rx_disposeBag)
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
//        let s = HotSpot.fakeEntity()
//        s.saveEntity()
//        
//        viewModel.annotationClicked(annotation: HotspotAnnotationWrapper(type: .hotspot(hotspot: s)))
        
        //// TODO: |Any| move to Reloadable protocol and reload map only on demand 
        viewModel.refreshMap()
        
    }
    
    @IBAction func addHotspot(_ sender: Any) {
        
        let controller = R.storyboard.hotSpots.upsertHotspotViewController()!
        
        controller.viewModel = UpsertHotspotViewModel(handler: controller,
                                                      initialHotspot: nil)
        
        navigationController?.pushViewController(controller, animated: true)
        
    }
    
}

extension HotSpotsViewController : MKMapViewDelegate, UISearchBarDelegate {
    
    func mapView(_ mapView: MKMapView,
                 regionDidChangeAnimated animated: Bool) {
        
        viewModel.reportRegionChange(region: mapView.region)
    }
    
    
    func mapView(_ mapView: MKMapView,
                 viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        if annotation is MKUserLocation { return nil }
        
        let pinId = "com.campfiire.pin"
        
        var view: AnnotationView! = mapView.dequeueReusableAnnotationView(withIdentifier: pinId) as? AnnotationView
        if view == nil {
            
            let v = AnnotationView(annotation: annotation,
                                   reuseIdentifier: pinId)
            
            v.delegate = self
            v.centerOffset = CGPoint(x: 0, y: -v.frame.size.height / 2)
            
            view = v
        }
        view.viewModel = viewModel.annotationViewModel(for: annotation as! AnnotationWrapper)
        
        return view
        
    }
    
}

extension HotSpotsViewController : AnnotationCalloutDelegate {
    
    func calloutViewTapped(for annotation: AnnotationWrapper) {
        viewModel.annotationClicked(annotation: annotation)
    }
    
    func calloutReportTapped(for annotation: AnnotationWrapper) {
        viewModel.reportHotspotClicked(wrapper: annotation)
    }
 
    @IBAction func searchClickAction(_ sender: Any) {
        viewModel.switchSearchBarStatus()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        viewModel.searchQueryChanged(query: searchText)
    }
    
    @IBAction func followedOnlyTapped(_ sender: Any) {
        viewModel.switchFollowedOnlyStatus()
    }
    
}
