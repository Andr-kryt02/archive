//
//  UpsertHotspotViewController.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/3/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import TOCropViewController

class UpsertHotspotViewController : UIViewController, ViewController {
    
    var viewModel: UpsertHotspotViewModel!
    
    @IBOutlet var upsertView: UpsertHotspotView!
    @IBOutlet var saveItem: UIBarButtonItem! {
        didSet {
            saveItem.target = self
            saveItem.action = #selector(UpsertHotspotViewController.didTapSave)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        upsertView.viewModel = viewModel
        
        if !viewModel.applyButtonHidden {
            navigationItem.rightBarButtonItem = saveItem
        }
        
        viewModel.navigationTitleString
            .bindTo(self.rx.title)
            .addDisposableTo(rx_disposeBag)
     
        let backButton = UIBarButtonItem(image: R.image.backButton(),
                                         style: .plain,
                                         target: self,
                                         action: #selector(UpsertHotspotViewController.safePop))
        navigationItem.leftBarButtonItem = backButton
        
    }
 
    func safePop() {
        presentConfirmQuestion(question: DisplayMessage(title: "Warning",
                                                        description: "All unsaved data will be lost. Proceed?"))
            .filter { $0 }
            .subscribe(onNext: { [weak n = navigationController] (_) in
                let _ = n?.popViewController(animated: true)
            })
            .addDisposableTo(rx_disposeBag)
    }
    
}

extension UpsertHotspotViewController {
    
    func didTapSave() {
        viewModel.approveClicked()
    }
 
    @IBAction func changeAvatar(_ sender: Any) {
        viewModel.selectAvatarClicked(){ [unowned self] image in
            
            let cropController : TOCropViewController = TOCropViewController(croppingStyle: .circular, image: image)
            cropController.delegate = self
            
            self.navigationController?.pushViewController(cropController, animated: true)

        }
    }
    
}

extension UpsertHotspotViewController : TOCropViewControllerDelegate {
    
    func cropViewController(_ cropViewController: TOCropViewController, didCropToCircularImage image: UIImage, with cropRect: CGRect, angle: Int) {
        
        viewModel.confirmCrop(image: image)
        
        let _ = self.navigationController?.popViewController(animated: true)
        
    }
}
