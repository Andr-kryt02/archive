//
//  TopRatedCategoryList .swift
//  Campfiire
//
//  Created by Andrew Seregin on 12/9/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

protocol TopRatedListViewModelProtocol {
 
    var title: String { get }
    func configureTableView(tableView: UITableView)
    
    func detailScreen(at: IndexPath) -> UIViewController
    
}

class TopRatedListViewController : UIViewController {

    var viewModel: TopRatedListViewModelProtocol!
    
    @IBOutlet weak var tableView: UITableView! {
        didSet {
            tableView.delegate = self
            
            tableView.rowHeight = UITableViewAutomaticDimension
            tableView.estimatedRowHeight = 100
        }
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        self.title = viewModel.title
        navigationItem.backBarButtonItem = UIBarButtonItem(title: " ",
                                                           style: .plain,
                                                           target: nil,
                                                           action: nil)
        
        tableView.register(R.nib.newsFeedCell)
        
        viewModel.configureTableView(tableView: tableView)
    
    }
    
}

extension TopRatedListViewController : UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        let c = viewModel.detailScreen(at: indexPath)
        
        navigationController?.pushViewController(c, animated: true)
        
    }
    
}
