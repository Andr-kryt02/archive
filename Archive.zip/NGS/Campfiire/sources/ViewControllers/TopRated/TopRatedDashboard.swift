//
//  TableViewController.swift
//  Campfiire
//
//  Created by Andrew Seregin on 12/13/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import UIKit
import RxDataSources


class TopRatedDashboard: UITableViewController {

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let controller = segue.destination as! TopRatedListViewController
        var viewModel: TopRatedListViewModelProtocol!
        
        switch segue.identifier! {
            
        case R.segue.topRatedDashboard.doctors.identifier:
            
            viewModel = directoriesViewModel(Doctor.self,
                                             title: "Top Doctors", controller: controller)
            
        case R.segue.topRatedDashboard.painClinics.identifier:
            
            viewModel = directoriesViewModel(PainClinic.self,
                                             title: "Top Pain Clinics", controller: controller)
            
        case R.segue.topRatedDashboard.producers.identifier:
            
            viewModel = directoriesViewModel(LicensedProducer.self,
                                             title: "Top Licensed Producer", controller: controller)
            
        case R.segue.topRatedDashboard.stores.identifier:
            
            viewModel = directoriesViewModel(OnlineStore.self,
                                             title: "Top Online Stores", controller: controller)
            
        case R.segue.topRatedDashboard.dispensaries.identifier:
            
            viewModel = directoriesViewModel(Dispensary.self,
                                             title: "Top Dispensary", controller: controller)
            
        case R.segue.topRatedDashboard.budtenders.identifier:
            
            viewModel = directoriesViewModel(Budtender.self,
                                             title: "Top Budtenders", controller: controller)
            
        case R.segue.topRatedDashboard.camps.identifier:
            
            let detailProvider = { (camp: Camp) -> UIViewController in
                
                let controller = R.storyboard.camps.campDetailsViewController()!
                controller.viewModel = CampDetailsViewModel(handler: controller, camp: camp)
                return controller
                
            }
            
            let cellProvider = { (tv: UITableView, ip: IndexPath, model: Camp) -> UITableViewCell in
                let cell = tv.dequeueReusableCell(withIdentifier: R.reuseIdentifier.topCampsCell)!
                
                cell.item = model
                cell.ordinaryNumber = ip.row + 1
                
                return cell
            }
            
            viewModel = TopRatedListViewModel(handler: controller,
                                              title: "Top Camps",
                                              detailsProvider: detailProvider,
                                              cellProvider: cellProvider,
                                              listProvider: Camp.self)
            
            
        case R.segue.topRatedDashboard.hotSpots.identifier:
            
            let detailProvider = { (hotspot: HotSpot) -> UIViewController in
                
                let controller = R.storyboard.hotSpots.hotspotDetailViewController()!
                controller.viewModel = HotspotDetailsViewModel(handler: controller,
                                                               hotSpot: hotspot)
                return controller
                
            }
            
            let cellProvider = { (tv: UITableView, ip: IndexPath, model: HotSpot) -> UITableViewCell in
                let cell = tv.dequeueReusableCell(withIdentifier: R.reuseIdentifier.newsFeedCell)!
                
                cell.viewModel = NewsFeedCellViewModel(storable: model)
                
                return cell
            }
            
            viewModel = TopRatedListViewModel(handler: controller,
                                              title: "Top Hot Spots",
                                              detailsProvider: detailProvider,
                                              cellProvider: cellProvider,
                                              listProvider: HotSpot.self)
            
        default: fatalError("Unhandled segue \(segue.identifier)")
            
        }
        
        controller.viewModel = viewModel
        
    }
    
    
    
}

extension TopRatedDashboard {
    
    fileprivate func directoriesViewModel<T: DirectoryItemType & TopRatedCellDisplayable & IdentifiableType & Equatable>
        (_ t: T.Type, title: String, controller: UIViewController) -> TopRatedListViewModelProtocol {
    
        return TopRatedListViewModel(handler: controller,
                                     title: title,
                                     detailsProvider: directoryDetailsProvider(T.self),
                                     cellProvider: directoryCellProvider(T.self),
                                     listProvider: AlamofireTopRatedProvider<T>.self)
    
    }
    
    fileprivate func directoryDetailsProvider<T: DirectoryItemType>(_ t: T.Type) -> (T) -> UIViewController {
        
        return { item in
            let controller = R.storyboard.directories.directoryItemViewController()!
            controller.viewModel = DirectoryItemViewModel(handler: controller, item: item)
            
            return controller
        }
        
    }
    
    fileprivate func directoryCellProvider<T: TopRatedCellDisplayable>(_ t: T.Type) ->
        (UITableView, IndexPath, T) -> UITableViewCell {
        
        return { (tableView, indexPath, item) in
            
            let cell = tableView.dequeueReusableCell(withIdentifier: R.reuseIdentifier.topDirectoryCell)!
            
            cell.item = item
            cell.ordinaryNumber = indexPath.row + 1
            
            return cell
        }
        
    }
    
}
