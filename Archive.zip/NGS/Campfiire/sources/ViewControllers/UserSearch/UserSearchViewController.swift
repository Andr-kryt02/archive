//
//  UserSearchViewController.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/22/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

import RxSwift

class UserSearchViewController : UIViewController, ViewController {
  
    lazy var viewModel: UserSearchViewModel! = UserSearchViewModel(handler: self)
    
    @IBOutlet weak var searchBarTextField: CampfiireTextField! {
        didSet {
            searchBarTextField.underlineColor = UIColor.gray
            searchBarTextField.textColor = UIColor.black
            searchBarTextField.placeholderColor = UIColor.gray
        }
    }
       override func viewDidLoad() {
        super.viewDidLoad()
        
        view.tapToDismissKeyboard()
        
        viewModel.appliedFilter
            .asObservable().notNil()
            .subscribe(onNext: { [unowned self] (filter) in
                
                let controller = R.storyboard.search.userSearchResultController()!
                
                let viewModel = UserSearchResultsViewModel(handler: controller,
                                                           searchFilter: filter)
                
                controller.viewModel = viewModel
                
                self.navigationController?.pushViewController(controller, animated: true)
            })
            .addDisposableTo(rx_disposeBag)
        
    }
    
    @IBAction func filterButtonClicked(_ sender: AnyObject) {
        
        let controller = R.storyboard.search.filterViewController()!
        let viewModel = FilterViewModel(handler: controller)
        
        controller.viewModel = viewModel
        self.viewModel.filterViewModel = viewModel
    
       
        controller.modalPresentationStyle = .custom
        controller.transitioningDelegate = controller
        self.present(controller, animated: true, completion: nil)
        
    }
    
    @IBAction func searchAction(_ sender: AnyObject) {
        
        viewModel.applyFilter(query: searchBarTextField.text ?? "")
        
    }
    
}

extension UserSearchViewController : UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        
        return true
    }
    
}
