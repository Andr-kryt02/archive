//
//  UserSearchResultController.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/25/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

import RxDataSources
import RxSwift
import RxCocoa

class UserSearchResultController : UIViewController, ViewController {
    
    var viewModel: UserSearchResultsViewModel!
    
    @IBOutlet weak var tableView: UITableView!
    
    let dataSource: RxTableViewSectionedAnimatedDataSource<AnimatableSectionModel<String, User>> = RxTableViewSectionedAnimatedDataSource()
    
    override func loadView() {
        super.loadView()
        
        tableView.register(R.nib.userSearchResultCell)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: " ", style: .plain, target: nil, action: nil)
        
        tableView.delegate = nil
        tableView.dataSource = nil
        
        viewModel.providerViewModel.pageTrigger.value =
            tableView!.rxex_simpleBottomShownTrigger()
        
        dataSource.configureCell = { [unowned self] (dataSource, tableView, indexPath, item: User) in

            let cell = tableView.dequeueReusableCell(withIdentifier: R.reuseIdentifier.userTableCell,
                                                                     for: indexPath)!

            cell.configureWithUser(user: item)
            cell.delegate = self
            
            return cell
        }
        
        
        viewModel.displayData
            .drive(tableView.rx.items(dataSource: dataSource))
            .addDisposableTo(rx_disposeBag)
     
        tableView.rx.modelSelected(User.self)
            .asDriver()
            .drive(onNext: { [unowned self] (selectedUser: User) in
                
                let controller = R.storyboard.user.userProfileViewController()!
                
                let viewModel = UserProfileViewModel(handler: controller,
                                                     user: selectedUser)
                controller.viewModel = viewModel
                self.navigationController?.pushViewController(controller,
                                                              animated: true)
            })
            .addDisposableTo(rx_disposeBag)
        
        ////empty data
        tableView.bindEmptyStateTo = viewModel.showsEmptyState
        
    }
    
    @IBAction func filterTapped(_ sender: AnyObject) {
        
        let controller = R.storyboard.search.filterViewController()!
        
        var filterViewModel = viewModel.filterViewModel
        filterViewModel.handler = controller
        
        controller.viewModel = filterViewModel
        
        controller.modalPresentationStyle = .custom
        controller.transitioningDelegate = controller
        
        self.present(controller, animated: true, completion: nil)
    }
    
}

extension UserSearchResultController : SearchResultCellDelegate {
    
    func chatButtonTapped(cell: UserSearchResultCell) {
        let ip = tableView.indexPath(for: cell)!
        
        let controller = R.storyboard.chats.chatContainerViewController()!
        controller.viewModel = viewModel.chatViewModelForItem(at: ip, for: controller)
        
        navigationController?.pushViewController(controller, animated: true)
    }
    
}

