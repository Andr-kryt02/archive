//
//  FilterViewController.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/22/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

class FilterViewController : UIViewController, ViewController{
    
    var viewModel : FilterViewModel!
   
    var reverse: Bool = false
    
    @IBAction func chooseAgeRange(_ sender: NMRangeSlider) {
        
        self.viewModel.setAgeRange(from : sender.lowerValue, to: sender.upperValue)
        
    }
    
    
    @IBAction func enterLocation(_ sender: CampfiireTextField) {
       
        self.viewModel.setLocation(location: locationTextField.text ?? "")
        
    }
    
    @IBAction func chooseGenderSegment(_ sender: UISegmentedControl) {
        
        self.viewModel.setGender(selectedIndex: sender.selectedSegmentIndex)
        
        
    }
    
    @IBOutlet weak var locationTextField: CampfiireTextField! {
        didSet {
            LocationAccessoryView.setUp(for: locationTextField)
        }
    }
    
    @IBOutlet weak var genderSegments: UISegmentedControl!
    
    @IBOutlet weak var rightPointer: UILabel!
    @IBOutlet weak var leftPointer: UILabel!
    @IBOutlet weak var rangeSlider: NMRangeSlider! {
     
        didSet {
            
            rangeSlider.minimumRange = viewModel.minimumRange
            rangeSlider.minimumValue = viewModel.minimumValue
            rangeSlider.maximumValue = viewModel.maximumValue
            rangeSlider.stepValue = viewModel.stepValue
            
            rangeSlider.lowerHandleImageNormal = R.image.handle()!
            rangeSlider.lowerHandleImageHighlighted = R.image.handle()!
            rangeSlider.upperHandleImageNormal = R.image.handle()!
            rangeSlider.upperHandleImageHighlighted = R.image.handle()!
            
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //view.tapToDismissKeyboard()
        view.keyboardAvoidingUIView(includeTapToDismiss: true)
        ////bindings
        viewModel.location
            .distinctUntilChanged()
            .bindTo(locationTextField.rx.text)
            .addDisposableTo(rx_disposeBag)
        
        viewModel.genderIndex
            .distinctUntilChanged()
            .bindTo(genderSegments.rx.value)
            .addDisposableTo(rx_disposeBag)
        
        viewModel.ageRange
            .distinctUntilChanged { $0.0 == $1.0 && $0.1 == $1.1 }
            .subscribe(onNext: { [unowned self] (from, to) in
                self.rangeSlider.upperValue = to
                self.rangeSlider.lowerValue = from
            })
            .addDisposableTo(rx_disposeBag)
        
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        var offset : CGFloat = 0
        
        if (self.rangeSlider.upperValue - self.rangeSlider.lowerValue ) <= 5 {
            offset = 9
        }
        
        let lowerCenter = CGPoint(x:
            (rangeSlider.lowerCenter.x + rangeSlider.frame.origin.x - offset),
                                  y:
            (rangeSlider.center.y - 30.0))
        
        let upperCenter = CGPoint(x:
            (rangeSlider.upperCenter.x + rangeSlider.frame.origin.x + offset),
                                  y:
            (rangeSlider.center.y - 30.0))
        
        rightPointer.center = upperCenter;
        rightPointer.text = String(Int(self.rangeSlider.upperValue))
        
        //rangeSlider.lowerTouchEdgeInsets = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
        //rangeSlider.upperTouchEdgeInsets = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)

        leftPointer.center = lowerCenter;
        leftPointer.text = String(Int(self.rangeSlider.lowerValue))
    }
    
    
    @IBAction func dismi(_ sender: AnyObject) {
        viewModel.approveFilters()
        self.dismiss(animated: true, completion:  nil)
    }
    
    @IBAction func updateLabels(_ sender: AnyObject) {
        self.view.setNeedsLayout()
    }
   
}

extension FilterViewController: UITextFieldDelegate {
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.resignFirstResponder()
    }
    
}

extension FilterViewController : UIViewControllerTransitioningDelegate, UIViewControllerAnimatedTransitioning {
    
    func animationController(forPresented presented: UIViewController,
                             presenting: UIViewController,
                             source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
   
        return self
    }
    

    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        
        
       
        return self
    }

    func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?) -> TimeInterval {
        
        return 0.5
    }
    
    func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        let toViewController = transitionContext.viewController(forKey: UITransitionContextViewControllerKey.to)!
        if(toViewController.isBeingPresented) {
            self.animatePresentation(transitionContext : transitionContext);
        } else {
            self.animateDismissal(transitionContext :transitionContext);
        }
       
 }
    
    
    private func animatePresentation(transitionContext : UIViewControllerContextTransitioning) {
    
        let toViewController = transitionContext.viewController(forKey: UITransitionContextViewControllerKey.to)!
        let fromViewController = transitionContext.viewController(forKey: UITransitionContextViewControllerKey.from)!
        let containerView = transitionContext.containerView
        
        toViewController.view.frame = CGRect(x: 0, y: 0, width: containerView.frame.size.width,
                                             height: 500)
        fromViewController.view.frame = CGRect(x: 0, y: 0, width: containerView.frame.size.width,
                                               height: containerView.frame.size.height)

        containerView.addSubview(toViewController.view)
        toViewController.view.transform = CGAffineTransform(translationX: 0,
                                                            y: (-containerView.frame.size.height));

        let duration: TimeInterval = 0.4
        
        UIView.animate(withDuration: duration,
                       delay: 0,
                       options: .curveEaseOut,
                       animations: {
                            toViewController.view.transform = CGAffineTransform.identity
                      
        }, completion: { _ in transitionContext.completeTransition(true) })

    }
    
    private func animateDismissal(transitionContext : UIViewControllerContextTransitioning) {
    
        let source =  transitionContext.viewController(forKey: UITransitionContextViewControllerKey.from)!
        let destination = transitionContext.viewController(forKey: UITransitionContextViewControllerKey.to)!;
        let container = transitionContext.containerView;
        
        destination.view.frame =  container.bounds;
        source.view.frame.origin.y = -container.frame.size.height
        
        // Move destination view below source view
        destination.view.frame = (self.presentingViewController?.view.frame)!;
        
        //destination.beginAppearanceTransition(true, animated: true);
        source.view.transform = CGAffineTransform(translationX: 0,
                                                  y: (container.frame.size.height));

        let duration: TimeInterval = 0.4
        
        UIView.animate(withDuration: duration,
                       delay: 0,
                       options: .curveEaseIn,
                       animations: {
                        
                    source.view.transform = CGAffineTransform.identity
                        
        }, completion: { _ in transitionContext.completeTransition(true) })
        
        
    }
}

