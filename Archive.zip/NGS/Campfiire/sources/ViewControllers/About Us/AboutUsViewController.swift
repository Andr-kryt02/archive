//
//  AboutUsViewController.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 02.11.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import MessageUI


class AboutUsViewController : UIViewController, ViewController, MFMailComposeViewControllerDelegate {
    
    lazy var viewModel: AboutUsViewModel! = AboutUsViewModel(handler: self)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
    @IBAction func contactAdmin(_ sender: Any) {
        
        let mailComposeViewController = configuredMailComposeViewController()
        if MFMailComposeViewController.canSendMail() {
            self.present(mailComposeViewController, animated: true, completion: nil)
        } else {
            self.showSendMailErrorAlert()
        }
    }
    
    func configuredMailComposeViewController() -> MFMailComposeViewController {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self
        mailComposerVC.setToRecipients(["gorobchenko.anna@gmail.com"])
        mailComposerVC.setSubject("Sending you an in-app e-mail...")
        mailComposerVC.setMessageBody("Sending e-mail in-app is not so bad!", isHTML: false)
    
        return mailComposerVC
    }
    
    func showSuccess () {
    
        let sendMailSuccessAlertController = UIAlertController(title: "Email sent", message: "", preferredStyle: .alert)
        
        let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        sendMailSuccessAlertController.addAction(defaultAction)
        
        present(sendMailSuccessAlertController, animated: true, completion: nil)
       
    }
    
    func showSendMailErrorAlert() {
        
        let sendMailErrorAlertController = UIAlertController(title: "Could Not Send Email", message: "Your device could not send e-mail.  Please check e-mail configuration and try again.", preferredStyle: .alert)
        
        let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        sendMailErrorAlertController.addAction(defaultAction)
        
        present(sendMailErrorAlertController, animated: true, completion: nil)
        
        
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        switch result {
            
        case MFMailComposeResult.sent: showSuccess()
        case MFMailComposeResult.failed: showSendMailErrorAlert()
        default : controller.dismiss(animated: true, completion: nil)
            controller.dismiss(animated: true, completion: nil)
            
        }
        
        
    }

}
