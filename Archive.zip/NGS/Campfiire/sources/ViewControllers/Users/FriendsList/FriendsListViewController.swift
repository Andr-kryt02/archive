//
//  FriendsListViewController.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/31/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

import RxDataSources
import RxSwift
import RxCocoa

class FriendsListViewController: UIViewController, ViewController {
    
    lazy var viewModel: FriendsListViewModel! = FriendsListViewModel(handler: self)
    
    @IBOutlet var searchBarHideConstraint: NSLayoutConstraint!
    @IBOutlet var tableView: UITableView!
    @IBOutlet var searchBar: UISearchBar!
    
    let dataSource: RxTableViewSectionedAnimatedDataSource<AnimatableSectionModel<String, FriendListTableItem>> = RxTableViewSectionedAnimatedDataSource()
    
    ///user table cell
    ///FriendRequestCell
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dataSource.configureCell = { [unowned self] (dataSource, tableView, indexPath, item) in
            
            switch item {
                
            case .friend(let user):
                let cell = tableView.dequeueReusableCell(withIdentifier: R.reuseIdentifier.userTableCell,
                                                         for: indexPath)!
                
                cell.configureWithUser(user: user)
                
                return cell
                
            case .request(let user):
                
                let cell = tableView.dequeueReusableCell(withIdentifier: R.reuseIdentifier.friendRequestCell,
                                                         for: indexPath)!
                 
                cell.delegate = self
                cell.configureWithUser(user: user)
                
                return cell
            }
            
        }
        
        dataSource.canEditRowAtIndexPath = { [unowned self] (_, ip) -> Bool in
            return self.viewModel.canEditItem(at: ip)
        }
        
        ////select friend
        tableView.rx.modelSelected(FriendListTableItem.self)
            .asDriver()
            .drive(onNext: { [unowned self] (selectedModel: FriendListTableItem) in
                
                switch selectedModel {
                    
                case .friend(let user):
                    
                    let controller = R.storyboard.user.userProfileViewController()!
                    
                    let viewModel = UserProfileViewModel(handler: controller,
                                                         user: user)
                    controller.viewModel = viewModel
                    self.navigationController?.pushViewController(controller,
                                                                  animated: true)
                    
                    
                case .request(_):
                    break ///nothing so far
                    
                }
                
                
            })
            .addDisposableTo(rx_disposeBag)
        
        ////remove friend
        tableView.rx.itemDeleted.asDriver()
            .drive(onNext: { [unowned self] (ip) in
                self.viewModel.removeFriend(at: ip)
            })
            .addDisposableTo(rx_disposeBag)

        ////bind friend list
        viewModel.datasource
            .drive(tableView.rx.items(dataSource: dataSource))
            .addDisposableTo(rx_disposeBag)
    
        ////search bar
        viewModel.searchBarHidden.asObservable()
            .do(onNext: { [unowned self] (hidden) in
                let _ = hidden ?
                    self.searchBar.resignFirstResponder() :
                    self.searchBar.becomeFirstResponder()
            })
            .map { $0 ? 44 : 0 }
            .skip(1)
            .subscribe(onNext: { [unowned self] (value) in
                self.searchBarHideConstraint.constant = CGFloat(value)
                UIView.animate(withDuration: 0.3) {
                    self.view.layoutIfNeeded()
                }
            })
            .addDisposableTo(rx_disposeBag)
     
        viewModel.searchBarHidden.asObservable()
            .map { !$0 }
            .bindTo(searchBar.rx.isUserInteractionEnabled)
            .addDisposableTo(rx_disposeBag)
        
        ///empty state
        tableView.bindEmptyStateTo = viewModel.showsEmptyState
        
    }
    
}

extension FriendsListViewController : FriendRequestCellDelegate, UISearchBarDelegate {
    
    func cellDidRejectRequest(cell: FriendRequestCell) {
        viewModel.rejectRequest(at: tableView.indexPath(for: cell)! )
    }
    
    func cellDidAcceptRequest(cell: FriendRequestCell) {
        viewModel.acceptRequest(at: tableView.indexPath(for: cell)! )
    }
    
    @IBAction func searchClickAction(_ sender: Any) {
        viewModel.switchSearchBarStatus()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        viewModel.searchQueryChanged(query: searchText)
    }
    
}

