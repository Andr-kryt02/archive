//
//  UserProfileViewController.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/18/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import RxSwift
import RxDataSources
import TOCropViewController

class UserProfileViewController: UIViewController, ViewController {
    
    var viewModel: UserProfileViewModel!
    
    let dataSource: RxTableViewSectionedAnimatedDataSource<AnimatableSectionModel<String, TableItemViewModel>> = RxTableViewSectionedAnimatedDataSource()
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet var editBarButtonItem: UIBarButtonItem!
    @IBOutlet var logoutBarButton: UIBarButtonItem!
    @IBOutlet var saveBarButtonItem: UIBarButtonItem!
    @IBOutlet var addFriendButtonItem: UIBarButtonItem!
    @IBOutlet var removeFriendButton: UIBarButtonItem!
    @IBOutlet var discardBarButtonItem: UIBarButtonItem!
    @IBOutlet var messageBarButtonItem: UIBarButtonItem!
    var leftBarButtonItem: UIBarButtonItem! {
        
        if let first = self.navigationController?.viewControllers.first,
            first === self {
            return (navigationController! as! AppNavigationController).drawerButton
        }
        else {
            return UIBarButtonItem(image: R.image.backButton(),
                                   style: .plain,
                                   target: self,
                                   action: #selector(UserProfileViewController.pop))
        }
        
    }
    
    @IBOutlet weak var avatarImageVIew: UIImageView!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var ageButton: UIButton!
    @IBOutlet weak var genderButton: UIButton!
    
    
    override func loadView() {
        super.loadView()
        
        tableView.register(R.nib.tagCell)
        tableView.register(R.nib.traitCell)
        
        tableView.delegate = self
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        guard viewModel != nil else {
            fatalError("viewModel must be instantiated before use of viewController")
        }
        
        dataSource.configureCell = { [unowned self] (dataSource, tableView, indexPath, item) in
            
            switch item {
            case .tag(let tag):
                let cell: TagTableCell = tableView.dequeueReusableCell(withIdentifier: R.nib.tagCell.identifier,
                                                                       for: indexPath) as! TagTableCell
                
                cell.setViewModel(viewModel: tag,
                                  delegate: self)
             
                return cell
                
            case .trait(let trait):
                let cell: TraitTableCell = tableView.dequeueReusableCell(withIdentifier: R.nib.traitCell.identifier,
                                                                         for: indexPath) as! TraitTableCell
                
                cell.setViewModel(viewModel: trait)
                return cell
           
            }
            
        }
        
        viewModel.dataSource.asObservable()
            .bindTo(tableView.rx.items(dataSource: dataSource))
            .addDisposableTo(self.rx_disposeBag)
     
        viewModel.rightButtons.asObservable()
             .subscribe(onNext: { [unowned self] (buttons) in
                
                var barButtonItems: [UIBarButtonItem] = []
                
                if buttons.contains(.logout) { barButtonItems.append(self.logoutBarButton) }
                if buttons.contains(.edit) { barButtonItems.append(self.editBarButtonItem) }
                if buttons.contains(.apply) { barButtonItems.append(self.saveBarButtonItem) }
                if buttons.contains(.beFriend) { barButtonItems.append(self.addFriendButtonItem) }
                if buttons.contains(.removeFriend) { barButtonItems.append(self.removeFriendButton) }
                if buttons.contains(.text) { barButtonItems.append(self.messageBarButtonItem) }
                
                self.navigationItem.setRightBarButtonItems(barButtonItems, animated: true)
                
             })
            .addDisposableTo(rx_disposeBag)
        
        viewModel.leftButtons.asObservable()
            .subscribe(onNext: { [unowned self] (buttons) in
                
                var barButtonItems: [UIBarButtonItem] = []
                
                if buttons.contains(.back) { barButtonItems.append(self.leftBarButtonItem) }
                if buttons.contains(.discardChanges) { barButtonItems.append(self.discardBarButtonItem) }
                
                self.navigationItem.setLeftBarButtonItems(barButtonItems, animated: true)
                
            })
            .addDisposableTo(rx_disposeBag)
        
        viewModel.avatar
            .asDriver()
            .notNil()
            .drive(avatarImageVIew.rx.image(transitionType: kCATransitionFade))
            .addDisposableTo(rx_disposeBag)
        
        viewModel.editingMode
            .asDriver()
            .drive(onNext: { [unowned self] editingMode in
                self.nameTextField.isUserInteractionEnabled = editingMode
                self.ageButton.isUserInteractionEnabled = editingMode
                self.genderButton.isUserInteractionEnabled = editingMode
            })
            .addDisposableTo(rx_disposeBag)
        
        viewModel.name
            .asDriver()
            .drive(nameTextField.rx.text)
            .addDisposableTo(rx_disposeBag)
        
        viewModel.gender
            .asDriver()
            .drive(onNext: { [unowned self] gender in
                self.genderButton.setTitle(gender, for: .normal)
            })
            .addDisposableTo(rx_disposeBag)
        
        viewModel.birthday
            .asDriver()
            .drive(onNext: { [unowned self] years in
                self.ageButton.setTitle(years, for: .normal)
            })
            .addDisposableTo(rx_disposeBag)
        
        ////next screen filter
        viewModel.presentSearchFilter.asDriver()
            .notNil()
            .drive(onNext: { [unowned self] (filter) in
                
                let controller = R.storyboard.search.userSearchResultController()!
                
                let viewModel = UserSearchResultsViewModel(handler: controller,
                                                           searchFilter: filter)
                
                controller.viewModel = viewModel
                
                self.navigationController?.pushViewController(controller, animated: true)
                
            })
            .addDisposableTo(rx_disposeBag)
        
        ////ui setup
        
        tableView.backgroundColor = UIColor.clear
        tableView.keyboardAvoiding()
    }
    
    @IBAction func discardChanges(_ sender: Any) {
        view.endEditing(true)
        viewModel.dropChanges()
    }
    
    @IBAction func saveClicked(_ sender: AnyObject) {
        view.endEditing(true)
        viewModel.saveClicked()
    }
    
    @IBAction func editClicked(_ sender: AnyObject) {
        viewModel.editButtonClicked()
    }
    
    @IBAction func logoutClicked(_ sender: AnyObject) {
        viewModel.logout()
    }
    
    @IBAction func addFriendTapped(_ sender: Any) {
        viewModel.addFriendTapped()
    }
    
    @IBAction func removeFriend(_ sender: Any) {
        viewModel.removeFriendTapped()
    }
    
    @IBAction func chatButtonTapped(_ sender: Any) {
        let controller = R.storyboard.chats.chatContainerViewController()!
        controller.viewModel = viewModel.chatViewModel(for: controller)
        
        self.navigationController?.pushViewController(controller, animated: true)
    }
    
    @IBAction func avatrPictureTapped(_ sender: AnyObject) {
        viewModel.updateAvatarClicked(){[unowned self] image in
            
            let cropController : TOCropViewController = TOCropViewController(croppingStyle: .circular, image: image)
            cropController.delegate = self
            
            self.navigationController?.pushViewController(cropController, animated: true)
            
        }
    }
    
    @IBAction func changeGender(_ sender: AnyObject) {
        
        let dataSource = ["Gender", Gender.male.description, Gender.female.description]
        let initialIndex = dataSource.index(of: viewModel.gender.value) ?? 0
        
        ActionSheetMultipleStringPicker.show(withTitle: "Pick your gender", rows: [
            dataSource
            ], initialSelection: [ initialIndex ], doneBlock: { [unowned self]
                picker, values, indexes in
                
                let selectedIndex = values!.first! as! NSNumber
                
                let gender = Gender(rawValue: selectedIndex.intValue)
                
                self.viewModel.updateGenderTo(gender: gender)
                
            }, cancel: { _ in }, origin: sender)
    }
    
    @IBAction func changeAge(_ sender: AnyObject) {
        
        ActionSheetDatePicker.show(withTitle: "Pick your birthdate",
                                   datePickerMode: UIDatePickerMode.date,
                                   selectedDate: viewModel.birthDate,
                                   minimumDate: NSDate(year: 1900, month: 1, day: 1) as Date,
                                   maximumDate: NSDate().subtractingYears(18) as Date,
                                   doneBlock: { [unowned self] (_, date: Any?, _) -> Void in
                                    
                                        let d = date as! NSDate
                                    
                                      self.viewModel.updateAgeTo(date: d as Date)
                                  },
                                   cancel: { _ in },
                                   origin: self.view)
        
    }
    
}

extension UserProfileViewController : UITableViewDelegate, UITextFieldDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        viewModel.updateNameTo(newName: textField.text!)
        
        textField.resignFirstResponder()
    }
    
}

extension UserProfileViewController : TagCellDelegate {
    
    func closeClicked(cell: TagTableCell) {
        
        guard let indexPath = tableView.indexPath(for: cell) else {
            ////fast clickers might get here
            return
        }
        
        viewModel.removeClicked(at: indexPath)
        
    }
    
}

extension UserProfileViewController {
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        avatarImageVIew.layer.cornerRadius = avatarImageVIew.frame.size.width / 2
    }
    
    internal func pop () {
        let _ = navigationController?.popViewController(animated: true)
    }
    
}

extension UserProfileViewController : TOCropViewControllerDelegate {
    
    func cropViewController(_ cropViewController: TOCropViewController, didCropToCircularImage image: UIImage, with cropRect: CGRect, angle: Int) {
        
        viewModel.uploadingCroppedImage(image: image)
        
        let _ = self.navigationController?.popViewController(animated: true)

        
    }
}
