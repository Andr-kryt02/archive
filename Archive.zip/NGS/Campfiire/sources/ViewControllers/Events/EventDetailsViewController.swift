//
//  EventDetailsViewController.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/29/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

import RxSwift
import RxCocoa

class EventDetailsViewController: UIViewController, ViewController {
    
    
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var eventDescription: UITextView! {
        didSet {
            eventDescription.text = ""
        }
    }
    @IBOutlet weak var locationLabel: UILabel!
    
    var viewModel: EventDetailsViewModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewModel.eventDriver
            .map{$0.name}
            .drive(self.rx.title)
            .addDisposableTo(rx_disposeBag)
        
        viewModel.eventDriver
            .map{$0.bottomRightString}
            .drive(self.time.rx.text)
            .addDisposableTo(rx_disposeBag)
        
        viewModel.eventDriver
            .map{$0.upperRightString}
            .drive(self.date.rx.text)
            .addDisposableTo(rx_disposeBag)
        
        viewModel.eventDriver
            .map{$0.description}
            .drive(self.eventDescription.rx.text)
            .addDisposableTo(rx_disposeBag)
        
        viewModel.eventDriver
            .map{$0.location}
            .drive(self.locationLabel.rx.text)
            .addDisposableTo(rx_disposeBag)
        
        viewModel.eventDriver
            .flatMapLatest{ ImageRetreiver.imageForURLWithoutProgress(url : $0.backgroundImageURL) }
            .drive(image.rx.image(transitionType: kCATransitionFade))
            .addDisposableTo(rx_disposeBag)

    }
    
}
