    //
//  EventsViewController.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/29/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import FSCalendar

class EventsViewController: UIViewController, ViewController {
    
    lazy var viewModel: EventsViewModel! = EventsViewModel(handler: self)
    
    @IBOutlet var dataRepresentationButton: UIButton!
    @IBOutlet var calendarHeightConstraint: NSLayoutConstraint!
    
    @IBOutlet var calendar: FSCalendar! {
        didSet {
            calendar.today = nil
            calendar.register(FSCalendarCell.self, forCellReuseIdentifier: "calendarCell")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewModel.dataRepresentationButtonImage
            .drive(onNext: { [unowned self] (image) in
                self.dataRepresentationButton.setImage(image, for: .normal)
            })
            .addDisposableTo(rx_disposeBag)
        
        viewModel.showsCalendar.asDriver()
            .skip(1)
            .drive(onNext: { [unowned self] (showsCalendar) in
                
                self.calendarHeightConstraint.constant = showsCalendar ? self.calendar.frame.size.width * 0.6 : 0
                UIView.animate(withDuration: 0.3) {
                    self.calendar.alpha = showsCalendar ? 1 : 0
                    self.view.layoutIfNeeded()
                }
                
            })
            .addDisposableTo(rx_disposeBag)
        
        viewModel.highlightDates.asDriver()
            .drive(onNext: { [unowned self] (dates) in
                self.calendar.reloadData()
            })
            .addDisposableTo(rx_disposeBag)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "embed events feed" {
            
            let controller = segue.destination as! NewsFeedTableViewController
            
            controller.viewModel = viewModel.feedViewModel
            
        }
        
    }
    
}

extension EventsViewController : FSCalendarDelegate {
    
    @IBAction func dataRepresentationSwitchTapped(_ sender: Any) {
        
        viewModel.changeDataRepresentationStyle()
        
    }
    
    func calendar(_ calendar: FSCalendar,
                  didSelect date: Date) {
        viewModel.changeEventsDate(date: date)
    }
    
    func calendar(_ calendar: FSCalendar,
                  didDeselect date: Date,
                  at monthPosition: FSCalendarMonthPosition) {
        
        let maybeCell: FSCalendarCell? = calendar.cell(for: date, at: monthPosition)
        
        if let cell = maybeCell,
           viewModel.highlightDates.value.contains(date),
            monthPosition == .current {
            cell.titleLabel.textColor = UIColor.eventDateRed
            cell.titleLabel.font = UIFont.appLightItalicPrimaryFont(size: 13)
        }
    }
    
    func calendar(_ calendar: FSCalendar,
                  willDisplay cell: FSCalendarCell,
                  for date: Date,
                  at position: FSCalendarMonthPosition) {
        
        if viewModel.highlightDates.value.contains(date),
            position == .current {
            cell.titleLabel.textColor = UIColor.eventDateRed
            cell.titleLabel.font = UIFont.appLightItalicPrimaryFont(size: 13)
        }
        else {
            cell.titleLabel.textColor = UIColor.lightGray
            cell.titleLabel.font = calendar.appearance.subtitleFont
        }
        
    }
    
}
