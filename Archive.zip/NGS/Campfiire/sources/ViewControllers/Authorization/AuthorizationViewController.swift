//
//  AuthorizationViewController.swift
//  Night Life
//
//  Created by Vlad Soroka on 2/5/16.
//  Copyright © 2016 com.NightLife. All rights reserved.
//

import UIKit
import RxSwift
import TOCropViewController

class AuthorizationViewController : UIViewController, ViewController {
    
    @IBOutlet var keyboardHeightLayoutConstraint: NSLayoutConstraint?
    @IBOutlet var authView: AuthView!
    
    lazy var viewModel: AuthViewModel! = {
       
        let validator =
        RegistrationValidation(email: self.authView.emailTextField.rx.text.asObservable(),
                               password: self.authView.passwordTextField.rx.text.asObservable(),
                               confirmPassword: self.authView.confirmPasswordTextField.rx.text.asObservable(),
                               name: self.authView.nameTextField.rx.text.asObservable(),
                               location: self.authView.locationTextField.rx.text.asObservable(),
                               favoriteProduct: self.authView.favoriteProductTextField.rx.text.asObservable())
        
        
        return AuthViewModel(handler: self,
                             registrationValidator: validator)
        
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        authView.viewModel = viewModel.registerUserViewModel
     
#if DEBUG
        authView.emailLoginTextField.text = "email19@email.com"
        authView.passwordLoginSection.text = "password"
#endif
        
        viewModel.registerUserViewModel.avatar.asDriver()
            .notNil()
            .drive(onNext: {[unowned self] (image) in
                
                let cropController : TOCropViewController = TOCropViewController(croppingStyle: .circular, image: image)
                cropController.delegate = self
                
                self.navigationController?.pushViewController(cropController, animated: true)
                
            }).addDisposableTo(rx_disposeBag)
        
    }
}

extension AuthorizationViewController {
    
    @IBAction func facebookTapped(_ sender: AnyObject) {
        viewModel.facebookButtonTapped()
    }
    
    @IBAction func instagramTapped(_ sender: AnyObject) {
        viewModel.instagramButtonTapped()
    }
    
    @IBAction func googlePlusTapped(_ sender: AnyObject) {
        viewModel.googlePlusButtonTapped()
    }
    
    @IBAction func login(_ sender: AnyObject) {
        viewModel.login(email: authView.emailLoginTextField.text!,
                        password: authView.passwordLoginSection.text!)
    }
    
    
    @IBAction func createAccountTapped(_ sender: AnyObject) {
        
        viewModel.register(email: authView.emailTextField.text!,
                           password: authView.passwordTextField.text!,
                           name: authView.nameTextField.text!,
                           location: authView.locationTextField.text,
                           favoriteProduct: authView.favoriteProductTextField.text)
        
    }
    
    @IBAction func forgotPasswordTapped(_ sender: Any) {
        
        viewModel.forgotPassword()
        
    }
    
    @IBAction func signUpAvatarTapped(_ sender: Any) {
        viewModel.registerUserViewModel
            .updateAvatarClicked()
    }
    
}

extension AuthorizationViewController : TOCropViewControllerDelegate {
    
    func cropViewController(_ cropViewController: TOCropViewController, didCropToCircularImage image: UIImage, with cropRect: CGRect, angle: Int) {
        
        viewModel.registerUserViewModel
            .uploadingCroppedImage(image: image)
        
        let _ = self.navigationController?.popViewController(animated: true)

    }
}
