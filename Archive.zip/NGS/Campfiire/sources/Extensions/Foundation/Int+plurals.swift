//
//  Int+plurals.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/14/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

extension Int {
    
    ///Method returns countable string based on amount of number for given noun
    ///If self == 1 than it would return "1 apple"
    ///But if self == 3 => "3 apples"
    func countableString(withSingularNoun noun: String) -> String {
        
        if self == 1 {
            return "\(self) \(noun)"
        }
        
        return "\(self) \(noun)s"
        
    }
    
}
