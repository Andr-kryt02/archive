//
//  MKCoordinateRegion+Circular.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/11/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import MapKit

extension MKCoordinateRegion {
    
    var circularApproximation: CLCircularRegion {
        
        let area = self
        
        let center = area.center
        let span = area.span.latitudeDelta
        
        let locationLeft = CLLocation(latitude: area.center.latitude - span / 2,
                                      longitude: area.center.longitude - span / 2)
        let locationCenter = CLLocation(latitude: area.center.latitude,
                                        longitude: area.center.longitude)
        
        let region = CLCircularRegion(center: center,
                                      radius: locationLeft.distance(from: locationCenter),
                                      identifier: "")
        
        return region
    }
    
}
