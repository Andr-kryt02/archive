//
//  String+Empty.swift
//  Campfiire
//
//  Created by Vlad Soroka on 1/22/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

import Foundation

extension OptionalEquivalent where WrappedValueType == String {
    
    var isEmpty: Bool {
        
        if !self.isNotNil() { return true }
        
        return self.unwrap().lengthOfBytes(using: .utf8) == 0
        
    }
    
}
