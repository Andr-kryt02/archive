//
//  Date+Campfiire.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/1/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation


extension Date {
    
    var campfiireString: String {
        
        let setting = SettingsManager().timeFormat24.value
        
        let date = (self as NSDate)
        
        var formatStyle = setting ? "HH:mm" : "hh:mm a"
        let locale = Locale(identifier: "en_US")
        
        if !date.isToday() {
            formatStyle = "dd/MM/yyyy"
        }
        
        return date.formattedDate(withFormat: formatStyle,
                                  locale: locale) as String
        
    }
 
    var campfiireTime: String {
        let setting = SettingsManager().timeFormat24.value
        
        let date = (self as NSDate)
        
        let formatStyle = setting ? "HH:mm" : "hh:mm a"
        let locale = Locale(identifier: "en_US")
        
        return date.formattedDate(withFormat: formatStyle,
                                  locale: locale) as String
    }
    
}
