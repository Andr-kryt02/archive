//
//  UITableView+ScrollToBottom.h
//  Campfiire
//
//  Created by Vlad Soroka on 1/29/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableView (ScrollToBottom)

- (void)scrollToBottomAnimated:(BOOL)animated;

@end
