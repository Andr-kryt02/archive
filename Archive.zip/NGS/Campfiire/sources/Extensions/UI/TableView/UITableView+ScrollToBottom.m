//
//  UITableView+ScrollToBottom.m
//  Campfiire
//
//  Created by Vlad Soroka on 1/29/17.
//  Copyright © 2017 campfiire. All rights reserved.
//

#import "UITableView+ScrollToBottom.h"

@implementation UITableView (ScrollToBottom)

- (void)scrollToBottomAnimated:(BOOL)animated
{
    if ([self numberOfSections] == 0) {
        return;
    }
    
    NSIndexPath *lastCell = [NSIndexPath indexPathForItem:([self numberOfRowsInSection:0] - 1)
                                                inSection:0];
    [self scrollToIndexPath:lastCell animated:animated];
}


- (void)scrollToIndexPath:(NSIndexPath *)indexPath animated:(BOOL)animated
{
    if ([self numberOfSections] <= indexPath.section) {
        return;
    }
    
    NSInteger numberOfItems = [self numberOfRowsInSection:indexPath.section];
    if (numberOfItems == 0) {
        return;
    }
    
    CGFloat collectionViewContentHeight =  self.contentSize.height;
    BOOL isContentTooSmall = (collectionViewContentHeight < CGRectGetHeight(self.bounds));
    
    if (isContentTooSmall) {
        //  workaround for the first few messages not scrolling
        //  when the collection view content size is too small, `scrollToItemAtIndexPath:` doesn't work properly
        //  this seems to be a UIKit bug, see #256 on GitHub
        [self scrollRectToVisible:CGRectMake(0.0, collectionViewContentHeight - 1.0f, 1.0f, 1.0f)
                         animated:animated];
        return;
    }
    
    NSInteger item = MAX(MIN(indexPath.item, numberOfItems - 1), 0);
    indexPath = [NSIndexPath indexPathForItem:item inSection:0];
    
    //  workaround for really long messages not scrolling
    //  if last message is too long, use scroll position bottom for better appearance, else use top
    //  possibly a UIKit bug, see #480 on GitHub
    CGFloat cellHeight = [self.delegate tableView:self
                       heightForRowAtIndexPath:indexPath];
    CGFloat maxHeightForVisibleMessage = cellHeight
    - self.contentInset.top
    - self.contentInset.bottom;
    
    UITableViewScrollPosition scrollPosition = (cellHeight > maxHeightForVisibleMessage) ? UITableViewScrollPositionBottom : UITableViewScrollPositionTop;
    
    [self scrollToRowAtIndexPath:indexPath
                atScrollPosition:scrollPosition
                        animated:animated];
}

@end
