//
//  ScrollView+keyboard.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 03.11.16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
import UIKit
import RxCocoa
import RxSwift

extension UIScrollView {
    
    func keyboardAvoiding(includeTapToDismiss: Bool = true) {
        
        self.keyboardDismissMode = .onDrag
        
        NotificationCenter.default.rx.notification(Notification.Name.UIKeyboardWillShow)
            .subscribe(onNext: { [weak self] not in
                self?.keyboardWillShow(notification: not)
                
            }).addDisposableTo(rx_disposeBag)
        
        NotificationCenter.default.rx.notification(Notification.Name.UIKeyboardWillHide)
            .subscribe(onNext: { [weak self] _ in
                self?.keyboardWillHide()
                
            }).addDisposableTo(rx_disposeBag)
        
        if includeTapToDismiss {
            tapToDismissKeyboard()
        }
        
    }
    

    
    private func keyboardWillShow(notification : Notification){
        //give room at the bottom of the scroll view, so it doesn't cover up anything the user needs to tap
        var userInfo = notification.userInfo!
        var keyboardFrame:CGRect = (userInfo[UIKeyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        keyboardFrame = self.convert(keyboardFrame, from: nil)
        
        var contentInset:UIEdgeInsets = self.contentInset
        contentInset.bottom = keyboardFrame.size.height + 20
        self.contentInset = contentInset
    }
    
    
    private func keyboardWillHide(){
        let contentInset:UIEdgeInsets = UIEdgeInsets.zero
        self.contentInset = contentInset
    }

}

extension UIView {
    
    func tapToDismissKeyboard() {
        var target: UIView! = self
        while target.superview != nil { target = target.superview }
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self,
                                                                 action: #selector(UIScrollView.dismissKeyboard))
        target.addGestureRecognizer(tap)
        
    }
    
    func dismissKeyboard() {
        self.endEditing(true)
    }
    
}
