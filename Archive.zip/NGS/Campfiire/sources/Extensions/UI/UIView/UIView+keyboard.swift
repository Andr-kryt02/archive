//
//  UIView+keyboard.swift
//  Campfiire
//
//  Created by Anna Gorobchenko on 2016-12-26.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation
extension UIView {
    
    func keyboardAvoidingUIView(includeTapToDismiss: Bool = true) {
        
        
        NotificationCenter.default.rx.notification(Notification.Name.UIKeyboardWillShow)
            .subscribe(onNext: { [weak self] not in
                self?.keyboardWillShow(notification: not)
                
            }).addDisposableTo(rx_disposeBag)
        
        NotificationCenter.default.rx.notification(Notification.Name.UIKeyboardWillHide)
            .subscribe(onNext: { [weak self] not in
                self?.keyboardWillHide(notification: not)
                
            }).addDisposableTo(rx_disposeBag)
        
        if includeTapToDismiss {
            tapToDismissKeyboard()
        }
        
    }
    
    
    
    private func keyboardWillShow(notification : Notification){
        var userInfo = notification.userInfo!
        var keyboardFrame:CGRect = (userInfo[UIKeyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        keyboardFrame = self.convert(keyboardFrame, from: nil)
        
        let y = self.frame.origin.y - (keyboardFrame.size.height/3)
        
        UIView.animate(withDuration: 0.3, animations: {
        self.frame = CGRect(x: 0, y: y, width: self.frame.size.width, height: self.frame.size.height)
       })
    }
    
    
    private func keyboardWillHide(notification : Notification){
        var userInfo = notification.userInfo!
        let keyboardFrame:CGRect = (userInfo[UIKeyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        let y = self.frame.origin.y + (keyboardFrame.size.height/3)
        
        UIView.animate(withDuration: 0.4, animations: {
        self.frame = CGRect(x: 0, y: y, width: self.frame.size.width, height: self.frame.size.height)
        })
}

}





