//
//  UIView+ProgressIndicator.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/11/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import UIKit
import RxCocoa
import SnapKit

extension UIView {
    
    /**
     *  @discussion - setOnly property for binding Driver to indicateProgress property.
     */
    var bindIndicatorProgresTo: Driver<Bool> {
        get { fatalError("bindIndicatorProgresTo is setOnly property") }
        set {
            
            newValue.drive (onNext: { [unowned self] indicator in
                self.indicateProgress = indicator
            })
            .addDisposableTo(self.rx_disposeBag)
            
        }
    }
    
    /**
     * @discussion - you can also enable/disable animation manually
     */
    var indicateProgress : Bool {
        get {
            return self.progressView.isHidden
        }
        set {
            let pv = self.progressView
            
            UIView.animate(withDuration: 0.3) {
                pv.alpha = newValue ? 1 : 0
            }
            
        }
    }
}


extension UIView {

    ///not the best solution, though.
    ///On heavy layots recursive search for view with tag might be expensive
    fileprivate var progressViewHash: Int {
        return "com.campfiire.progressHash".hash
    }
    
    fileprivate var progressView: UIView {
    
        if let pv = self.subviews.filter({ $0.tag == self.progressViewHash }).first {
            return pv
        }
    
        
        let container = UIView()
        container.isUserInteractionEnabled = true
        container.alpha = 0;
        container.tag = self.progressViewHash;
        
        let dimmedView = UIView();
        dimmedView.backgroundColor = UIColor.black
        dimmedView.alpha = 0.5;
        
        let spinner = ProgressView()

        container.addSubview(dimmedView)
        container.addSubview(spinner)
        self.addSubview(container)
        
        if self is UIScrollView {
            self.positionOnScrollView(container: container,
                                      dimmedView: dimmedView,
                                      spinner: spinner)
        }
        else {
            self.positionOnStaticView(container: container,
                                      dimmedView: dimmedView,
                                      spinner: spinner)
        }
        
        return container
    }
 
    func positionOnScrollView(container: UIView,
                              dimmedView: UIView,
                              spinner: ProgressView) {
        
        guard let scrollView = self as? UIScrollView else {
            fatalError("self is not a scrollView subclass")
        }
        
        let _ =
        scrollView.rx.sentMessage(#selector(UIView.layoutSubviews))
            .subscribe(onNext: { [unowned sv = scrollView] (_) in
                
                sv.bringSubview(toFront: container)
                
                container.frame = CGRect(origin: sv.contentOffset, size: sv.frame.size)
                dimmedView.frame = container.bounds
                spinner.center = CGPoint(x: dimmedView.center.x,
                                         y: dimmedView.center.y - sv.contentInset.bottom / 2 )
                
        })
        
    }
    
    func positionOnStaticView(container: UIView,
                              dimmedView: UIView,
                              spinner: ProgressView) {
        spinner.snp.makeConstraints { make in
            make.center.equalTo(container)
        }
        
        dimmedView.snp.makeConstraints { make in
            make.edges.equalTo(container)
        }
        
        container.snp.makeConstraints { make in
            make.edges.equalTo(self)
        }

    }
    

    
}
