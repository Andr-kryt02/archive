//
//  UIView+FancyShape.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/14/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import UIKit

extension UIView {
    
    func applyShape(forSubview subview: UIView) {
        
        guard self.subviews.contains(subview) else {
            fatalError("Can't apply shape for view that's not in the subview Hierarchy")
        }
        
        if let mask = subview.layer.mask,
           mask.isMember(of: CAShapeLayer.self) {
            self.layer.mask = nil
        }
        
        if let layer = subview.layer.sublayers?.first,
            layer.isMember(of: CAShapeLayer.self) {
            layer.removeFromSuperlayer()
        }
        
        let h = subview.bounds.size.height
        let w = subview.bounds.size.width
        
        let dh:CGFloat = w / 7
        
        let beziePath = UIBezierPath()
        beziePath.move(to: CGPoint(x: 0,y: 0))
        beziePath.addLine(to: CGPoint(x: 0,y: h - dh))
        beziePath.addQuadCurve(to: CGPoint(x: w,y: h - dh),
                               controlPoint: CGPoint(x: w/2, y: h + dh))
        beziePath.addLine(to: CGPoint(x: w,y: 0))
        beziePath.close()
        
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = beziePath.cgPath
        subview.layer.mask = shapeLayer

        let containerLayer = CALayer()
        containerLayer.shadowRadius = 4
        containerLayer.shadowOffset = CGSize(width: 0,height: 2);
        containerLayer.shadowOpacity = 0.5;
        
        // add masked image layer into container layer so that it's shadowed
        containerLayer.addSublayer(subview.layer)
        
        // add container including masked image and shadow into view
        self.layer.addSublayer(containerLayer)
        
    }
    
}
