//
//  UIView+wiggle.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/13/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

extension UIView {
    
    func wiggle(isInward x: Bool) {
        
        let t: CGFloat = x ? 1 : -1
        let one: CGFloat = 1.0
        let dx: CGFloat = 0.05
        
        self.transform = CGAffineTransform(scaleX: one + dx * t ,
                                           y: one + dx * t)
        
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: [],
                       animations: {
                        self.transform = CGAffineTransform.identity
        },
                       completion: nil)
    }
    
}
