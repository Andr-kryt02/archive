//
//  UIColor+Additions.swift
//  Campfiire
//
//  Created by Vlad Soroka on 10/24/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

extension UIColor {
    
    static var tagSelected: UIColor {
        return UIColor(fromHex: 0xd7514c)
    }
    
    static var tagDeselected: UIColor {
        return UIColor(fromHex: 0x1f386d)
        
    }
    
    static var acceptanceGreen: UIColor {
        return UIColor(fromHex: 0x54a751)
    }
    
    static var backgroundBlack: UIColor {
        return UIColor(fromHex: 0x2c2c2c)
    }
    
    static var destructiveRed: UIColor {
        return UIColor(red: 201.0 / 255.0, green: 26.0 / 255.0, blue: 30.0 / 255.0, alpha: 1.0)
    }
    
    static var userTagRegular: UIColor {
        return UIColor(fromHex: 0x687497)
    }
    
    static var userStatusOnline: UIColor {
        return UIColor(red: 93, green: 171, blue: 90)
    
    }
    
    static var userStatusOffline: UIColor {
        return UIColor(red: 193, green: 27, blue: 31)
        
    }
    
    static var eventRedBackground: UIColor {
        return UIColor(fromHex: 0xbe4949)
    }
    
    static var photoPurpleBackground: UIColor {
        return UIColor(fromHex: 0x9d72b1)
    }
    
    
    static var calloutBrown: UIColor {
        return UIColor(fromHex: 0xa04401)
    }
    
    static var starIconOrangeTint: UIColor {
        return UIColor(fromHex: 0xFF7901)
    }
    
    static var eventDateRed: UIColor {
        return UIColor(fromHex: 0xbe4949)
    }
    
    ///comments
    
    static var hotspotCommentTopBar: UIColor {
        return UIColor(fromHex: 0xd8d8d8)
    }
    
    static var hotspotCommentTopBarFont: UIColor {
        return UIColor(fromHex: 0x2f3749)
    }
    
    static var campCommentTopBar: UIColor {
        return UIColor(fromHex: 0xe96e01)
    }
    
    ///chats
    
    static var othersChatBuble: UIColor {
        return UIColor(red: 229.0 / 255.0, green: 255.0 / 255.0, blue: 251.0 / 255.0, alpha: 1.0)
    }
    
    static var ownChatBubble: UIColor {
        return UIColor(red: 240.0 / 255.0, green: 240.0 / 255.0, blue: 255.0 / 255.0, alpha: 1.0)
    }
    
    static var chatTextColor: UIColor {
        return UIColor(fromHex: 0x262436)
    }
    
}
