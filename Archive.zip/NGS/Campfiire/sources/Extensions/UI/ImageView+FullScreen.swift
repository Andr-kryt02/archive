//
//  ImageView+FullScreen.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/25/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import NYTPhotoViewer
import RxSwift

extension UIImageView: NYTPhotosViewControllerDelegate {
    
    func enableFullScreenMode(in viewController:UIViewController) {
        enableFullScreenMode(in: viewController, disposeBag: rx_disposeBag)
    }
    
    func enableFullScreenMode(in viewController:UIViewController,
                              disposeBag: DisposeBag) {
        isUserInteractionEnabled = true
        let gr = UITapGestureRecognizer()
        self.addGestureRecognizer(gr)
        
        gr.rx.event.asDriver()
            .drive(onNext: { [unowned self,
                              weak vc = viewController] (_) in
                guard let image = self.image else { return; }
                
                let photosViewController = NYTPhotosViewController(photos: [image])
                photosViewController.delegate = self
                photosViewController.rightBarButtonItems = nil
                vc?.present(photosViewController, animated: true, completion: nil)
                
            }, onDisposed: { [unowned self] in
                self.removeGestureRecognizer(gr)
            })
            .addDisposableTo(disposeBag)
    }
    
    public func photosViewController(_ photosViewController: NYTPhotosViewController,
                                     referenceViewFor photo: NYTPhoto) -> UIView? {
        return self
    }
    
}

extension UIImage : NYTPhoto {
    
    public var image: UIImage? { return self }
    
    public var imageData: Data? { return nil }
    public var placeholderImage: UIImage? { return nil }
    public var attributedCaptionTitle: NSAttributedString? { return nil }
    public var attributedCaptionSummary: NSAttributedString? { return nil }
    public var attributedCaptionCredit: NSAttributedString? { return nil }

}
