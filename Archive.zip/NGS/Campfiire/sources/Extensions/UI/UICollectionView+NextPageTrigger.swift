//
//  UICollectionView+NextPageTrigger.swift
//  Night Life
//
//  Created by Vlad Soroka on 3/2/16.
//  Copyright © 2016 com.NightLife. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

typealias CollectionTuple = (collectionView: UICollectionView, cell: UICollectionViewCell, indexPath: NSIndexPath)

extension UICollectionView {
    
    func rxex_cellDisplayed () -> Observable<CollectionTuple> {
        
        let selector = #selector(UICollectionViewDelegate.collectionView(_:willDisplay:forItemAt:))
        
        return self.rx.delegate.methodInvoked(selector)
            .flatMap { (args: [Any]) -> Observable<CollectionTuple> in
                let c = args[0] as! UICollectionView
                let v = args[1] as! UICollectionViewCell
                let i = args[2] as! NSIndexPath
                
                let element = (c,v,i)
                
                return Observable.just( element )
        }
        
    }
}

extension UITableView {
    
    func rxex_simpleBottomShownTrigger() -> Observable<Void> {
        
        return self.rx.contentOffset
                .map{ [weak t = self] offset -> (CGFloat, UITableView?) in
                    return (offset.y, t)
                }
                .flatMapLatest { args -> Observable<Void> in
                    
                    guard let tableView = args.1 else { return Observable.empty() }
                    
                    ////TODO: |Vlad| tableView with autolayout provides poor expirience regarding contentSize calculation. So we need some more reliable way of finding out if we scrolled to long enough to triger update 
                    
                    let offset = args.0
                    let shouldTriger = offset + tableView.frame.size.height + 70 > tableView.contentSize.height
                    return shouldTriger ? Observable.just() : Observable.empty()
        }
        
    }
    
}
