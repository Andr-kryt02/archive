//
//  UITextView+Secure.swift
//  Campfiire
//
//  Created by Vlad Soroka on 12/3/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

extension UITextField {
    
    func enableSecureSwitch() {
        
        let b = UIButton(frame: CGRect(x: 0,
                                       y: 0,
                                       width: 30,
                                       height: 30))
        b.setImage(R.image.showpasswordIc()!, for: .normal)
        
        self.rightView = b
        self.rightViewMode = .always
        
        b.addTarget(self, action: #selector(UITextField.switchEntry), for: .touchUpInside)
    }
    
    func switchEntry() {
        
        guard let b = self.rightView as? UIButton else { return }
        
        self.isSecureTextEntry = !self.isSecureTextEntry
        b.setImage(self.isSecureTextEntry ? R.image.showpasswordIc()!
                                          : R.image.hidepasswordIc()!, for: .normal)
        
    }
    
}
