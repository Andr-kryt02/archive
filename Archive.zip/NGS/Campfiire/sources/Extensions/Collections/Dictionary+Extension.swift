//
//  Dictionary+Extension.swift
//  Campfiire
//
//  Created by Andrew Seregin on 11/4/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

extension Dictionary where Value : OptionalEquivalent {
    
    func nullKeyRemoval() -> Dictionary<Key, Value.WrappedValueType> {
        var dict: [Key: Value.WrappedValueType] = [:]
        
        for (key, value) in self {
            
            if value.isNotNil() {
                dict[key] = value.unwrap()
            }
            
        }
        
        return dict
        
    }
}
