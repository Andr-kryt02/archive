//
//  CampPageBuilder.swift
//  Campfiire
//
//  Created by Vlad Soroka on 11/29/16.
//  Copyright © 2016 campfiire. All rights reserved.
//

import Foundation

struct CampPageBuilder {
    
    static let postsPerPage = 5
    
    private let totalPosts: Int
    init(camp: Camp) {
        totalPosts = camp.totalComments
    }
    
    //// 1 comment = 1 page
    //// 4 comments = 1 page
    //// 6 comments = 2 pages
    /// 10 comments = 2 pages
    /// 0 comments = 1 page
    var pagesCount: Int {
        
        guard totalPosts > 0 else { return 1 }
        
        return (totalPosts - 1) / CampPageBuilder.postsPerPage + 1
        
    }
    
    func networkBatch(for pageNumber: Int) -> Batch? {
        
        guard pagesCount >= pageNumber,
              pagesCount > 0,
              totalPosts > 0 else { return nil }
        
        var limit = CampPageBuilder.postsPerPage
        if (pageNumber == pagesCount) { ///last batch is special
            limit = totalPosts - ((pagesCount - 1) * CampPageBuilder.postsPerPage) ///number of posts in last page
        }
        
        return Batch(offset: (pageNumber - 1) * CampPageBuilder.postsPerPage,
                     limit: limit)
    }
    
    ////fist page prev = nil
    ////last page next = nil
    ////pageNumber always equal to passed param
    ////page at 0 errors
    ////comments are to be filled
    func campPage(at pageNumber:Int, comments: [Comment]) -> CampPage {
        
        var page = CampPage()
        
        page.pageNumber = pageNumber
        if (pageNumber > 1) {
            page.previousPageNumber = pageNumber - 1
        }
        
        if (pageNumber < pagesCount) {
            page.nextPageNumber = pageNumber + 1
        }
            
        page.comments = comments
        
        return page
    }
    
    
}
